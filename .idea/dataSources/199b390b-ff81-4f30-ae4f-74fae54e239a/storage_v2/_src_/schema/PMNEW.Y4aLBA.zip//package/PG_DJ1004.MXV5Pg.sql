create package pg_dj1004 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/2 14:40:37
  -- Purpose :
  -- 查询入库台帐
  procedure getinputlist(a_begindate    date, --起始时间
                         a_enddate      date, --结束时间
                         a_plantcode    varchar2, --厂矿编码
                         a_departcode   varchar2, --部门编码
                         a_itype        varchar2, --物资分类
                         a_store_desc   varchar2, --库房描述
                         a_materialcode varchar2, --物资编码
                         a_materialname varchar2, --物资名称
                         a_etalon       varchar2, --规格
                         a_loc_desc     varchar2, --存放位置描述
                         a_userid       varchar2,
                         ret            out sys_refcursor);
end pg_dj1004;
/

