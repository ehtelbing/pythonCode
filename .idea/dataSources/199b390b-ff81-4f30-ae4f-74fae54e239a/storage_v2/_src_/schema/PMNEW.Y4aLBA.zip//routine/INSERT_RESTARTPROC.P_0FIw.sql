create PROCEDURE INSERT_RESTARTPROC(RET OUT VARCHAR2) IS
OUT_ORDERGUID VARCHAR2(50);
OUT_ENTERED_BY VARCHAR2(50);
OUT_SHORT_TXT VARCHAR2(500);
BEGIN
  /*DELETE FROM TABLE1_RESTART;
  FOR I IN (SELECT T.FLOW_CODE,
                   T.NEXT_SPR,
                   T.NEXT_PERSONCODE,
                   T.PROCESSKEY
                    FROM TABLE_RESTART T) LOOP
                    SELECT P.V_ORDERGUID INTO OUT_ORDERGUID FROM PM_WORKORDER P
                    WHERE P.V_ORDERID=I.FLOW_CODE;
                     SELECT P.V_ENTERED_BY INTO OUT_ENTERED_BY FROM PM_WORKORDER P
                    WHERE P.V_ORDERID=I.FLOW_CODE;
                     SELECT P.V_SHORT_TXT INTO OUT_SHORT_TXT FROM PM_WORKORDER P
                    WHERE P.V_ORDERID=I.FLOW_CODE;
     INSERT INTO TABLE1_RESTART(FLOW_CODE,
                                NEXT_SPR,
                                NEXT_PERSONCODE,
                                PROCESSKEY,
                                ORIGINATOR,
                                FLOW_BUSINESSKEY,
                                IDEA,
                                REMARK,
                                FLOW_YJ,
                                FLOW_TYPE)VALUES(I.FLOW_CODE,
                                I.NEXT_SPR,
                                I.NEXT_PERSONCODE,
                                I.PROCESSKEY,
                                OUT_ENTERED_BY,
                                OUT_ORDERGUID,
                                '请审批！',
                                OUT_SHORT_TXT,
                                '请审批！',
                                'WORK');
                                
  END LOOP;*/
  
  FOR I IN (SELECT T.FLOW_CODE,T.FLOW_BUSINESSKEY
                    FROM TABLE1_RESTART T) LOOP
                  IF I.FLOW_BUSINESSKEY IS NULL THEN
                  SELECT P.V_ORDERGUID INTO OUT_ORDERGUID FROM PM_WORKORDER P
                    WHERE P.V_ORDERID=I.FLOW_CODE;
                     SELECT P.V_ENTERED_BY INTO OUT_ENTERED_BY FROM PM_WORKORDER P
                    WHERE P.V_ORDERID=I.FLOW_CODE;
                     SELECT P.V_SHORT_TXT INTO OUT_SHORT_TXT FROM PM_WORKORDER P
                    WHERE P.V_ORDERID=I.FLOW_CODE;
                    
                    UPDATE TABLE1_RESTART T
                    SET T.FLOW_BUSINESSKEY=OUT_ORDERGUID,
                         ORIGINATOR=OUT_ENTERED_BY,
                        T.REMARK=OUT_SHORT_TXT
                        WHERE T.FLOW_CODE=I.FLOW_CODE;
                        END IF;
                        END LOOP;
  COMMIT;
  RET:='Success';
  EXCEPTION 
    WHEN OTHERS THEN 
      RET:='Fail';
END INSERT_RESTARTPROC;
/

