create package pg_oil12 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/7 8:31:03
  -- Purpose : 1.2 设备润滑部位管理（地址：JMM_AK/page/oil/1_2.jsp）

  --.查询和导出设备，调用过程pg_oil12.getinstequlist获取数据
  procedure getinstequlist(a_equtype    varchar2, --设备类型编码
                           a_plantcode  varchar2, --厂矿编码
                           a_departcode varchar2, --部门编码
                           a_equip_id   varchar2, --设备ID（设备编号）
                           a_equip_name varchar2, --设备名
                           ret          out sys_refcursor --返回数据集
                           );
  procedure getinstequlist_dd(a_equtype    varchar2, --设备类型编码
                              a_plantcode  varchar2, --厂矿编码
                              a_departcode varchar2, --部门编码
                              a_equip_id   varchar2, --设备ID（设备编号）
                              a_equip_name varchar2, --设备名
                              ret          out sys_refcursor --返回数据集
                              );
  --电机“设置”按钮，调用过程pg_oil12.setequ_no
  procedure setequ_no(a_equip_id varchar2, --设备ID（设备编号）
                      a_equip_no varchar2, --主机编号
                      ret_msg    out varchar2, --反馈信息
                      ret        out varchar2 --执行结果
                      );
  procedure nosetequ_no(a_equip_id varchar2, --设备ID（设备编号）
                        ret_msg    out varchar2, --反馈信息
                        ret        out varchar2 --执行结果
                        );
  --下方的人员表格调用过程pg_oil12.getequperson加载
  procedure getequperson(a_equip_id varchar2, --设备ID（设备编号）
                         ret        out sys_refcursor --返回数据集
                         );
  --单击该界面的保存按钮，调用过程pg_oil12.addequperson添加
  procedure addequperson(a_equip_id varchar2, --设备ID（设备编号）
                         a_userid   varchar2, --用户名
                         ret_msg    out varchar2, --反馈信息
                         ret        out varchar2 --执行结果
                         );
  --调用过程pg_oil12.deleteequperson删除选择的人员
  procedure deleteequperson(a_equip_id varchar2, --设备ID（设备编号）
                            a_userid   varchar2, --用户名
                            ret_msg    out varchar2, --反馈信息
                            ret        out varchar2 --执行结果
                            );
end pg_oil12;
/

