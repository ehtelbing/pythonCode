create package pg_dj601 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/8/10 13:56:08
  -- Purpose :
  -- 查询可用库存
  procedure getmatkc(a_plantcode    varchar2, --厂矿编码
                     a_departcode   varchar2, --部门编码
                     a_itype        varchar2, --物资分类
                     a_materialcode varchar2, --物资编号
                     a_materialname varchar2, --物资名称
                         a_etalon varchar2,--规格型号
                     ret            out sys_refcursor);
end pg_dj601;
/

