create package BODY PG_SY201010 is
  --氧化锌避雷器试验数据录入
  --1，查询
  procedure pro_sy201010_onedeatil(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select a.record_id,
             a.SY_LOC_DESC,
             a.sy_loc_code,
             a.sy_equ_id,
             a.sy_equ_name,
             a.sy_date,
             a.sy_weather,
             a.sy_temp,
             a.sy_reason,
             a.sy_verdict,
             b.yhx_type,
             b.yhx_kv,
             b.yhx_make,
             a.sy_resp_username, --负责人
             a.sy_resp_userid,
             a.sy_exa_userid,
             a.sy_exa_username, --审核人
             a.sy_recordid,
             a.sy_recordname, --记录人
             a.equtype_code, --设备种类
             a.equtype_name,
             sy_opuserid,
             sy_opusername,
             sy_jxuserid,
             sy_jxusername,
             a.make_date, --制造日期
             a.outplant_date --出厂日期
        from SY_RECORD_MAIN a
        left outer join SY_RE_YHX_MAIN b
          on a.record_id = b.record_id
       where a.record_id = recordcode_in;
  end;
  --1,添加
  procedure pro_sy201010_oneadd(usercode_in     varchar2, --登录人
                                username_in     varchar2, --登录人姓名
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿
                                departcode_in   varchar2, --部门
                                plantname_in    varchar2, --厂矿名称
                                departname_in   varchar2, --部门名称
                                sydate_in           DATE, --实验时间
                                syloccode_in        varchar2, --实验地点编码
                                sylocname_in        varchar2, --实验地点名称
                                syequcode_in        varchar2, --实验设备编码
                                syequname_in        varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN    VARCHAR2,
                                SYEQUTYPTNAME_IN    VARCHAR2,
                                SYWEATHER_in        varchar2, --天气
                                sytemp_in           number, --气温
                                syreason_in         varchar2, --实验原因
                                SYVERDICT_in        varchar2, --结论
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,
                                v_yhxtype        varchar2,
                                v_yhxkv          number,
                                v_yhxmake        varchar2,
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2) as
    p_recordcode   varchar2(36) := FUNC_NEW_GUID();
    p_itemtypedesc varchar2(100);
    p_itemdesc     varchar2(50);
    p_printurl     varchar2(200);
  begin
    savepoint s;
    select t.itemtype_desc
      into p_itemtypedesc
      from SY_ITEM_TYPE t
     where t.itemtype = itemtypecode_in;
    select d.item_name
      into p_itemdesc
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    select d.item_url
      into p_printurl
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    insert into SY_RECORD_MAIN
      (RECORD_ID,
       RECORD_DATE,
       SY_DATE,
       RECORD_USERID,
       RECORD_USERNAME,
       DEPARTCODE,
       DEPARTNAME,
       PLANTCODE,
       PLANTNAME,
       SY_LOC_CODE,
       SY_LOC_DESC,
       SY_EQU_ID,
       SY_EQU_NAME,
       SY_WEATHER,
       SY_TEMP,
       SY_URL,
       SY_REASON,
       SY_VERDICT,
       SY_RESP_USERID,
       SY_RESP_USERNAME,
       SY_EXA_USERID,
       SY_EXA_USERNAME,
       RECORD_STATUS,
       ITEM_CODE,
       ITEM_NAME,
       ITEMTYPE,
       ITEMTYPE_DESC,
       SUBMIT_DATE,
       SUBMIT_USERID,
       SUBMIT_USERNAME,
       sy_recordid,
       sy_recordname,
       EQUTYPE_CODE,
       EQUTYPE_NAME,
       sy_opuserid,
       sy_opusername,
       sy_jxuserid,
       sy_jxusername,
       make_date,
       outplant_date)
    values
      (p_recordcode,
       sysdate,
       sydate_in,
       usercode_in,
       username_in,
       departcode_in,
       departname_in,
       plantcode_in,
       plantname_in,
       syloccode_in,
       sylocname_in,
       syequcode_in,
       syequname_in,
       SYWEATHER_in,
       sytemp_in,
       p_printurl,
       syreason_in,
       SYVERDICT_in,
       SYRESPUSERNAME_code,
       SYRESPUSERNAME_in,
       SYEXAUSERNAME_code,
       SYEXAUSERNAME_in,
       '未提交',
       itemcode_in,
       p_itemdesc,
       itemtypecode_in,
       p_itemtypedesc,
       null,
       null,
       null,
       SYRECORDID_IN,
       SYRECORDNAME_IN,
       SYEQUTYPTCODE_IN,
       SYEQUTYPTNAME_IN,
       SY_OPUSERID_in,
       SY_OPUSERNAME_in,
       SY_JXUSERID_in,
       SY_JXUSERNAME_in,
       make_date_in,
       outplant_date_in);
    insert into SY_RE_YHX_MAIN
    values
      (p_recordcode, v_yhxtype, v_yhxkv, v_yhxmake);
    commit;
    ret := p_recordcode;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --1,更新
  procedure pro_sy201010_oneupdate(recordcode_in       varchar2,
                                   usercode_in         varchar2, --登录人
                                   username_in         varchar2, --登录人姓名
                                   sydate_in           DATE, --实验时间
                                   syloccode_in        varchar2, --实验地点编码
                                   sylocname_in        varchar2, --实验地点名称
                                   syequcode_in        varchar2, --实验设备编码
                                   syequname_in        varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN    VARCHAR2,
                                   SYEQUTYPTNAME_IN    VARCHAR2,
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温 12.3
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,
                                   v_yhxtype        varchar2,
                                   v_yhxkv          number,
                                   v_yhxmake        varchar2,
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2) as
  begin
    savepoint s;
    update SY_RECORD_MAIN a
       set RECORD_DATE      = sysdate,
           SY_DATE          = sydate_in,
           RECORD_USERID    = usercode_in,
           RECORD_USERNAME  = username_in,
           SY_LOC_CODE      = syloccode_in,
           SY_LOC_DESC      = sylocname_in,
           SY_EQU_ID        = syequcode_in,
           SY_EQU_NAME      = syequname_in,
           SY_WEATHER       = SYWEATHER_in,
           SY_TEMP          = sytemp_in,
           SY_REASON        = syreason_in,
           SY_VERDICT       = SYVERDICT_in,
           sy_resp_userid   = SYRESPUSERNAME_code,
           SY_RESP_USERNAME = SYRESPUSERNAME_in,
           sy_exa_userid    = SYEXAUSERNAME_code,
           SY_EXA_USERNAME  = SYEXAUSERNAME_in,
           a.sy_recordid    = SYRECORDID_IN,
           a.sy_recordname  = SYRECORDNAME_IN,
           a.equtype_code   = SYEQUTYPTCODE_IN,
           a.equtype_name   = SYEQUTYPTNAME_IN,
           a.sy_opuserid    = SY_OPUSERID_in,
           a.sy_opusername  = SY_OPUSERNAME_in,
           a.sy_jxuserid    = SY_JXUSERID_in,
           a.sy_jxusername  = SY_JXUSERNAME_in,
           a.make_date      = make_date_in,
           a.outplant_date  = outplant_date_in
     where RECORD_ID = recordcode_in;
    update SY_RE_YHX_MAIN a
       set a.yhx_type = v_yhxtype,
           a.yhx_kv   = v_yhxkv,
           a.yhx_make = v_yhxmake
     where a.record_id = recordcode_in;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2,查询
  procedure pro_sy201010_twodetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from SY_RE_YHX_JYDZ_MAIN a
       where a.record_id = recordcode_in;
  end;
  --2,添加
  procedure pro_sy201010_twoadd(recordcode_in varchar2, --记录ID
                                v_yqxs        VARCHAR2,
                                v_yqbh        VARCHAR2,
                                v_a1          varchar2,
                                v_a2          number,
                                v_a3          varchar2,
                                v_b1          varchar2,
                                v_b2          number,
                                v_b3          varchar2,
                                v_c1          varchar2,
                                v_c2          number,
                                v_c3          varchar2,
                                --v_opuser      varchar2, --操作人
                                -- v_recorduser  varchar2, --记录人
                                --v_jxuser varchar2, --接线人
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_YHX_JYDZ_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_a1,
       v_yqxs,
       v_yqbh,
       v_a2,
       v_a3,
       v_b1,
       v_b2,
       v_b3,
       v_c1,
       v_c2,
       v_c3,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2,更新
  procedure pro_sy201010_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2, --记录ID
                                   v_yqxs        VARCHAR2,
                                   v_yqbh        VARCHAR2,
                                   v_a1          varchar2,
                                   v_a2          number,
                                   v_a3          varchar2,
                                   v_b1          varchar2,
                                   v_b2          number,
                                   v_b3          varchar2,
                                   v_c1          varchar2,
                                   v_c2          number,
                                   v_c3          varchar2,
                                   --v_opuser      varchar2, --操作人
                                   -- v_recorduser  varchar2, --记录人
                                   --v_jxuser varchar2, --接线人
                                   ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_YHX_JYDZ_MAIN a
       set a.record_id = recordcode_in,
           a.yqxs      = v_yqxs,
           a.yqbh      = v_yqbh,
           a.a1        = v_a1,
           a.a2        = v_a2,
           a.a3        = v_a3,
           a.b1        = v_b1,
           a.b2        = v_b2,
           a.b3        = v_b3,
           a.c1        = v_c1,
           a.c2        = v_c2,
           a.c3        = v_c3
    --a.op_user   = v_opuser,
    ---a.record_user = v_recorduser,
    --a.jx_user = v_jxuser
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3,查询
  procedure pro_sy201010_threedetail(recordcode_in varchar2,
                                     v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from SY_RE_YHX_ZLXL_MAIN a
       where a.record_id = recordcode_in;
  end;
  --3,添加
  procedure pro_sy201010_threeadd(recordcode_in varchar2,
                                  v_yqxs        VARCHAR2,
                                  v_yqbh        VARCHAR2,
                                  v_a1          number,
                                  v_a2          number,
                                  v_a3          number,
                                  v_a4          varchar2,
                                  v_b1          number,
                                  v_b2          number,
                                  v_b3          number,
                                  v_b4          varchar2,
                                  v_c1          number,
                                  v_c2          number,
                                  v_c3          number,
                                  v_c4          varchar2,
                                  --v_opuser      varchar2,
                                  --v_recorduser  varchar2,
                                  -- v_jxuser varchar2,
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_YHX_ZLXL_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_yqxs,
       v_yqbh,
       v_a1,
       v_a2,
       v_a3,
       v_a4,
       v_b1,
       v_b2,
       v_b3,
       v_b4,
       v_c1,
       v_c2,
       v_c3,
       v_c4,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3,更新
  procedure pro_sy201010_threeupdate(v_id          varchar2,
                                     recordcode_in varchar2,
                                     v_yqxs        VARCHAR2,
                                     v_yqbh        VARCHAR2,
                                     v_a1          number,
                                     v_a2          number,
                                     v_a3          number,
                                     v_a4          varchar2,
                                     v_b1          number,
                                     v_b2          number,
                                     v_b3          number,
                                     v_b4          varchar2,
                                     v_c1          number,
                                     v_c2          number,
                                     v_c3          number,
                                     v_c4          varchar2,
                                     --v_opuser      varchar2,
                                     -- v_recorduser  varchar2,
                                     --v_jxuser varchar2,
                                     ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_YHX_ZLXL_MAIN a
       set a.record_id = recordcode_in,
           a.yqxs      = v_yqxs,
           a.yqbh      = v_yqbh,
           a.a1        = v_a1,
           a.a2        = v_a2,
           a.a3        = v_a3,
           a.a4        = v_a4,
           a.b1        = v_b1,
           a.b2        = v_b2,
           a.b3        = v_b3,
           a.b4        = v_b4,
           a.c1        = v_c1,
           a.c2        = v_c2,
           a.c3        = v_c3,
           a.c4        = v_c4
    --a.op_user   = v_opuser,
    --a.record_user = v_recorduser,
    --a.jx_user = v_jxuser
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
end PG_SY201010;
/

