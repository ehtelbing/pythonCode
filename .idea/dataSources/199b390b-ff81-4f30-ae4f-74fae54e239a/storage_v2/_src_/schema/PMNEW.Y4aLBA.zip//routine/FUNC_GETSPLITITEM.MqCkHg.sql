create FUNCTION FUNC_GETSPLITITEM(MAIN_STR  VARCHAR2,
                                             SPLIT_STR VARCHAR2)
  RETURN SYS_REFCURSOR IS
  SPLIT_ITEM_CURSOR SYS_REFCURSOR;
BEGIN
  open SPLIT_ITEM_CURSOR for
    select regexp_substr(MAIN_STR, '[^' || SPLIT_STR || ']+', 1, level) item
      from dual
    connect by level <=
               length(MAIN_STR) - length(replace(MAIN_STR, SPLIT_STR)) + 1;
  return SPLIT_ITEM_CURSOR;
END FUNC_GETSPLITITEM;
/

