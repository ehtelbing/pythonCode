create procedure ADD_PRELOADWARE_COMPONENT(X_MODELNUMBER VARCHAR2,
                                      X_SEQUENCE    NUMBER,
                                      X_SPCODE      VARCHAR2,
                                      X_SPNAME      VARCHAR2,
                                      X_SIZE        VARCHAR2,
                                      X_UNITPRICE   NUMBER,
                                      X_NUMBER      NUMBER) is

  /*
  查询相应厂矿下的点检人员
  */
begin
  INSERT INTO BASE_PRELOADWARECOMPONENT
      (V_MODELNUMBER,
       I_SEQUENCE,
       V_SPCODE,
       V_SPNAME,
       V_SIZE,
       N_UNITPRICE,
       N_NUMBER)
    VALUES
      (X_MODELNUMBER,
       X_SEQUENCE,
       X_SPCODE,
       X_SPNAME,
       X_SIZE,
       X_UNITPRICE,
       X_NUMBER);
end ADD_PRELOADWARE_COMPONENT;
/

