create PROCEDURE droplist_lubmode(o_cursor OUT SYS_REFCURSOR) IS
BEGIN
  OPEN o_cursor FOR
    SELECT v_basecode, v_basename
      FROM pm_basedic
     WHERE v_basetype = 'PM_LUB/V_LUBMODECODE'
     ORDER BY i_orderid;
END droplist_lubmode;
/

