create PROCEDURE BASE_AQCS_EDIT(V_V_AQCS_CODE   IN VARCHAR2,
                                           V_V_AQCS_NAME   IN VARCHAR2,
                                           V_V_AQ_ZYSX     IN VARCHAR2,
                                           V_V_AQCS_DETAIL IN VARCHAR2,
                                           V_INFO          OUT VARCHAR2) IS
  /*安全措施新增与修改*/
  V_V_NUMBER VARCHAR2(50);
BEGIN

  SELECT COUNT(*)
    INTO V_V_NUMBER
    FROM PM_1917_AQCS T
   WHERE T.V_AQCS_CODE = V_V_AQCS_CODE;

  IF V_V_NUMBER = 0 THEN
    INSERT INTO PM_1917_AQCS
      (V_AQCS_CODE, V_AQCS_NAME, V_AQ_ZYSX, V_AQCS_DETAIL)
    VALUES
      (V_V_AQCS_CODE,
       V_V_AQCS_NAME,

       V_V_AQ_ZYSX,
       V_V_AQCS_DETAIL);

  ELSE
    UPDATE PM_1917_AQCS
       SET V_AQCS_NAME   = V_V_AQCS_NAME,
           V_AQ_ZYSX     = V_V_AQ_ZYSX,
           V_AQCS_DETAIL = V_V_AQCS_DETAIL
     WHERE V_AQCS_CODE = V_V_AQCS_CODE;
  END IF;

  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

END BASE_AQCS_EDIT;
/

