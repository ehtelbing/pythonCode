create package body pg_oil15 is

  -- 单击查询按钮，调用过程pg_oil15.getequtypelist表格数据。
  procedure getequtypelist(ret out sys_refcursor --返回数据集
                           ) is
  begin
    open ret for
      select t.type_code, --设备类型编号
             t.type_desc, --设备类型名
             t.type_remark, --设备类型备注
             t.type_status, --设备类型状态
             case t.type_status
               when '1' then
                '使用中'
               else
                '停用'
             end type_status_desc, --设备类型状态描述
             t.insertdate --录入时间
        from oil_equip_type t;
  end;
  --打开“新增设备类型”界面，单击“保存”按钮，调用过程pg_oil15.addequtype保存
  procedure addequtype(a_equtype        varchar2, --设备类型编码
                       a_equtype_name   varchar2, --设备类型名称
                       a_equtype_remark varchar2, --设备类型备注
                       ret_msg          out varchar2, --反馈信息
                       ret              out varchar2 --执行结果
                       ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equip_type t
     where t.type_code = a_equtype;
    if p_num = 0 then
      begin
        insert into oil_equip_type
          (type_code, type_desc, type_remark, type_status, insertdate)
        values
          (a_equtype, a_equtype_name, a_equtype_remark, '1', sysdate);
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '该设备类型编号已存在';
    end if;
  end;
  --原数据调用pg_oil15.getequtypedetail加载
  procedure getequtypedetail(a_equtype varchar2, --设备类型编码
                             ret       out sys_refcursor --返回数据集
                             ) is
  begin
    open ret for
      select t.type_code, --设备类型编号
             t.type_desc, --设备类型名
             t.type_remark, --设备类型备注
             t.type_status, --设备类型状态
             case t.type_status
               when '1' then
                '使用中'
               else
                '停用'
             end type_status_desc, --设备类型状态描述
             t.insertdate --录入时间
        from oil_equip_type t
       where t.type_code = a_equtype;
  end;
  --单击“保存”按钮，调用过程pg_oil15.updateequtype保存
  procedure updateequtype(a_equtype        varchar2, --设备类型编码
                          a_equtype_name   varchar2, --设备类型名称
                          a_equtype_remark varchar2, --设备类型备注
                          ret_msg          out varchar2, --反馈信息
                          ret              out varchar2 --执行结果
                          ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equip_type t
     where t.type_code = a_equtype;
    if p_num = 1 then
      begin
        update oil_equip_type
           set type_desc = a_equtype_name, type_remark = a_equtype_remark
         where type_code = a_equtype;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '该设备类型编号已不存在';
    end if;
  end;
  --状态变更，调用过程pg_oil15.setequtypestatus过程设置状态
  procedure setequtypestatus(a_equtype varchar2, --设备类型编码
                             ret_msg   out varchar2, --反馈信息
                             ret       out varchar2 --执行结果
                             ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equip_type t
     where t.type_code = a_equtype;
    if p_num = 1 then
      begin
        update oil_equip_type t
           set t.type_status =
               (case t.type_status
                 when '1' then
                  '0'
                 else
                  '1'
               end)
         where type_code = a_equtype;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '该设备类型编号已不存在';
    end if;
  end;
end pg_oil15;
/

