create package body pg_oil11 is

  --1.选择设备类型列表：pg_oil11.getequtypelist_able
  procedure getequtypelist_able(ret out sys_refcursor) is
  begin
    open ret for
      select '未分配' TYPE_CODE, --设备类型编码
             '未分配' TYPE_DESC --设备类型名称
        from dual
      union all
      select T.TYPE_CODE, --设备类型编码
             T.TYPE_DESC --设备类型名称
        from oil_equip_type t
       where t.type_status = '1';
  end;
  --2.查询，更新左侧主机名称表格，调用过程pg_oil11.get_equlist
  procedure get_equlist(a_equtype varchar2, --设备类型编码
                        ret       out sys_refcursor) is
  begin
    open ret for
      select e.equip_no, --主机编码
             e.equip_desc, --主机名称
             e.equ_level, --设备等级
             e.equip_remark --备注
        from oil_equips e
       where e.type_code like a_equtype
         and e.del_flag = '0'
       order by e.equip_desc;
  end;
  --新增规范：显示出新增规范界面，保存调用过程pg_oil11.addequ
  procedure addequ(a_equtype    varchar2, --设备类型编码
                   a_equip_no   varchar2, --主机编号
                   a_equip_name varchar2, --主机名
                   a_remark     varchar2, --备注
                   a_equ_level  varchar2, --设备等级
                   ret_msg      out varchar2, --反馈信息
                   ret          out varchar2 --执行结果
                   ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equips e
     where e.equip_no = a_equip_no;
    if p_num = 0 then
      begin
        insert into oil_equips
          (equip_no,
           equip_desc,
           type_code,
           equip_remark,
           del_flag,
           insertdate,
           equ_level)
        values
          (a_equip_no,
           a_equip_name,
           a_equtype,
           a_remark,
           '0',
           sysdate,
           a_equ_level);
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '该主机编号已被使用';
    end if;
  end;
  --删除调用过程pg_oil11.deleteequ
  procedure deleteequ(a_equip_no varchar2, --主机编号
                      ret_msg    out varchar2, --反馈信息
                      ret        out varchar2 --执行结果
                      ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equips e
     where e.equip_no = a_equip_no;
    if p_num = 1 then
      begin
        Update oil_equips set del_flag = '1' where equip_no = a_equip_no;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '该主机编号已不存在';
    end if;

  end;
  --原选中行数据调用过程pg_oil11.getequdetail获取
  procedure getequdetail(a_equip_no varchar2, --主机编号
                         ret        out sys_refcursor) is
  begin
    open ret for
      select e.equip_no, --主机编号
             e.equip_desc, --主机名
             e.type_code, -- 设备类型编号
             t.type_desc, -- 设备类型名
             e.equip_remark, --备注
             e.del_flag, --删除标识
             case e.del_flag
               when '1' then
                '已删除'
               else
                '未删除'
             end del_flag_desc, --删除标识描述
             e.insertdate, --录入时间
             e.equ_level
        from oil_equips e
        left outer join oil_equip_type t
          on t.type_code = e.type_code
       where e.equip_no = a_equip_no;
  end;
  --保存调用过程pg_oil11.updateequ
  procedure updateequ(a_equip_no   varchar2, --主机编号
                      a_equip_name varchar2, --主机名
                      a_equtype    varchar2, --设备类型编码
                      a_remark     varchar2, --备注
                      a_equ_level  varchar2,
                      ret_msg      out varchar2, --反馈信息
                      ret          out varchar2 --执行结果
                      ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equips e
     where e.equip_no = a_equip_no;
    if p_num = 1 then
      begin

        update oil_equips e
           set e.equip_desc   = a_equip_name,
               e.type_code    = a_equtype,
               e.equip_remark = a_remark,
               e.del_flag     = '0',
               e.insertdate   = sysdate,
               e.equ_level    = a_equ_level
         where e.equip_no = a_equip_no;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '该主机编号已不存在';
    end if;
  end;
  --点击“润滑规范”，更新右侧的部位表格，调用过程pg_oil11.getpartlist

  procedure getpartlist_select(a_equip_no  varchar2, --主机编号
                               a_mat_no    varchar2,
                               a_mat_desc  varchar2,
                               a_part_desc varchar2,
                               ret         out sys_refcursor) is
  begin
    open ret for
      select p.part_no, --部位编号
             p.part_desc, --部位名
             p.equip_no, --主机编号
             e.equip_desc,
             p.work_desc, --工况情况
             p.oil_type, --加油方式
             p.design_oil_desc, --设计油品名称
             p.summer_oil_desc, --夏季使用油品名称
             p.winter_oil_desc, --冬季使用油品名称
             p.current_oil_desc, --目前使用油品名称
             p.design_oil_code, --设计油品牌号
             p.summer_oil_code, --夏季油品牌号
             p.winter_oil_code, --冬季油品牌号
             p.current_oil_code, --目前油品牌号
             p.oil_etalon, --规范油品型号
             p.oil_qs, --产品标准
             --q.qs_id, --标准Id
             p.part_remark, --部位备注
             p.part_status, --部位状态
             case p.part_status
               when '1' then
                '正常使用'
               else
                '已停用'
             end part_status_desc, --部位状态描述
             p.insertdate, --修改时间
             p.order_desc, --排序描述
             p.del_flag, --删除标识
             case p.del_flag
               when '1' then
                '已删除'
               else
                '未删除'
             end del_flag_desc, --删除状态描述
             c.cycle_value || t.cycle_unit_desc oil_cycle, -- 加油周期
             p.part_level
        from oil_equip_parts p
        left outer join oil_equips e
          on e.equip_no = p.equip_no
        left outer join oil_equip_cycle c
          on p.part_no = c.part_no
        left outer join OIL_CYCLE_UNIT t
          on t.cycle_unit = c.cycle_unit
      --left outer join qs_main q on q.qs_code = p.oil_qs  and q.status = '1'
       where p.equip_no like a_equip_no
         and p.del_flag = '0'
         and lower(p.current_oil_code) like '%' || lower(a_mat_no) || '%'
         and lower(nvl(p.current_oil_desc, 'N/A')) like
             '%' || lower(a_mat_desc) || '%'
         and lower(p.part_desc) like '%' || lower(a_part_desc) || '%'
       order by p.part_no;
  end;
  procedure getpartlist(a_equip_no varchar2, --主机编号
                        a_mat_no   varchar2,
                        ret        out sys_refcursor) is
  begin
    pg_oil11.getpartlist_select(a_equip_no, a_mat_no, '%', '%', ret);
  end;
  --新增部位按钮，打开“新增部位”界面，保存调用过程pg_oil11.addpart
  procedure addpart(a_part_no          varchar2, --部位编号
                    a_part_desc        varchar2, --部位名
                    a_equip_no         varchar2, --主机编号
                    a_work_desc        varchar2, --工况情况
                    a_oil_type         varchar2, --加油方式
                    a_oil_etalon       varchar2, --规范油品型号
                    a_oil_qs           varchar2, --产品标准
                    a_part_remark      varchar2, --部位备注
                    a_design_oil_code  varchar2, --设计油品牌号
                    a_summer_oil_code  varchar2, --夏季油品牌号
                    a_winter_oil_code  varchar2, --冬季油品牌号
                    a_current_oil_code varchar2, --目前使用油品牌号
                    a_userid           varchar2,
                    a_ip               varchar2,
                    a_part_level       varchar2,
                    ret_msg            out varchar2, --反馈信息
                    ret                out varchar2 --执行结果
                    ) is
    p_num              number(2, 0) := 0;
    p_design_oil_desc  varchar2(200) := getmatdesc(a_design_oil_code);
    p_summer_oil_desc  varchar2(200) := getmatdesc(a_summer_oil_code);
    p_winter_oil_desc  varchar2(200) := getmatdesc(a_winter_oil_code);
    p_current_oil_desc varchar2(200) := getmatdesc(a_current_oil_code);
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equip_parts p
     where p.part_no = a_part_no;
    if p_num = 0 then
      begin
        savepoint s;
        insert into oil_equip_parts
          (part_no,
           part_desc,
           equip_no,
           work_desc,
           oil_type,
           design_oil_desc,
           summer_oil_desc,
           winter_oil_desc,
           current_oil_desc,
           oil_etalon,
           oil_qs,
           part_remark,
           part_status,
           insertdate,
           order_desc,
           del_flag,
           design_oil_code,
           summer_oil_code,
           winter_oil_code,
           current_oil_code,
           insert_userid,
           insert_username,
           insert_ip,
           part_level)
        values
          (a_part_no,
           a_part_desc,
           a_equip_no,
           a_work_desc,
           a_oil_type,
           p_design_oil_desc,
           p_summer_oil_desc,
           p_winter_oil_desc,
           p_current_oil_desc,
           a_oil_etalon,
           a_oil_qs,
           a_part_remark,
           '1',
           sysdate,
           null,
           '0',
           a_design_oil_code,
           a_summer_oil_code,
           a_winter_oil_code,
           a_current_oil_code,
           a_userid,
           func_wp_getusername(a_userid),
           a_ip,
           a_part_level);
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          rollback to s;
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '该部位编号已被使用';
    end if;
  end;
  --根据物料号获取物料名
  function getmatdesc(a_mat_no varchar2) return varchar2 is
    p_mat_desc varchar2(200);
  begin
    select m.mat_desc
      into p_mat_desc
      from mm_mats@namm.fjwz m
     where m.mat_no = a_mat_no;
    return p_mat_desc;
  exception
    when others then
      return null;
  end;
  --点击“删除选中的部位”，调用过程pg_oil11.deletepart
  procedure deletepart(a_part_no varchar2,
                       a_userid  varchar2,
                       a_ip      varchar2,
                       ret_msg   out varchar2, --反馈信息
                       ret       out varchar2 --执行结果
                       ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equip_parts p
     where p.part_no = a_part_no;
    if p_num = 1 then
      begin
        savepoint s;
        insert into oil_equip_parts_history
          (his_id,
           part_no,
           part_desc,
           equip_no,
           work_desc,
           oil_type,
           design_oil_desc,
           summer_oil_desc,
           winter_oil_desc,
           current_oil_desc,
           oil_etalon,
           oil_qs,
           part_remark,
           part_status,
           order_desc,
           del_flag,
           design_oil_code,
           summer_oil_code,
           winter_oil_code,
           current_oil_code,
           insertdate,
           insert_username,
           insert_userid,
           insert_ip)
          select func_run_guid(),
                 part_no,
                 part_desc,
                 equip_no,
                 work_desc,
                 oil_type,
                 design_oil_desc,
                 summer_oil_desc,
                 winter_oil_desc,
                 current_oil_desc,
                 oil_etalon,
                 oil_qs,
                 part_remark,
                 part_status,
                 order_desc,
                 del_flag,
                 design_oil_code,
                 summer_oil_code,
                 winter_oil_code,
                 current_oil_code,
                 insertdate,
                 insert_username,
                 insert_userid,
                 insert_ip
            from oil_equip_parts
           where part_no = a_part_no;

        update oil_equip_parts p
           set p.del_flag      = '1',
               insert_userid   = a_userid,
               insert_username = func_wp_getusername(a_userid),
               insert_ip       = a_ip,
               insertdate      = sysdate
         where p.part_no = a_part_no;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          rollback to s;
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret := '该部位编号不存在';
    end if;
  end;
  --部位详细信息调用pg_oil11.getpartdetail过程获取
  procedure getpartdetail(a_part_no varchar2, --部位编号
                          ret       out sys_refcursor) is
  begin
    open ret for
      select p.part_desc, --部位名
             p.equip_no, --主机编号
             p.work_desc, --工况情况
             p.oil_type, --加油方式
             p.design_oil_desc, --设计油品名称
             p.summer_oil_desc, --夏季使用油品名称
             p.winter_oil_desc, --冬季使用油品名称
             p.current_oil_desc, --目前使用油品名称
             p.design_oil_code, --设计油品牌号
             p.summer_oil_code, --夏季油品牌号
             p.winter_oil_code, --冬季油品牌号
             p.current_oil_code, --目前油品牌号
             p.oil_etalon, --规范油品型号
             p.oil_qs, --产品标准
             p.part_remark, --部位备注
             p.part_status, --部位状态
             case p.part_status
               when '1' then
                '正常使用'
               else
                '已停用'
             end part_status_desc, --部位状态描述
             p.insertdate, --修改时间
             p.order_desc, --排序描述
             p.del_flag, --删除标识
             case p.del_flag
               when '1' then
                '已删除'
               else
                '未删除'
             end del_flag_desc, --删除状态描述
             c.cycle_value || c.cycle_unit oil_cycle, -- 加油周期
             p.part_level
        from oil_equip_parts p
        left outer join oil_equip_cycle c
          on p.part_no = c.part_no
       where p.part_no = a_part_no;
  end;
  --其中部位编号只读，保存调用过程pg_oil11.updatepart
  procedure updatepart(a_part_no          varchar2, --部位编号
                       a_part_desc        varchar2, --部位名
                       a_equip_no         varchar2, --主机编号
                       a_work_desc        varchar2, --工况情况
                       a_oil_type         varchar2, --加油方式
                       a_oil_etalon       varchar2, --规范油品型号
                       a_oil_qs           varchar2, --产品标准
                       a_part_remark      varchar2, --部位备注
                       a_design_oil_code  varchar2, --设计油品牌号
                       a_summer_oil_code  varchar2, --夏季油品牌号
                       a_winter_oil_code  varchar2, --冬季油品牌号
                       a_current_oil_code varchar2, --目前使用油品牌号
                       a_userid           varchar2,
                       a_ip               varchar2,
                       a_part_level       varchar2,
                       ret_msg            out varchar2, --反馈信息
                       ret                out varchar2 --执行结果
                       ) is
    p_num              number(2, 0) := 0;
    p_design_oil_desc  varchar2(200) := getmatdesc(a_design_oil_code);
    p_summer_oil_desc  varchar2(200) := getmatdesc(a_summer_oil_code);
    p_winter_oil_desc  varchar2(200) := getmatdesc(a_winter_oil_code);
    p_current_oil_desc varchar2(200) := getmatdesc(a_current_oil_code);
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equip_parts p
     where p.part_no = a_part_no;
    if p_num = 1 then
      begin
        savepoint s;
        insert into oil_equip_parts_history
          (his_id,
           part_no,
           part_desc,
           equip_no,
           work_desc,
           oil_type,
           design_oil_desc,
           summer_oil_desc,
           winter_oil_desc,
           current_oil_desc,
           oil_etalon,
           oil_qs,
           part_remark,
           part_status,
           order_desc,
           del_flag,
           design_oil_code,
           summer_oil_code,
           winter_oil_code,
           current_oil_code,
           insertdate,
           insert_username,
           insert_userid,
           insert_ip,
           part_level)
          select func_run_guid(),
                 part_no,
                 part_desc,
                 equip_no,
                 work_desc,
                 oil_type,
                 design_oil_desc,
                 summer_oil_desc,
                 winter_oil_desc,
                 current_oil_desc,
                 oil_etalon,
                 oil_qs,
                 part_remark,
                 part_status,
                 order_desc,
                 del_flag,
                 design_oil_code,
                 summer_oil_code,
                 winter_oil_code,
                 current_oil_code,
                 insertdate,
                 insert_username,
                 insert_userid,
                 insert_ip,
                 part_level
            from oil_equip_parts
           where part_no = a_part_no;

        update oil_equip_parts
           set part_desc        = a_part_desc,
               equip_no         = a_equip_no,
               work_desc        = a_work_desc,
               oil_type         = a_oil_type,
               design_oil_desc  = p_design_oil_desc,
               summer_oil_desc  = p_summer_oil_desc,
               winter_oil_desc  = p_winter_oil_desc,
               current_oil_desc = p_current_oil_desc,
               oil_etalon       = a_oil_etalon,
               oil_qs           = a_oil_qs,
               part_remark      = a_part_remark,
               insertdate       = sysdate,
               design_oil_code  = a_design_oil_code,
               summer_oil_code  = a_summer_oil_code,
               winter_oil_code  = a_winter_oil_code,
               current_oil_code = a_current_oil_code,
               insert_userid    = a_userid,
               insert_username  = func_wp_getusername(a_userid),
               insert_ip        = a_ip,
               part_level       = a_part_level
         where part_no = a_part_no;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          rollback to s;
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret := '该部位编号不存在';
    end if;
  end;
  --原加油周期数据调用过程pg_oil11.getpart_oil获取
  procedure getpart_oil(a_part_no varchar2, --部位编号
                        ret       out sys_refcursor) is
  begin
    open ret for
      select c.cycle_type, --计算方式
             c.cycle_unit, --计算单位
             c.cycle_value, --周期值
             c.insert_amount, --单次加油量
             c.insert_unit --加油单位
        from oil_equip_cycle c
       where c.part_no = a_part_no;
  end;
  --保存调用pg_oil11.setpart_oil
  procedure setpart_oil(a_equip_no      varchar2, --主机编号
                        a_part_no       varchar2, --部位编号
                        a_cycle_type    varchar2, --计算方式
                        a_cycle_unit    varchar2, --计算单位
                        a_cycle_value   number, --周期值
                        a_insert_amount number, --单次加油量
                        a_insert_unit   varchar2, --加油单位
                        ret_msg         out varchar2, --反馈信息
                        ret             out varchar2 --执行结果
                        ) is
    p_num number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_num
      from oil_equip_cycle
     where part_no = a_part_no;
    if p_num = 0 then
      insert into oil_equip_cycle
        (id,
         equip_no,
         part_no,
         cycle_type,
         cycle_unit,
         cycle_value,
         insert_amount,
         insert_unit,
         del_flag,
         op_date)
      values
        (func_run_guid(),
         a_equip_no,
         a_part_no,
         a_cycle_type,
         a_cycle_unit,
         a_cycle_value,
         a_insert_amount,
         a_insert_unit,
         '0',
         sysdate);
    else
      update oil_equip_cycle
         set cycle_type    = a_cycle_type,
             cycle_unit    = a_cycle_unit,
             cycle_value   = a_cycle_value,
             insert_amount = a_insert_amount,
             insert_unit   = a_insert_unit,
             op_date       = sysdate
       where part_no = a_part_no;
    end if;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      rollback to s;
      ret_msg := '操作失败：' || sqlerrm;

  end;
  --计算方式选择列表调用pg_oil11.getmathtype
  procedure getmathtype(ret out sys_refcursor) is
  begin
    open ret for
      select t.cycle_type, --计算方式
             t.cycle_type_desc --计算方式描述
        from oil_cycle_type t
       where t.del_flag = '0';
  end;
  -- 计量单位选择列表，调用过程pg_oil11.getmathunit
  procedure getmathunit(a_cycle_type varchar2, --计算方式
                        ret          out sys_refcursor) is
  begin
    open ret for
      select u.cycle_unit, --计算单位
             u.cycle_unit_desc --计算单位描述
        from oil_cycle_unit u
       where u.cycle_type = a_cycle_type
         and u.del_flag = '0';
  end;
  --加油单位，调用过程pg_oil.getunit获取
  procedure getunit(ret out sys_refcursor) is
  begin
    open ret for
      select u.insert_unit, --加油单位
             u.insert_unit_desc --加油单位描述
        from oil_cycle_insert_unit u
       where u.del_flag = '0';
  end;
end pg_oil11;
/

