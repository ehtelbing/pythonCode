create procedure PM_03_JXMX_DATA_SEL(V_V_ORGCODE       IN VARCHAR2, --单位编码
                                                V_V_DEPTCODE      IN VARCHAR2, --作业区编码
                                                V_V_EQUTYPE       IN VARCHAR2, --设备类型编码
                                                V_V_EQUCODE       IN VARCHAR2, --设备名称编码
                                                V_V_EQUCHILD_CODE IN VARCHAR2, --子设备名称编码
                                                V_V_JXMX_NAME     IN VARCHAR2, --检修模型名称
                                                V_CURSOR          OUT SYS_REFCURSOR) is

  /*
  检修模型查询过程
  */
begin

  OPEN V_CURSOR FOR
    SELECT P.I_ID,
           P.V_MX_CODE,
           P.V_MX_NAME,
           P.V_GX_CODE,
           P.V_ORGCODE,
           P.V_DEPTCODE,
           P.V_EQUTYPE,
           P.V_EQUCODE,
           P.V_EQUCODE_CHILD,
           P.V_BZ,
           P.V_IN_DATE,
           P.V_IN_PER,
           D.V_JXGX_NR,
           D.V_JXGX_CODE,
           D.V_JXGX_NAME,
           e.v_equname
      FROM PM_1917_JXMX_DATA P
    INNER JOIN PM_1917_JXGX_DATA D ON P.V_GX_CODE = D.V_JXMX_CODE
    left join SAP_PM_EQU_P e on e.v_equcode=P.V_EQUCODE
     WHERE P.V_ORGCODE = V_V_ORGCODE
       AND P.V_DEPTCODE LIKE '%' || V_V_DEPTCODE || '%'
       AND P.V_EQUTYPE LIKE '%' || V_V_EQUTYPE || '%'
       AND P.V_EQUCODE LIKE '%' || V_V_EQUCODE || '%'
       AND P.V_EQUCODE_CHILD LIKE '%' || V_V_EQUCHILD_CODE || '%'
       AND P.V_MX_NAME LIKE '%' || V_V_JXMX_NAME || '%'
     ORDER BY TO_DATE(P.V_IN_DATE, 'yyyy-mm-dd') desc;

end PM_03_JXMX_DATA_SEL;
/

