create package pg_oil13 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/7 9:34:42
  -- Purpose : 1.3 润滑油脂物料设置（地址：JMM_AK/page/oil/1_3.jsp）

  -- 查询和导出Excel，调用过程pg_oil13.getmatlist，加载表格数据
  procedure getmatlist(a_mat_no   varchar2, --物料号
                       a_mat_desc varchar2, --物料名
                       ret        out sys_refcursor --返回结果集
                       );
  --删除选中物料，点击后，调用过程pg_oil13.deletemat
  procedure deletemat(a_mat_no varchar2, --物料号
                      ret_msg  out varchar2, --反馈信息
                      ret      out varchar2 --执行结果
                      );
  --，在该界面上，点击查询，调用过程pg_oil13.selectmat查询数据并加载表格
  procedure selectmat(a_mat_desc varchar2, --物料名
                      ret        out sys_refcursor --返回结果集
                      );
  --将选择的物料号调用过程pg_oil13.importmat导入
  procedure importmat(a_mat_no   varchar2, --物料号
                      a_mat_desc varchar2, --物料名
                      ret_msg    out varchar2, --反馈信息
                      ret        out varchar2 --执行结果
                      );
end pg_oil13;
/

