create package body pg_dj704 is
  --1.查询：pg_dj704.getitypelist，页面加载时自动查询数据。
  procedure getitypelist(ret out sys_refcursor) is
  begin
    open ret for
      select I.TYPECODE, --分类编号
             I.TYPENAME, --分类名
             I.STATUS, --状态
             CASE I.STATUS
               WHEN '1' THEN
                '启用'
               ELSE
                '停用'
             END STATUS_DESC, --状态描述
             I.TYPE_PREFIX, --前缀编号
             I.TYPE_UNIT, --默认单位
             I.REC_STATUS, --回收状态
             CASE I.REC_STATUS
               WHEN '1' THEN
                '回收'
               ELSE
                '不回收'
             END REC_STATUS_DESC, --回收状态描述
             I_INDEX
        from dj_mat_itype i
        order by nvl(i.i_index,99);
  end;
  -- 4.删除，调用过程pg_dj704.deleteitype,调用成功，更新表格内的数据。
  procedure deleteitype(a_typecode varchar2, --分类编码
                        a_userid   varchar2, --用户ID
                        a_username varchar2, --姓名
                        ret        out varchar2,
                        ret_msg    out varchar2) is
  begin
    ret := 'Fail';
    delete from dj_mat_itype where typecode = a_typecode;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败,原因：' || sqlerrm;
  end;
  --5.新增-保存，调用过程pg_dj704.additype,其中使用状态和回收状态传入的参数为括号内的值。
  procedure additype(a_typecode    varchar2, --分类编码
                     a_typename    varchar2, --分类名
                     a_status      varchar2, --状态
                     a_type_prefix varchar2, --编码前缀
                     a_type_unit   varchar2, --默认单位
                     a_rec_status  varchar2, --回收状态
                     a_userid      varchar2, --用户ID
                     a_username    varchar2, --用户姓名
                     a_index       number, --顺序号
                     ret           out varchar2,
                     ret_msg       out varchar2) is
    p_count number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_count
      from dj_mat_itype i
     where i.typecode = a_typecode;
    if p_count = 0 then
      begin
        insert into dj_mat_itype
          (typecode,
           typename,
           status,
           type_prefix,
           type_unit,
           rec_status,
           i_index)
        values
          (a_typecode,
           a_typename,
           a_status,
           a_type_prefix,
           a_type_unit,
           a_rec_status,
           a_index);
        commit;
        ret := 'Success';
      exception
        when others then
          ret_msg := '操作失败，原因：' || sqlerrm;
      end;
    else
      ret_msg := '该编号已存在';
    end if;
  end;
  --       7.修改-保存，调用过程pg_dj704.updteitype,其中使用状态和回收状态传入的参数为括号内的值。
  procedure updteitype(a_typecode    varchar2, --分类编码
                       a_typename    varchar2, --分类名
                       a_status      varchar2, --状态
                       a_type_prefix varchar2, --编码前缀
                       a_type_unit   varchar2, --默认单位
                       a_rec_status  varchar2, --回收状态
                       a_userid      varchar2, --用户ID
                       a_username    varchar2, --用户姓名
                       a_index       number,
                       ret           out varchar2,
                       ret_msg       out varchar2) is
  begin
    update dj_mat_itype i
       set i.typecode    = a_typecode,
           i.typename    = a_typename,
           i.status      = a_status,
           i.type_prefix = a_type_prefix,
           i.type_unit   = a_type_unit,
           i.rec_status  = a_rec_status,
           i.i_index     = nvl(a_index, '99')
     where i.typecode = a_typecode;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因：' || sqlerrm;
  end;
end pg_dj704;
/

