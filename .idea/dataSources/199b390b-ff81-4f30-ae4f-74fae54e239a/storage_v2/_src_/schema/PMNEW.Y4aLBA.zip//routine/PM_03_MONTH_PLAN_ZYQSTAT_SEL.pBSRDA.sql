create procedure PM_03_MONTH_PLAN_ZYQSTAT_SEL(V_V_YEAR    IN VARCHAR2, --年份
                                                         V_V_MONTH   IN VARCHAR2, --月份
                                                         V_V_ORGCODE IN VARCHAR2, --厂矿编码
                                                         V_CURSOR    OUT SYS_REFCURSOR) is
  V_ALLNUM  NUMBER;
  V_EXENUM  NUMBER;
  V_EXTRATE NUMBER;
  /*
  月计划作业区执行率
  */
begin
  FOR P IN (SELECT D.V_DEPTCODE, D.V_DEPTNAME
              FROM BASE_DEPT D
             WHERE D.V_DEPTTYPE LIKE '%主体作业区%'
               AND D.V_DEPTCODE LIKE '%' || V_V_ORGCODE || '%') LOOP

    SELECT COUNT(M.V_GUID)
      INTO V_ALLNUM
      FROM PM_03_PLAN_MONTH M
     WHERE M.V_YEAR = V_V_YEAR
       AND M.V_MONTH = V_V_MONTH
       AND M.V_ORGCODE LIKE '%' || V_V_ORGCODE || '%'
       AND M.V_DEPTCODE = P.V_DEPTCODE
       AND M.V_STATE NOT IN ('10', '20','80', '99', '100');

    SELECT COUNT(C.V_OTHERPLAN_GUID)
      INTO V_EXENUM
      FROM (SELECT DISTINCT M.V_OTHERPLAN_GUID
              FROM PM_03_PLAN_WEEK M
             WHERE M.V_OTHERPLAN_GUID IS NOT NULL
               AND M.V_OTHERPLAN_TYPE = 'MONTH'
               AND M.V_YEAR = V_V_YEAR
               AND M.V_MONTH = V_V_MONTH
               AND M.V_ORGCODE LIKE '%' || V_V_ORGCODE || '%'
               AND M.V_DEPTCODE = P.V_DEPTCODE
               AND M.V_STATE NOT IN ('10', '20','80', '99', '100')) C;

    V_EXTRATE := ROUND(V_EXENUM / (CASE
                         WHEN V_ALLNUM = 0 THEN
                          1
                         ELSE
                          V_ALLNUM
                       END) * 100,
                       2);

    INSERT INTO TEMP_TABLE
      (V_1, V_2, V_3, V_4, V_5)
    VALUES
      (P.V_DEPTCODE, P.V_DEPTNAME, V_ALLNUM, V_EXENUM, V_EXTRATE);

  END LOOP;
  OPEN V_CURSOR FOR
    SELECT T.V_1 AS V_DEPTCODE,
           T.V_2 AS V_DEPTNAME,
           T.V_3 AS ALLNUM,
           T.V_4 AS EXENUM,
           T.V_5 AS EXTRATE
      FROM TEMP_TABLE T;

end PM_03_MONTH_PLAN_ZYQSTAT_SEL;
/

