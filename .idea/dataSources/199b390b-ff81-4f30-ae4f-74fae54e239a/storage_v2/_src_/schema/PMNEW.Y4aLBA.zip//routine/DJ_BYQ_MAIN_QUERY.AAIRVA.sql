create PROCEDURE DJ_BYQ_MAIN_query(keyCode varchar2,
                                              PRESULT OUT SYS_REFCURSOR) AS
BEGIN
  OPEN PRESULT FOR
    SELECT * FROM DJ_BYQ_MAIN d where d.byq_unique_code = keyCode;
END DJ_BYQ_MAIN_query;
/

