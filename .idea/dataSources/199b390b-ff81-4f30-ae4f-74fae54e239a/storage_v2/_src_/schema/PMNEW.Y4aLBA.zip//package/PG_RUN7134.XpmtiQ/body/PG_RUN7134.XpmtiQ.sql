create package body pg_run7134 is

  --1.查询，导出：pg_run7134.getbjlist
  procedure getbjlist(a_mat_no   varchar2, --备件编码
                      a_mat_desc varchar2, --备件名称
                      ret        out sys_refcursor) is
  begin
    open ret for
      select m.materialcode, --备件编码
             m.materialname, --备件名称
             m.materialetalon, --规格型号
             m.unit, --单位
             m.f_price, --单价
             m.run_pre_time --预期寿命
        from run_mat m
       where m.materialcode like '%' || a_mat_no || '%'
         and m.materialname like '%' || a_mat_desc || '%'
       order by m.materialcode;
  end;
  --2.新增，打开新增界面。点击选择按钮，打开物料搜索界面进行查询（查询：pg_run7134.getmatlist）。点击选择列，将选中行的信息填入并管理搜索界面。保存（保存：pg_run7134.addbj）后关闭新增界面。
  procedure getmatlist(a_mat_no   VARCHAR2, --备件编码
                       a_mat_desc varchar2, --备件名称
                       ret        out sys_refcursor) is
  begin
    open ret for
      select *
        from (select m.mat_no, --备件编码
                     m.mat_desc, --备件名称
                     m.ltext, --规格型号
                     m.plan_price, --计划价
                     m.unit, --计量单位
                     rownum rowIndex
                from view_mm_mats@namm.fjwz m
               where m.mat_no like '%' || a_mat_no || '%'
                 and m.mat_desc like '%' || a_mat_desc || '%') a
       where rowIndex <= 1000
       order by mat_no;
  end;
  procedure addbj(a_mat_no   varchar2, --备件编码
                  a_mat_desc varchar2, --备件名称
                  a_etalon   varchar2, --规格型号
                  a_unit     varchar2, --计量单位
                  a_price    number, --计划价
                  ret_msg    out varchar2,
                  ret        out varchar2) is
  begin
    ret := 'Fail';
    insert into run_mat
      (materialcode, materialname, materialetalon, unit, f_price)
    values
      (a_mat_no, a_mat_desc, a_etalon, a_unit, a_price);
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
  --3.删除，pg_run7134.deletebj
  procedure deletebj(a_mat_no varchar2, --备件编码
                     ret_msg  out varchar2,
                     ret      out varchar2) is
    p_count number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_count
      from run_bj_material m
     where m.materialcode = a_mat_no;
    if p_count = 0 then
      begin
        delete from run_mat where materialcode = a_mat_no;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '操作失败：该备件在设备中被使用，不能删除！';
    end if;
  end;
  --4.安装位置-查看（pg_run7134.getsitelist），更新右侧表格
  procedure getsitelist(a_mat_no varchar2, --备件编码
                        ret      out sys_refcursor) is
  begin
    open ret for
      select d.v_deptname, --作业区
             e.equ_desc, --设备
             s.site_desc, --备件安装位置
             s.bj_amount --安装数量
        from run_bj_material m
        left outer join run_bj b
          on b.bj_id = m.bj_id
        left outer join run_site_dic s
          on s.bj_id = b.bj_id
        left outer join run_equ_dic e
          on e.equ_id = s.equ_id
        left outer join base_dept d
          on d.v_deptcode = e.departcode
       where m.materialcode = a_mat_no
       order by d.v_deptname, e.equ_desc, s.site_desc;
  end;
  --保存预期寿命
  procedure saveBjPreTime(v_ip     varchar2,
                          v_userid varchar2,
                          v_mat_no varchar2, --备件代码
                          f_time   number, --预期寿命
                          ret_msg  out varchar2,
                          ret      out varchar2) is
  begin
    ret := 'Fail';
    if f_time > 0 then
      begin
        update run_mat m
           set m.run_pre_time = f_time
         where m.materialcode = v_mat_no;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败:' || sqlerrm;
      end;
    else
      ret_msg := '操作失败:寿命不能小于0';
    end if;
  end;
end pg_run7134;
/

