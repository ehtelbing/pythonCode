create package body PG_DJ702 is
  --检修状态人员配置
  --下拉
  procedure pro_dj702_droplist(v_cursor out sys_refcursor) as
  begin
    open v_cursor for
      select a.order_status_desc, a.order_status from DJ_ORDER_STATUS a;
  end;
  --检修单位下拉
  procedure pro_dj702_jxdwdroplist(v_userid in varchar2,
                                   v_cursor out sys_refcursor) as
  begin
    open v_cursor for
      select a.menddept_code, a.menddept_name
        from DJ_MENDDEPT a
       where a.userid like v_userid || '%';
  end;
  --查询
  procedure pro_dj702_select(v_ordersts varchar2,
                             v_cursor   out sys_refcursor) as
  begin
    open v_cursor for
      select a.*,
             (select c.menddept_name
                from DJ_MENDDEPT c
               where b.menddept_code = c.menddept_code) as menddept_name,
             b.menddept_code,
             b.id
        from DJ_STATUS_POWER a
        left outer join DJ_STATUS_POWER_MENDDEPT b
          on a.powerid = b.powerid
       where a.order_status like v_ordersts || '%';
  end;
  --删除
  procedure pro_dj702_delete(v_powerid varchar2,
                             v_id      in varchar2,
                             ret       out varchar2) as
  begin
    savepoint s;
    delete DJ_STATUS_POWER_MENDDEPT a where a.id = v_id;
    delete DJ_STATUS_POWER a where a.powerid = v_powerid;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --新增
  procedure pro_dj702_insert(v_ordersts     varchar2,
                             v_userid       varchar2,
                             v_username     varchar2,
                             v_sts          varchar2,
                             v_menddeptcode varchar2,
                             ret            out varchar2) as
    p_powerid varchar2(50);
  begin
    savepoint s;
    p_powerid := func_new_guid();
    insert into DJ_STATUS_POWER
    values
      (p_powerid, v_ordersts, v_userid, v_username, v_sts);
    insert into DJ_STATUS_POWER_MENDDEPT
    values
      (func_new_guid(), p_powerid, v_menddeptcode);
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := sqlerrm;
  end;
end PG_DJ702;
/

