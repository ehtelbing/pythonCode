create PROCEDURE ADD_PRELOADWARE_MAIN(X_MODELNUMBER VARCHAR2,
                                                 X_MODELNAME   VARCHAR2,
                                                 X_UNIT        VARCHAR2,
                                                 X_TYPE        VARCHAR2,
                                                 X_SETSITE     VARCHAR2,
                                                 X_MEMO        VARCHAR2,
                                                 X_DRAWING     VARCHAR2,
                                                 X_EQUTYPECODE VARCHAR2,
                                                 X_DEPTCODE    VARCHAR2,
                                                 X_YBJCODE     VARCHAR2) IS

BEGIN
  INSERT INTO BASE_PRELOADWAREMODEL
    (V_MODELNUMBER,
     V_MODELNAME,
     V_UNIT,
     V_TYPE,
     V_SETSITE,
     V_MEMO,
     V_DRAWING,
     V_EQUTYPECODE,
     V_DEPTCODE,
     V_YBJCODE)
  VALUES
    (X_MODELNUMBER, --FUNC_GETPRELOADNUMBER()
     X_MODELNAME,
     X_UNIT,
     X_TYPE,
     X_SETSITE,
     X_MEMO,
     X_DRAWING,
     X_EQUTYPECODE,
     X_DEPTCODE,
     X_YBJCODE);

END ADD_PRELOADWARE_MAIN;
/

