create package BODY pg_dj1002 is
  -- 获取库存列表
  procedure getkc(a_plantcode    varchar2, --厂矿编码
                  a_departcode   varchar2, --部门编码
                  a_itype        varchar2, --物资分类
                  a_store_desc   varchar2, --库房描述
                  a_materialcode varchar2, --物资编码
                  a_materialname varchar2, --物资名称
                  a_etalon       varchar2, --规格
                  a_loc_desc     varchar2, --存放位置描述
                  a_userid       varchar2, --用户ID
                  ret            out sys_refcursor) is
  begin
    open ret for
      select null materialcode,
             null kcid,
             null materialname,
             null etalon,
             null unit,
             null f_price,
             sum(k.amount) amount,
             sum(k.f_price * k.amount) f_money,
             sum(k.ky_amount) ky_amount,
             sum(k.ky_amount * k.f_price) f_kymoney,
             null store_desc,
             '合计' i_type
        from dj_mat_kc k
       where k.useflag = '1'
         and k.plantcode = a_plantcode
         and k.departcode like a_departcode
         and k.i_type like a_itype
         and k.store_desc like '%' || a_store_desc || '%'
         and k.materialcode like '%' || a_materialcode || '%'
         and k.materialname like '%' || a_materialname || '%'
         and nvl(k.loc_desc, '0') like '%' || a_loc_desc || '%'
         and nvl(k.etalon, '0') like '%' || a_etalon || '%'
         and k.ky_amount > 0
      union all
      select materialcode,
             kcid,
             materialname,
             etalon,
             unit,
             f_price,
             amount,
             (f_price * amount) f_money,
             ky_amount,
             ky_amount * f_price f_kymoney,
             store_desc,
             i_type
        from (select k.materialcode,
                     k.kcid,
                     k.materialname,
                     k.etalon,
                     k.unit,
                     k.f_price,
                     k.amount,
                     (k.f_price * k.amount) f_money,
                     k.ky_amount,
                     k.ky_amount * k.f_price f_kymoney,
                     k.store_desc,
                     k.i_type
                from dj_mat_kc k
               where k.useflag = '1'
                 and k.plantcode = a_plantcode
                 and k.departcode like a_departcode
                 and k.i_type like a_itype
                 and k.store_desc like '%' || a_store_desc || '%'
                 and k.materialcode like '%' || a_materialcode || '%'
                 and k.materialname like '%' || a_materialname || '%'
                 and nvl(k.loc_desc, '0') like '%' || a_loc_desc || '%'
                 and nvl(k.etalon, '0') like '%' || a_etalon || '%'
                 and k.ky_amount > 0
               order by insertdate desc) a;
  end;
  --消耗明细
  procedure getconsumedetail(a_kcid varchar2, --库存ID
                             ret    out sys_refcursor) is
  begin
    open ret for
      select m.materialcode,
             m.materialname,
             m.etalon,
             m.unit,
             m.f_price,
             m.act_amount plan_amount,
             m.f_price * m.act_amount f_money,
             m.orderid,
             o.insertdate
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
       where m.kcid = a_kcid;
  end;
  --修改库房描述
  procedure setStoredesc(a_kcid          varchar2,
                         a_new_storedesc varchar2,
                         ret_msg         out varchar2,
                         ret             out varchar2) is
  begin
    ret := 'Fail';
    update dj_mat_kc set STORE_DESC = a_new_storedesc where kcid = a_kcid;
    commit;
    ret := 'Success';
  end;
end pg_dj1002;
/

