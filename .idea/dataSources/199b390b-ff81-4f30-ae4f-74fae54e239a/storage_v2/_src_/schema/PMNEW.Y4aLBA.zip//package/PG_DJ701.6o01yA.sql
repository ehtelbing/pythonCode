create package PG_DJ701 is
  --检修人员单位配置
  procedure pro_dj701_select(menddept_name_in varchar2,
                             username_in      varchar2,
                             v_cursor         out sys_refcursor);
  --修改
  procedure pro_dj701_update1(v_menddeptcode varchar2,
                              v_menddeptname varchar2,
                              v_userid       varchar2,
                              v_username     varchar2,
                              ret            out varchar2);
  --删除
  procedure pro_dj701_delete(v_menddeptcode varchar2, ret out varchar2);
  --新增
  procedure pro_dj701_insert(v_menddeptname varchar2,
                             v_menddeptcode varchar2,
                             v_menddepttype varchar2,
                             v_supercode    varchar2,
                             v_userid       varchar2,
                             v_username     varchar2,
                             ret            out varchar2);
  --查询检修单位人员
  procedure pro_dj701_view(v_menddeptcode varchar2,
                           v_cursor       out sys_refcursor);
  --删除人员
  procedure pro_dj701_persondel(v_userid varchar2, ret out varchar2);
  --新增检修人员
  procedure pro_dj701_perinsert(v_menddeptcode in varchar2,
                                v_userid       in varchar2,
                                v_username     in varchar2,
                                ret            out varchar2);
end PG_DJ701;
/

