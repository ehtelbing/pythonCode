create procedure PM_03_MONTH_PLAN_BYPER_SEL(V_V_YEAR      IN VARCHAR2, --年份
                                                       V_V_MONTH     IN VARCHAR2, --月份
                                                       V_V_ORGCODE   IN VARCHAR2, --厂矿编码
                                                       V_V_DEPTCODE  IN VARCHAR2, --作业区变啊
                                                       V_V_EQUTYPE   IN VARCHAR2, --设备类型编码
                                                       V_V_EQUCODE   IN VARCHAR2, --设备名称编码
                                                       V_V_ZY        IN VARCHAR2, --专业编码
                                                       V_V_CONTENT   IN VARCHAR2, --检修内容
                                                       V_V_STATECODE IN VARCHAR2, --计划状态
                                                       V_V_PEROCDE   IN VARCHAR2, --人员编码
                                                       V_V_PAGE      IN VARCHAR2, --页数
                                                       V_V_PAGESIZE  IN VARCHAR2, --每页显示条数
                                                       V_V_SNUM      OUT VARCHAR2, --返回总条数
                                                       V_CURSOR      OUT SYS_REFCURSOR) is

  /*
  人员月计划查询
  */
begin

  SELECT COUNT(*)
    INTO V_V_SNUM
    FROM VIEW_PM_PLAN_MONTH M
   WHERE M.V_YEAR = V_V_YEAR
     AND M.V_MONTH = V_V_MONTH
     AND M.V_ORGCODE = V_V_ORGCODE
        --AND M.V_DEPTCODE LIKE V_V_DEPTCODE
     AND NVL(M.V_REPAIRMAJOR_CODE, ' ') LIKE NVL(V_V_ZY, '%')
     AND NVL(M.V_EQUCODE, ' ') LIKE NVL(V_V_EQUCODE, '%')
     AND NVL(M.V_EQUTYPECODE, ' ') LIKE NVL(V_V_EQUTYPE, '%')
     AND M.V_STATE LIKE V_V_STATECODE
     AND M.V_CONTENT LIKE '%' || V_V_CONTENT || '%'
     AND M.V_INPER = V_V_PEROCDE
   ORDER BY M.V_YEAR, M.V_MONTH, M.V_MONTHID DESC;

  OPEN V_CURSOR FOR
    SELECT D.*
      FROM (SELECT C.*, rownum as rn
              FROM (SELECT M.*,
                           /*(SELECT count(*)
                              FROM PM_03_PLAN_WEEK
                             WHERE V_OTHERPLAN_GUID = M.V_GUID) AS V_WEEKNUM,*/
                           B.V_BASENAME AS V_FLOWNAME,
                           C.V_BASENAME AS V_STATENAME
                      FROM VIEW_PM_PLAN_MONTH M
                      LEFT JOIN PM_BASEDIC B
                        ON M.V_FLOWCODE = B.V_BASECODE
                       AND B.V_BASETYPE = 'PLAN/FLOW'
                      LEFT JOIN PM_BASEDIC C
                        ON M.V_STATE = C.V_BASECODE
                       AND C.V_BASETYPE = 'PLAN/STATE'
                     WHERE M.V_YEAR = V_V_YEAR
                       AND M.V_MONTH = V_V_MONTH
                       AND M.V_ORGCODE = V_V_ORGCODE
                          --AND M.V_DEPTCODE LIKE V_V_DEPTCODE
                       AND NVL(M.V_REPAIRMAJOR_CODE, ' ') LIKE
                           NVL(V_V_ZY, '%')
                       AND NVL(M.V_EQUCODE, ' ') LIKE NVL(V_V_EQUCODE, '%')
                       AND NVL(M.V_EQUTYPECODE, ' ') LIKE
                           NVL(V_V_EQUTYPE, '%')
                       AND M.V_STATE LIKE V_V_STATECODE
                       AND M.V_CONTENT LIKE '%' || V_V_CONTENT || '%'
                       AND M.V_INPER = V_V_PEROCDE
                     ORDER BY M.V_YEAR, M.V_MONTH, M.V_MONTHID DESC) C
             WHERE rownum <= V_V_PAGE * V_V_PAGESIZE) D
     WHERE D.rn > (V_V_PAGE - 1) * V_V_PAGESIZE;
end PM_03_MONTH_PLAN_BYPER_SEL;
/

