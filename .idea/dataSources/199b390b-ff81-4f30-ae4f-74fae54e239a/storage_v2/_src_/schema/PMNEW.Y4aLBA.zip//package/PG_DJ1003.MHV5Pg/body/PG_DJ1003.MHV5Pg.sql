create package BODY pg_dj1003 is
  -- 查询消耗
  procedure getconsume(a_begindate    date, --起始日期
                       a_enddate      date, --结束日期
                       a_orderid      varchar2, --检修单号
                       a_plantcode    varchar2, --厂矿编码
                       a_departcode   varchar2, --部门编码
                       a_itype        varchar2, --物资分类
                       a_storedesc    varchar2, --库房描述
                       a_materialcode varchar2, --物资分类
                       a_materialname varchar2, --物资名称
                       a_etalon       varchar2, --规格
                       a_lcodesc      varchar2, --存放位置描述
                       ret            out sys_refcursor) is
  begin
    open ret for
      select null materialcode,
             '合计' materialname,
             null etalon,
             null unit,
             null f_price,
             sum(m.plan_amount) plan_amount,
             sum(m.f_price * m.plan_amount) f_money,
             sum(m.act_amount) act_amount,
             sum(m.act_amount * m.f_price) f_act_money,
             null orderid,
             null insertdate,
             null store_desc,
             null i_type,
             null dj_vol,
             null mend_context
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
       where to_number(to_char(m.insertdate, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(m.insertdate, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and m.orderid like func_isnull(a_orderid) || '%'
         and o.PLANTCODE = a_plantcode
         and o.departcode like func_isnull(a_departcode)
         and k.i_type like func_isnull(a_itype)
         and nvl(k.store_desc, '0') like '%' ||func_isnull(a_storedesc) || '%'
         and nvl(m.materialcode, '0') like '%' || func_isnull(a_materialcode) || '%'
         and nvl(m.materialname, '0') like '%' || func_isnull(a_materialname) || '%'
         and nvl(m.etalon, '0') like '%' || func_isnull(a_etalon) || '%'
         and nvl(k.loc_desc, '0') like '%' || func_isnull(a_lcodesc) || '%'
      union all
      select m.materialcode,
             m.materialname,
             m.etalon,
             m.unit,
             m.f_price,
             m.plan_amount,
             m.f_price * m.plan_amount f_money,
             m.act_amount,
             m.act_amount * m.f_price f_act_money,
             m.orderid,
             m.insertdate,
             k.store_desc,
             k.i_type,
             o.dj_vol,
             nvl(o.mend_context, ' ') mend_context
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
       where to_number(to_char(m.insertdate, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(m.insertdate, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and m.orderid like func_isnull(a_orderid) || '%'
         and o.PLANTCODE = a_plantcode
         and o.departcode like func_isnull(a_departcode)
         and k.i_type like func_isnull(a_itype)
         and nvl(k.store_desc, '0') like '%' ||func_isnull(a_storedesc) || '%'
         and nvl(m.materialcode, '0') like '%' || func_isnull(a_materialcode) || '%'
         and nvl(m.materialname, '0') like '%' || func_isnull(a_materialname) || '%'
         and nvl(m.etalon, '0') like '%' || func_isnull(a_etalon) || '%'
         and nvl(k.loc_desc, '0') like '%' || func_isnull(a_lcodesc) || '%'
         ;
  end;
  --查询检修单消耗物料
  procedure getorderconsume(a_orderid varchar2, --检修单号
                            ret       out sys_refcursor) is
  begin
    open ret for
      select m.materialcode,
             m.materialname,
             m.etalon,
             m.unit,
             m.f_price,
             m.plan_amount,
             m.f_price * m.plan_amount f_money,
             m.act_amount,
             m.act_amount * m.f_price f_act_money,
             m.orderid,
             o.insertdate,
             k.store_desc,
             k.i_type
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
       where m.orderid = a_orderid;
  end;
end pg_dj1003;
/

