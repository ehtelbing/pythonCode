create PROCEDURE GYS_LAYER_4_SEL(V_VENDORNAME IN VARCHAR2,
                                            V_EKORG      IN VARCHAR2,
                                            V_CURSOR     OUT SYS_REFCURSOR) IS
BEGIN
  OPEN V_CURSOR FOR
    with t as
     (select row_number() over(partition by b.VENDOR_KEY order by m.TIMESTAMP desc) rn,
             B.MESSAGE_ID,
             B.VENDOR_KEY, --流水号
             B.VENDOR_NAME, --供应商名称
             B.ENTERPRISE_TYPE, --企业类型
             B.LEGAL_PERSON, --法人代表
             M.TIMESTAMP
        FROM SAP_XI_OA0004_BASIC@DB_BPM B, SAP_XI_MESSAGE_OA0004@DB_BPM M
       WHERE B.MESSAGE_ID = M.ID
         AND B.VENDOR_NAME LIKE '%' || V_VENDORNAME || '%'
         AND B.EKORG LIKE V_EKORG)
    SELECT MESSAGE_ID,
           VENDOR_KEY,
           VENDOR_NAME,
           ENTERPRISE_TYPE,
           LEGAL_PERSON
      from t
     where rn = 1;

END GYS_LAYER_4_SEL;
/

