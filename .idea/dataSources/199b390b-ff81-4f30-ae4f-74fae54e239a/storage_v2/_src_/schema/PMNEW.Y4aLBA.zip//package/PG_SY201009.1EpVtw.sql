create package PG_SY201009 is
  --母线试验数据录入
  --2,
  procedure pro_sy201009_twodetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor);
  --2,添加
  procedure pro_sy201009_twoadd(recordcode_in varchar2,
                                v_yqxs        VARCHAR2,
                                v_yqbh        VARCHAR2,
                                v_a1          number,
                                v_b1          number,
                                v_c1          number,
                                --v_opuser      varchar2,
                                --v_recorduser  varchar2,
                                --v_jxuser varchar2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2);
  --2,更新
  procedure pro_sy201009_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2,
                                   v_yqxs        VARCHAR2,
                                   v_yqbh        VARCHAR2,
                                   v_a1          number,
                                   v_b1          number,
                                   v_c1          number,
                                   -- v_opuser      varchar2,
                                   --v_recorduser  varchar2,
                                   --v_jxuser varchar2,
                                   ret out varchar2);
  --3,查询
  procedure pro_sy201009_threedetail(recordcode_in varchar2,
                                     v_cursor      out sys_refcursor);
  --3,添加
  procedure pro_sy201009_threeadd(recordcode_in varchar2,
                                  v_yqxs        VARCHAR2,
                                  v_yqbh        VARCHAR2,
                                  v_a1          number,
                                  v_a2          number,
                                  v_a3          number,
                                  v_b1          number,
                                  v_b2          number,
                                  v_b3          number,
                                  v_c1          number,
                                  v_c2          number,
                                  v_c3          number,
                                  -- v_opuser      varchar2,
                                  --v_recorduser  varchar2,
                                  -- v_jxuser varchar2,
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2);
  --3,更新
  procedure pro_sy201009_threeupdate(v_id          varchar2,
                                     recordcode_in varchar2,
                                     v_yqxs        VARCHAR2,
                                     v_yqbh        VARCHAR2,
                                     v_a1          number,
                                     v_a2          number,
                                     v_a3          number,
                                     v_b1          number,
                                     v_b2          number,
                                     v_b3          number,
                                     v_c1          number,
                                     v_c2          number,
                                     v_c3          number,
                                     --v_opuser      varchar2,
                                     --v_recorduser  varchar2,
                                     --v_jxuser varchar2,
                                     ret out varchar2);
end PG_SY201009;
/

