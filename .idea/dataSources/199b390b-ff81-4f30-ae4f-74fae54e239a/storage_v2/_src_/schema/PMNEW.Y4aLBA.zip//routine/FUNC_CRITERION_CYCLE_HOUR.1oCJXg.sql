create FUNCTION FUNC_CRITERION_CYCLE_HOUR(V_CRITERION_CYCLE     NUMBER,
                                                     V_CRITERION_CYCLETYPE VARCHAR2)
  RETURN NUMBER IS
  V_RETURN NUMBER;
BEGIN
  /*
  季度
  年
  天
  小时
  月
  周

  */

  IF (V_CRITERION_CYCLETYPE = '年') THEN
    --年折算成小时  365天*24小时
    V_RETURN := NVL(V_CRITERION_CYCLE, 0) * 365 * 24;
  ELSE
    IF (V_CRITERION_CYCLETYPE = '季度') THEN
      --季度折算成小时
      V_RETURN := NVL(V_CRITERION_CYCLE, 0) * (365 / 4) * 24;
    ELSE
      IF (V_CRITERION_CYCLETYPE = '月') THEN
        --月折算成小时
        V_RETURN := NVL(V_CRITERION_CYCLE, 0) * (365 / 12) * 24;
      ELSE
        IF (V_CRITERION_CYCLETYPE = '周') THEN
          --周折算成小时
          V_RETURN := NVL(V_CRITERION_CYCLE, 0) * 7 * 24;
        ELSE
          IF (V_CRITERION_CYCLETYPE = '天') THEN
            --天折算成小时
            V_RETURN := NVL(V_CRITERION_CYCLE, 0) * 24;
          ELSE
            IF (V_CRITERION_CYCLETYPE = '小时') THEN
              --小时折算成小时
              V_RETURN := V_CRITERION_CYCLE;
            ELSE
              --什么也没选
              V_RETURN := V_CRITERION_CYCLE;
            END IF;
          END IF;
        END IF;
      END IF;
    END IF;

  END IF;

  RETURN V_RETURN;
END FUNC_CRITERION_CYCLE_HOUR;
/

