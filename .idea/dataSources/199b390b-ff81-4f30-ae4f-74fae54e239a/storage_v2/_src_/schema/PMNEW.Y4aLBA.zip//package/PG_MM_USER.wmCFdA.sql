create package pg_mm_user is

  -- Author  : WY
  -- Created : 2017/11/15 14:25:46
  -- Purpose :

  -- 获取用户姓名
  function getusername(v_userid varchar2) return varchar2;

end pg_mm_user;
/

