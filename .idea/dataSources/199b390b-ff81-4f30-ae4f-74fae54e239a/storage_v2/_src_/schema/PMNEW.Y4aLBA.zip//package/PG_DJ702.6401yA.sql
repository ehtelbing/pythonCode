create package PG_DJ702 is
  --下拉
  procedure pro_dj702_droplist(v_cursor out sys_refcursor);
  --检修单位下拉
  procedure pro_dj702_jxdwdroplist(v_userid in varchar2,
                                   v_cursor out sys_refcursor);
  --查询
  procedure pro_dj702_select(v_ordersts varchar2,
                             v_cursor   out sys_refcursor);
  --删除
  procedure pro_dj702_delete(v_powerid varchar2,
                             v_id      in varchar2,
                             ret       out varchar2);
  --新增
  procedure pro_dj702_insert(v_ordersts     varchar2,
                             v_userid       varchar2,
                             v_username     varchar2,
                             v_sts          varchar2,
                             v_menddeptcode varchar2,
                             ret            out varchar2);
end PG_DJ702;
/

