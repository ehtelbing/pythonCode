create function DR_PM_03_PLAN_PROJECT(V_V_YEAR IN NUMBER)
  return varchar2 is
  p_ret varchar2(10) := 'FAIL';
begin
  begin
    MERGE INTO PM_03_PLAN_PROJECT T1
    USING (select *
             from FX_DATA_NJH t
            WHERE V_NJH_JHZT = '已放行'
              AND V_NJH_JHNF = V_V_YEAR) T2
    ON (T1.V_YEAR = T2.V_NJH_JHNF AND T1.V_PORJECT_NAME = T2.V_NJH_GCMC)
    WHEN NOT MATCHED THEN
      INSERT
        (V_GUID,
         V_YEAR,
         V_ORGCODE,
         V_ORGNAME,
         --V_DEPTCODE,
         --V_DEPTNAME,
         V_PORJECT_CODE,
         V_PORJECT_NAME,
         V_SPECIALTY,
         V_SPECIALTYMAN,
         V_WXTYPECODE,
         V_WXTYPENAME,
         V_JHLB,
         V_SCLB,
         V_CPZL,
         V_CPGX,
         V_SGFS,
         V_BDATE,
         V_EDATE,
         V_STATE,
         V_FLAG,
         V_INMANCODE,
         V_INDATE,
         V_MONEY,
         V_BJMONEY,
         V_CLMONEY,
         V_SFXJ, --是否修旧
         V_CONTENT, --维修内容
         V_DEPTCODE, --
         V_DEPTNAME)
      VALUES
        (CREATEGUID(),
         T2.V_NJH_JHNF,
         (select V_DEPTCODE from BASE_DEPT where
         V_DEPT_WBS = (select f.V_DEPTWBS1
                          from FX_BASE_DEPT f
                         WHERE f.V_DEPTCODE = T2.V_ORGCODE)),
         (select V_DEPTNAME from BASE_DEPT where
         V_DEPT_WBS = (select f.V_DEPTWBS1
                          from FX_BASE_DEPT f
                         WHERE f.V_DEPTCODE = T2.V_ORGCODE)),
         --T2.V_V_ORGNAME,
         -- T2.V_V_DEPTCODE,
         -- T2.V_V_DEPTNAME,
         T2.V_NJH_GCBH,
         T2.V_NJH_GCMC,
         T2.I_ZYXX_XH,
         T2.V_NJH_XMFZR,
         T2.I_WXLX_XH,
         (select v_basename
            from PM_BASEDIC
           WHERE v_basetype = 'PM_DX/REPAIRTYPE'
             and v_basecode = T2.I_WXLX_XH),
         T2.I_JHLB_XH,
         T2.I_SCLB_XH,
         T2.I_CPZL_XH,
         T2.I_GXXX_XH,
         T2.I_SGFS_XH,
         T2.D_NJH_YJKGRQ,
         T2.D_NJH_YJJGRQ,
         '0', --导入
         'YEAR',
         T2.I_PERSONID,
         T2.D_NJH_XGSJ,
         T2.F_NJH_HJFY,
         T2.F_NJH_BJF,
         T2.F_NJH_CLF,
         decode(T2.V_NJH_SFZJ, '是', '0', '正常', '1'), --是否折旧
         T2.V_NJH_GCNR, --工程内容
         (select V_DEPTCODE from BASE_DEPT where
         V_DEPT_WBS = (select f.V_DEPTWBS1
                        from FX_BASE_DEPT f
                       WHERE f.V_DEPTCODE = T2.V_CBS_WYBS)), --
         (select V_DEPTNAME from BASE_DEPT  where
         V_DEPT_WBS = (select f.V_DEPTWBS1
                        from FX_BASE_DEPT f
                       WHERE f.V_DEPTCODE = T2.V_CBS_WYBS)));
    commit;
    p_ret := 'SUCCESS';
  end;
  return p_ret;
end;
/

