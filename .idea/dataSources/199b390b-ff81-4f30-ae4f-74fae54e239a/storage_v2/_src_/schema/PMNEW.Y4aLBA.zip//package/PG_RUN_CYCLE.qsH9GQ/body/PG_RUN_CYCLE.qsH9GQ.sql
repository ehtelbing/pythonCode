create PACKAGE BODY PG_RUN_CYCLE
/*
说明：备件生命周期类型
*/
 IS
  --获取可用周期类型列表
  FUNCTION GET_CYCLE_ABLE(RET OUT SYS_REFCURSOR) RETURN VARCHAR2 IS
  BEGIN
    OPEN RET FOR
      SELECT CYCLE_ID --周期ID
            ,
             CYCLE_DESC || '(' || CYCLE_UNIT || ')' CYCLE_DESC --周期描述
        FROM RUN_CYCLE_DIC;
    RETURN 'Success';
  END;
  --添加，修改，删除周期类型列表
  FUNCTION OP_CYCLE(A_CYCLE_ID   VARCHAR2 --周期ID
                   ,
                    A_CYCLE_DESC VARCHAR2 --周期描述
                   ,
                    A_CYCLE_UNIT VARCHAR2 --计算单位
                   ,
                    A_OP         VARCHAR2,
                    RET_MSG      OUT VARCHAR2) RETURN VARCHAR2 IS
    P_RET VARCHAR2(10) := 'Fail';
  BEGIN
    IF A_OP = 'add' THEN
      INSERT INTO RUN_CYCLE_DIC
        (CYCLE_ID, CYCLE_DESC, CYCLE_UNIT)
      VALUES
        (FUNC_RUN_GUID(), A_CYCLE_DESC, A_CYCLE_UNIT);
    ELSIF A_OP = 'update' THEN
      UPDATE RUN_CYCLE_DIC
         SET CYCLE_DESC = A_CYCLE_DESC, CYCLE_UNIT = A_CYCLE_UNIT
       WHERE CYCLE_ID = A_CYCLE_ID;
    ELSIF A_OP = 'delete' THEN
      DELETE FROM RUN_CYCLE_DIC WHERE CYCLE_ID = A_CYCLE_ID;
    END IF;
    COMMIT;
    P_RET   := 'Success';
    RET_MSG := '操作成功';
    RETURN P_RET;
  EXCEPTION
    WHEN OTHERS THEN
      RET_MSG := '操作失败' || sqlerrm;
      RETURN P_RET;
  END;
  --查询所有周期类型
  FUNCTION GET_CYCLE_ALL(RET OUT SYS_REFCURSOR) RETURN VARCHAR2 IS
  BEGIN
    OPEN RET FOR
      SELECT CYCLE_ID --周期ID
            ,
             CYCLE_DESC --周期描述
            ,
             CYCLE_UNIT --计算单位
        FROM RUN_CYCLE_DIC;
    RETURN 'Success';
  END;
END PG_RUN_CYCLE;
/

