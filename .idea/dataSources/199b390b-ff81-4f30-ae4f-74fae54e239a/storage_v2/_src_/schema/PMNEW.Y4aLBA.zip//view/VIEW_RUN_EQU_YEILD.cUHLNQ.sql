create view VIEW_RUN_EQU_YEILD as
SELECT Y.ID
      ,Y.EQU_ID
      ,FUNC_RUN_GETEQUNAME(Y.EQU_ID) EQUNAME
      ,Y.CYCLE_ID
      ,C.CYCLE_DESC
      ,C.CYCLE_UNIT
      ,Y.WORKDATE
      ,Y.INSERT_VALUE
      ,Y.INSERT_PERSON
      ,Y.INSERTDATE
      ,e.plantcode,
      e.departcode
  FROM RUN_EQU_YEILD Y
  LEFT OUTER
  JOIN RUN_CYCLE_DIC C ON C.CYCLE_ID = Y.CYCLE_ID
  left outer join run_equ_dic e on e.equ_id = y.equ_id
/

