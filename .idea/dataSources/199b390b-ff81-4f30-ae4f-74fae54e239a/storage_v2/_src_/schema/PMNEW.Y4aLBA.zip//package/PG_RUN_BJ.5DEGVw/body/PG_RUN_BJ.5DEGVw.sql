create package body pg_run_bj
/*
说明：设备备件字典管理
*/
 is
  --添加，修改，删除备件信息
  function op_bj(a_bj_id      varchar2, --id
                 a_bj_desc    varchar2, --备件描述
                 a_bj_type    varchar2, --规格型号
                 a_bj_unit    varchar2, --计量单位
                 a_bj_remark  varchar2, --备注
                 a_plantcode  varchar2, --厂矿编码
                 a_departcode varchar2, --作业区编码
                 a_equid      varchar2, --设备id
                 a_op         varchar2, --操作
                 a_pre_flag   varchar2,
                 ret_msg      out varchar2) return varchar2 is
    p_ret varchar2(10) := 'Fail';
  begin
    if a_op = 'add' then
      insert into run_bj
        (bj_id,
         bj_desc,
         bj_type,
         bj_unit,
         bj_remark,
         plantcode,
         departcode,
         equ_id,
         pre_flag)
      values
        (trim(a_bj_id),
         a_bj_desc,
         a_bj_type,
         a_bj_unit,
         a_bj_remark,
         a_plantcode,
         a_departcode,
         a_equid,
         a_pre_flag);
    elsif a_op = 'update' then
      update run_bj
         set bj_desc   = a_bj_desc,
             bj_type   = a_bj_type,
             bj_unit   = a_bj_unit,
             bj_remark = a_bj_remark,
             pre_flag  = a_pre_flag
       where bj_id = a_bj_id;
    elsif a_op = 'delete' then
      delete from run_bj where bj_id = a_bj_id;
    end if;
    commit;
    ret_msg := '操作成功';
    p_ret   := 'Success';
    return p_ret;
  exception
    when others then
      ret_msg := '操作失败';
      return p_ret;
  end;
  --查询当前备件信息
  function get_bj_all(a_plantcode  varchar2, --厂矿编码
                      a_departcode varchar2, --作业区编码
                      a_equid      varchar2, --设备id
                      ret          out sys_refcursor) return varchar2 is
  begin
    open ret for
      select bj_id, --备件id
             bj_desc, --备件描述
             bj_type, --规格型号
             bj_unit, --计量单位
             bj_remark, --备注
             plantname, --厂矿名称
             departname, --作业区名称
             equ_name, --设备名称
             b.pre_flag,
             case b.pre_flag
               when '0' then
                '否'
               else
                '是'
             end pre_flag_desc
        from view_run_bj b
       where plantcode = a_plantcode
         and departcode like a_departcode
         and equ_id = a_equid;
    return 'Success';
  end;
  --获取备件描述
  function get_bj_desc(a_bj_id varchar2) return varchar2 is
    p_ret varchar2(80);
  begin
    select bj_desc into p_ret from run_bj where bj_id = a_bj_id;
    return p_ret;
  exception
    when others then
      return null;
  end;
  --添加删除备件标准报警周期
  function op_bj_cycle_basic(a_bj_id       varchar2, --备件id
                             a_cycle_id    varchar2, --周期id
                             a_cycle_value number, --周期报警值
                             a_op          varchar2,
                             ret_msg       out varchar) return varchar2 is
    p_ret varchar2(10) := 'Fail';
  begin
    if a_op = 'add' then
      insert into run_bj_cycle_basic
        (id, bj_id, cycle_id, cycle_value)
      values
        (func_run_guid(), a_bj_id, a_cycle_id, a_cycle_value);
    elsif a_op = 'delete' then
      delete from run_bj_cycle_basic
       where bj_id = a_bj_id
         and cycle_id = a_cycle_id;
    end if;
    commit;
    ret_msg := '操作成功';
    p_ret   := 'Success';
    return p_ret;
  exception
    when others then
      ret_msg := '操作失败' || sqlerrm;
      return p_ret;
  end;
  --查询当前备件的标准报警周期信息
  function get_bj_cycle_basic_all(a_bj_id varchar2, --备件id
                                  ret     out sys_refcursor) return varchar2 is
  begin
    open ret for
      select bj_id,
             cycle_id,
             cycle_desc, --周期描述
             cycle_unit, --计算单位
             cycle_value --周期值
        from view_run_bj_cycle_basic
       where bj_id = a_bj_id;
    return 'Success';
  end;
  --获取备件对应的物资字典
  function get_bj_material(a_bj_id varchar2, --备件id
                           ret     out sys_refcursor) return varchar2 is
  begin
    open ret for
      select m.bj_id, --备件id
             m.materialcode, --物资编码
             mat.materialname, --物资名称
             mat.materialetalon, --规格 型号
             mat.unit, --计量单位
             mat.f_price --单价
        from run_bj_material m
        left outer join run_mat mat
          on mat.materialcode = m.materialcode
       where bj_id = a_bj_id;
    return 'Success';
  end;
  --添加,删除备件对应物资
  function op_bj_mat(a_bj_id          varchar2, --备件id
                     a_materialcode   varchar2, --物资编码
                     a_materialname   varchar2, --物资名称
                     a_materialetalon varchar2, --规格型号
                     a_unit           varchar2, --计量单位
                     a_price          number, --单价
                     a_op             varchar2,
                     ret_msg          out varchar2) return varchar2 is
    p_ret   varchar2(10) := 'Fail';
    p_count number(2, 0) := 0;
  begin
    select count(*)
      into p_count
      from run_mat
     where materialcode = a_materialcode;
    if a_op = 'add' then
      insert into run_bj_material
        (bj_id, materialcode)
      values
        (a_bj_id, a_materialcode);
      if p_count = 0 then
        insert into run_mat
          (materialcode, materialname, materialetalon, unit, f_price)

        values
          (a_materialcode,
           a_materialname,
           a_materialetalon,
           a_unit,
           a_price);
      end if;

    elsif a_op = 'delete' then
      delete from run_bj_material
       where bj_id = a_bj_id
         and materialcode = a_materialcode;
    end if;
    commit;
    ret_msg := '操作成功';
    p_ret   := 'Success';
    return p_ret;
  exception
    when others then
      ret_msg := sqlerrm;
      return p_ret;
  end;
end pg_run_bj;
/

