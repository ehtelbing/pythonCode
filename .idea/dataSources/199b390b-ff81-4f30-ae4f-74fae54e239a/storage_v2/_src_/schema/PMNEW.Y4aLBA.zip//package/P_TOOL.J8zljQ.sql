create package P_TOOL is

  -- Author  : Dduchen
  -- Created : 2014/6/23 10:31:01
  -- Purpose : P_工具包

  --获取禁用后的名称
  function FUNC_GETDISABLENAME(V_NAME        VARCHAR2,
                               V_TABLE_NAME  VARCHAR2,
                               V_COLUMN_NAME VARCHAR2) RETURN VARCHAR2;
  --获取所有子节点
  FUNCTION FUNC_GETCHILDID(table_name          varchar2,
                           parent_column       varchar2,
                           child_column        varchar2,
                           parent_column_value varchar2) RETURN sys_refcursor;

  --获取流程下所有子节点
  FUNCTION FUNC_GETCHILDID_PROCESS(table_name          varchar2,
                                   parent_column       varchar2,
                                   child_column        varchar2,
                                   parent_column_value varchar2,
                                   process_column      varchar2,
                                   process_value       varchar2)
    RETURN sys_refcursor;

  --获取所有子节点,父节点
  FUNCTION FUNC_GETCPID(table_name          varchar2,
                        parent_column       varchar2,
                        child_column        varchar2,
                        parent_column_value varchar2) RETURN sys_refcursor;
  --将字符串用符号分割
  FUNCTION FUNC_GETSPLITITEM(MAIN_STR VARCHAR2, SPLIT_STR VARCHAR2)
    RETURN SYS_REFCURSOR;

  --检修工时获取工时换算后个数
  function FUNC_GETFINALTASKTIME(V_ORDER_TYP VARCHAR2,
                                 D_BEGINTIME DATE,
                                 D_ENDTIME   DATE,
                                 V_RET       OUT VARCHAR2) RETURN NUMBER;

  --检修工时一天内获取工时换算后个数
  function FUNC_GETASKTIMERANGE(V_ORDER_TYP VARCHAR2,
                                D_DATE      DATE,
                                V_BEGINTIME VARCHAR2,
                                V_ENDTIME   VARCHAR2) RETURN NUMBER;
  --检修工时基础工时计算
  function FUNC_GETWORKDAYTASKTIME(V_ORDER_TYP VARCHAR2,
                                   V_BEGINTIME VARCHAR2,
                                   V_ENDTIME   VARCHAR2) RETURN NUMBER;

  --检修工时节假日工时计算
  function FUNC_GETHOLIDAYTASKTIME(V_ORDER_TYP VARCHAR2,
                                   D_DATE      DATE,
                                   V_BEGINTIME VARCHAR2,
                                   V_ENDTIME   VARCHAR2) RETURN NUMBER;
  --获取检修工时折算基数
  function FUNC_GETTASKTIMENUM(V_ORDER_TYP VARCHAR2, D_DATE DATE)
    RETURN NUMBER;

  --依据工单编码，获取工时数，人数
  function FUNC_GETORDERTASKTIMEPERSON(V_WORKORDER_GUID VARCHAR2,
                                       TASKTIME         OUT NUMBER,
                                       PERSON_NUM       OUT NUMBER)
    RETURN VARCHAR;

  --依据工单编码,人员编码，获取工时数，人员工时
  function FUNC_GETPERSONTASKTIME(V_WORKORDER_GUID VARCHAR2,
                                  V_PERSONCODE     VARCHAR2,
                                  TASKTIME         OUT NUMBER,
                                  PERSON_TASKTIME  OUT NUMBER) RETURN VARCHAR;

end P_TOOL;
/

