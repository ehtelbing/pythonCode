create package body PG_DJ701 is
  --检修人员单位配置
  procedure pro_dj701_select(menddept_name_in varchar2,
                             username_in      varchar2,
                             v_cursor         out sys_refcursor) as
  begin

    open v_cursor for
      select *
        from DJ_MENDDEPT a
       where nvl(a.menddept_name,'0') like menddept_name_in || '%'
         and nvl(a.username, 0) like username_in || '%'
         order by a.menddept_code;
  end;
  --修改
  procedure pro_dj701_update1(v_menddeptcode varchar2,
                              v_menddeptname varchar2,
                              v_userid       varchar2,
                              v_username     varchar2,
                              ret            out varchar2) as
  begin
    savepoint s;
    update DJ_MENDDEPT a
       set a.menddept_name = v_menddeptname,
           a.userid        = v_userid,
           a.username      = v_username
     where a.menddept_code = v_menddeptcode;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --删除
  procedure pro_dj701_delete(v_menddeptcode varchar2, ret out varchar2) as
  begin
    savepoint s;
    delete DJ_MENDDEPT a where a.menddept_code = v_menddeptcode;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --新增
  procedure pro_dj701_insert(v_menddeptname varchar2,
                             v_menddeptcode varchar2,
                             v_menddepttype varchar2,
                             v_supercode    varchar2,
                             v_userid       varchar2,
                             v_username     varchar2,
                             ret            out varchar2) as
  begin
    savepoint s;
    insert into DJ_MENDDEPT
      (MENDDEPT_CODE,
       MENDDEPT_NAME,
       MENDDATE_TYPE,
       SUPER_CODE,
       USERID,
       USERNAME)
    values
      (v_menddeptcode,
       v_menddeptname,
       v_menddepttype,
       v_supercode,
       v_userid,
       v_username);
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --查询检修单位人员
  procedure pro_dj701_view(v_menddeptcode varchar2,
                           v_cursor       out sys_refcursor) as
  begin
    open v_cursor for
      select (select b.menddept_name
                from DJ_MENDDEPT b
               where a.menddept_code = b.menddept_code) as menddept_name,
             a.menddept_code,
             a.username,
             a.userid
        from DJ_MENDDEPT_PERSON a
       where a.menddept_code = v_menddeptcode;
  end;
  --删除人员
  procedure pro_dj701_persondel(v_userid varchar2, ret out varchar2) as
  begin
    savepoint s;
    delete DJ_MENDDEPT_PERSON a where a.userid = v_userid;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --新增检修人员
  procedure pro_dj701_perinsert(v_menddeptcode in varchar2,
                                v_userid       in varchar2,
                                v_username     in varchar2,
                                ret            out varchar2) as
  begin
    savepoint s;
    insert into DJ_MENDDEPT_PERSON
    values
      (v_userid, v_username, v_menddeptcode);
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
end PG_DJ701;
/

