create procedure BASE_JXMX_DATA_EDIT(V_V_JXMX_CODE        IN VARCHAR2, --检修模型编码
                                                V_V_JXMX_NAME        IN VARCHAR2, --检修模型名称
                                                V_V_ORGCODE          IN VARCHAR2, --单位编码
                                                V_V_DEPTCODE         IN VARCHAR2, --作业区编码
                                                V_V_EQUTYPECODE      IN VARCHAR2, --设备类型编码
                                                V_V_EQUCODE          IN VARCHAR2, --设备名称编码
                                                V_V_EQUCODE_CHILD    IN VARCHAR2, --子设备名称编码
                                                V_V_REPAIRMAJOR_CODE IN VARCHAR2, ---专业
                                                V_V_BZ               IN VARCHAR2, --备注
                                                V_V_HOUR             IN VARCHAR2, --时间
                                                V_V_IN_PER           IN VARCHAR2, --录入人
                                                V_V_IN_DATE          IN VARCHAR2, --录入时间
                                                V_V_MXBB_NUM         IN VARCHAR2, --模型版本号
                                                V_INFO               OUT VARCHAR2) IS

  /*
  检修模型管理修改和新增
  */
  V_NUMBER NUMBER;
begin

  SELECT COUNT(*)
    INTO V_NUMBER
    FROM PM_1917_JXMX_DATA D
   WHERE D.V_MX_CODE = V_V_JXMX_CODE;

  IF V_NUMBER = 1 THEN
    UPDATE PM_1917_JXMX_DATA D
       SET D.V_MX_NAME        = V_V_JXMX_NAME,
           D.V_ORGCODE        = V_V_ORGCODE,
           D.V_DEPTCODE       = V_V_DEPTCODE,
           D.V_EQUTYPE        = V_V_EQUTYPECODE,
           D.V_EQUCODE        = V_V_EQUCODE,
           D.V_EQUCODE_CHILD  = V_V_EQUCODE_CHILD,
           V_REPAIRMAJOR_CODE = V_V_REPAIRMAJOR_CODE,
           D.V_BZ             = V_V_BZ,
           D.V_HOUR           = V_V_HOUR,
           D.V_IN_DATE        = V_V_IN_DATE,
           D.V_IN_PER         = V_V_IN_PER,
           D.V_MXBB_NUM       = V_V_MXBB_NUM
     WHERE D.V_MX_CODE = V_V_JXMX_CODE;
  ELSE
    INSERT INTO PM_1917_JXMX_DATA
      (V_MX_CODE,
       V_MX_NAME,
       V_GX_CODE,
       V_ORGCODE,
       V_DEPTCODE,
       V_EQUTYPE,
       V_EQUCODE,
       V_EQUCODE_CHILD,
       V_REPAIRMAJOR_CODE,
       V_BZ,
       V_HOUR,
       V_IN_DATE,
       V_IN_PER,
       V_MXBB_NUM)
    VALUES
      (V_V_JXMX_CODE,
       V_V_JXMX_NAME,
       createguid(),
       V_V_ORGCODE,
       V_V_DEPTCODE,
       V_V_EQUTYPECODE,
       V_V_EQUCODE,
       V_V_EQUCODE_CHILD,
       V_V_REPAIRMAJOR_CODE,
       V_V_BZ,
       V_V_HOUR,
       V_V_IN_DATE,
       V_V_IN_PER,
       V_V_MXBB_NUM);
  END IF;

  V_INFO := 'SUCCESS';

EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

end BASE_JXMX_DATA_EDIT;
/

