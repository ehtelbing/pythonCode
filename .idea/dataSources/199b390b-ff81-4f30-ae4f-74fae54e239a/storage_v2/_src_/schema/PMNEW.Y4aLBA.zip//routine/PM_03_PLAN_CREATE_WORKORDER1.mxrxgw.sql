create PROCEDURE PM_03_PLAN_CREATE_WORKORDER1(V_V_GUID       IN VARCHAR2, --周计划编码，可多个周计划生成一个工单用逗号分隔
                                                         V_V_PERCODE    IN VARCHAR2,
                                                         V_INFO         OUT VARCHAR2,
                                                         V_V_ORDERGUID  OUT VARCHAR2,
                                                         V_V_SOURCECODE OUT VARCHAR2,
                                                         V_V_EQUTYPE    OUT VARCHAR2,
                                                         V_CURSOR       OUT SYS_REFCURSOR) IS
  /*周计划生成工单*/
  P_SPLIT_TABLE TYPE_SPLIT := NEW TYPE_SPLIT();
  V_RET         VARCHAR2(50);
  I_NUMBER      NUMBER;

  V_V_ORGCODE          VARCHAR2(50); --厂矿
  V_V_DEPTCODE         VARCHAR2(50); --作业区
  V_V_REPAIRCODE       VARCHAR2(50); --检修作业区
  V_V_EQUCODE          VARCHAR2(50); --设备编码
  V_V_EQUSITE          VARCHAR2(50); --设备位置
  V_V_REPAIRMAJOR_CODE VARCHAR2(50); --专业
  V_V_PERNAME          VARCHAR2(50);

  V_V_ORDER_TYPE    VARCHAR2(50);
  V_V_ORDER_TYP_TXT VARCHAR2(50);
  V_V_CONTENT       VARCHAR2(4000);

  V_V_ORDERID     VARCHAR2(50); --工单号
  V_D_ENTER_DATE  DATE; --输入时间
  V_V_WORK_AREA   VARCHAR2(50); --SAP作业区
  V_V_PLANNER     VARCHAR2(50); --SAP作业区计划组员
  V_V_DEFECT_GUID VARCHAR2(50); --缺陷GUID

  V_V_GSBER        VARCHAR2(50);
  V_V_GSBER_TXT    VARCHAR2(50);
  V_V_PLANT        VARCHAR2(50);
  V_V_IWERK        VARCHAR2(50);
  V_V_PLAN_CONTENT VARCHAR2(4000);

  V_V_FUNC_LOC   VARCHAR2(50); --功能位置
  V_V_EQUIP_NO   VARCHAR2(50); --设备编号
  V_V_EQUIP_NAME VARCHAR2(50); --设备名称

BEGIN

  BEGIN
  
    V_D_ENTER_DATE := TO_DATE(TO_CHAR(SYSDATE, 'yyyy/mm/dd hh24:mi:ss'),
                              'yyyy/mm/dd hh24:mi:ss'); --输入时间
  
    SELECT P.V_PERSONNAME
      INTO V_V_PERNAME
      FROM BASE_PERSON P
     WHERE P.V_PERSONCODE = V_V_PERCODE;
  
    V_V_SOURCECODE := 'defct13';
    V_V_ORDER_TYPE := 'AK05';
  
    --获取多个周计划检修内容，用逗号分隔
    V_RET := FUNC_SPLIT(V_V_GUID, ',', P_SPLIT_TABLE);
  
    --查看多少个周计划生成一张工单
    SELECT COUNT(*) INTO I_NUMBER FROM TABLE(P_SPLIT_TABLE);
  
    IF I_NUMBER = 0 THEN
      /*
      一个周计划生成一张工单
      查询周计划是否有在编辑状态的工单
      */
      SELECT COUNT(*)
        INTO I_NUMBER
        FROM PM_DEFECTTOWORKORDER P
       INNER JOIN PM_WORKORDER O
          ON P.V_WORKORDER_GUID = O.V_ORDERGUID
       WHERE P.V_WEEK_GUID = V_V_GUID
         AND O.V_STATECODE = '99'
         AND O.V_ORDER_TYP = V_V_ORDER_TYPE
         AND P.V_WORKFLAG NOT IN ('1');
    
      IF I_NUMBER = 0 THEN
      
        /*
        周计划没有在编辑状态的工单
         */
      
        --查询周计划是否由缺陷添加
        SELECT COUNT(*)
          INTO I_NUMBER
          FROM (SELECT P.V_DEFECT_GUID
                  FROM PM_DEFECTTOWORKORDER P
                 WHERE P.V_WEEK_GUID = V_V_GUID
                   AND P.V_WORKORDER_GUID IS NULL
                 GROUP BY P.V_DEFECT_GUID);
      
        IF I_NUMBER = 0 THEN
          --该周计划不是由缺陷添加，生成缺陷guid
          V_V_DEFECT_GUID := createguid();
          --生成工单guid
          V_V_ORDERGUID := createguid();
        
          --添加关系表
          INSERT INTO PM_DEFECTTOWORKORDER
            (V_WORKORDER_GUID, V_DEFECT_GUID, V_WEEK_GUID, V_WORKFLAG)
          VALUES
            (V_V_ORDERGUID, V_V_DEFECT_GUID, V_V_GUID, '0');
        
          --获取周计划信息
          SELECT W.V_EQUCODE,
                 W.V_ORGCODE,
                 W.V_DEPTCODE,
                 W.V_WORKORDER_GUID,
                 W.V_EQUTYPECODE,
                 W.V_REPAIRMAJOR_CODE,
                 W.V_CONTENT,
                 W.V_EQUCODE
            INTO V_V_EQUCODE,
                 V_V_ORGCODE,
                 V_V_DEPTCODE,
                 V_V_ORDERGUID,
                 V_V_EQUTYPE,
                 V_V_REPAIRMAJOR_CODE,
                 V_V_CONTENT,
                 V_V_EQUIP_NO
            FROM PM_03_PLAN_WEEK W
           WHERE W.V_GUID = V_V_GUID;
          --查询设备名称以及功能位置
          SELECT P.V_EQUNAME, P.V_EQUSITE
            INTO V_V_EQUIP_NAME, V_V_FUNC_LOC
            FROM SAP_PM_EQU_P P
           WHERE P.V_EQUCODE = V_V_EQUIP_NO;
        
          V_V_ORDERID := FUNC_GETWORKORDERORDERID(V_V_ORGCODE); --工单号
        
          --SAP作业区
          SELECT V_SAP_DEPT
            INTO V_V_WORK_AREA
            FROM BASE_DEPT
           WHERE V_DEPTCODE = V_V_DEPTCODE;
        
          --SAP作业区计划组员
          SELECT V_SAP_PER
            INTO V_V_PLANNER
            FROM SAP_PM_DEPT
           WHERE V_SAP_DEPT = V_V_WORK_AREA;
        
          --获取设备位置
          SELECT P.V_EQUSITE
            INTO V_V_EQUSITE
            FROM SAP_PM_EQU_P P
           WHERE P.V_EQUCODE = V_V_EQUCODE;
        
          --获取录入人
          SELECT B.V_PERSONNAME
            INTO V_V_PERNAME
            FROM BASE_PERSON B
           WHERE B.V_PERSONCODE = V_V_PERCODE;
        
          BEGIN
            SELECT BASE_DEPT.V_SAP_YWFW,
                   SAP_PM_YWFW.V_YWFWNAMELONG,
                   V_SAP_JHGC,
                   V_SAP_JHGC
              INTO V_V_GSBER, V_V_GSBER_TXT, V_V_PLANT, V_V_IWERK
              FROM BASE_DEPT, SAP_PM_YWFW
             WHERE SAP_PM_YWFW.V_YWFW = BASE_DEPT.V_SAP_YWFW
               AND (BASE_DEPT.V_DEPTCODE = SUBSTR(V_V_DEPTCODE, 0, 4));
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_INFO := '错误没有对应的业务范围';
              RETURN;
          END;
        
          SELECT P.ORDER_TYP_TXT
            INTO V_V_ORDER_TYP_TXT
            FROM PM_WORKORDER_TYP P
           WHERE P.ORDER_TYP = V_V_ORDER_TYPE;
        
          --写入缺陷表
          INSERT INTO PM_DEFECT
            (V_DEFECTLIST,
             V_SOURCECODE,
             D_DEFECTDATE,
             D_INDATE,
             V_PERCODE,
             V_PERNAME,
             V_DEPTCODE,
             V_EQUCODE,
             V_STATECODE,
             V_GUID,
             V_EQUSITE,
             V_INPERCODE,
             V_INPERNAME,
             V_EQUTYPECODE,
             V_ORGCODE,
             V_REPAIRMAJOR_CODE)
          VALUES
            (V_V_CONTENT,
             V_V_SOURCECODE,
             SYSDATE,
             SYSDATE,
             V_V_PERCODE,
             V_V_PERNAME,
             V_V_DEPTCODE,
             V_V_EQUCODE,
             10,
             V_V_DEFECT_GUID,
             V_V_EQUSITE,
             V_V_PERCODE,
             V_V_PERNAME,
             V_V_EQUTYPE,
             V_V_ORGCODE,
             V_V_REPAIRMAJOR_CODE);
        
          --写入工单主表信息
          INSERT INTO PM_WORKORDER
            (V_ORDERGUID,
             V_ORDERID,
             V_ORDER_TYP,
             V_ORDER_TYP_TXT,
             V_PLANNER, --计划组员
             V_GSBER,
             V_GSBER_TXT,
             V_WORK_AREA, --作业区
             V_ENTERED_BY,
             D_ENTER_DATE, --创建时间
             V_PLANT,
             V_IWERK,
             V_DEPTCODE,
             V_STATECODE,
             V_FUNC_LOC,
             V_EQUIP_NO,
             V_EQUIP_NAME,
             V_SHORT_TXT)
          VALUES
            (V_V_ORDERGUID,
             V_V_ORDERID,
             V_V_ORDER_TYPE,
             V_V_ORDER_TYP_TXT,
             V_V_PLANNER,
             V_V_GSBER,
             V_V_GSBER_TXT,
             V_V_WORK_AREA,
             V_V_PERCODE,
             V_D_ENTER_DATE,
             V_V_PLANT,
             V_V_IWERK,
             V_V_DEPTCODE,
             '99',
             V_V_FUNC_LOC,
             V_V_EQUIP_NO,
             V_V_EQUIP_NAME,
             V_V_CONTENT);
          --写入工单_其它信息表
          INSERT INTO PM_WORKORDER_OTHER
            (V_ORDERGUID, V_STATECODE, V_DEPTCODE)
          VALUES
            (V_V_ORDERGUID, '99', V_V_DEPTCODE);
          --写入缺陷处理日志
          PRO_PM_07_DEFECT_LOG_SET(V_V_DEFECT_GUID,
                                   V_V_PERNAME || '由周计划产生的缺陷生成工单(' ||
                                   V_V_ORDERID || '),工单状态为编辑中。',
                                   99,
                                   V_V_ORDERGUID,
                                   V_RET);
        
          OPEN V_CURSOR FOR
            SELECT I_ID,
                   V_ORDERGUID,
                   V_ORDERID,
                   V_ORDER_TYP,
                   V_ORDER_TYP_TXT,
                   V_FUNC_LOC,
                   V_EQUIP_NO,
                   V_EQUIP_NAME,
                   V_PLANT,
                   V_IWERK,
                   D_START_DATE,
                   D_FINISH_DATE,
                   V_ACT_TYPE,
                   V_PLANNER,
                   V_WORK_CTR,
                   V_SHORT_TXT,
                   V_GSBER,
                   V_GSBER_TXT,
                   V_WORK_AREA,
                   V_WBS,
                   V_WBS_TXT,
                   V_ENTERED_BY,
                   D_ENTER_DATE,
                   V_SYSTEM_STATUS,
                   V_SYSNAME,
                   V_ORGCODE,
                   V_ORGNAME,
                   V_DEPTCODE,
                   V_DEPTNAME,
                   V_DEPTCODEREPARIR,
                   V_DEPTNAMEREPARIR,
                   V_DEFECTGUID,
                   V_STATECODE,
                   V_STATENAME,
                   V_TOOL,
                   V_TECHNOLOGY,
                   V_SAFE,
                   D_DATE_ACP, --验收日期
                   I_OTHERHOUR, --提前/逾期时间
                   V_OTHERREASON, --逾期原因
                   V_REPAIRCONTENT, --检修方说明
                   V_REPAIRSIGN, --检修方签字
                   V_REPAIRPERSON, --检修人员
                   V_POSTMANSIGN, --岗位签字
                   V_CHECKMANCONTENT, --点检员验收意见
                   V_CHECKMANSIGN, --点检员签字
                   V_WORKSHOPCONTENT, --作业区验收
                   V_WORKSHOPSIGN, --作业区签字
                   V_DEPTSIGN --部门签字
              FROM VIEW_PM_WORKORDER
             WHERE V_ORDERGUID = V_V_ORDERGUID;
        
        ELSE
          --该周计划由缺陷添加,同时该周计划无编辑状态的工单
        
          --生成工单guid
          V_V_ORDERGUID := createguid();
        
          --向关系表添加工单，缺陷，周计划guid
        
          FOR C IN (SELECT P.V_DEFECT_GUID
                      FROM PM_DEFECTTOWORKORDER P
                     WHERE P.V_WEEK_GUID = V_V_GUID
                       AND P.V_WORKORDER_GUID IS NULL) LOOP
          
            INSERT INTO PM_DEFECTTOWORKORDER
              (V_WORKORDER_GUID, V_DEFECT_GUID, V_WEEK_GUID, V_WORKFLAG)
            VALUES
              (V_V_ORDERGUID, C.V_DEFECT_GUID, V_V_GUID, '0');
          
            --修改缺陷状态
            UPDATE PM_DEFECT D
               SET D.V_STATECODE = '50'
             WHERE D.V_GUID = C.V_DEFECT_GUID;
          
            --写入缺陷处理日志
            PRO_PM_07_DEFECT_LOG_SET(C.V_DEFECT_GUID,
                                     V_V_PERNAME || '由缺陷生成的周计划生成工单(' ||
                                     V_V_ORDERID || '),工单状态为编辑中。',
                                     99,
                                     V_V_ORDERGUID,
                                     V_RET);
          
          END LOOP;
        
          --获取周计划信息
          SELECT W.V_EQUCODE,
                 W.V_ORGCODE,
                 W.V_DEPTCODE,
                 W.V_WORKORDER_GUID,
                 W.V_EQUTYPECODE,
                 W.V_REPAIRMAJOR_CODE,
                 W.V_CONTENT,
                 W.V_EQUCODE
            INTO V_V_EQUCODE,
                 V_V_ORGCODE,
                 V_V_DEPTCODE,
                 V_V_ORDERGUID,
                 V_V_EQUTYPE,
                 V_V_REPAIRMAJOR_CODE,
                 V_V_CONTENT,
                 V_V_EQUIP_NO
            FROM PM_03_PLAN_WEEK W
           WHERE W.V_GUID = V_V_GUID;
          --查询设备名称以及功能位置
          SELECT P.V_EQUNAME, P.V_EQUSITE
            INTO V_V_EQUIP_NAME, V_V_FUNC_LOC
            FROM SAP_PM_EQU_P P
           WHERE P.V_EQUCODE = V_V_EQUIP_NO;
        
          V_V_ORDERID := FUNC_GETWORKORDERORDERID(V_V_ORGCODE); --工单号
        
          --SAP作业区
          SELECT V_SAP_DEPT
            INTO V_V_WORK_AREA
            FROM BASE_DEPT
           WHERE V_DEPTCODE = V_V_DEPTCODE;
        
          --SAP作业区计划组员
          SELECT V_SAP_PER
            INTO V_V_PLANNER
            FROM SAP_PM_DEPT
           WHERE V_SAP_DEPT = V_V_WORK_AREA;
        
          --获取设备位置
          SELECT P.V_EQUSITE
            INTO V_V_EQUSITE
            FROM SAP_PM_EQU_P P
           WHERE P.V_EQUCODE = V_V_EQUCODE;
        
          --获取录入人
          SELECT B.V_PERSONNAME
            INTO V_V_PERNAME
            FROM BASE_PERSON B
           WHERE B.V_PERSONCODE = V_V_PERCODE;
        
          BEGIN
            SELECT BASE_DEPT.V_SAP_YWFW,
                   SAP_PM_YWFW.V_YWFWNAMELONG,
                   V_SAP_JHGC,
                   V_SAP_JHGC
              INTO V_V_GSBER, V_V_GSBER_TXT, V_V_PLANT, V_V_IWERK
              FROM BASE_DEPT, SAP_PM_YWFW
             WHERE SAP_PM_YWFW.V_YWFW = BASE_DEPT.V_SAP_YWFW
               AND (BASE_DEPT.V_DEPTCODE = SUBSTR(V_V_DEPTCODE, 0, 4));
          EXCEPTION
            WHEN NO_DATA_FOUND THEN
              V_INFO := '错误没有对应的业务范围';
              RETURN;
          END;
        
          SELECT P.ORDER_TYP_TXT
            INTO V_V_ORDER_TYP_TXT
            FROM PM_WORKORDER_TYP P
           WHERE P.ORDER_TYP = V_V_ORDER_TYPE;
        
          --写入工单主表信息
          INSERT INTO PM_WORKORDER
            (V_ORDERGUID,
             V_ORDERID,
             V_ORDER_TYP,
             V_ORDER_TYP_TXT,
             V_PLANNER, --计划组员
             V_GSBER,
             V_GSBER_TXT,
             V_WORK_AREA, --作业区
             V_ENTERED_BY,
             D_ENTER_DATE, --创建时间
             V_PLANT,
             V_IWERK,
             V_DEPTCODE,
             V_STATECODE,
             V_FUNC_LOC,
             V_EQUIP_NO,
             V_EQUIP_NAME,
             V_SHORT_TXT)
          VALUES
            (V_V_ORDERGUID,
             V_V_ORDERID,
             V_V_ORDER_TYPE,
             V_V_ORDER_TYP_TXT,
             V_V_PLANNER,
             V_V_GSBER,
             V_V_GSBER_TXT,
             V_V_WORK_AREA,
             V_V_PERCODE,
             V_D_ENTER_DATE,
             V_V_PLANT,
             V_V_IWERK,
             V_V_DEPTCODE,
             '99',
             V_V_FUNC_LOC,
             V_V_EQUIP_NO,
             V_V_EQUIP_NAME,
             V_V_CONTENT);
          --写入工单_其它信息表
          INSERT INTO PM_WORKORDER_OTHER
            (V_ORDERGUID, V_STATECODE, V_DEPTCODE)
          VALUES
            (V_V_ORDERGUID, '99', V_V_DEPTCODE);
        
          OPEN V_CURSOR FOR
            SELECT I_ID,
                   V_ORDERGUID,
                   V_ORDERID,
                   V_ORDER_TYP,
                   V_ORDER_TYP_TXT,
                   V_FUNC_LOC,
                   V_EQUIP_NO,
                   V_EQUIP_NAME,
                   V_PLANT,
                   V_IWERK,
                   D_START_DATE,
                   D_FINISH_DATE,
                   V_ACT_TYPE,
                   V_PLANNER,
                   V_WORK_CTR,
                   V_SHORT_TXT,
                   V_GSBER,
                   V_GSBER_TXT,
                   V_WORK_AREA,
                   V_WBS,
                   V_WBS_TXT,
                   V_ENTERED_BY,
                   D_ENTER_DATE,
                   V_SYSTEM_STATUS,
                   V_SYSNAME,
                   V_ORGCODE,
                   V_ORGNAME,
                   V_DEPTCODE,
                   V_DEPTNAME,
                   V_DEPTCODEREPARIR,
                   V_DEPTNAMEREPARIR,
                   V_DEFECTGUID,
                   V_STATECODE,
                   V_STATENAME,
                   V_TOOL,
                   V_TECHNOLOGY,
                   V_SAFE,
                   D_DATE_ACP, --验收日期
                   I_OTHERHOUR, --提前/逾期时间
                   V_OTHERREASON, --逾期原因
                   V_REPAIRCONTENT, --检修方说明
                   V_REPAIRSIGN, --检修方签字
                   V_REPAIRPERSON, --检修人员
                   V_POSTMANSIGN, --岗位签字
                   V_CHECKMANCONTENT, --点检员验收意见
                   V_CHECKMANSIGN, --点检员签字
                   V_WORKSHOPCONTENT, --作业区验收
                   V_WORKSHOPSIGN, --作业区签字
                   V_DEPTSIGN --部门签字
              FROM VIEW_PM_WORKORDER
             WHERE V_ORDERGUID = V_V_ORDERGUID;
        
        END IF;
      
      ELSE
      
        --获取工单guid
      
        SELECT P.V_WORKORDER_GUID
          INTO V_V_ORDERGUID
          FROM PM_DEFECTTOWORKORDER P
         INNER JOIN PM_WORKORDER O
            ON P.V_WORKORDER_GUID = O.V_ORDERGUID
         WHERE P.V_WEEK_GUID = V_V_GUID
           AND O.V_STATECODE = '99'
           AND O.V_ORDER_TYP = V_V_ORDER_TYPE
           AND P.V_WORKFLAG NOT IN ('1');
      
        UPDATE PM_WORKORDER
           SET D_ENTER_DATE = V_D_ENTER_DATE
         WHERE V_ORDERGUID = V_V_ORDERGUID;
      
        OPEN V_CURSOR FOR
          SELECT I_ID,
                 V_ORDERGUID,
                 V_ORDERID,
                 V_ORDER_TYP,
                 V_ORDER_TYP_TXT,
                 V_FUNC_LOC,
                 V_EQUIP_NO,
                 V_EQUIP_NAME,
                 V_PLANT,
                 V_IWERK,
                 D_START_DATE,
                 D_FINISH_DATE,
                 V_ACT_TYPE,
                 V_PLANNER,
                 V_WORK_CTR,
                 V_SHORT_TXT,
                 V_GSBER,
                 V_GSBER_TXT,
                 V_WORK_AREA,
                 V_WBS,
                 V_WBS_TXT,
                 V_ENTERED_BY,
                 D_ENTER_DATE,
                 V_SYSTEM_STATUS,
                 V_SYSNAME,
                 V_ORGCODE,
                 V_ORGNAME,
                 V_DEPTCODE,
                 V_DEPTNAME,
                 V_DEPTCODEREPARIR,
                 V_DEPTNAMEREPARIR,
                 V_DEFECTGUID,
                 V_STATECODE,
                 V_STATENAME,
                 V_TOOL,
                 V_TECHNOLOGY,
                 V_SAFE,
                 D_DATE_ACP, --验收日期
                 I_OTHERHOUR, --提前/逾期时间
                 V_OTHERREASON, --逾期原因
                 V_REPAIRCONTENT, --检修方说明
                 V_REPAIRSIGN, --检修方签字
                 V_REPAIRPERSON, --检修人员
                 V_POSTMANSIGN, --岗位签字
                 V_CHECKMANCONTENT, --点检员验收意见
                 V_CHECKMANSIGN, --点检员签字
                 V_WORKSHOPCONTENT, --作业区验收
                 V_WORKSHOPSIGN, --作业区签字
                 V_DEPTSIGN --部门签字
            FROM VIEW_PM_WORKORDER
           WHERE V_ORDERGUID = V_V_ORDERGUID;
      END IF;
    
    ELSE
      /*多个周计划生成一张工单*/
    
      --删除该多个周计划工单在编辑状态，并且V_WORKFLAG为1的数据
    
      FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP
      
        SELECT P.V_WORKORDER_GUID, P.V_DEFECT_GUID
          INTO V_V_ORDERGUID, V_V_DEFECT_GUID
          FROM PM_DEFECTTOWORKORDER P
         INNER JOIN PM_WORKORDER O
            ON P.V_WORKORDER_GUID = O.V_ORDERGUID
         WHERE P.V_WEEK_GUID = C.COLUMN_VALUE
           AND O.V_STATECODE = '99'
           AND O.V_ORDER_TYP = V_V_ORDER_TYPE
           AND P.V_WORKFLAG = '1';
      
        DELETE FROM PM_DEFECTTOWORKORDER P
         WHERE P.V_WORKORDER_GUID = V_V_ORDERGUID
           AND P.V_DEFECT_GUID = V_V_DEFECT_GUID
           AND P.V_WEEK_GUID = C.COLUMN_VALUE
           AND P.V_WORKFLAG = '1';
        DELETE FROM PM_WORKORDER W WHERE W.V_ORDERGUID = V_V_ORDERGUID;
        DELETE FROM PM_WORKORDER_OTHER W
         WHERE W.V_ORDERGUID = V_V_ORDERGUID;
        DELETE FROM PM_DEFECT D WHERE D.V_GUID = V_V_DEFECT_GUID;
      
      END LOOP;
    
      V_V_ORDERGUID   := CREATEGUID();
      V_V_DEFECT_GUID := CREATEGUID();
      --重新添加关系表
      FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP
      
        INSERT INTO PM_DEFECTTOWORKORDER
          (V_WORKORDER_GUID, V_DEFECT_GUID, V_WEEK_GUID, V_WORKFLAG)
        VALUES
          (V_V_ORDERGUID, V_V_DEFECT_GUID, C.COLUMN_VALUE, '1');
      END LOOP;
    
      FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP
        IF V_V_CONTENT IS NULL OR V_V_CONTENT = '' THEN
          SELECT W.V_EQUCODE,
                 W.V_ORGCODE,
                 W.V_DEPTCODE,
                 W.V_WORKORDER_GUID,
                 W.V_EQUTYPECODE,
                 W.V_REPAIRMAJOR_CODE,
                 W.V_CONTENT,
                 W.V_EQUCODE
            INTO V_V_EQUCODE,
                 V_V_ORGCODE,
                 V_V_DEPTCODE,
                 V_V_ORDERGUID,
                 V_V_EQUTYPE,
                 V_V_REPAIRMAJOR_CODE,
                 V_V_PLAN_CONTENT,
                 V_V_EQUIP_NO
            FROM PM_03_PLAN_WEEK W
           WHERE W.V_GUID = C.COLUMN_VALUE;
          V_V_CONTENT := V_V_PLAN_CONTENT;
        ELSE
          SELECT W.V_CONTENT
            INTO V_V_PLAN_CONTENT
            FROM PM_03_PLAN_WEEK W
           WHERE W.V_GUID = C.COLUMN_VALUE;
          V_V_CONTENT := V_V_CONTENT || ',' || V_V_PLAN_CONTENT;
        END IF;
      END LOOP;
    
      --查询设备名称以及功能位置
      SELECT P.V_EQUNAME, P.V_EQUSITE
        INTO V_V_EQUIP_NAME, V_V_FUNC_LOC
        FROM SAP_PM_EQU_P P
       WHERE P.V_EQUCODE = V_V_EQUIP_NO;
    
      V_V_ORDERID := FUNC_GETWORKORDERORDERID(V_V_ORGCODE); --工单号
    
      --SAP作业区
      SELECT V_SAP_DEPT
        INTO V_V_WORK_AREA
        FROM BASE_DEPT
       WHERE V_DEPTCODE = V_V_DEPTCODE;
    
      --SAP作业区计划组员
      SELECT V_SAP_PER
        INTO V_V_PLANNER
        FROM SAP_PM_DEPT
       WHERE V_SAP_DEPT = V_V_WORK_AREA;
    
      --获取设备位置
      SELECT P.V_EQUSITE
        INTO V_V_EQUSITE
        FROM SAP_PM_EQU_P P
       WHERE P.V_EQUCODE = V_V_EQUCODE;
    
      --获取录入人
      SELECT B.V_PERSONNAME
        INTO V_V_PERNAME
        FROM BASE_PERSON B
       WHERE B.V_PERSONCODE = V_V_PERCODE;
    
      BEGIN
        SELECT BASE_DEPT.V_SAP_YWFW,
               SAP_PM_YWFW.V_YWFWNAMELONG,
               V_SAP_JHGC,
               V_SAP_JHGC
          INTO V_V_GSBER, V_V_GSBER_TXT, V_V_PLANT, V_V_IWERK
          FROM BASE_DEPT, SAP_PM_YWFW
         WHERE SAP_PM_YWFW.V_YWFW = BASE_DEPT.V_SAP_YWFW
           AND (BASE_DEPT.V_DEPTCODE = SUBSTR(V_V_DEPTCODE, 0, 4));
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_INFO := '错误没有对应的业务范围';
          RETURN;
      END;
    
      SELECT P.ORDER_TYP_TXT
        INTO V_V_ORDER_TYP_TXT
        FROM PM_WORKORDER_TYP P
       WHERE P.ORDER_TYP = V_V_ORDER_TYPE;
    
      --写入缺陷表
      INSERT INTO PM_DEFECT
        (V_DEFECTLIST,
         V_SOURCECODE,
         D_DEFECTDATE,
         D_INDATE,
         V_PERCODE,
         V_PERNAME,
         V_DEPTCODE,
         V_EQUCODE,
         V_STATECODE,
         V_GUID,
         V_EQUSITE,
         V_INPERCODE,
         V_INPERNAME,
         V_EQUTYPECODE,
         V_ORGCODE,
         V_REPAIRMAJOR_CODE)
      VALUES
        (V_V_CONTENT,
         V_V_SOURCECODE,
         SYSDATE,
         SYSDATE,
         V_V_PERCODE,
         V_V_PERNAME,
         V_V_DEPTCODE,
         V_V_EQUCODE,
         10,
         V_V_DEFECT_GUID,
         V_V_EQUSITE,
         V_V_PERCODE,
         V_V_PERNAME,
         V_V_EQUTYPE,
         V_V_ORGCODE,
         V_V_REPAIRMAJOR_CODE);
    
      --写入工单主表信息
      INSERT INTO PM_WORKORDER
        (V_ORDERGUID,
         V_ORDERID,
         V_ORDER_TYP,
         V_ORDER_TYP_TXT,
         V_PLANNER, --计划组员
         V_GSBER,
         V_GSBER_TXT,
         V_WORK_AREA, --作业区
         V_ENTERED_BY,
         D_ENTER_DATE, --创建时间
         V_PLANT,
         V_IWERK,
         V_DEPTCODE,
         V_STATECODE,
         V_FUNC_LOC,
         V_EQUIP_NO,
         V_EQUIP_NAME,
         V_SHORT_TXT)
      VALUES
        (V_V_ORDERGUID,
         V_V_ORDERID,
         V_V_ORDER_TYPE,
         V_V_ORDER_TYP_TXT,
         V_V_PLANNER,
         V_V_GSBER,
         V_V_GSBER_TXT,
         V_V_WORK_AREA,
         V_V_PERCODE,
         V_D_ENTER_DATE,
         V_V_PLANT,
         V_V_IWERK,
         V_V_DEPTCODE,
         '99',
         V_V_FUNC_LOC,
         V_V_EQUIP_NO,
         V_V_EQUIP_NAME,
         V_V_CONTENT);
      --写入工单_其它信息表
      INSERT INTO PM_WORKORDER_OTHER
        (V_ORDERGUID, V_STATECODE, V_DEPTCODE)
      VALUES
        (V_V_ORDERGUID, '99', V_V_DEPTCODE);
      --写入缺陷处理日志
      PRO_PM_07_DEFECT_LOG_SET(V_V_DEFECT_GUID,
                               V_V_PERNAME || '由周计划产生的缺陷生成工单(' ||
                               V_V_ORDERID || '),工单状态为编辑中。',
                               99,
                               V_V_ORDERGUID,
                               V_RET);
    
      OPEN V_CURSOR FOR
        SELECT I_ID,
               V_ORDERGUID,
               V_ORDERID,
               V_ORDER_TYP,
               V_ORDER_TYP_TXT,
               V_FUNC_LOC,
               V_EQUIP_NO,
               V_EQUIP_NAME,
               V_PLANT,
               V_IWERK,
               D_START_DATE,
               D_FINISH_DATE,
               V_ACT_TYPE,
               V_PLANNER,
               V_WORK_CTR,
               V_SHORT_TXT,
               V_GSBER,
               V_GSBER_TXT,
               V_WORK_AREA,
               V_WBS,
               V_WBS_TXT,
               V_ENTERED_BY,
               D_ENTER_DATE,
               V_SYSTEM_STATUS,
               V_SYSNAME,
               V_ORGCODE,
               V_ORGNAME,
               V_DEPTCODE,
               V_DEPTNAME,
               V_DEPTCODEREPARIR,
               V_DEPTNAMEREPARIR,
               V_DEFECTGUID,
               V_STATECODE,
               V_STATENAME,
               V_TOOL,
               V_TECHNOLOGY,
               V_SAFE,
               D_DATE_ACP, --验收日期
               I_OTHERHOUR, --提前/逾期时间
               V_OTHERREASON, --逾期原因
               V_REPAIRCONTENT, --检修方说明
               V_REPAIRSIGN, --检修方签字
               V_REPAIRPERSON, --检修人员
               V_POSTMANSIGN, --岗位签字
               V_CHECKMANCONTENT, --点检员验收意见
               V_CHECKMANSIGN, --点检员签字
               V_WORKSHOPCONTENT, --作业区验收
               V_WORKSHOPSIGN, --作业区签字
               V_DEPTSIGN --部门签字
          FROM VIEW_PM_WORKORDER
         WHERE V_ORDERGUID = V_V_ORDERGUID;
    
    END IF;
  
  END;

END PM_03_PLAN_CREATE_WORKORDER1;
/

