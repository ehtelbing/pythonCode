create package BODY pg_mm_split_string is
  function get_substr(a_source    varchar2,
                      a_splitchar varchar2,
                      ret         out MM_STRINGLIST) return varchar2 is
    p_split_table  MM_STRINGLIST := new MM_STRINGLIST();
    p_source_count number(4, 0) := 0;
    p_last_count   number(4, 0) := 0;
    p_cur_count    number(4, 0) := 0;
    p_temp_substr  varchar2(200);
    p_ret          varchar2(10) := 'Fail';
  begin
    if length(a_source) > 0 and length(a_splitchar) = 1 and
       a_splitchar is not null then
      p_source_count := length(a_source);
      for i in 1 .. p_source_count loop
        p_cur_count := i;
        if substr(a_source, i, 1) = a_splitchar then
          p_temp_substr := substr(a_source,
                                  p_last_count + 1,
                                  i - p_last_count - 1);
          p_split_table.extend;
          p_split_table(p_split_table.last) := p_temp_substr;
          p_last_count := i;
        else
          null;
        end if;
      end loop;
      if substr(a_source, p_cur_count, 1) <> a_splitchar then
        p_temp_substr := substr(a_source,
                                p_last_count + 1,
                                p_cur_count - p_last_count);
        p_split_table.extend;
        p_split_table(p_split_table.last) := p_temp_substr;
      end if;
      p_ret := 'Success';
    end if;
    ret := p_split_table;
       for j in (select column_value from table(ret)) loop
      dbms_output.put_line(j.column_value);
    end loop;
    return p_ret;
  end;
  function deletezero(a_source varchar2, a_dircetion varchar2)
    return varchar2 is
    p_ret varchar2(2000);
  begin
    if a_dircetion = 'b' then
      for i in 1 .. length(a_source) loop
        if substr(a_source, i, 1) <> '0' then
          p_ret := substr(a_source, i, length(a_source));
          exit;
        end if;
      end loop;
    else
      null;
    end if;
    return p_ret;
  end;
end pg_mm_split_string;
/

