create PROCEDURE FIXED_ASSETS_SEL(V_V_ORG_CODE    IN VARCHAR2, --厂矿（单位）编码
                                             V_V_ASSETS_CODE IN VARCHAR2, --资产编码
                                             V_V_ASSETS_NAME IN VARCHAR2, --资产名称
                                             V_V_PAGE        IN VARCHAR2, --页数
                                             V_V_PAGESIZE    IN VARCHAR2, --每页显示条数
                                             V_V_SNUM        OUT VARCHAR2, --返回总条数
                                             V_CURSOR        OUT SYS_REFCURSOR) IS
  /*查询固定资产表*/
BEGIN
  SELECT COUNT(*)
    INTO V_V_SNUM
    FROM FIXED_ASSETS
   WHERE V_ORG_NAME LIKE '%' || V_V_ORG_CODE || '%'
     AND V_ASSETS_CODE LIKE '%' || V_V_ASSETS_CODE || '%'
     AND V_ASSETS_NAME LIKE '%' || V_V_ASSETS_NAME || '%';
  OPEN V_CURSOR FOR
    SELECT D.*
      FROM (SELECT C.*, rownum as rn
              FROM (SELECT *
                      FROM FIXED_ASSETS
                     WHERE V_ORG_NAME LIKE '%' || V_V_ORG_CODE || '%'
                       AND V_ASSETS_CODE LIKE '%' || V_V_ASSETS_CODE || '%'
                       AND V_ASSETS_NAME LIKE '%' || V_V_ASSETS_NAME || '%'
                     ORDER BY V_ASSETS_CODE) C
             WHERE rownum <= V_V_PAGE * V_V_PAGESIZE) D
     WHERE D.rn > (V_V_PAGE - 1) * V_V_PAGESIZE;
END FIXED_ASSETS_SEL;
/

