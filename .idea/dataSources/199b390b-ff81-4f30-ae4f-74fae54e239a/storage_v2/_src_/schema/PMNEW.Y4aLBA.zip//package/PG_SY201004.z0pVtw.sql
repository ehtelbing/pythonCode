create package PG_SY201004 is
  --断路器实验
  --1，查询
  procedure pro_sy201004_onedetail(recordcode_in in varchar2, --记录ID
                                   v_cursor      out sys_refcursor);
  --1，添加
  procedure pro_sy201004_oneadd(usercode_in     varchar2, --登录人
                                username_in     varchar2, --登录人姓名
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿
                                departcode_in   varchar2, --部门
                                plantname_in    varchar2, --厂矿名称
                                departname_in   varchar2, --部门名称

                                sydate_in           DATE, --实验时间
                                syloccode_in        varchar2, --实验地点编码
                                sylocname_in        varchar2, --实验地点名称
                                syequcode_in        varchar2, --实验设备编码
                                syequname_in        varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN    VARCHAR2,
                                SYEQUTYPTNAME_IN    VARCHAR2,
                                SYWEATHER_in        varchar2, --天气
                                sytemp_in           number, --气温
                                syreason_in         varchar2, --实验原因
                                SYVERDICT_in        varchar2, --结论
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,

                                v_dlqcode        varchar2, --断路器号
                                v_dlqmake        varchar2, --制造商
                                v_dlqtype        varchar2, --型号
                                v_dlqrl          varchar2, --遮断容量
                                v_dlqkv          varchar2, --定额电压
                                v_dlqa           varchar2, --定额电流
                                v_dlqoutdate     date, --出厂时间
                                make_date_in     date, --制造日期
                                outplant_date_in date, -- 出厂日期
                                ret              out varchar2,
                                v_info           out varchar2,
                                v_info1          out varchar2,
                                v_info2          out varchar2);
  --1.更新
  procedure pro_sy201004_oneupdate(recordcode_in       varchar2, --记录id
                                   usercode_in         varchar2, --登录人
                                   username_in         varchar2, --登录人姓名
                                   sydate_in           DATE, --实验时间
                                   syloccode_in        varchar2, --实验地点编码
                                   sylocname_in        varchar2, --实验地点名称
                                   syequcode_in        varchar2, --实验设备编码
                                   syequname_in        varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN    VARCHAR2,
                                   SYEQUTYPTNAME_IN    VARCHAR2,
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温 12.3
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,

                                   v_dlqcode        varchar2, --断路器号
                                   v_dlqmake        varchar2, --制造商
                                   v_dlqtype        varchar2, --型号
                                   v_dlqrl          varchar2, --遮断容量
                                   v_dlqkv          varchar2, --定额电压
                                   v_dlqa           varchar2, --定额电流
                                   v_dlqoutdate     date, --出厂时间
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, -- 出厂日期
                                   ret              out varchar2);
  --2,查询
  procedure pro_sy201004_twodetail(recordcode_in varchar2, --记录ID
                                   v_cursor      out sys_refcursor);
  --2.添加
  procedure pro_sy201004_twoadd(recordcode_in varchar2, --记录ID
                                v_yqxs        varchar2, --仪器型式
                                v_yqbh        varchar2, --编码
                                v_a1          number, --A绝缘电阻1
                                v_a2          number, --A绝缘电阻2
                                v_b1          number, --B绝缘电阻1
                                v_b2          number, --B绝缘电阻2
                                v_c1          number, --C绝缘电阻1
                                v_c2          number, --C绝缘电阻2
                                v_a3          number, --A绝缘电阻3
                                v_b3          number, --B绝缘电阻3
                                v_c3          number, --C绝缘电阻3
                                --v_opuser      varchar2, --操作人
                                -- v_recordrduser varchar2, --记录人
                                --v_jxuser varchar2, --接线人
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2);
  --2.修改
  procedure pro_sy201004_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2, --记录ID
                                   v_yqxs        varchar2, --仪器型式
                                   v_yqbh        varchar2, --编码
                                   v_a1          number, --A绝缘电阻1
                                   v_a2          number, --A绝缘电阻2
                                   v_b1          number, --B绝缘电阻1
                                   v_b2          number, --B绝缘电阻2
                                   v_c1          number, --C绝缘电阻1
                                   v_c2          number, --C绝缘电阻2
                                   v_a3          number, --A绝缘电阻3
                                   v_b3          number, --B绝缘电阻3
                                   v_c3          number, --C绝缘电阻3
                                   -- v_opuser      varchar2, --操作人
                                   --v_recordrduser varchar2, --记录人
                                   --v_jxuser varchar2, --接线人
                                   ret out varchar2);
  --断路器接触电阻
  --3,查询
  procedure pro_sy201004_threedetail(recordcode_in varchar2, --记录ID
                                     v_cursor      out sys_refcursor);
  --3，添加
  procedure pro_sy201004_threeadd(recordcode_in varchar2, --记录ID
                                  v_yqxs        varchar2, --仪器型式
                                  v_yqbh        varchar2, --编码
                                  v_ads         number,
                                  v_bds         number,
                                  v_cds         number,
                                  v_abl         number,
                                  v_bbl         number,
                                  v_cbl         number,
                                  v_ascz        number,
                                  v_bscz        number,
                                  v_cscz        number,
                                  --  v_opuser      varchar2, --操作人
                                  -- v_recorduser  varchar2, --记录人
                                  -- v_jxuser varchar2, --接线人
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2);
  --3,更新
  procedure pro_sy201004_threeupdate(v_id          varchar2,
                                     recordcode_in varchar2,
                                     v_yqxs        varchar2, --仪器型式
                                     v_yqbh        varchar2, --编码
                                     v_ads         number,
                                     v_bds         number,
                                     v_cds         number,
                                     v_abl         number,
                                     v_bbl         number,
                                     v_cbl         number,
                                     v_ascz        number,
                                     v_bscz        number,
                                     v_cscz        number,
                                     --v_opuser      varchar2, --操作人
                                     -- v_recorduser  varchar2, --记录人
                                     --v_jxuser varchar2, --接线人
                                     ret out varchar2);
  --4 工频耐压试验数据
  --4,查询
  procedure pro_sy201004_fourdetail(recordcode_in varchar2, --记录ID
                                    v_cursor      out sys_refcursor);
  --4，添加
  procedure pro_sy201004_fouradd(recordcode_in varchar2, --记录ID
                                 v_yqxs        varchar2,
                                 v_yqbh        varchar2,
                                 v_hzv         number,
                                 v_hza         number,
                                 v_hzt         number,
                                 v_fzv         number,
                                 v_fza         number,
                                 v_fzt         number,
                                 v_xjv         number,
                                 v_xja         number,
                                 v_xjt         number,
                                 --v_opuser      varchar2, --操作人
                                 --v_recorduser  varchar2, --记录人
                                 --v_jxuser varchar2, --接线人
                                 ret     out varchar2,
                                 v_info  out varchar2,
                                 v_info1 out varchar2,
                                 v_info2 out varchar2);
  --4,更新
  procedure pro_sy201004_fourupdate(v_id          varchar2,
                                    recordcode_in varchar2, --记录ID
                                    v_yqxs        varchar2,
                                    v_yqbh        varchar2,
                                    v_hzv         number,
                                    v_hza         number,
                                    v_hzt         number,
                                    v_fzv         number,
                                    v_fza         number,
                                    v_fzt         number,
                                    v_xjv         number,
                                    v_xja         number,
                                    v_xjt         number,
                                    -- v_opuser      varchar2, --操作人
                                    --v_recorduser  varchar2, --记录人
                                    -- v_jxuser varchar2, --接线人
                                    ret out varchar2);
end PG_SY201004;
/

