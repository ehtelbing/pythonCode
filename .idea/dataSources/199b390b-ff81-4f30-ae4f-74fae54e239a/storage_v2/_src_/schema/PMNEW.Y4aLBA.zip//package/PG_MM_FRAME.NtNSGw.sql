create PACKAGE PG_MM_FRAME
/*
说明：框架数据操作
*/
 IS
  --p_default_urlprefix varchar2(128) := pg_mm_sysporperty.get_porpvalue('sys-url-prefix',
    --                                                                   'all');
  --获取用户菜单
  FUNCTION GET_USER_MENU(A_USERID    VARCHAR2,
                         A_UP_MENUID VARCHAR2,
                         RET         OUT SYS_REFCURSOR) RETURN VARCHAR2;
  --获取用户菜单
  FUNCTION GET_USER_MENU_bysystem(A_USERID     VARCHAR2,
                                  A_UP_MENUID  VARCHAR2,
                                  a_systemname varchar2,
                                  RET          OUT SYS_REFCURSOR)
    RETURN VARCHAR2;
  --获取用户收藏链接
  FUNCTION GET_USER_FAVORITE(A_USERID VARCHAR2, RET OUT SYS_REFCURSOR)
    RETURN VARCHAR2;
  FUNCTION GET_USER_FAVORITE_bysystem(A_USERID     VARCHAR2,
                                      a_systemname varchar2,
                                      RET          OUT SYS_REFCURSOR)
    RETURN VARCHAR2;
  --添加,删除收藏
  FUNCTION OP_FAVORITE(A_USERID VARCHAR2 --用户ID
                      ,
                       A_MENUID VARCHAR2 --菜单Id
                      ,
                       A_OP     VARCHAR2) RETURN VARCHAR2;
  --设置首页：
  FUNCTION SETHOMEPAGE(A_USERID VARCHAR2 --用户ID
                      ,
                       A_MENUID VARCHAR2 --菜单Id
                       ) RETURN VARCHAR2;
  --首页：
  FUNCTION GETEHOMEPAGE(A_USERID VARCHAR2 --用户ID
                        ) RETURN VARCHAR2;
  FUNCTION GETEHOMEPAGE_sysname(A_USERID  VARCHAR2, --用户ID
                                a_sysname varchar2) RETURN VARCHAR2;
  --修改密码
  FUNCTION UPDATEPWD(A_USERID  VARCHAR2 --用户ID
                    ,
                     A_OLD_PWD VARCHAR2 --旧密码
                    ,
                     A_NEW_PWD VARCHAR2 --新密码
                     ) RETURN VARCHAR2;
  --查询最近登录用户ID
  function get_last_login_user(a_ip     varchar2, --IP
                               a_userid varchar2, --登录名
                               ret      out sys_refcursor) return varchar2;
END PG_MM_FRAME;
/

