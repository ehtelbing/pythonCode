create package BODY pg_dj602 is
  --退回工单到上一步
  procedure rollbacktoprestep(a_orderid  varchar2, --工单号
                              a_userid   varchar2, --用户ID
                              a_username varchar2, --用户名
                              ret_msg    out varchar2,
                              ret        out varchar2) is
    p_cur_status dj_order.order_status%type;
    p_pre_status dj_order_status.order_status%type;
  begin
    ret := 'Fail';
    select o.order_status
      into p_cur_status
      from dj_order o
     where o.orderid = a_orderid;
    select s.order_status
      into p_pre_status
      from dj_order_status s
     where s.next_status = p_cur_status;
    update dj_order o
       set o.order_status = p_pre_status
     where o.orderid = a_orderid;
    insert into dj_order_proc
      (logid, orderid, proc_desc, op_username, op_date, remark)
    values
      (func_new_guid(),
       a_orderid,
       p_cur_status,
       a_username,
       sysdate,
       '退回到' || p_pre_status);
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
end pg_dj602;
/

