create package PG_SY201006 is
  --互感器绝缘试验记录
  --1,查询
  procedure pro_sy201006_onedetail(recordcode_in varchar2, --记录ID
                                   v_cursor      out sys_refcursor);
  --1,t添加
  procedure pro_sy201006_oneadd(usercode_in     varchar2, --登录人cookie
                                username_in     varchar2, --登录人姓名cookie
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿cookie
                                departcode_in   varchar2, --部门cookie
                                plantname_in    varchar2, --厂矿名称cookie
                                departname_in   varchar2, --部门名称cookie
                                sydate_in           DATE, --实验时间
                                syloccode_in        varchar2, --实验地点编码
                                sylocname_in        varchar2, --实验地点名称
                                syequcode_in        varchar2, --实验设备编码
                                syequname_in        varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN    VARCHAR2,
                                SYEQUTYPTNAME_IN    VARCHAR2,
                                SYWEATHER_in        varchar2, --天气
                                sytemp_in           number, --气温
                                syreason_in         varchar2, --实验原因
                                SYVERDICT_in        varchar2, --结论
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,
                                v_hgqtype        varchar2, --型式
                                v_hgqrl          varchar2, --容量
                                v_hgqxbb         varchar2, --相变化
                                v_hgqkv          number, --额定电压
                                v_hgmake         varchar2, --制造厂
                                v_hgqdatea       date, --制造时间
                                v_hgqdateb       date,
                                v_hgqdatec       date,
                                v_hgqtgtype      varchar2, --套管型式
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2,
                                v_info           out varchar2,
                                v_info1          out varchar2,
                                v_info2          out varchar2);
  --1,更新
  procedure pro_sy201006_oneupdate(recordcode_in       varchar2, --记录ID
                                   usercode_in         varchar2, --登录人cookie
                                   username_in         varchar2, --登录人姓名cookie
                                   sydate_in           DATE, --实验时间
                                   syloccode_in        varchar2, --实验地点编码
                                   sylocname_in        varchar2, --实验地点名称
                                   syequcode_in        varchar2, --实验设备编码
                                   syequname_in        varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN    VARCHAR2,
                                   SYEQUTYPTNAME_IN    VARCHAR2,
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温 12.3
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,
                                   v_hgqtype        varchar2, --型式
                                   v_hgqrl          varchar2, --容量
                                   v_hgqxbb         varchar2, --相变化
                                   v_hgqkv          number, --额定电压
                                   v_hgmake         varchar2, --制造厂
                                   v_hgqdatea       date, --制造时间
                                   v_hgqdateb       date,
                                   v_hgqdatec       date,
                                   v_hgqtgtype      varchar2, --套管型式
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2);
  --2，查询
  procedure pro_sy201006_twodetail(recordcode_in varchar2, --记录ID
                                   v_cursor      out sys_refcursor);
  --2,添加
  procedure pro_sy201006_twoadd(recordcode_in varchar2,
                                v_YQXS        VARCHAR2, --仪器型式
                                v_YQBM        VARCHAR2, --仪器编码
                                v_aid         varchar2,
                                v_an          number,
                                v_ap          number,
                                v_ar          number,
                                v_asc         number,
                                v_a20         varchar2,
                                v_bid         varchar2,
                                v_bn          number,
                                v_bp          number,
                                v_br          number,
                                v_bsc         number,
                                v_b20         varchar2,
                                v_cid         varchar2,
                                v_cn          number,
                                v_cp          number,
                                v_cr          number,
                                v_csc         number,
                                v_c20         varchar2,
                                --v_opuser      varchar2,
                                --v_recorduser  varchar2,
                                --v_jxuser varchar2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2);
  --2,更新
  procedure pro_sy201006_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2,
                                   v_YQXS        VARCHAR2, --仪器型式
                                   v_YQBM        VARCHAR2, --仪器编码
                                   v_aid         varchar2,
                                   v_an          number,
                                   v_ap          number,
                                   v_ar          number,
                                   v_asc         number,
                                   v_a20         varchar2,
                                   v_bid         varchar2,
                                   v_bn          number,
                                   v_bp          number,
                                   v_br          number,
                                   v_bsc         number,
                                   v_b20         varchar2,
                                   v_cid         varchar2,
                                   v_cn          number,
                                   v_cp          number,
                                   v_cr          number,
                                   v_csc         number,
                                   v_c20         varchar2,
                                   -- v_opuser      varchar2,
                                   -- v_recorduser  varchar2,
                                   -- v_jxuser varchar2,
                                   ret out varchar2);
  --3,查询
  procedure pro_sy201006_threedetail(recordcode_in varchar2, --记录ID
                                     v_cursor      out sys_refcursor);
  --3,t添加
  procedure pro_sy201006_threeadd(recordcode_in varchar2, --记录ID
                                  v_YQXS        VARCHAR2, --仪器型式
                                  v_YQBM        VARCHAR2, --仪器编码
                                  v_a1          number,
                                  v_b1          number,
                                  v_c1          number,
                                  --  v_opuser      varchar2,
                                  -- v_recorduser  varchar2,
                                  --v_jxuser varchar2,
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2);
  --3,更新
  procedure pro_sy201006_threeupdate(v_id          varchar2,
                                     recordcode_in varchar2,
                                     v_YQXS        VARCHAR2, --仪器型式
                                     v_YQBM        VARCHAR2, --仪器编码
                                     v_a1          number,
                                     v_b1          number,
                                     v_c1          number,
                                     --v_opuser      varchar2,
                                     -- v_recorduser  varchar2,
                                     -- v_jxuser varchar2,
                                     ret out varchar2);
  --4，查询
  procedure pro_sy201006_fourdetail(recordcode_in varchar2,
                                    v_cursor      out sys_refcursor);
  --4,添加
  procedure pro_sy201006_fouradd(recordcode_in varchar2,
                                 v_YQXS        VARCHAR2, --仪器型式
                                 v_YQBM        VARCHAR2, --仪器编码
                                 v_akv         number,
                                 v_as          number,
                                 v_ama         number,
                                 v_ajg         varchar2,
                                 v_bkv         number,
                                 v_bs          number,
                                 v_bma         number,
                                 v_bjg         varchar2,
                                 v_ckv         number,
                                 v_cs          number,
                                 v_cma         number,
                                 v_cjg         varchar2,
                                 --v_opuser      varchar2,
                                 --v_recorduser  varchar2,
                                 ---  v_jxuser varchar2,
                                 ret     out varchar2,
                                 v_info  out varchar2,
                                 v_info1 out varchar2,
                                 v_info2 out varchar2);
  --4,更新
  procedure pro_sy201006_fourupdate(v_id          varchar2,
                                    recordcode_in varchar2,
                                    v_YQXS        VARCHAR2, --仪器型式
                                    v_YQBM        VARCHAR2, --仪器编码
                                    v_akv         number,
                                    v_as          number,
                                    v_ama         number,
                                    v_ajg         varchar2,
                                    v_bkv         number,
                                    v_bs          number,
                                    v_bma         number,
                                    v_bjg         varchar2,
                                    v_ckv         number,
                                    v_cs          number,
                                    v_cma         number,
                                    v_cjg         varchar2,
                                    --v_opuser      varchar2,
                                    --v_recorduser  varchar2,
                                    -- v_jxuser varchar2,
                                    ret out varchar2);
end PG_SY201006;
/

