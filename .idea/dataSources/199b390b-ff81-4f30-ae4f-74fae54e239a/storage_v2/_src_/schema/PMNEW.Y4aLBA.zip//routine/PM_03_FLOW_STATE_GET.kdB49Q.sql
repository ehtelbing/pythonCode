create procedure PM_03_FLOW_STATE_GET(V_V_GUID IN VARCHAR2,
                                                 V_CURSOR OUT SYS_REFCURSOR) is
  /*计划流程设置 */
  V_V_PERCODE VARCHAR2(500);
  V_V_PERNAME VARCHAR2(500);
begin

  FOR C IN (SELECT P.V_PERCODE, p.V_PERNAME
              FROM VIEW_03_PLAN_FLOW_STATE P
             WHERE P.V_GUID = V_V_GUID) LOOP
    IF V_V_PERCODE = '' OR V_V_PERCODE IS NULL THEN
      V_V_PERCODE := C.V_PERCODE;

      V_V_PERNAME := C.V_PERNAME;
    ELSE
      V_V_PERCODE := V_V_PERCODE || ',' || C.V_PERCODE;

      V_V_PERNAME := V_V_PERNAME || ',' || C.V_PERNAME;
    END IF;
  END LOOP;

  OPEN V_CURSOR FOR
    SELECT  V.V_PLANTYPE,
           V.V_ORGCODE,
           V.V_DEPTCODE,
           V.V_ORDER,
           V.V_ROLECODE,
           V.V_ROLENAME,
           V.V_URL,
           V.V_GUID,
           V.V_FLOWNAME,
           V.V_FLOWNAME_NEXT,
           V_V_PERCODE AS V_PERCODE,
           V.V_ORGNAME,
           V.V_DEPTNAME,
           V_V_PERNAME AS V_PERNAME
      FROM VIEW_03_PLAN_FLOW_STATE V
     WHERE V.V_GUID = V_V_GUID
     GROUP BY V.V_PLANTYPE,
           V.V_ORGCODE,
           V.V_DEPTCODE,
           V.V_ORDER,
           V.V_ROLECODE,
           V.V_ROLENAME,
           V.V_URL,
           V.V_GUID,
           V.V_FLOWNAME,
           V.V_FLOWNAME_NEXT,
           V.V_ORGNAME,
           V.V_DEPTNAME;

end PM_03_FLOW_STATE_GET;
/

