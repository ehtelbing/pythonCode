create package pg_sy106 is
  -- Author  : ADMINISTRATOR
  -- Created : 2016/4/8 8:47:25
  -- Purpose :
  --3.查询：pg_sy106.syuserlist
  procedure syuserlist(a_plantcode  varchar2, --厂矿编码
                       a_departcode varchar2, --部门编码
                       a_loc_code   varchar2, --试验地点编号
                       ret          out sys_refcursor);
  --5.新增保存：pg_sy106.addsyuser
  procedure addsyuser(a_usercode  varchar2, --用户编号
                      a_username  varchar2, --姓名
                      a_plantcode varchar2, --厂矿编码
                      a_deptcode  varchar2, --部门编码
                      a_loc_code  varchar2, --试验地点编号
                      a_sts       varchar2, --状态
                      a_plantname varchar2, --厂矿名称
                      a_deptname  varchar2, --部门名称
                      a_loc_name  varchar2, --试验地点名
                      ret         out varchar2,
                      ret_msg     out varchar2);
  --7.修改-保存：pg_sy106.updatesyuser
  procedure updatesyuser(a_usercode  varchar2, --用户编号
                         a_username  varchar2, --姓名
                         a_plantcode varchar2, --厂矿编码
                         a_deptcode  varchar2, --部门编码
                         a_loc_code  varchar2, --试验地点编号
                         a_sts       varchar2, --状态
                         a_plantname varchar2, --厂矿名称
                         a_deptname  varchar2, --部门名称
                         a_loc_name  varchar2, --试验地点名
                         ret         out varchar2,
                         ret_msg     out varchar2);
  ---8.删除：pg_sy106.deletesyuser
  procedure deletesyuser(a_usercode varchar2, --用户编号
                         ret        out varchar2,
                         ret_msg    out varchar2);
  --9.启用：pg_sy106.startsyuser
  procedure startsyuser(a_usercode varchar2, --用户编号
                        ret        out varchar2,
                        ret_msg    out varchar2);
  --10.停用：pg_sy106.stopsyuser
  procedure stopsyuser(a_usercode varchar2, --用户编号
                       ret        out varchar2,
                       ret_msg    out varchar2);
end pg_sy106;
/

