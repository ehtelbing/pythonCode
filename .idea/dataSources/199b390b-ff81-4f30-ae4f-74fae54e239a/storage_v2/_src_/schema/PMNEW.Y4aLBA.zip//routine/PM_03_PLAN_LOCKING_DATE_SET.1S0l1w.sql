create PROCEDURE PM_03_PLAN_LOCKING_DATE_SET(V_I_YEAR    IN VARCHAR2,--年份
                                                        V_I_MONTH   IN VARCHAR2,--月份
                                                        V_I_WEEKNUM IN VARCHAR2,--周
                                                        V_V_TYPE    IN VARCHAR2,--类型
                                                        V_D_DATE_E  IN DATE,--结束时间啊
                                                        V_I_LOCK    IN NUMBER,--是否解锁(0解锁，1未解锁)
                                                        V_D_DATE_S  IN DATE,--开始时间
                                                        V_CURSOR    OUT VARCHAR2) IS
  V_I_NUMBER NUMBER;
BEGIN
  SELECT COUNT(*)
    INTO V_I_NUMBER
    FROM PM_03_PLAN_LOCKING_DATE
   WHERE V_TYPE = V_V_TYPE
     AND I_YEAR = V_I_YEAR
     AND I_MONTH = V_I_MONTH
     AND I_WEEKNUM = NVL(V_I_WEEKNUM, 0);
  IF V_I_NUMBER = 0 THEN
    INSERT INTO PM_03_PLAN_LOCKING_DATE
      (V_TYPE, I_YEAR, I_MONTH, I_WEEKNUM, D_DATE_E, I_LOCK, D_DATE_S)
    VALUES
      (V_V_TYPE,
       V_I_YEAR,
       V_I_MONTH,
       NVL(V_I_WEEKNUM, 0),
       V_D_DATE_E,
       V_I_LOCK,
       V_D_DATE_S);
  ELSE
    UPDATE PM_03_PLAN_LOCKING_DATE
       SET D_DATE_E = V_D_DATE_E, I_LOCK = V_I_LOCK, D_DATE_S = V_D_DATE_S
     WHERE V_TYPE = V_V_TYPE
       AND I_YEAR = V_I_YEAR
       AND I_MONTH = V_I_MONTH
       AND I_WEEKNUM = NVL(V_I_WEEKNUM, 0);
  END IF;
  V_CURSOR := '成功';
END PM_03_PLAN_LOCKING_DATE_SET;
/

