create procedure PM_03_PLAN_MANAGE_LOG_SET(V_V_PLAN_GUID IN VARCHAR2, --计划guid
                                                      V_V_FLOW_CODE IN VARCHAR2, --计划状态
                                                      V_V_PERSON    IN VARCHAR2, --操作人员
                                                      V_V_TIME      IN VARCHAR2 --操作时间
                                                      ) is
  /*
  计划管理日志保存
  */

begin

  INSERT INTO PM_PLAN_MANAGE_LOG
    (V_PLAN_GUID, V_FLOW_CODE, V_PERSON, V_TIME)
  VALUES
    (V_V_PLAN_GUID, V_V_FLOW_CODE, V_V_PERSON, V_V_TIME);

end PM_03_PLAN_MANAGE_LOG_SET;
/

