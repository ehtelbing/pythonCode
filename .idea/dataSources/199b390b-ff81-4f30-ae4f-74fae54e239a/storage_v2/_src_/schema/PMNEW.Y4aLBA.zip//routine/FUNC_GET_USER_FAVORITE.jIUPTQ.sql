create FUNCTION FUNC_GET_USER_FAVORITE(A_USERID     VARCHAR2, --用户ID
                                      RET          OUT SYS_REFCURSOR)
    RETURN VARCHAR2 IS
    p_default_urlprefix varchar2(128) := get_porpvalue('sys-url-prefix','all');
  BEGIN
    OPEN RET FOR
      SELECT F.MENU_ID --菜单Id
            ,
             M.V_MENUNAME --菜单描述
            ,
             case
               when substr(M.V_URL, 1, 7) <> 'http://' then
                (p_default_urlprefix || '/pm/app/pm' || M.V_URL)
               else
                M.V_URL
             end URL --URL
        FROM BASIC_MENU_FAVORITE F
        LEFT OUTER JOIN BASE_MENU M
          ON F.MENU_ID = TO_CHAR(M.V_MENUCODE)
       WHERE F.USERID = A_USERID
       order by m.v_menuname;
    RETURN 'Success';
END FUNC_GET_USER_FAVORITE;
/

