create PROCEDURE BASE_EXAMINE_CAR_DIS(V_V_GUID IN VARCHAR2,
                                                 V_INFO   OUT VARCHAR2) is

  /*报废机具*/
BEGIN

  UPDATE BASE_EXAMINE_CAR B
     SET B.V_FLAG = '报废'
   WHERE B.V_GUID = V_V_GUID;
  V_INFO := 'success';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
END BASE_EXAMINE_CAR_DIS;
/

