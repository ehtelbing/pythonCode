create PROCEDURE BASE_AQCS_FAULT_ITEM_SEL(V_V_AQCS_CODE IN VARCHAR2, --安全措施编码
                                                     V_CURSOR      OUT SYS_REFCURSOR) IS
  /*传入安全措施编码查询安全事故案例*/
  /*故障现象为事故详情*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT *
      FROM PM_14_FAULT_ITEM_DATA P
     WHERE P.V_AQCS_CODE = V_V_AQCS_CODE;
END BASE_AQCS_FAULT_ITEM_SEL;
/

