create FUNCTION "RETURN_BASE_PERSONROLE_CODE1"(V_V_DEPTCODE IN VARCHAR2)
  return VARCHAR2 is
  V_V_ROLECODE varchar2(50);
  V_I_ROLECODE INTEGER;
begin
  begin
    select To_number(V_ROLECODE)
      into V_I_ROLECODE
      from BASE_PERSONROLE
     where rownum < 2
       AND V_DEPTCODE = V_V_DEPTCODE
     order by V_ROLECODE desc;
  EXCEPTION
    WHEN no_data_found THEN
      V_I_ROLECODE := 0;
  end;
  V_V_ROLECODE := LPAD(to_char(V_I_ROLECODE + 1), 2, '0');
  return V_V_ROLECODE;
END;
/

