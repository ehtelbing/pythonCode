create procedure BASE_JXMX_GZ_INS(V_V_JXGX_CODE  in varchar2, --检修工序编码
                                             V_V_PERCODE_DE in varchar2, --检修工种编码
                                             V_V_PERNAME_DE in varchar2, --检修工种名称
                                             V_V_TS         in varchar2, --检修台时
                                             V_V_DE         in varchar2, --检修定额
                                             V_V_PERTYPE_DE in varchar2, --检修工种类型
                                             V_INFO         out varchar2) is
  /*
  新增检修工序的工种
  */
  V_NUMBER number;
begin
  select count(*)
    into V_NUMBER
    from PM_1917_JXGX_PER_DATA P
   where P.V_JXGX_CODE = V_V_JXGX_CODE
     and P.V_PERCODE_DE = V_V_PERCODE_DE;

  if V_NUMBER = 0 then
    insert into PM_1917_JXGX_PER_DATA (V_JXGX_CODE, V_PERCODE_DE, V_PERNAME_DE, V_TS, V_DE, V_PERTYPE_DE) values (V_V_JXGX_CODE, V_V_PERCODE_DE, V_V_PERNAME_DE, V_V_TS, V_V_DE, V_V_PERTYPE_DE);
  end if;
  V_INFO := 'SUCCESS';
exception
  when others then
    V_INFO := sqlerrm;

end BASE_JXMX_GZ_INS;
/

