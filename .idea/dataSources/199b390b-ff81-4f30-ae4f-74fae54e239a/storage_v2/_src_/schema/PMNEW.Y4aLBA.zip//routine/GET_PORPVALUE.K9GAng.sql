create function get_porpvalue(a_name varchar2, a_plant varchar2) return varchar2 is
    p_porpvalue pm_sys_porperty.porp_value%type;
  begin
    begin
      select PORP_VALUE
        into p_porpvalue
        from pm_sys_porperty
       where plant = a_plant
         and PORP_NAME = a_name;
    end;
    return p_porpvalue;
  end;
/

