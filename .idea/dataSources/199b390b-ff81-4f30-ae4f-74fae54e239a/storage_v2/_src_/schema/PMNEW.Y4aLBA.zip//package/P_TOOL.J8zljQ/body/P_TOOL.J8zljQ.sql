create package body P_TOOL is

  --获取禁用后的名称
  FUNCTION FUNC_GETDISABLENAME(V_NAME        IN VARCHAR2,
                               V_TABLE_NAME  IN VARCHAR2,
                               V_COLUMN_NAME IN VARCHAR2) RETURN VARCHAR2 IS
    v_column_len   number;
    v_new_name_len number;
    v_new_name     varchar2(500);
    v_flag_num     number;
    v_sqlstr       varchar2(500);
  BEGIN
    v_new_name := V_NAME || '(已废弃)';
    v_sqlstr   := 'select count(*) flag_num  from ' || V_TABLE_NAME ||
                  ' where ' || V_COLUMN_NAME || '=:1';
    EXECUTE IMMEDIATE v_sqlstr
      into v_flag_num
      USING v_new_name;

    if v_flag_num > 0 then
      v_new_name := v_new_name || dbms_random.string('a', 2);
    end if;

    select data_length
      into v_column_len
      from user_tab_columns
     where table_name = V_TABLE_NAME
       and column_name = V_COLUMN_NAME;

    select lengthb(v_new_name) into v_new_name_len from dual;

    if v_new_name_len > v_column_len then
      v_new_name := substr(v_new_name,
                           v_new_name_len - v_column_len + 1,
                           v_column_len);
    end if;
    RETURN(v_new_name);
  END FUNC_GETDISABLENAME;

  --获取所有子节点
  FUNCTION FUNC_GETCHILDID(table_name          varchar2,
                           parent_column       varchar2,
                           child_column        varchar2,
                           parent_column_value varchar2) RETURN sys_refcursor IS
    OUT_CURSOR sys_refcursor;
    var_select varchar2(8000);
  BEGIN
    BEGIN
      var_select := 'select MAIN.' || child_column || ' CHILDID from ' ||
                    table_name || ' MAIN start with MAIN.' || parent_column ||
                    ' =''' || parent_column_value || '''' ||
                    ' connect by prior MAIN.' || child_column || ' =MAIN.' ||
                    parent_column;
      open OUT_CURSOR for var_select;
    END;
    RETURN OUT_CURSOR;
  END FUNC_GETCHILDID;

  --获取流程所有子节点
  FUNCTION FUNC_GETCHILDID_PROCESS(table_name          varchar2,
                                   parent_column       varchar2,
                                   child_column        varchar2,
                                   parent_column_value varchar2,
                                   process_column      varchar2,
                                   process_value       varchar2)
    RETURN sys_refcursor IS
    OUT_CURSOR sys_refcursor;
    var_select varchar2(8000);
  BEGIN
    BEGIN
      var_select := 'select MAIN.' || child_column ||
                    ' CHILDID from (select * from ' || table_name ||
                    ' where ' || table_name || '.' || process_column ||
                    '=''' || process_value || ''') MAIN start with MAIN.' ||
                    parent_column || ' =''' || parent_column_value || '''' ||
                    ' connect by prior MAIN.' || child_column || ' =MAIN.' ||
                    parent_column;
      open OUT_CURSOR for var_select;
    END;
    RETURN OUT_CURSOR;
  END FUNC_GETCHILDID_PROCESS;

  --获取所有子节点,父节点
  FUNCTION FUNC_GETCPID(table_name          varchar2,
                        parent_column       varchar2,
                        child_column        varchar2,
                        parent_column_value varchar2) RETURN sys_refcursor is
    OUT_CURSOR sys_refcursor;
    var_select varchar2(8000);
  BEGIN
    BEGIN
      var_select := 'select MAIN.' || child_column || ' CHILDID,MAIN.' ||
                    parent_column || ' PARENTID from ' || table_name ||
                    ' MAIN start with MAIN.' || parent_column || ' =''' ||
                    parent_column_value || '''' ||
                    ' connect by prior MAIN.' || child_column || ' =MAIN.' ||
                    parent_column;
      open OUT_CURSOR for var_select;
    END;
    RETURN OUT_CURSOR;
  END FUNC_GETCPID;

  --将字符串用符号分割
  FUNCTION FUNC_GETSPLITITEM(MAIN_STR VARCHAR2, SPLIT_STR VARCHAR2)
    RETURN SYS_REFCURSOR IS
    SPLIT_ITEM_CURSOR SYS_REFCURSOR;
  BEGIN
    open SPLIT_ITEM_CURSOR for
      select regexp_substr(MAIN_STR, '[^' || SPLIT_STR || ']+', 1, level) item
        from dual
      connect by level <=
                 length(MAIN_STR) - length(replace(MAIN_STR, SPLIT_STR)) + 1;
    return SPLIT_ITEM_CURSOR;
  END FUNC_GETSPLITITEM;

  --检修工时获取工时换算后个数
  function FUNC_GETFINALTASKTIME(V_ORDER_TYP VARCHAR2,
                                 D_BEGINTIME DATE,
                                 D_ENDTIME   DATE,
                                 V_RET       OUT VARCHAR2) RETURN NUMBER IS

    var_begin_date     date;
    var_end_date       date;
    var_begin_time     varchar2(100);
    var_end_time       varchar2(100);
    var_final_tasktime number;
    var_date_range     number;
  BEGIN
    var_final_tasktime := 0;
    var_begin_date     := to_date(to_char(D_BEGINTIME, 'yyyy-MM-dd'),
                                  'yyyy-MM-dd');
    var_end_date       := to_date(to_char(D_ENDTIME, 'yyyy-MM-dd'),
                                  'yyyy-MM-dd');
    var_begin_time     := to_char(D_BEGINTIME, 'HH24:mi:ss');
    var_end_time       := to_char(D_ENDTIME, 'HH24:mi:ss');
    var_date_range     := ROUND(TO_NUMBER(var_end_date - var_begin_date));

    if var_date_range >= 0 then
      if var_date_range = 0 then
        var_final_tasktime := var_final_tasktime +
                              FUNC_GETASKTIMERANGE(V_ORDER_TYP => V_ORDER_TYP,
                                                   D_DATE      => to_date(to_char(var_begin_date,
                                                                                  'yyyy-MM-dd'),
                                                                          'yyyy-MM-dd'),
                                                   V_BEGINTIME => var_begin_time,
                                                   V_ENDTIME   => var_end_time);
      else
        for i in 1 .. var_date_range - 1 loop
          var_final_tasktime := var_final_tasktime +
                                FUNC_GETASKTIMERANGE(V_ORDER_TYP => V_ORDER_TYP,
                                                     D_DATE      => to_date(to_char(var_begin_date + i,
                                                                                    'yyyy-MM-dd'),
                                                                            'yyyy-MM-dd'),
                                                     V_BEGINTIME => var_begin_time,
                                                     V_ENDTIME   => var_end_time);

        end loop;
      end if;
    else
      V_RET := 'fail';
      return(0);
    end if;

    V_RET := 'success';
    return(var_final_tasktime);
  END FUNC_GETFINALTASKTIME;

  --检修工时一天内获取工时换算后个数
  function FUNC_GETASKTIMERANGE(V_ORDER_TYP VARCHAR2,
                                D_DATE      DATE,
                                V_BEGINTIME VARCHAR2,
                                V_ENDTIME   VARCHAR2) RETURN NUMBER IS
    var_holiday_flag number;
    var_workday_flag number;
    type ref_cursor_type is ref cursor;
    var_holiday_cursor       ref_cursor_type;
    var_holiday_row          TT_TASKTIME_HOLIDAY_NUM%rowtype;
    var_tasktime             number;
    var_holiday_f_begin_time varchar2(100); --假日前区间开始时间
    var_holiday_f_end_time   varchar2(100); --假日前区间结束时间
    var_workday_f_begin_time varchar2(100); --基础前区间开始时间
    var_workday_f_end_time   varchar2(100); --基础前区间结束时间
    var_holiday_b_begin_time varchar2(100); --假日后区间开始时间
    var_holiday_b_end_time   varchar2(100); --假日后区间结束时间
    var_workday_b_begin_time varchar2(100); --基础后区间开始时间
    var_workday_b_end_time   varchar2(100); --基础后区间结束时间
    var_holiday_min          varchar2(100);
    var_holiday_max          varchar2(100);
    var_workday_min          varchar2(100);
    var_workday_max          varchar2(100);
    var_end_time             varchar2(100);
    var_begin_time           varchar2(100);
  BEGIN
    var_holiday_min          := null;
    var_holiday_max          := null;
    var_workday_min          := null;
    var_workday_max          := null;
    var_holiday_f_begin_time := null;
    var_holiday_f_end_time   := null;
    var_holiday_b_begin_time := null;
    var_holiday_b_end_time   := null;
    var_workday_f_begin_time := null;
    var_workday_f_end_time   := null;
    var_workday_b_begin_time := null;
    var_workday_b_end_time   := null;
    var_tasktime             := 0;
    var_end_time             := V_ENDTIME;
    var_begin_time           := V_BEGINTIME;
    select count(*)
      into var_holiday_flag
      from TT_TASKTIME_HOLIDAY_NUM MAIN
     where MAIN.HOLIDAY_DATE = D_DATE
       and MAIN.ORDER_TYP = V_ORDER_TYP;

    select count(*)
      into var_workday_flag
      from TT_TASKTIME_WORKDAY_NUM MAIN
     where MAIN.ORDER_TYP = V_ORDER_TYP;

    if var_holiday_flag > 0 then
      select min(to_char(to_date(MAIN.BEGIN_TIME, 'HH24:mi:ss'),
                         'HH24:mi:ss')),
             max(to_char(to_date(MAIN.END_TIME, 'HH24:mi:ss'), 'HH24:mi:ss'))
        into var_holiday_min, var_holiday_max
        from TT_TASKTIME_HOLIDAY_NUM MAIN
       where MAIN.HOLIDAY_DATE = D_DATE
         and MAIN.ORDER_TYP = V_ORDER_TYP;
    end if;

    if var_workday_flag > 0 then
      select min(to_char(to_date(MAIN.BEGIN_TIME, 'HH24:mi:ss'),
                         'HH24:mi:ss')),
             max(to_char(to_date(MAIN.END_TIME, 'HH24:mi:ss'), 'HH24:mi:ss'))
        into var_workday_min, var_workday_max
        from TT_TASKTIME_WORKDAY_NUM MAIN
       where MAIN.ORDER_TYP = V_ORDER_TYP;
    end if;

    --计算节假日工时
    if var_holiday_flag > 0 then

      if to_date(V_BEGINTIME, 'HH24:mi:ss') >=
         to_date(var_holiday_min, 'HH24:mi:ss') and
         to_date(V_BEGINTIME, 'HH24:mi:ss') <
         to_date(var_holiday_max, 'HH24:mi:ss') then
        --实际开始时间大于等于设置最小时间并且小于最大时间
        if to_date(V_ENDTIME, 'HH24:mi:ss') >=
           to_date(var_holiday_max, 'HH24:mi:ss') then
          --实际结束时间大于设置最大时间
          var_holiday_b_begin_time := var_holiday_max;
          var_holiday_b_end_time   := V_ENDTIME;
          var_end_time             := var_holiday_max;
        end if;
      else
        --实际开始时间小于于等于设置最小时间

        if to_date(V_ENDTIME, 'HH24:mi:ss') >=
           to_date(var_holiday_max, 'HH24:mi:ss') then
          --实际结束时间大于设置最大时间
          var_holiday_b_begin_time := var_holiday_max;
          var_holiday_b_end_time   := V_ENDTIME;

          var_holiday_f_begin_time := V_BEGINTIME;
          var_holiday_f_end_time   := var_holiday_min;
        else
          if to_date(V_ENDTIME, 'HH24:mi:ss') <
             to_date(var_holiday_max, 'HH24:mi:ss') and
             to_date(V_ENDTIME, 'HH24:mi:ss') >=
             to_date(var_holiday_min, 'HH24:mi:ss') then

            var_holiday_f_begin_time := V_BEGINTIME;
            var_holiday_f_end_time   := var_holiday_min;
            var_begin_time           := var_holiday_min;
          end if;
        end if;
      end if;

      var_tasktime := var_tasktime +
                      FUNC_GETHOLIDAYTASKTIME(V_ORDER_TYP => V_ORDER_TYP,
                                              D_DATE      => D_DATE,
                                              V_BEGINTIME => var_begin_time,
                                              V_ENDTIME   => var_end_time);

      --超出范围的工时计算，按照基本工时进行计算
      --基本工时
      if var_workday_flag > 0 then
        if var_holiday_f_begin_time is not null and
           var_holiday_f_end_time is not null then
          if to_date(var_holiday_f_begin_time, 'HH24:mi:ss') >=
             to_date(var_workday_min, 'HH24:mi:ss') and
             to_date(var_holiday_f_begin_time, 'HH24:mi:ss') <
             to_date(var_workday_max, 'HH24:mi:ss') then
            --开始时间大于等于设置最小时间
            if to_date(var_holiday_f_end_time, 'HH24:mi:ss') >=
               to_date(var_workday_max, 'HH24:mi:ss') then
              --结束时间大于设置最大时间
              var_workday_b_begin_time := var_workday_max;
              var_workday_b_end_time   := var_holiday_f_end_time;
              var_holiday_f_end_time   := var_workday_max;
            end if;
          else
            --开始时间小于设置最小时间

            if to_date(var_holiday_f_end_time, 'HH24:mi:ss') >=
               to_date(var_workday_max, 'HH24:mi:ss') then
              --结束时间大于设置最大时间
              var_workday_b_begin_time := var_workday_max;
              var_workday_b_end_time   := var_holiday_f_end_time;

              var_workday_f_begin_time := var_holiday_f_begin_time;
              var_workday_f_end_time   := var_workday_min;
            else
              if to_date(var_holiday_f_end_time, 'HH24:mi:ss') <
                 to_date(var_workday_max, 'HH24:mi:ss') and
                 to_date(var_holiday_f_end_time, 'HH24:mi:ss') >
                 to_date(var_workday_min, 'HH24:mi:ss') then
                --结束时间小于设置最大时间并且大于最小时间
                var_workday_f_begin_time := var_holiday_f_begin_time;
                var_workday_f_end_time   := var_workday_min;
                var_holiday_f_begin_time := var_workday_min;
              end if;
            end if;

          end if;

          var_tasktime := var_tasktime +
                          FUNC_GETWORKDAYTASKTIME(V_ORDER_TYP => V_ORDER_TYP,
                                                  V_BEGINTIME => var_holiday_f_begin_time,
                                                  V_ENDTIME   => var_holiday_f_end_time);

          --无基本设置，基数按照1基数
          if var_workday_f_begin_time is not null and
             var_workday_f_end_time is not null then
            var_tasktime := var_tasktime +
                            ROUND(TO_NUMBER(to_date(var_workday_f_end_time,
                                                    'HH24:mi:ss') -
                                            to_date(var_workday_f_begin_time,
                                                    'HH24:mi:ss')) * 24) * 1;
          end if;

          if var_workday_b_begin_time is not null and
             var_workday_b_end_time is not null then
            var_tasktime := var_tasktime +
                            ROUND(TO_NUMBER(to_date(var_workday_b_end_time,
                                                    'HH24:mi:ss') -
                                            to_date(var_workday_b_begin_time,
                                                    'HH24:mi:ss')) * 24) * 1;
          end if;
        end if;

        if var_holiday_b_begin_time is not null and
           var_holiday_b_end_time is not null then
          if to_date(var_holiday_b_begin_time, 'HH24:mi:ss') >=
             to_date(var_workday_min, 'HH24:mi:ss') and
             to_date(var_holiday_b_begin_time, 'HH24:mi:ss') <
             to_date(var_workday_max, 'HH24:mi:ss') then
            --开始时间大于等于设置最小时间
            if to_date(var_holiday_b_end_time, 'HH24:mi:ss') >=
               to_date(var_workday_max, 'HH24:mi:ss') then
              --结束时间大于设置最大时间
              var_workday_b_begin_time := var_workday_max;
              var_workday_b_end_time   := var_holiday_b_end_time;
              var_holiday_b_end_time   := var_workday_max;
            end if;
          else
            --开始时间小于设置最小时间

            if to_date(var_holiday_f_end_time, 'HH24:mi:ss') >=
               to_date(var_workday_max, 'HH24:mi:ss') then
              --结束时间大于设置最大时间
              var_workday_f_begin_time := var_holiday_b_begin_time;
              var_workday_f_end_time   := var_workday_min;

              var_workday_b_begin_time := var_workday_max;
              var_workday_b_end_time   := var_holiday_b_end_time;
            else
              if to_date(var_holiday_f_end_time, 'HH24:mi:ss') <
                 to_date(var_workday_max, 'HH24:mi:ss') and
                 to_date(var_holiday_f_end_time, 'HH24:mi:ss') >=
                 to_date(var_workday_min, 'HH24:mi:ss') then
                --结束时间小于设置最大时间
                var_workday_f_begin_time := var_holiday_b_begin_time;
                var_workday_f_end_time   := var_workday_min;
                var_workday_f_begin_time := var_workday_min;
              end if;
            end if;
          end if;

          var_tasktime := var_tasktime +
                          FUNC_GETWORKDAYTASKTIME(V_ORDER_TYP => V_ORDER_TYP,
                                                  V_BEGINTIME => var_holiday_b_begin_time,
                                                  V_ENDTIME   => var_holiday_b_end_time);

          --无基本设置，基数按照1基数
          if var_workday_f_begin_time is not null and
             var_workday_f_end_time is not null then
            var_tasktime := var_tasktime +
                            ROUND(TO_NUMBER(to_date(var_workday_f_end_time,
                                                    'HH24:mi:ss') -
                                            to_date(var_workday_f_begin_time,
                                                    'HH24:mi:ss')) * 24) * 1;
          end if;

          if var_workday_b_begin_time is not null and
             var_workday_b_end_time is not null then
            var_tasktime := var_tasktime +
                            ROUND(TO_NUMBER(to_date(var_workday_b_end_time,
                                                    'HH24:mi:ss') -
                                            to_date(var_workday_b_begin_time,
                                                    'HH24:mi:ss')) * 24) * 1;
          end if;
        end if;

      else
        --无基本设置，基数按照1基数
        if var_holiday_f_begin_time is not null and
           var_holiday_f_end_time is not null then
          var_tasktime := var_tasktime +
                          ROUND(TO_NUMBER(to_date(var_holiday_f_end_time,
                                                  'HH24:mi:ss') -
                                          to_date(var_holiday_f_begin_time,
                                                  'HH24:mi:ss')) * 24) * 1;
        end if;

        if var_holiday_b_begin_time is not null and
           var_holiday_b_end_time is not null then
          var_tasktime := var_tasktime +
                          ROUND(TO_NUMBER(to_date(var_holiday_b_end_time,
                                                  'HH24:mi:ss') -
                                          to_date(var_holiday_b_begin_time,
                                                  'HH24:mi:ss')) * 24) * 1;
        end if;

      end if;

    else
      --基本工时，无节假日
      if var_workday_flag > 0 then
        if to_date(V_BEGINTIME, 'HH24:mi:ss') >=
           to_date(var_workday_min, 'HH24:mi:ss') and
           to_date(V_BEGINTIME, 'HH24:mi:ss') <
           to_date(var_workday_max, 'HH24:mi:ss') then
          --实际开始时间大于等于设置最小时间并且小于最大时间
          if to_date(V_ENDTIME, 'HH24:mi:ss') >=
             to_date(var_workday_max, 'HH24:mi:ss') then
            --实际结束时间大于设置最大时间
            var_workday_b_begin_time := var_workday_max;
            var_workday_b_end_time   := V_ENDTIME;
            var_end_time             := var_workday_max;
          end if;
        else
          --实际开始时间小于于等于设置最小时间

          if to_date(V_ENDTIME, 'HH24:mi:ss') >=
             to_date(var_workday_max, 'HH24:mi:ss') then
            --实际结束时间大于设置最大时间
            var_workday_b_begin_time := var_workday_max;
            var_workday_b_end_time   := V_ENDTIME;

            var_workday_f_begin_time := V_BEGINTIME;
            var_workday_f_end_time   := var_workday_min;
          else
            if to_date(V_ENDTIME, 'HH24:mi:ss') <
               to_date(var_workday_max, 'HH24:mi:ss') and
               to_date(V_ENDTIME, 'HH24:mi:ss') >=
               to_date(var_workday_min, 'HH24:mi:ss') then
              var_workday_f_begin_time := V_BEGINTIME;
              var_workday_f_end_time   := var_workday_min;
              var_begin_time           := var_workday_min;

            end if;
          end if;
        end if;

        var_tasktime := var_tasktime +
                        FUNC_GETWORKDAYTASKTIME(V_ORDER_TYP => V_ORDER_TYP,
                                                V_BEGINTIME => var_begin_time,
                                                V_ENDTIME   => var_end_time);

        --无基本设置，基数按照1基数
        if var_workday_f_begin_time is not null and
           var_workday_f_end_time is not null then
          var_tasktime := var_tasktime +
                          ROUND(TO_NUMBER(to_date(var_workday_f_end_time,
                                                  'HH24:mi:ss') -
                                          to_date(var_workday_f_begin_time,
                                                  'HH24:mi:ss')) * 24) * 1;
        end if;
        if var_workday_b_begin_time is not null and
           var_workday_b_end_time is not null then
          var_tasktime := var_tasktime +
                          ROUND(TO_NUMBER(to_date(var_workday_b_end_time,
                                                  'HH24:mi:ss') -
                                          to_date(var_workday_b_begin_time,
                                                  'HH24:mi:ss')) * 24) * 1;
        end if;

      else
        var_tasktime := var_tasktime +
                        ROUND(TO_NUMBER(to_date(V_ENDTIME, 'HH24:mi:ss') -
                                        to_date(V_BEGINTIME, 'HH24:mi:ss')) * 24) * 1;
      end if;

    end if;

    return(var_tasktime);
  END FUNC_GETASKTIMERANGE;

  --检修工时基础工时计算
  FUNCTION FUNC_GETWORKDAYTASKTIME(V_ORDER_TYP VARCHAR2,
                                   V_BEGINTIME VARCHAR2,
                                   V_ENDTIME   VARCHAR2) RETURN number IS

    var_tasktime number;
    type ref_cursor_type is ref cursor;
    var_workday_cursor ref_cursor_type;
    var_workday_row    TT_TASKTIME_WORKDAY_NUM%rowtype;
    var_begintime      varchar2(100);
    var_endtime        varchar2(100);
  BEGIN
    var_tasktime  := 0;
    var_begintime := V_BEGINTIME;
    var_endtime   := V_ENDTIME;
    --基本设置
    open var_workday_cursor for
      select *
        from TT_TASKTIME_WORKDAY_NUM MAIN
       where MAIN.ORDER_TYP = V_ORDER_TYP;

    loop
      fetch var_workday_cursor
        into var_workday_row;
      exit when var_workday_cursor%notfound;
      if to_date(var_begintime, 'HH24:mi:ss') >=
         to_date(var_workday_row.begin_time, 'HH24:mi:ss') and
         to_date(var_begintime, 'HH24:mi:ss') <
         to_date(var_workday_row.end_time, 'HH24:mi:ss') then

        if to_date(var_begintime, 'HH24:mi:ss') >=
           to_date(var_workday_row.begin_time, 'HH24:mi:ss') then
          --实际开始时间大于等于设置的开始时间

          if to_date(var_endtime, 'HH24:mi:ss') <=
             to_date(var_workday_row.end_time, 'HH24:mi:ss') then
            --实际的结束时间小于设置的结束时间
            var_tasktime := var_tasktime + ROUND(TO_NUMBER(to_date(var_endtime,
                                                                   'HH24:mi:ss') -
                                                           to_date(var_begintime,
                                                                   'HH24:mi:ss')) * 24) *
                            var_workday_row.num;
          else
            --实际的结束时间大于设置的结束时间
            var_tasktime := var_tasktime + ROUND(TO_NUMBER(to_date(var_workday_row.end_time,
                                                                   'HH24:mi:ss') -
                                                           to_date(var_begintime,
                                                                   'HH24:mi:ss')) * 24) *
                            var_workday_row.num;

          end if;
          var_begintime := var_workday_row.end_time;
        else
          --实际开始时间小于设置开始时间
          if to_date(var_endtime, 'HH24:mi:ss') <=
             to_date(var_workday_row.end_time, 'HH24:mi:ss') then
            --实际的结束时间小于设置的结束时间
            var_tasktime := var_tasktime + ROUND(TO_NUMBER(to_date(var_endtime,
                                                                   'HH24:mi:ss') -
                                                           to_date(var_workday_row.begin_time,
                                                                   'HH24:mi:ss')) * 24) *
                            var_workday_row.num;
          else
            --实际的结束时间大于设置的结束时间
            var_tasktime := var_tasktime + ROUND(TO_NUMBER(to_date(var_workday_row.end_time,
                                                                   'HH24:mi:ss') -
                                                           to_date(var_workday_row.begin_time,
                                                                   'HH24:mi:ss')) * 24) *
                            var_workday_row.num;
          end if;
          var_begintime := var_workday_row.end_time;
        end if;
      end if;
    end loop;
    return(var_tasktime);
  end FUNC_GETWORKDAYTASKTIME;

  --检修工时节假日工时计算
  FUNCTION FUNC_GETHOLIDAYTASKTIME(V_ORDER_TYP VARCHAR2,
                                   D_DATE      DATE,
                                   V_BEGINTIME VARCHAR2,
                                   V_ENDTIME   VARCHAR2) RETURN number IS

    var_tasktime number;
    type ref_cursor_type is ref cursor;
    var_holiday_cursor ref_cursor_type;
    var_holiday_row    TT_TASKTIME_HOLIDAY_NUM%rowtype;
    var_begintime      varchar2(100);
    var_endtime        varchar2(100);
  BEGIN
    var_tasktime  := 0;
    var_begintime := V_BEGINTIME;
    var_endtime   := V_ENDTIME;
    --节假日设置
    open var_holiday_cursor for
      select *
        from TT_TASKTIME_HOLIDAY_NUM MAIN
       where MAIN.HOLIDAY_DATE = D_DATE
         and MAIN.ORDER_TYP = V_ORDER_TYP;
    --循环节假日设置记录
    loop
      fetch var_holiday_cursor
        into var_holiday_row;
      exit when var_holiday_cursor%notfound;

      if to_date(var_begintime, 'HH24:mi:ss') >=
         to_date(var_holiday_row.begin_time, 'HH24:mi:ss') and
         to_date(var_begintime, 'HH24:mi:ss') <
         to_date(var_holiday_row.end_time, 'HH24:mi:ss') then

        if to_date(var_begintime, 'HH24:mi:ss') >=
           to_date(var_holiday_row.begin_time, 'HH24:mi:ss') then
          --实际开始时间大于等于设置的开始时间

          if to_date(var_endtime, 'HH24:mi:ss') <=
             to_date(var_holiday_row.end_time, 'HH24:mi:ss') then
            --实际的结束时间小于设置的结束时间
            var_tasktime := var_tasktime + ROUND(TO_NUMBER(to_date(var_endtime,
                                                                   'HH24:mi:ss') -
                                                           to_date(var_begintime,
                                                                   'HH24:mi:ss')) * 24) *
                            var_holiday_row.num;
          else
            --实际的结束时间大于设置的结束时间
            var_tasktime  := var_tasktime + ROUND(TO_NUMBER(to_date(var_holiday_row.end_time,
                                                                    'HH24:mi:ss') -
                                                            to_date(var_begintime,
                                                                    'HH24:mi:ss')) * 24) *
                             var_holiday_row.num;
            var_begintime := var_holiday_row.end_time;
          end if;

        else
          --实际开始时间小于设置开始时间

          if to_date(var_endtime, 'HH24:mi:ss') <=
             to_date(var_holiday_row.end_time, 'HH24:mi:ss') then
            --实际的结束时间小于设置的结束时间
            var_tasktime := var_tasktime + ROUND(TO_NUMBER(to_date(var_endtime,
                                                                   'HH24:mi:ss') -
                                                           to_date(var_holiday_row.begin_time,
                                                                   'HH24:mi:ss')) * 24) *
                            var_holiday_row.num;
          else
            --实际的结束时间大于设置的结束时间
            var_tasktime := var_tasktime + ROUND(TO_NUMBER(to_date(var_holiday_row.end_time,
                                                                   'HH24:mi:ss') -
                                                           to_date(var_holiday_row.begin_time,
                                                                   'HH24:mi:ss')) * 24) *
                            var_holiday_row.num;
          end if;
          var_begintime := var_holiday_row.end_time;
        end if;
      end if;
    end loop;
    return(var_tasktime);
  end FUNC_GETHOLIDAYTASKTIME;

  --获取检修工时折算基数
  function FUNC_GETTASKTIMENUM(V_ORDER_TYP VARCHAR2, D_DATE DATE)
    RETURN NUMBER IS

    var_date         date;
    var_time         varchar2(100);
    var_tasktime_num number;
    var_workday_flag number;
    var_holiday_flag number;
    type ref_cursor_type is ref cursor;
    var_holiday_cursor ref_cursor_type;
    var_holiday_row    TT_TASKTIME_HOLIDAY_NUM%rowtype;
    var_workday_cursor ref_cursor_type;
    var_workday_row    TT_TASKTIME_WORKDAY_NUM%rowtype;
  BEGIN
    var_tasktime_num := 0;
    var_date         := to_date(to_char(D_DATE, 'yyyy-MM-dd'), 'yyyy-MM-dd');
    var_time         := to_char(D_DATE, 'HH24:mi:ss');

    select count(*)
      into var_holiday_flag
      from TT_TASKTIME_HOLIDAY_NUM MAIN
     where MAIN.HOLIDAY_DATE = var_date
       and MAIN.ORDER_TYP = V_ORDER_TYP;

    select count(*)
      into var_workday_flag
      from TT_TASKTIME_WORKDAY_NUM MAIN
     where MAIN.ORDER_TYP = V_ORDER_TYP;

    if var_holiday_flag > 0 then

      --节假日设置
      open var_holiday_cursor for
        select *
          from TT_TASKTIME_HOLIDAY_NUM MAIN
         where MAIN.HOLIDAY_DATE = var_date
           and MAIN.ORDER_TYP = V_ORDER_TYP;
      --循环节假日设置记录
      loop
        fetch var_holiday_cursor
          into var_holiday_row;
        exit when var_holiday_cursor%notfound;

        if to_date(var_time, 'HH24:mi:ss') >=
           to_date(var_holiday_row.begin_time, 'HH24:mi:ss') and
           to_date(var_time, 'HH24:mi:ss') <
           to_date(var_holiday_row.end_time, 'HH24:mi:ss') then

          var_tasktime_num := var_holiday_row.num;
        end if;

      end loop;
    elsif var_workday_flag > 0 then
      --基本设置
      open var_workday_cursor for
        select *
          from TT_TASKTIME_WORKDAY_NUM MAIN
         where MAIN.ORDER_TYP = V_ORDER_TYP;

      loop
        fetch var_workday_cursor
          into var_workday_row;
        exit when var_workday_cursor%notfound;
        if to_date(var_time, 'HH24:mi:ss') >=
           to_date(var_workday_row.begin_time, 'HH24:mi:ss') and
           to_date(var_time, 'HH24:mi:ss') <
           to_date(var_workday_row.end_time, 'HH24:mi:ss') then
          var_tasktime_num := var_workday_row.num;
        end if;
      end loop;
    else
      var_tasktime_num := 1;
    end if;
    return(var_tasktime_num);
  END FUNC_GETTASKTIMENUM;

  --依据工单编码，获取工时数，人数
  function FUNC_GETORDERTASKTIMEPERSON(V_WORKORDER_GUID VARCHAR2,
                                       TASKTIME         OUT NUMBER,
                                       PERSON_NUM       OUT NUMBER)
    RETURN VARCHAR is
    var_workorder_guid varchar2(100);

  begin
    select PM_WORKORDER_HOURS.ORDERGUID,
           count(PM_WORKORDER_HOURS.V_PERSONCODE),
           sum(PM_WORKORDER_HOURS.I_WORKHOUR)
      into var_workorder_guid, PERSON_NUM, TASKTIME
      from PM_WORKORDER_HOURS
     where PM_WORKORDER_HOURS.ORDERGUID = V_WORKORDER_GUID
     group by PM_WORKORDER_HOURS.ORDERGUID;

    return('success');
  end FUNC_GETORDERTASKTIMEPERSON;

  --依据工单编码,人员编码，获取工时数，人员工时
  function FUNC_GETPERSONTASKTIME(V_WORKORDER_GUID VARCHAR2,
                                  V_PERSONCODE     VARCHAR2,
                                  TASKTIME         OUT NUMBER,
                                  PERSON_TASKTIME  OUT NUMBER) RETURN VARCHAR is
    var_workorder_guid varchar2(100);

  begin
    select PM_WORKORDER_HOURS.ORDERGUID, sum(PM_WORKORDER_HOURS.I_WORKHOUR)
      into var_workorder_guid, TASKTIME
      from PM_WORKORDER_HOURS
     where PM_WORKORDER_HOURS.ORDERGUID = V_WORKORDER_GUID
     group by PM_WORKORDER_HOURS.ORDERGUID;

    select sum(PM_WORKORDER_HOURS.I_WORKHOUR)
      into PERSON_TASKTIME
      from PM_WORKORDER_HOURS
     where PM_WORKORDER_HOURS.ORDERGUID = V_WORKORDER_GUID
       and PM_WORKORDER_HOURS.V_PERSONCODE = V_PERSONCODE
     group by PM_WORKORDER_HOURS.ORDERGUID;

    return('success');
  end FUNC_GETPERSONTASKTIME;

end P_TOOL;
/

