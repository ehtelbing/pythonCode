create package body pg_oil13 is

  -- 查询和导出Excel，调用过程pg_oil13.getmatlist，加载表格数据
  procedure getmatlist(a_mat_no   varchar2, --物料号
                       a_mat_desc varchar2, --物料名
                       ret        out sys_refcursor --返回结果集
                       ) is
  begin
    open ret for
      select m.mat_no, --物料编码
             m.mat_desc, --物料名称
             m1.unit,
             s.supply_code,
             s.supply_name
        from oil_mats m
        left outer join mm_mats@namm.fjwz m1
          on m1.mat_no = m.mat_no
        left outer join mm_supply_mat@namm.fjwz sm
          on sm.mat_no = m.mat_no
         and sm.del_flag = '0'
        left outer join mm_supply_dic@namm.fjwz s
          on s.supply_code = sm.supply_code
       where m.mat_no like '%' || a_mat_no || '%'
         and m.mat_desc like '%' || a_mat_desc || '%'
       order by m.mat_no;
  end;
  --删除选中物料，点击后，调用过程pg_oil13.deletemat
  procedure deletemat(a_mat_no varchar2, --物料号
                      ret_msg  out varchar2, --反馈信息
                      ret      out varchar2 --执行结果
                      ) is
  begin
    ret := 'Fail';
    delete from oil_mats where mat_no = a_mat_no;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
  --，在该界面上，点击查询，调用过程pg_oil13.selectmat查询数据并加载表格
  procedure selectmat(a_mat_desc varchar2, --物料名
                      ret        out sys_refcursor --返回结果集
                      ) is
  begin
    open ret for
      select mat_no, --物料号
             mat_desc --物料名
        from mm_mats@namm.fjwz m
       where m.mat_desc like '%' || a_mat_desc || '%'
          or m.mat_no like '%' || a_mat_desc || '%'
       order by m.mat_no;
  end;
  --将选择的物料号调用过程pg_oil13.importmat导入
  procedure importmat(a_mat_no   varchar2, --物料号
                      a_mat_desc varchar2, --物料名
                      ret_msg    out varchar2, --反馈信息
                      ret        out varchar2 --执行结果
                      ) is
  begin
    ret := 'Fail';
    insert into oil_mats (mat_no, mat_desc) values (a_mat_no, a_mat_desc);
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
end pg_oil13;
/

