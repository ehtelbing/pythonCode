create view VIEW_BASIC_PERSON as
select base_person.i_personid,
         base_person.v_personCode,
        base_person.v_personname,
        base_person.v_loginname,
        base_person.v_password,
        base_person.v_deptcode,
        base_person.v_class_code,
        (select base_deptclass.v_class_name
        from base_deptclass
        where base_deptclass.v_class_code =  base_person.v_class_code)v_class_name,
        base_dept.v_deptname,
        base_person.v_rolecode,
        base_personrole.v_rolename,
        '' as  v_postcode,
        FUNC_GETPERSONPOST(base_person.v_personCode) as v_postname,
        base_person.i_orderid,
        base_person.v_classCode,
        base_personrole.i_roleid,
        base_dept.i_deptid,
        '' i_postid,
        base_dept.v_deptsmallname,
        base_dept.v_deptfullname,
        base_dept.v_depttype,
        base_deptorg.v_deptcode v_orgcode,
        base_deptorg.v_deptname v_orgname

   from base_person
    INNER JOIN base_personrole   on base_person.v_rolecode = base_personrole.v_rolecode and substr(base_person.v_deptcode,0,4)=base_personrole.v_deptcode
       INNER JOIN   base_dept on base_person.v_deptcode = base_dept.v_deptcode
       LEFT OUTER JOIN base_dept base_deptorg on substr(base_person.v_deptcode,0,4) = base_deptorg.v_deptcode
/

