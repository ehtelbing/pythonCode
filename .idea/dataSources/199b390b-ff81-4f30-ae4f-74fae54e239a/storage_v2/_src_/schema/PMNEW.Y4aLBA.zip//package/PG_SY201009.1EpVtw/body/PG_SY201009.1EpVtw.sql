create package BODY PG_SY201009 is
  --母线试验数据录入
  --2,
  procedure pro_sy201009_twodetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select * from SY_RE_MX_JYDZ_MAIN a where a.record_id = recordcode_in;
  end;
  --2,添加
  procedure pro_sy201009_twoadd(recordcode_in varchar2,
                                v_yqxs        VARCHAR2,
                                v_yqbh        VARCHAR2,
                                v_a1          number,
                                v_b1          number,
                                v_c1          number,
                                --v_opuser      varchar2,
                                --v_recorduser  varchar2,
                                --v_jxuser varchar2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_MX_JYDZ_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_yqxs,
       v_yqbh,
       v_a1,
       v_b1,
       v_c1,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2,更新
  procedure pro_sy201009_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2,
                                   v_yqxs        VARCHAR2,
                                   v_yqbh        VARCHAR2,
                                   v_a1          number,
                                   v_b1          number,
                                   v_c1          number,
                                   --v_opuser      varchar2,
                                   -- v_recorduser  varchar2,
                                   -- v_jxuser varchar2,
                                   ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_MX_JYDZ_MAIN a
       set a.record_id = recordcode_in,
           a.yqxs      = v_yqxs,
           a.yqbh      = v_yqbh,
           a.a1        = v_a1,
           a.b1        = v_b1,
           a.c1        = v_c1
    -- a.op_user   = v_opuser,
    -- a.record_user = v_recorduser,
    --a.jx_user = v_jxuser
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3 母线工频耐压试验记录表
  --3,查询
  procedure pro_sy201009_threedetail(recordcode_in varchar2,
                                     v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select * from SY_RE_MX_GPNA_MAIN a where a.record_id = recordcode_in;
  end;
  --3,添加
  procedure pro_sy201009_threeadd(recordcode_in varchar2,
                                  v_yqxs        VARCHAR2,
                                  v_yqbh        VARCHAR2,
                                  v_a1          number,
                                  v_a2          number,
                                  v_a3          number,
                                  v_b1          number,
                                  v_b2          number,
                                  v_b3          number,
                                  v_c1          number,
                                  v_c2          number,
                                  v_c3          number,
                                  --v_opuser      varchar2,
                                  --v_recorduser  varchar2,
                                  --v_jxuser varchar2,
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_MX_GPNA_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_yqxs,
       v_yqbh,
       v_a1,
       v_a2,
       v_a3,
       v_b1,
       v_b2,
       v_b3,
       v_c1,
       v_c2,
       v_c3,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3,更新
  procedure pro_sy201009_threeupdate(v_id          varchar2,
                                     recordcode_in varchar2,
                                     v_yqxs        VARCHAR2,
                                     v_yqbh        VARCHAR2,
                                     v_a1          number,
                                     v_a2          number,
                                     v_a3          number,
                                     v_b1          number,
                                     v_b2          number,
                                     v_b3          number,
                                     v_c1          number,
                                     v_c2          number,
                                     v_c3          number,
                                     --v_opuser      varchar2,
                                     -- v_recorduser  varchar2,
                                     -- v_jxuser varchar2,
                                     ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_MX_GPNA_MAIN a
       set a.record_id = recordcode_in,
           a.yqxs      = v_yqxs,
           a.yqbh      = v_yqbh,
           a.a1        = v_a1,
           a.a2        = v_a2,
           a.a3        = v_a3,
           a.b1        = v_b1,
           a.b2        = v_b2,
           a.b3        = v_b3,
           a.c1        = v_c1,
           a.c2        = v_c2,
           a.c3        = v_c3
    --a.op_user   = v_opuser,
    -- a.record_user = v_recorduser,
    --a.jx_user = v_jxuser
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
end PG_SY201009;
/

