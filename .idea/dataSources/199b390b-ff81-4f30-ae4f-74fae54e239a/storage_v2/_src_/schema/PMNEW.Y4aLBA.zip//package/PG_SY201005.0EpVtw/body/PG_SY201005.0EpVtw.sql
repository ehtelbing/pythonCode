create package BODY PG_SY201005 is
  --过电压保护器试验记录
  --1. 查询
  procedure pro_sy201005_onedetail(recordcode_in varchar2, --记录ID
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select a.record_id,
             a.SY_LOC_DESC,
             a.sy_loc_code,
             a.sy_equ_id,
             a.sy_equ_name,
             a.sy_date,
             a.sy_weather,
             a.sy_temp,
             a.sy_reason,
             a.sy_verdict,
             b.gdy_type,
             b.gdy_kv,
             b.gqy_make,
             a.sy_resp_username, --负责人
             a.sy_resp_userid,
             a.sy_exa_userid,
             a.sy_exa_username, --审核人
             a.sy_recordid,
             a.sy_recordname, --记录人
             a.equtype_code,
             a.equtype_name,
             sy_opuserid,
             sy_opusername,
             sy_jxuserid,
             sy_jxusername,
             a.make_date, --制造日期
             a.outplant_date -- 出厂日期
        from SY_RECORD_MAIN a
        left outer join SY_RE_GDY_MAIN b
          on a.record_id = b.record_id
       where a.record_id = recordcode_in;
  end;
  --1.添加
  procedure pro_sy201005_oneadd(usercode_in     varchar2, --登录人
                                username_in     varchar2, --登录人姓名
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿
                                departcode_in   varchar2, --部门
                                plantname_in    varchar2, --厂矿名称
                                departname_in   varchar2, --部门名称
                                sydate_in          DATE, --实验时间
                                syloccode_in       varchar2, --实验地点编码
                                sylocname_in       varchar2, --实验地点名称
                                syequcode_in       varchar2, --实验设备编码
                                syequname_in       varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN   VARCHAR2,
                                SYEQUTYPTNAME_IN   VARCHAR2,
                                SYWEATHER_in       varchar2, --天气
                                sytemp_in          number, --气温
                                syreason_in        varchar2, --实验原因
                                SYVERDICT_in       varchar2, --结论
                                SYEXAUSERNAME_code varchar2, --审核人
                                SYEXAUSERNAME_in   varchar2,
                                SYRECORDID_IN      VARCHAR2, --记录人
                                SYRECORDNAME_IN    VARCHAR2,
                                SY_OPUSERID_in     VARCHAR2, ---操作人
                                SY_OPUSERNAME_in   VARCHAR2,
                                SY_JXUSERID_in     VARCHAR2, --接线人
                                SY_JXUSERNAME_in   VARCHAR2,
                                v_gdytype varchar2, --避雷器型号
                                v_gdykv   varchar2, --工作电压
                                v_gdymake varchar2, --制造厂
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2) as
    p_recordcode   varchar2(36) := FUNC_NEW_GUID();
    p_itemtypedesc varchar2(100);
    p_itemdesc     varchar2(50);
    p_printurl     varchar2(200);
  begin
    savepoint s;
    select t.itemtype_desc
      into p_itemtypedesc
      from SY_ITEM_TYPE t
     where t.itemtype = itemtypecode_in;
    select d.item_name
      into p_itemdesc
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    select d.item_url
      into p_printurl
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    insert into SY_RECORD_MAIN
      (RECORD_ID,
       RECORD_DATE,
       SY_DATE,
       RECORD_USERID,
       RECORD_USERNAME,
       DEPARTCODE,
       DEPARTNAME,
       PLANTCODE,
       PLANTNAME,
       SY_LOC_CODE,
       SY_LOC_DESC,
       SY_EQU_ID,
       SY_EQU_NAME,
       SY_WEATHER,
       SY_TEMP,
       SY_URL,
       SY_REASON,
       SY_VERDICT,
       SY_RESP_USERID,
       SY_RESP_USERNAME,
       SY_EXA_USERID,
       SY_EXA_USERNAME,
       RECORD_STATUS,
       ITEM_CODE,
       ITEM_NAME,
       ITEMTYPE,
       ITEMTYPE_DESC,
       SUBMIT_DATE,
       SUBMIT_USERID,
       SUBMIT_USERNAME,
       sy_recordid,
       sy_recordname,
       EQUTYPE_CODE,
       EQUTYPE_NAME,
       sy_opuserid,
       sy_opusername,
       sy_jxuserid,
       sy_jxusername,
       make_date,
       outplant_date)
    values
      (p_recordcode,
       sysdate,
       sydate_in,
       usercode_in,
       username_in,
       departcode_in,
       departname_in,
       plantcode_in,
       plantname_in,
       syloccode_in,
       sylocname_in,
       syequcode_in,
       syequname_in,
       SYWEATHER_in,
       sytemp_in,
       p_printurl,
       syreason_in,
       SYVERDICT_in,
       null,
       '',
       SYEXAUSERNAME_code,
       SYEXAUSERNAME_in,
       '未提交',
       itemcode_in,
       p_itemdesc,
       itemtypecode_in,
       p_itemtypedesc,
       null,
       null,
       null,
       SYRECORDID_IN,
       SYRECORDNAME_IN,
       SYEQUTYPTCODE_IN,
       SYEQUTYPTNAME_IN,
       SY_OPUSERID_in,
       SY_OPUSERNAME_in,
       SY_JXUSERID_in,
       SY_JXUSERNAME_in,
       make_date_in,
       outplant_date_in);
    --插入属性主表
    insert into SY_RE_GDY_MAIN
    values
      (p_recordcode, v_gdytype, v_gdykv, v_gdymake);
    commit;
    ret := p_recordcode;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --1,更新
  procedure pro_sy201005_oneupdate(recordcode_in      varchar2,
                                   usercode_in        varchar2, --登录人
                                   username_in        varchar2, --登录人姓名
                                   sydate_in          DATE, --实验时间
                                   syloccode_in       varchar2, --实验地点编码
                                   sylocname_in       varchar2, --实验地点名称
                                   syequcode_in       varchar2, --实验设备编码
                                   syequname_in       varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN   VARCHAR2,
                                   SYEQUTYPTNAME_IN   VARCHAR2,
                                   SYWEATHER_in       varchar2, --天气
                                   sytemp_in          number, --气温 12.3
                                   syreason_in        varchar2, --实验原因
                                   SYVERDICT_in       varchar2, --结论
                                   SYEXAUSERNAME_code varchar2, --审核人
                                   SYEXAUSERNAME_in   varchar2,
                                   SYRECORDID_IN      VARCHAR2, --记录人
                                   SYRECORDNAME_IN    VARCHAR2,
                                   SY_OPUSERID_in     VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in   VARCHAR2,
                                   SY_JXUSERID_in     VARCHAR2, --接线人
                                   SY_JXUSERNAME_in   VARCHAR2,
                                   v_gdytype varchar2, --避雷器型号
                                   v_gdykv   varchar2, --工作电压
                                   v_gdymake varchar2, --制造厂
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2) as
  begin
    savepoint s;
    update SY_RECORD_MAIN a
       set RECORD_DATE     = sysdate,
           SY_DATE         = sydate_in,
           RECORD_USERID   = usercode_in,
           RECORD_USERNAME = username_in,
           SY_LOC_CODE     = syloccode_in,
           SY_LOC_DESC     = sylocname_in,
           SY_EQU_ID       = syequcode_in,
           SY_EQU_NAME     = syequname_in,
           SY_WEATHER      = SYWEATHER_in,
           SY_TEMP         = sytemp_in,
           SY_REASON       = syreason_in,
           SY_VERDICT      = SYVERDICT_in,
           sy_exa_userid   = SYEXAUSERNAME_code,
           SY_EXA_USERNAME = SYEXAUSERNAME_in,
           a.sy_recordid   = SYRECORDID_IN,
           a.sy_recordname = SYRECORDNAME_IN,
           a.equtype_code  = SYEQUTYPTCODE_IN,
           a.equtype_name  = SYEQUTYPTNAME_IN,
           a.sy_opuserid   = SY_OPUSERID_in,
           a.sy_opusername = SY_OPUSERNAME_in,
           a.sy_jxuserid   = SY_JXUSERID_in,
           a.sy_jxusername = SY_JXUSERNAME_in,
           a.make_date     = make_date_in,
           a.outplant_date = outplant_date_in
     where RECORD_ID = recordcode_in;
    update SY_RE_GDY_MAIN a
       set a.gdy_type = v_gdytype,
           a.gdy_kv   = v_gdykv,
           a.gqy_make = v_gdymake
     where a.record_id = recordcode_in;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2.查询
  procedure pro_sy201005_twodetail(recordcode_in varchar2, --记录ID
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from SY_RE_GDY_CXLD_MAIN a
       where a.record_id = recordcode_in;
  end;
  --2,添加
  procedure pro_sy201005_twoadd(recordcode_in varchar2, --记录ID
                                v_YQXS        VARCHAR2, --仪器型式
                                v_YQBM        VARCHAR2, --仪器编码
                                v_ID_A1       VARCHAR2,
                                v_MAKEDATE_A1 DATE,
                                v_A1_DZ       NUMBER,
                                v_A1_1        NUMBER,
                                v_A1_2        NUMBER,
                                v_A1_XS       VARCHAR2,
                                v_A1_REMARK   VARCHAR2,
                                v_ID_A2       VARCHAR2,
                                v_MAKEDATE_A2 DATE,
                                v_A1_DZ2      NUMBER,
                                v_A2_1        NUMBER,
                                v_A2_2        NUMBER,
                                v_A2_XS       VARCHAR2,
                                v_A2_REMARK   VARCHAR2,
                                v_ID_A3       VARCHAR2,
                                v_MAKEDATE_A3 DATE,
                                v_A3_DZ       NUMBER,
                                v_A3_1        NUMBER,
                                v_A3_2        NUMBER,
                                v_A3_XS       VARCHAR2,
                                v_A3_REMARK   VARCHAR2,
                                v_ID_B1       VARCHAR2,
                                v_MAKEDATE_B1 DATE,
                                v_B1_DZ       NUMBER,
                                v_B1_1        NUMBER,
                                v_B1_2        NUMBER,
                                v_B1_XS       VARCHAR2,
                                v_B1_REMARK   VARCHAR2,
                                v_ID_B2       VARCHAR2,
                                v_MAKEDATE_B2 DATE,
                                v_B2_DZ       NUMBER,
                                v_B2_1        NUMBER,
                                v_B2_2        NUMBER,
                                v_B2_XS       VARCHAR2,
                                v_B2_REMARK   VARCHAR2,
                                v_ID_B3       VARCHAR2,
                                v_MAKEDATE_B3 DATE,
                                v_B3_DZ3      NUMBER,
                                v_B3_1        NUMBER,
                                v_B3_2        NUMBER,
                                v_B3_XS       VARCHAR2,
                                v_B3_REMARK   VARCHAR2,
                                v_ID_C1       VARCHAR2,
                                v_MAKEDATE_C1 DATE,
                                v_A1_DZ3      NUMBER,
                                v_C1_1        NUMBER,
                                v_C1_2        NUMBER,
                                v_C1_XS       VARCHAR2,
                                v_C1_REMARK   VARCHAR2,
                                v_ID_C2       VARCHAR2,
                                v_MAKEDATE_C2 DATE,
                                v_C2_DZ       NUMBER,
                                v_C2_1        NUMBER,
                                v_C2_2        NUMBER,
                                v_C2_XS       VARCHAR2,
                                v_C2_REMARK   VARCHAR2,
                                v_ID_C3       VARCHAR2,
                                v_MAKEDATE_C3 DATE,
                                v_C3_DZ       NUMBER,
                                v_C3_1        NUMBER,
                                v_C3_2        NUMBER,
                                v_C3_XS       VARCHAR2,
                                v_C3_REMARK   VARCHAR2,
                                -- v_OP_USER     VARCHAR2,
                                --v_RECORD_USER VARCHAR2,
                                -- v_JX_USER VARCHAR2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_GDY_CXLD_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_YQXS,
       v_YQBM,
       v_ID_A1,
       v_MAKEDATE_A1,
       v_A1_DZ,
       v_A1_1,
       v_A1_2,
       v_A1_XS,
       v_A1_REMARK,
       v_ID_A2,
       v_MAKEDATE_A2,
       v_A1_DZ2,
       v_A2_1,
       v_A2_2,
       v_A2_XS,
       v_A2_REMARK,
       v_ID_A3,
       v_MAKEDATE_A3,
       v_A3_DZ,
       v_A3_1,
       v_A3_2,
       v_A3_XS,
       v_A3_REMARK,
       v_ID_B1,
       v_MAKEDATE_B1,
       v_B1_DZ,
       v_B1_1,
       v_B1_2,
       v_B1_XS,
       v_B1_REMARK,
       v_ID_B2,
       v_MAKEDATE_B2,
       v_B2_DZ,
       v_B2_1,
       v_B2_2,
       v_B2_XS,
       v_B2_REMARK,
       v_ID_B3,
       v_MAKEDATE_B3,
       v_B3_DZ3,
       v_B3_1,
       v_B3_2,
       v_B3_XS,
       v_B3_REMARK,
       v_ID_C1,
       v_MAKEDATE_C1,
       v_A1_DZ3,
       v_C1_1,
       v_C1_2,
       v_C1_XS,
       v_C1_REMARK,
       v_ID_C2,
       v_MAKEDATE_C2,
       v_C2_DZ,
       v_C2_1,
       v_C2_2,
       v_C2_XS,
       v_C2_REMARK,
       v_ID_C3,
       v_MAKEDATE_C3,
       v_C3_DZ,
       v_C3_1,
       v_C3_2,
       v_C3_XS,
       v_C3_REMARK,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2，修改
  procedure pro_sy201005_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2, --记录ID
                                   v_YQXS        VARCHAR2, --仪器型式
                                   v_YQBM        VARCHAR2, --仪器编码
                                   v_ID_A1       VARCHAR2,
                                   v_MAKEDATE_A1 DATE,
                                   v_A1_DZ       NUMBER,
                                   v_A1_1        NUMBER,
                                   v_A1_2        NUMBER,
                                   v_A1_XS       VARCHAR2,
                                   v_A1_REMARK   VARCHAR2,
                                   v_ID_A2       VARCHAR2,
                                   v_MAKEDATE_A2 DATE,
                                   v_A1_DZ2      NUMBER,
                                   v_A2_1        NUMBER,
                                   v_A2_2        NUMBER,
                                   v_A2_XS       VARCHAR2,
                                   v_A2_REMARK   VARCHAR2,
                                   v_ID_A3       VARCHAR2,
                                   v_MAKEDATE_A3 DATE,
                                   v_A3_DZ       NUMBER,
                                   v_A3_1        NUMBER,
                                   v_A3_2        NUMBER,
                                   v_A3_XS       VARCHAR2,
                                   v_A3_REMARK   VARCHAR2,
                                   v_ID_B1       VARCHAR2,
                                   v_MAKEDATE_B1 DATE,
                                   v_B1_DZ       NUMBER,
                                   v_B1_1        NUMBER,
                                   v_B1_2        NUMBER,
                                   v_B1_XS       VARCHAR2,
                                   v_B1_REMARK   VARCHAR2,
                                   v_ID_B2       VARCHAR2,
                                   v_MAKEDATE_B2 DATE,
                                   v_B2_DZ       NUMBER,
                                   v_B2_1        NUMBER,
                                   v_B2_2        NUMBER,
                                   v_B2_XS       VARCHAR2,
                                   v_B2_REMARK   VARCHAR2,
                                   v_ID_B3       VARCHAR2,
                                   v_MAKEDATE_B3 DATE,
                                   v_B3_DZ3      NUMBER,
                                   v_B3_1        NUMBER,
                                   v_B3_2        NUMBER,
                                   v_B3_XS       VARCHAR2,
                                   v_B3_REMARK   VARCHAR2,
                                   v_ID_C1       VARCHAR2,
                                   v_MAKEDATE_C1 DATE,
                                   v_A1_DZ3      NUMBER,
                                   v_C1_1        NUMBER,
                                   v_C1_2        NUMBER,
                                   v_C1_XS       VARCHAR2,
                                   v_C1_REMARK   VARCHAR2,
                                   v_ID_C2       VARCHAR2,
                                   v_MAKEDATE_C2 DATE,
                                   v_C2_DZ       NUMBER,
                                   v_C2_1        NUMBER,
                                   v_C2_2        NUMBER,
                                   v_C2_XS       VARCHAR2,
                                   v_C2_REMARK   VARCHAR2,
                                   v_ID_C3       VARCHAR2,
                                   v_MAKEDATE_C3 DATE,
                                   v_C3_DZ       NUMBER,
                                   v_C3_1        NUMBER,
                                   v_C3_2        NUMBER,
                                   v_C3_XS       VARCHAR2,
                                   v_C3_REMARK   VARCHAR2,
                                   --v_OP_USER     VARCHAR2,
                                   --v_RECORD_USER VARCHAR2,
                                   -- v_JX_USER VARCHAR2,
                                   ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_GDY_CXLD_MAIN a
       set a.record_id = recordcode_in,
           yqxs        = v_YQXS,
           yqbm        = v_YQBM,
           id_a1       = v_ID_A1,
           makedate_a1 = (case
                           when v_MAKEDATE_A1 is not null then
                            v_MAKEDATE_A1
                           else
                            makedate_a1
                         end),
           a1_dz       = v_A1_DZ,
           a1_1        = v_A1_1,
           a1_2        = v_A1_2,
           a1_xs       = v_A1_XS,
           a1_remark   = v_A1_REMARK,
           id_a2       = v_ID_A2,
           makedate_a2 = (case
                           when v_MAKEDATE_A2 is not null then
                            v_MAKEDATE_A2
                           else
                            makedate_a2
                         end),
           a1_dz2      = v_A1_DZ2,
           a2_1        = v_A2_1,
           a2_2        = v_A2_2,
           a2_xs       = v_A2_XS,
           a2_remark   = v_A2_REMARK,
           id_a3       = v_ID_A3,
           makedate_a3 = (case
                           when v_MAKEDATE_A3 is not null then
                            v_MAKEDATE_A3
                           else
                            makedate_a3
                         end),
           a3_dz       = v_A3_DZ,
           a3_1        = v_A3_1,
           a3_2        = v_A3_2,
           a3_xs       = v_A3_XS,
           a3_remark   = v_A3_REMARK,
           id_b1       = v_ID_B1,
           makedate_b1 = (case
                           when v_MAKEDATE_B1 is not null then
                            v_MAKEDATE_B1
                           else
                            makedate_b1
                         end),
           b1_dz       = v_B1_DZ,
           b1_1        = v_B1_1,
           b1_2        = v_B1_2,
           b1_xs       = v_B1_XS,
           b1_remark   = v_B1_REMARK,
           id_b2       = v_ID_B2,
           makedate_b2 = (case
                           when v_MAKEDATE_B2 is not null then
                            v_MAKEDATE_B2
                           else
                            makedate_b2
                         end),
           b2_dz       = v_B2_DZ,
           b2_1        = v_B2_1,
           b2_2        = v_B2_2,
           b2_xs       = v_B2_XS,
           b2_remark   = v_B2_REMARK,
           id_b3       = v_ID_B3,
           makedate_b3 = (case
                           when v_MAKEDATE_B3 is not null then
                            v_MAKEDATE_B3
                           else
                            makedate_b3
                         end),
           b3_dz       = v_B3_DZ3,
           b3_1        = v_B3_1,
           b3_2        = v_B3_2,
           b3_xs       = v_B3_XS,
           b3_remark   = v_B3_REMARK,
           id_c1       = v_ID_C1,
           makedate_c1 = (case
                           when v_MAKEDATE_C1 is not null then
                            v_MAKEDATE_C1
                           else
                            makedate_c1
                         end),
           C1_dz       = v_A1_DZ3,
           c1_1        = v_C1_1,
           c1_2        = v_C1_2,
           c1_xs       = v_C1_XS,
           c1_remark   = v_C1_REMARK,
           id_c2       = v_ID_C2,
           makedate_c2 = (case
                           when v_MAKEDATE_C2 is not null then
                            v_MAKEDATE_C2
                           else
                            makedate_c2
                         end),
           c2_dz       = v_C2_DZ,
           c2_1        = v_C2_1,
           c2_2        = v_C2_2,
           c2_xs       = v_C2_XS,
           c2_remark   = v_C2_REMARK,
           id_c3       = v_ID_C3,
           makedate_c3 = (case
                           when v_MAKEDATE_C3 is not null then
                            v_MAKEDATE_C3
                           else
                            makedate_c3
                         end),
           c3_dz       = v_C3_DZ,
           c3_1        = v_C3_1,
           c3_2        = v_C3_2,
           c3_xs       = v_C3_XS,
           c3_remark   = v_C3_REMARK
    -- op_user     = v_OP_USER,
    --record_user = v_RECORD_USER,
    --jx_user = v_JX_USER
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3,查询
  procedure pro_sy201005_threedetail(recordcode_in varchar2,
                                     v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from SY_RE_GDY_JYDZ_MAIN a
       where a.record_id = recordcode_in;
  end;
  --3,添加
  procedure pro_sy201005_threeadd(recordcode_in VARCHAR2,
                                  v_yqxs        VARCHAR2,
                                  v_yqbh        VARCHAR2,
                                  v_a_ype       VARCHAR2,
                                  v_a_id        VARCHAR2,
                                  v_a_dz        NUMBER,
                                  v_a_kv        NUMBER,
                                  v_a_jg        VARCHAR2,
                                  v_b_type      VARCHAR2,
                                  v_b_id        VARCHAR2,
                                  v_b_dz        NUMBER,
                                  v_b_kv        NUMBER,
                                  v_b_jg        VARCHAR2,
                                  v_c_type      VARCHAR2,
                                  v_c_id        VARCHAR2,
                                  v_c_dz        NUMBER,
                                  v_c_kv        NUMBER,
                                  v_c_jg        VARCHAR2,
                                  --v_op_user     VARCHAR2,
                                  -- v_record_user VARCHAR2,
                                  --v_jx_user VARCHAR2,
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_GDY_JYDZ_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_yqxs,
       v_yqbh,
       v_a_ype,
       v_a_id,
       v_a_dz,
       v_a_kv,
       v_a_jg,
       v_b_type,
       v_b_id,
       v_b_dz,
       v_b_kv,
       v_b_jg,
       v_c_type,
       v_c_id,
       v_c_dz,
       v_c_kv,
       v_c_jg,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3,更新
  procedure pro_sy201005_threeupdate(v_id          varchar2,
                                     recordcode_in VARCHAR2,
                                     v_yqxs        VARCHAR2,
                                     v_yqbh        VARCHAR2,
                                     v_a_ype       VARCHAR2,
                                     v_a_id        VARCHAR2,
                                     v_a_dz        NUMBER,
                                     v_a_kv        NUMBER,
                                     v_a_jg        VARCHAR2,
                                     v_b_type      VARCHAR2,
                                     v_b_id        VARCHAR2,
                                     v_b_dz        NUMBER,
                                     v_b_kv        NUMBER,
                                     v_b_jg        VARCHAR2,
                                     v_c_type      VARCHAR2,
                                     v_c_id        VARCHAR2,
                                     v_c_dz        NUMBER,
                                     v_c_kv        NUMBER,
                                     v_c_jg        VARCHAR2,
                                     --v_op_user     VARCHAR2,
                                     --v_record_user VARCHAR2,
                                     --v_jx_user VARCHAR2,
                                     ret out VARCHAR2) as
  begin
    savepoint s;
    update SY_RE_GDY_JYDZ_MAIN
       set RECORD_ID = recordcode_in,
           yqxs      = v_yqxs,
           yqbh      = v_yqbh,
           a_ype     = v_a_ype,
           a_id      = v_a_id,
           a_dz      = v_a_dz,
           a_kv      = v_a_kv,
           a_jg      = v_a_jg,
           b_type    = v_b_type,
           b_id      = v_b_id,
           b_dz      = v_b_dz,
           b_kv      = v_b_kv,
           b_jg      = v_b_jg,
           c_type    = v_c_type,
           c_id      = v_c_id,
           c_dz      = v_c_dz,
           c_kv      = v_c_kv,
           c_jg      = v_c_jg
    --op_user   = v_op_user,
    --  record_user = v_record_user,
    --jx_user = v_jx_user
     where id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
end PG_SY201005;
/

