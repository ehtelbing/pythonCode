create view VIEW_RUN_EQU_YEILD_SAP as
select t.equ_id,t.equ_desc,p.v_sap_dept plantcode,p.v_deptname plantname,d.v_sap_dept departcode,d.v_deptname departname,to_number(to_char(y.workdate,'YYYYMMDD')) workdate,y.insert_value,c.cycle_unit
from RUN_EQU_DIC t
left outer join run_equ_yeild y on y.equ_id = t.equ_id
left outer join base_dept p on p.v_deptcode = t.plantcode
left outer join base_dept d on d.v_deptcode = t.departcode
left outer join run_cycle_dic c on c.cycle_id = y.cycle_id
/

