create view VIEW_RUN_BJ_CHANGE_LOG as
select l.id
      ,l.bj_unique_code
      ,l.changedate
      ,l.change_site_id
      ,s.site_desc change_site_desc
      ,func_run_getequname(s.equ_id) change_equname
      ,l.changeperson
      ,l.orderid
      ,l.direction
      ,l.reason_remark||','||l.remark remark
      ,c.materialcode
      ,m.materialname
      ,c.unit
      ,c.bj_id
      ,c.bj_desc
      ,c.neworold
      ,c.bj_status
      ,c.supply_code
      ,c.supply_name
      ,l.change_amount
  from run_cycle_bj_change_log l
  left outer  join view_run_bj_cycle c on c.bj_unique_code=l.bj_unique_code
  left outer  join run_site_dic s on s.site_id = l.change_site_id
  left outer join run_mat m on m.materialcode = c.materialcode
/

