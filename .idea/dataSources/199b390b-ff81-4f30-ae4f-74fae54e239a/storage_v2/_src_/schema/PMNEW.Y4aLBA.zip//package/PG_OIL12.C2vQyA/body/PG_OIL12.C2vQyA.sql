create package body pg_oil12 is

  --.查询和导出设备，调用过程pg_oil12.getinstequlist获取数据
  procedure getinstequlist(a_equtype    varchar2, --设备类型编码
                           a_plantcode  varchar2, --厂矿编码
                           a_departcode varchar2, --部门编码
                           a_equip_id   varchar2, --设备ID（设备编号）
                           a_equip_name varchar2, --设备名
                           ret          out sys_refcursor --返回数据集
                           ) is
  begin
    open ret for
      select i.inst_equip_id, --设备ID（设备编号）
             i.inst_equip_name, --设备名
             i.equip_no, --主机编号
             e.equip_desc, --主机名
             e.type_code, --设备类型编号
             t.type_desc, --设备类型名
             i.plantcode, --厂矿编码
             func_run_getdepartname(i.plantcode) plantname, --厂矿名称
             i.departcode, --部门编码
             func_run_getdepartname(i.departcode) departname, --厂矿名称
             i.inst_equip_remark, --设备备注
             i.inst_equip_status, --设备状态
             (case i.inst_equip_status
               when '1' then
                '正常运行'
               else
                '停用'
             end) inst_equip_status_desc, --设备状态描述
             i.del_flag, --删除状态
             (case i.del_flag
               when '0' then
                '未删除'
               else
                '已删除'
             end) del_flag_desc
        from oil_equip_inst i
        left outer join oil_equips e
          on e.equip_no = i.equip_no
        left outer join oil_equip_type t
          on t.type_code = e.type_code
       where i.del_flag = '0'
         and i.inst_equip_status = '1'
         and i.plantcode = a_plantcode
         and i.departcode like a_departcode
         and i.inst_equip_id like '%' || a_equip_id || '%'
         and i.inst_equip_name like '%' || a_equip_name || '%'
         and nvl(e.type_code, '未分配') like a_equtype
       order by i.inst_equip_id;
  end;
  procedure getinstequlist_dd(a_equtype    varchar2, --设备类型编码
                              a_plantcode  varchar2, --厂矿编码
                              a_departcode varchar2, --部门编码
                              a_equip_id   varchar2, --设备ID（设备编号）
                              a_equip_name varchar2, --设备名
                              ret          out sys_refcursor --返回数据集
                              ) is
  begin
    open ret for
      select i.inst_equip_id, --设备ID（设备编号）
             i.inst_equip_name --设备名

        from oil_equip_inst i
        left outer join oil_equips e
          on e.equip_no = i.equip_no
        left outer join oil_equip_type t
          on t.type_code = e.type_code
       where i.del_flag = '0'
         and i.inst_equip_status = '1'
         and i.plantcode = a_plantcode
         and i.departcode like a_departcode
         and i.inst_equip_id like '%' || a_equip_id || '%'
         and i.inst_equip_name like '%' || a_equip_name || '%'
         and nvl(e.type_code, '未分配') like a_equtype
       order by i.inst_equip_id;
  end;
  --电机“设置”按钮，调用过程pg_oil12.setequ_no
  procedure setequ_no(a_equip_id varchar2, --设备ID（设备编号）
                      a_equip_no varchar2, --主机编号
                      ret_msg    out varchar2, --反馈信息
                      ret        out varchar2 --执行结果
                      ) is

  begin
    ret := 'Fail';
    update oil_equip_inst i
       set i.equip_no = a_equip_no
     where i.inst_equip_id = a_equip_id;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
  procedure nosetequ_no(a_equip_id varchar2, --设备ID（设备编号）
                        ret_msg    out varchar2, --反馈信息
                        ret        out varchar2 --执行结果
                        ) is
  begin
    ret := 'Fail';
    update oil_equip_inst i
       set i.equip_no = null
     where i.inst_equip_id = a_equip_id;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
  --下方的人员表格调用过程pg_oil12.getequperson加载
  procedure getequperson(a_equip_id varchar2, --设备ID（设备编号）
                         ret        out sys_refcursor --返回数据集
                         ) is
  begin
    open ret for
      select p.userid, --用户名
             p.username --姓名
        from oil_equip_person p
       where p.inst_equip_id = a_equip_id;
  end;
  --单击该界面的保存按钮，调用过程pg_oil12.addequperson添加
  procedure addequperson(a_equip_id varchar2, --设备ID（设备编号）
                         a_userid   varchar2, --用户名
                         ret_msg    out varchar2, --反馈信息
                         ret        out varchar2 --执行结果
                         ) is
    p_username varchar2(50) := func_wp_getusername(a_userid);
  begin
    ret := 'Fail';
    insert into oil_equip_person
      (inst_equip_id, userid, username)
    values
      (a_equip_id, a_userid, p_username);
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
  --调用过程pg_oil12.deleteequperson删除选择的人员
  procedure deleteequperson(a_equip_id varchar2, --设备ID（设备编号）
                            a_userid   varchar2, --用户名
                            ret_msg    out varchar2, --反馈信息
                            ret        out varchar2 --执行结果
                            ) is
  begin
    ret := 'Fail';
    delete from oil_equip_person p
     where p.inst_equip_id = a_equip_id
       and p.userid = a_userid;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
end pg_oil12;
/

