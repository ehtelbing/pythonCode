create package body pg_oil6 is

  --6.1 按主机设备统计油品使用情况
  --查询和导出，调用过程pg_oil6.get_equoilconsume_table获取数据，并加载主机设备润滑油脂使用情况表格
  procedure get_equoilconsume_table(a_plantcode  varchar2, --厂矿编码
                                    a_departcode varchar2, --部门编码
                                    a_equtype    varchar2, --设备类型编码
                                    a_equip_id   varchar2, --设备编号（ID）
                                    a_begindate  date, --查询起始日期
                                    a_enddate    date, --查询结束日期
                                    a_mat_no     varchar2,
                                    a_mat_desc   varchar2,
                                    ret          out sys_refcursor --返回结果集
                                    ) is
  begin
    open ret for
      select c.inst_equip_code, --设备编码
             i.inst_equip_name, --设备名称
             func_run_getdepartname(c.plantcode) plantname, --厂矿名
             func_run_getdepartname(c.departcode) departname, --部门名
             c.oil_mat_no, --物料号
             c.oil_mat_desc, --物料名
             c.oil_unit, --计量单位
             c.oil_price, --单价
             c.oil_amount, --消耗数量
             (c.oil_price * c.oil_amount) oil_money, --金额
             to_char(c.out_date, 'YYYY-MM-DD') out_date --日期
        from oil_equip_consume c
        left outer join oil_equip_inst i
          on i.inst_equip_id = c.inst_equip_code
        left outer join oil_equips e
          on e.equip_no = i.equip_no
       where c.plantcode = a_plantcode
         and c.departcode like a_departcode
         and e.type_code like a_equtype
         and c.inst_equip_code like a_equip_id
         and to_number(to_char(c.out_date, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(c.out_date, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and c.oil_status = '1'
         and c.oil_mat_no like '%' || a_mat_no || '%'
         and c.oil_mat_desc like '%' || a_mat_desc || '%'
       order by c.out_date desc;
  end;
  --6.2 按主机设备部位统计油品使用情况
  --调用过程pg_oil6.get_equpart_draw获取数据，并更新图表。
  procedure get_equpart_draw(a_plantcode  varchar2, --厂矿编码
                             a_departcode varchar2, --部门编码
                             a_equtype    varchar2, --设备类型编码
                             a_equip_no   varchar2, --主机编号
                             a_part_no    varchar2, --部位码
                             a_begindate  date, --查询起始日期
                             a_enddate    date, --查询结束日期
                             ret          out sys_refcursor --返回结果集
                             ) is
  begin
    open ret for
      select c.inst_equip_code, --设备编号（ID）
             i.inst_equip_name, --设备名
             sum(p.use_amount) use_amount --消耗量
        from oil_equip_part_consume p
        left outer join oil_equip_consume c
          on c.consume_id = p.consume_id
        left outer join oil_equip_inst i
          on i.inst_equip_id = c.inst_equip_code
        left outer join oil_equips e
          on e.equip_no = i.equip_no
       where c.plantcode = a_plantcode
         and c.departcode like a_departcode
         and e.type_code like a_equtype
         and to_number(to_char(p.oiling_date, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(p.oiling_date, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and i.equip_no = a_equip_no
         and p.part_no = a_part_no
         and p.submit_flag = '1'
       group by c.inst_equip_code, i.inst_equip_name;
  end;
  --6.3 按油品统计使用情况
  --查询和导出：调用过程pg_oil6.get_oilmat_table获取数据，并加载润滑油品使用（消耗）情况表格
  procedure get_oilmat_table(a_plantcode  varchar2, --厂矿编码
                             a_departcode varchar2, --部门编码
                             a_begindate  date, --查询起始日期
                             a_enddate    date, --查询结束日期
                             a_mat_no     varchar2, --物料号
                             a_mat_desc   varchar2, --物料名
                             ret          out sys_refcursor --返回结果集
                             ) is
  begin
    open ret for
      select c.oil_mat_no, --物料号
             c.oil_mat_desc, --物料名
             c.oil_unit, --计量单位
             c.oil_price, --单价
             p.use_amount, --消耗数量
             (c.oil_price * p.use_amount) oil_money, --金额
             func_run_getdepartname(c.plantcode) plantname, --厂矿名
             func_run_getdepartname(c.departcode) departname, --部门名
             i.inst_equip_name, --设备名
             p.part_no, --部位码
             ep.part_desc, --部位名
             p.oil_enddate - p.oil_begindate as oiled_date --消耗时间
        from oil_equip_part_consume p
        left outer join oil_equip_consume c
          on c.consume_id = p.consume_id
        left outer join oil_equip_inst i
          on i.inst_equip_id = c.inst_equip_code
        left outer join oil_equips e
          on e.equip_no = i.equip_no
        left outer join oil_equip_parts ep
          on ep.part_no = p.part_no
       where c.plantcode = a_plantcode
         and c.departcode like a_departcode
         and to_number(to_char(p.oiling_date, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(p.oiling_date, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and c.oil_mat_no like '%' || a_mat_no || '%'
         and c.oil_mat_desc like '%' || a_mat_desc || '%'
         and c.oil_status = '1';
  end;
  --6.4 按供应商统计使用情况
  --4.查询和导出，调用过程pg_oil6.get_supplyoiluse_table获取数据并加载表格。
  procedure get_supplyoiluse_table(a_plantcode   varchar2, --厂矿编码
                                   a_departcode  varchar2, --部门编码
                                   a_begindate   date, --查询起始日期
                                   a_enddate     date, --查询结束日期
                                   a_mat_desc    varchar2, --物料名
                                   a_supply_code varchar2, --供应商编码
                                   ret           out sys_refcursor --返回结果集
                                   ) is
  begin
    open ret for
      select c.inst_equip_code, --设备编码
             i.inst_equip_name, --设备名称
             c.supplier_name, --供应商
             func_run_getdepartname(c.plantcode) plantname, --厂矿名
             func_run_getdepartname(c.departcode) departname, --部门名
             c.oil_mat_no, --物料号
             c.oil_mat_desc, --物料名
             c.oil_unit, --计量单位
             c.oil_price, --单价
             c.oil_amount, --消耗数量
             (c.oil_price * c.oil_amount) oil_money, --金额
             to_char(c.out_date, 'YYYY-MM-DD') out_date --日期
        from oil_equip_consume c
        left outer join oil_equip_inst i
          on i.inst_equip_id = c.inst_equip_code
        left outer join oil_equips e
          on e.equip_no = i.equip_no
       where c.plantcode = a_plantcode
         and c.departcode like a_departcode
         and c.supplier_code like a_supply_code
         and to_number(to_char(c.out_date, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(c.out_date, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and c.oil_mat_desc like '%' || a_mat_desc || '%'
         and c.oil_status = '1'
       order by c.out_date desc;
  end;
  --6.5 按油品单价统计使用情况
  --查询，调用过程pg_oil6.get_oilprice_draw加载图表。
  procedure get_oilprice_draw(a_plantcode  varchar2, --厂矿编码
                              a_departcode varchar2, --部门编码
                              a_begindate  date, --查询起始日期
                              a_enddate    date, --查询结束日期
                              ret          out sys_refcursor --返回结果集
                              ) is
  begin
    open ret for
      select price_desc, --单价
             sum(oil_amount) oil_amount --消耗数量
        from (select (case
                       when c.oil_price <= 1000 then
                        '1000以下'
                       when c.oil_price > 1000 and c.oil_price <= 3000 then
                        '1000-3000'
                       when c.oil_price > 3000 and c.oil_price <= 5000 then
                        '3000-5000'
                       when c.oil_price > 5000 and c.oil_price <= 10000 then
                        '5000-10000'
                       else
                        '10000以上'
                     end) price_desc, --单价
                     c.oil_amount, --消耗数量
                     (case
                       when c.oil_price <= 1000 then
                        '1'
                       when c.oil_price > 1000 and c.oil_price <= 3000 then
                        '2'
                       when c.oil_price > 3000 and c.oil_price <= 5000 then
                        '3'
                       when c.oil_price > 5000 and c.oil_price <= 10000 then
                        '4'
                       else
                        '5'
                     end) order_desc
                from oil_equip_consume c
                left outer join oil_equip_inst i
                  on i.inst_equip_id = c.inst_equip_code
                left outer join oil_equips e
                  on e.equip_no = i.equip_no
               where c.plantcode = a_plantcode
                 and c.departcode like a_departcode
                 and to_number(to_char(c.out_date, 'YYYYMMDD')) >=
                     to_number(to_char(a_begindate, 'YYYYMMDD'))
                 and to_number(to_char(c.out_date, 'YYYYMMDD')) <=
                     to_number(to_char(a_enddate, 'YYYYMMDD'))
                 and c.oil_status = '1') a
       group by price_desc;
  end;

  --6.6 按作业区统计使用情况
  --查询，调用过程pg_oil6.get_depart_draw加载图表。
  procedure get_depart_draw(a_plantcode varchar2, --厂矿编码
                            a_begindate date, --查询起始日期
                            a_enddate   date, --查询结束日期
                            ret         out sys_refcursor --返回结果集
                            ) is
  begin
    open ret for
      select func_run_getdepartname(c.departcode) departname, --部门名
             sum(c.oil_amount) oil_amount --消耗数量
        from oil_equip_consume c
        left outer join oil_equip_inst i
          on i.inst_equip_id = c.inst_equip_code
        left outer join oil_equips e
          on e.equip_no = i.equip_no
       where c.plantcode = a_plantcode
         and to_number(to_char(c.out_date, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(c.out_date, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and c.oil_status = '1'
       group by c.departcode;
  end;
end pg_oil6;
/

