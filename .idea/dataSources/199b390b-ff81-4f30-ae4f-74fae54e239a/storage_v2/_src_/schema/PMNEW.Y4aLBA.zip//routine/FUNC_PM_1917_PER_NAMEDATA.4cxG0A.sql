create function FUNC_PM_1917_PER_NAMEDATA(V_V_JXGX_CODE IN VARCHAR2)
  RETURN VARCHAR2 IS
  V_RESULT VARCHAR2(1500);
begin
  FOR C IN (SELECT D.v_pername_de
              FROM PM_1917_JXGX_PER_DATA D
             WHERE D.V_JXGX_CODE = V_V_JXGX_CODE) LOOP
    IF V_RESULT IS NULL OR V_RESULT = '' THEN
      V_RESULT := C.v_pername_de;
    ELSE
      V_RESULT := V_RESULT || ',' || C.v_pername_de;
    END IF;
  END LOOP;

  return(V_RESULT);
end FUNC_PM_1917_PER_NAMEDATA;
/

