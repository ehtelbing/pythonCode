create package body pg_pm_proj_bud is

  --获取工程大类列表
  procedure getProjectClassList(ret out sys_refcursor) is
  begin
    open ret for
      select c.class_code, --大类代码
             c.class_desc --大类描述
        from pm_bud_class c
       order by c.class_code;
  end;
  --获取工程列表
  procedure getProjectList(v_class_code varchar2, --工程大类代码
                           ret          out sys_refcursor) is
  begin
    open ret for
      select p.proj_code, --工程代码
             p.proj_desc --工程名称
        from pm_bud_project p
       where p.class_code = v_class_code
       order by p.proj_code;
  end;
  --获取定额预算费用表
  procedure getProjBudgetItemTable(v_class_code   varchar2, --工程大类代码
                                   v_proj_code    varchar2, --工程代码
                                   v_item_code    varchar2, --项目代码
                                   v_item_desc    varchar2, --项目描述
                                   v_dinge_code   varchar2, --定额代码
                                   v_machine_type varchar2, --主机规格型号
                                   v_machine_code varchar2, --主机代码
                                   v_machine_desc varchar2, --主机名
                                   ret            out sys_refcursor) is
  begin
    open ret for
      select m.main_id, --定额Id
             m.main_code,
             m.item_code,
             m.machine_type, --主机规格型号
             m.machine_code,
             m.machine_desc, --主机名
             m.person_money, --人工费
             m.mat_money, --材料备件费
             m.jx_money, --机械费
             (nvl(m.person_money, 0) + nvl(m.mat_money, 0) +
             nvl(m.jx_money, 0)) f_money, --总金额
             m.main_remark, --备注说明
             m.version_num, --版本号
             case m.version_status
               when '1' then
                '使用'
               else
                '停用'
             end version_status_desc, --版本状态
             c.class_code,
             c.class_desc, --工程大类描述
             p.proj_code, --工程代码
             p.proj_desc, --工程描述
             i.item_desc --项目描述
        from pm_bud_main m
        left outer join pm_bud_equ_item i
          on i.item_code = m.item_code
        left outer join pm_bud_project p
          on p.proj_code = i.proj_code
        left outer join pm_bud_class c
          on c.class_code = p.class_code
       where p.class_code like v_class_code
         and i.proj_code like v_proj_code
         and m.item_code like '%' || v_item_code || '%'
         and i.item_desc like '%' || v_item_desc || '%'
         and m.main_code like '%' || v_dinge_code || '%'
         and m.machine_type like '%' || v_machine_type || '%'
         and nvl(m.machine_code, 'N/A') like '%' || v_machine_code || '%'
         and nvl(m.machine_desc, 'N/A') like '%' || v_machine_desc || '%'
       order by m.machine_type, m.item_code;
  end;
  --根据定额ID，获取项目预算详细信息，pg_pm_proj_bud.getProjectBudgetItemMessage
  procedure getProjectBudgetItemMessage(v_dinge_id varchar2, --定额ID
                                        ret        out sys_refcursor) is
  begin
    open ret for
      select m.main_id, --定额Id
             m.main_code, --定额代码
             m.item_code, --项目代码
             m.machine_type, --主机规格型号
             m.machine_code, --主机代码
             m.machine_desc, --主机名
             m.person_money, --人工费
             m.mat_money, --材料备件费
             m.jx_money, --机械费
             (nvl(m.person_money, 0) + nvl(m.mat_money, 0) +
             nvl(m.jx_money, 0)) f_money, --总金额
             m.main_remark, --费用备注
             m.version_num, --版本号
             case m.version_status
               when '1' then
                '使用'
               else
                '停用'
             end version_status_desc, --版本状态
             c.class_code,
             c.class_desc, --工程大类描述
             p.proj_code, --工程代码
             p.proj_desc, --工程描述
             i.item_desc, --项目描述
             i.item_remark --项目备注
        from pm_bud_main m
        left outer join pm_bud_equ_item i
          on i.item_code = m.item_code
        left outer join pm_bud_project p
          on p.proj_code = i.proj_code
        left outer join pm_bud_class c
          on c.class_code = p.class_code
       where m.main_id = v_dinge_id;
  end;
  --根据定额ID，获取人工预算明细，pg_pm_proj_bud.getProjectBudgetItemPersonTable。
  procedure getProjectBudgetItemPerTable(v_dinge_id varchar2, --定额ID
                                         ret        out sys_refcursor) is
  begin
    open ret for
      select p.person_id, --人工ID
             p.gz_code, --工种代码
             p.gz_desc, --工种名称
             p.unit, --计算单位
             p.work_hour, --工时
             p.person_amount, --人数
             p.f_price, --单价
             (p.work_hour * p.person_amount * p.f_price) f_money, --金额
             p.person_remark --备注
        from pm_bud_main_person p
       where p.main_id = v_dinge_id
       order by p.gz_code;
  end;
  --根据定额ID，获取机械预算明细，pg_pm_proj_bud.getProjectBudgetItemJXTable。
  procedure getProjectBudgetItemJXTable(v_dinge_id varchar2, --定额ID
                                        ret        out sys_refcursor) is
  begin
    open ret for
      select j.jx_id, --机械ID
             j.jx_code, --机械代码
             j.jx_desc, --机械描述
             j.jx_unit, --费用单位
             j.f_price, --单价
             j.f_amount, --所需数量
             (j.f_price * j.f_amount) f_money, --金额
             j.jx_remark --备注
        from pm_bud_main_jx j
       where j.main_id = v_dinge_id
       order by j.jx_code;
  end;
  --根据定额ID，获取材料备件费用明细，pg_pm_proj_bud.getProjectBudgetItemMatTable。
  procedure getProjectBudgetItemMatTable(v_dinge_id varchar2, --定额ID
                                         ret        out sys_refcursor) is
  begin
    open ret for
      select m.mat_id, --物资ID
             m.mat_no, --物资码
             m.mat_desc, --物料描述
             m.mat_ltext, --规格型号
             m.mat_unit, --计量单位
             m.f_price, --单价
             m.f_amount, --所属数量
             (m.f_price * m.f_amount) f_money, --金额
             m.mat_class --物资分类
        from pm_bud_main_mat m
       where m.main_id = v_dinge_id
       order by m.mat_class, m.mat_no;
  end;
end pg_pm_proj_bud;
/

