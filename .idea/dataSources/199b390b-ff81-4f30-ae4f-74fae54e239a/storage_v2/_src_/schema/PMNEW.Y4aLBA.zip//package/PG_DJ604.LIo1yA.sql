create package pg_dj604 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/25 8:58:19
  -- Purpose :
  --电机维修台帐
  procedure getdjmendtable(a_datetype        varchar2, --时间类型
                           a_begindate       date, --            起始日期
                           a_enddate         date, --结束日期
                           a_dj_series_class varchar2, --电机类型
                           a_orderid         varchar2, --检修编号
                           a_sendplant       varchar2, --送修单位
                           a_plant           varchar2, --检修单位
                           a_dept            varchar2, --检修厂矿
                           a_group           varchar2, --检修班组
                           ret               out sys_refcursor);
end pg_dj604;
/

