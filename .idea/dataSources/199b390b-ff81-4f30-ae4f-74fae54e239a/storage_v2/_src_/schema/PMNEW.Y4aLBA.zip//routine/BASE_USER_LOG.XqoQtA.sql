create PROCEDURE BASE_USER_LOG(A_USERCODE     VARCHAR2,
                                         A_WORKCENTER           VARCHAR2,
                                         RET OUT VARCHAR2)

 IS
  P_RET        number;
BEGIN
  SELECT count(WORKCENTER)
      INTO P_RET
      FROM BASE_USER_TRENDS
     WHERE USERID = A_USERCODE;
  BEGIN
    if P_RET =0 THEN
    ret := add_user_trends(a_usercode, A_WORKCENTER);
    END IF;
    IF P_RET <>0 THEN
      ret := update_user_trends(a_usercode, A_WORKCENTER);
      END IF;
  EXCEPTION
    WHEN OTHERS THEN
      RET := SQLERRM;
  END;
END BASE_USER_LOG;
/

