create trigger BASE_DRAWING_TRI
  before insert
  on BASE_DRAWING
  for each row
declare
begin

  SELECT BASE_DRAWING_SEQ.NEXTVAL INTO :NEW.V_ID FROM DUAL;

end BASE_DRAWING_TRI;
/

