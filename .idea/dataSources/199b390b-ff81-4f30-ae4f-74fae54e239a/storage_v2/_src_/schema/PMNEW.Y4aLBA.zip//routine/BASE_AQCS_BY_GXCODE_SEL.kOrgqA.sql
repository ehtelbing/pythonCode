create PROCEDURE BASE_AQCS_BY_GXCODE_SEL(V_V_GX_CODE IN VARCHAR2, --工序编码
                                                    V_CURSOR    OUT SYS_REFCURSOR) IS
  /*传入工序查询安全措施*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT *
      FROM PM_1917_AQCS P
     WHERE P.V_AQCS_CODE IN
           (SELECT V_AQCS_CODE
              FROM PM_1917_JXGX_AQCS_DATA
             WHERE V_JXGX_CODE = V_V_GX_CODE);
END BASE_AQCS_BY_GXCODE_SEL;
/

