create procedure DEFECT_UPFILE_DELETE(V_FILECODE IN VARCHAR2, --文件编码,
RET          OUT VARCHAR2) is
begin
  DELETE FROM DEFECT_UPFILE U
     WHERE U.FILE_CODE = V_FILECODE;
     COMMIT;
     RET:='Success';
     exception
       when others then
         RET:='Fail';
end DEFECT_UPFILE_DELETE;
/

