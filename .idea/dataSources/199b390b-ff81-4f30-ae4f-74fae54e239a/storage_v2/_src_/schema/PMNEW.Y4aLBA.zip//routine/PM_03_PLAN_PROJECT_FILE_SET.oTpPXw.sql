create procedure PM_03_PLAN_PROJECT_FILE_SET(V_V_GUID IN VARCHAR2, --关系guid
                                                        -- V_V_FILEGUID  IN VARCHAR2, --附件唯一值
                                                        V_V_FILENAME  IN VARCHAR2, --附件名称
                                                        V_V_FILETYPE  IN VARCHAR2,--附件类型
                                                        V_V_FILE      IN BLOB, --文件流
                                                        V_V_INPERCODE IN VARCHAR2, --录入人
                                                        V_V_INPERNAME IN VARCHAR2, --录入人姓名
                                                        V_V_TYPE      IN VARCHAR2, --类型
                                                        V_INFO        OUT VARCHAR2) is

begin

  INSERT INTO PM_03_PLAN_PROJECT_FILE
    (V_GUID,
     V_FILEGUID,
     V_FILENAME,
     V_FILE,
     V_INPERCODE,
     V_INPERNAME,
     V_TYPE,
     V_FILETYPE)
  VALUES
    (V_V_GUID,
     createguid(),
     V_V_FILENAME,
     V_V_FILE,
     V_V_INPERCODE,
     V_V_INPERNAME,
     V_V_TYPE,
     V_V_FILETYPE);
  COMMIT;

  V_INFO := 'SUCCESS';

EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
  
end PM_03_PLAN_PROJECT_FILE_SET;
/

