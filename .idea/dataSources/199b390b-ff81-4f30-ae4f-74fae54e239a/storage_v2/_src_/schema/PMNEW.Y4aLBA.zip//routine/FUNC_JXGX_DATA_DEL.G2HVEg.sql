create FUNCTION FUNC_JXGX_DATA_DEL(V_V_JXGX_CODE IN VARCHAR2) RETURN VARCHAR2 IS
  BEGIN

      DELETE FROM PM_1917_JXGX_AQCS_DATA a where a.v_jxgx_code = V_V_JXGX_CODE;
  delete from pm_1917_jxgx_gj_data g where g.v_jxgx_code = V_V_JXGX_CODE;
  delete from pm_1917_jxgx_jj_data j where j.v_jxgx_code = V_V_JXGX_CODE;
  delete from pm_1917_jxgx_jsyq_data s where s.v_jxgx_code = V_V_JXGX_CODE;
  delete from pm_1917_jxgx_per_data p where p.v_jxgx_code = V_V_JXGX_CODE;
  delete from pm_1917_jxgx_wl_data w where w.v_jxgx_code = V_V_JXGX_CODE;
  delete from pm_1917_jxgx_data d where d.v_jxgx_code = V_V_JXGX_CODE;

    COMMIT;
    RETURN 'Success';
  EXCEPTION
    WHEN OTHERS THEN
      RETURN 'Fail';
END FUNC_JXGX_DATA_DEL;
/

