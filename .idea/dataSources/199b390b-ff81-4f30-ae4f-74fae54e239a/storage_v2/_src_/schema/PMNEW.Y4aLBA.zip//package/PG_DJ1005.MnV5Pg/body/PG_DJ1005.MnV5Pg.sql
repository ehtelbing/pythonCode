create package BODY pg_dj1005 is
  --获取收发存
  procedure getsfc(a_begindate  date, --起始日期
                   a_enddate    date, --结束日期
                   a_plantcode  varchar2, --厂矿编码
                   a_departcode varchar2, --部门编码
                   a_itype      varchar2, --物资分类
                   a_code       varchar2, --物资编码
                   a_name       varchar2, --物资名称
                   ret          out sys_refcursor) is
    p_begin number(8, 0) := to_number(to_char(a_begindate, 'YYYYMMDD'));
    p_end   number(8, 0) := to_number(to_char(a_enddate, 'YYYYMMDD'));
  begin
    open ret for
      select kc.materialcode,
             kc.materialname,
             kc.etalon,
             kc.unit,
             kc.f_price,
             sum(qc_amount) qc_amount,
             sum(qc_amount) * f_price qc_money,
             sum(in_amount) in_amount,
             sum(in_amount) * f_price in_money,
             sum(out_amount) out_amount,
             sum(out_amount) * f_price out_money,
             sum(qc_amount + in_amount - out_amount) qm_amount,
             sum((qc_amount + in_amount - out_amount)) * f_price qm_money
        from (select k.kcid,
                     sum(k.amount) -
                     (select nvl(sum(om.act_amount), 0)
                        from dj_order_mat om
                        left outer join dj_order o
                          on o.orderid = om.orderid
                       where to_number(to_char(o.insertdate, 'YYYYMMDD')) <
                             p_begin
                         and om.kcid = k.kcid) qc_amount,
                     0 in_amount,
                     0 out_amount
                from dj_mat_kc k
               where k.plantcode = a_plantcode
                 and k.departcode like func_isnull(a_departcode)
                 and k.i_type like func_isnull(a_itype)
                 and k.materialcode like '%' || func_isnull(a_code) || '%'
                 and k.materialname like '%' || func_isnull(a_name) || '%'
                 and to_number(to_char(k.insertdate, 'YYYYMMDD')) < p_begin
                 and k.useflag = '1'
               group by k.kcid
              union all
              select k.kcid, 0 qc_amount, k.amount in_amount, 0 out_amount
                from dj_mat_kc k
               where k.plantcode = a_plantcode
                 and k.departcode like func_isnull(a_departcode)
                 and k.i_type like func_isnull(a_itype)
                 and k.materialcode like '%' || func_isnull(a_code) || '%'
                 and k.materialname like '%' || func_isnull(a_name) || '%'
                 and to_number(to_char(k.insertdate, 'YYYYMMDD')) <= p_end
                 and to_number(to_char(k.insertdate, 'YYYYMMDD')) >= p_begin
                 and k.amount>0
                 and k.useflag = '1'
              union all
              select om.kcid,
                     0              qc_amount,
                     0              in_amount,
                     om.act_amount out_amount
                from dj_order_mat om
                left outer join dj_mat_kc k
                  on om.kcid = k.kcid
                left outer join dj_order o
                  on o.orderid = om.orderid
               where o.plantcode = a_plantcode
                 and o.departcode like func_isnull(a_departcode)
                 and k.i_type like func_isnull(a_itype)
                 and om.materialcode like '%' || func_isnull(a_code) || '%'
                 and om.materialname like '%' || func_isnull(a_name) || '%'
                 and to_number(to_char(o.insertdate, 'YYYYMMDD')) <= p_end
                 and to_number(to_char(o.insertdate, 'YYYYMMDD')) >= p_begin
                 and om.act_amount>0) a
        left outer join dj_mat_kc kc
          on a.kcid = kc.kcid
       where qc_amount > 0 or in_amount>0 or out_amount>0
       group by kc.materialcode,
                kc.materialname,
                kc.etalon,
                kc.unit,
                kc.f_price;
  end;
end pg_dj1005;
/

