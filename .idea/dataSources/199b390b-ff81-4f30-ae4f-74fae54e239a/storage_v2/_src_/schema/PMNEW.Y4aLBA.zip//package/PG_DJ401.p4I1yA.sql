create package pg_dj401 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/8/10 13:16:32
  -- Purpose :
  --工单申请编号生成
  procedure getapplyorderid(a_plantcode varchar2, --厂矿编码
                            ret         out varchar2);
end pg_dj401;
/

