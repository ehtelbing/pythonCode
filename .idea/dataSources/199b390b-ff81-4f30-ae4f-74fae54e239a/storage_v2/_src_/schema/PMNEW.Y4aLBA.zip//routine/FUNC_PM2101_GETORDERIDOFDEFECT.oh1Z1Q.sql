create function func_pm2101_getorderidofDEFECT(V_V_GUID in varchar2)
  return VARCHAR2 IS
  v_number      number;
  V_V_CODE_WEEK VARCHAR2(50);
  V_V_ORDERID   VARCHAR2(50);
  v_number2     number;
begin
  select count(*)
    into v_number
    from PM_PLAN_WEEK_DEFECT
   where V_DEFECTGUID = V_V_GUID;

  if v_number = 1 then
    select V_CODE_WEEK
      into V_V_CODE_WEEK
      from PM_PLAN_WEEK_DEFECT
     where V_DEFECTGUID = V_V_GUID;
    select V_ORDERID
      into V_V_ORDERID
      from PM_WORKORDER
     where PM_WORKORDER.V_WPCODE = V_V_CODE_WEEK;
  else
    select count(*)
      into v_number2
      from PM_WORKORDER
     where V_DEFECTGUID = V_V_GUID;
    if v_number2 = 1 then
      select V_ORDERID
        into V_V_ORDERID
        from PM_WORKORDER
       where V_DEFECTGUID = V_V_GUID;
    else
      return('');
    end if;

  end if;

  return(V_V_ORDERID);
end func_pm2101_getorderidofDEFECT;
/

