create PROCEDURE DEFECT_UPFILE_SELECT(V_GUID IN VARCHAR2, --文件编码
                                                 RET       OUT SYS_REFCURSOR) IS
BEGIN
  OPEN RET FOR
    SELECT U.FILE_CODE, --文件编码
           U.FILE_NAME, --文件名称
           U.FILE_TYPE, --文件类型
           U.INSERT_DATE, --传入时间
           U.INSERT_PERSON, --传入人编码
          -- sum(u.file_code) as Fcount,--对应缺陷的文件数量
           U.REMARK
      FROM DEFECT_UPFILE U
     WHERE U.DEFECT_CODE = V_GUID;

END DEFECT_UPFILE_SELECT;
/

