create function func_mm_guid return varchar2
--获取一个guid
 is
  v_guid varchar2(36);
begin
  v_guid := lower(sys_guid());
  return substr(v_guid, 1, 8) || '-' || substr(v_guid, 9, 4) || '-' || substr(v_guid,
                                                                              13,
                                                                              4) || '-' || substr(v_guid,
                                                                                                  17,
                                                                                                  4) || '-' || substr(v_guid,
                                                                                                                      21,
                                                                                                                      12);
end func_mm_guid;
/

