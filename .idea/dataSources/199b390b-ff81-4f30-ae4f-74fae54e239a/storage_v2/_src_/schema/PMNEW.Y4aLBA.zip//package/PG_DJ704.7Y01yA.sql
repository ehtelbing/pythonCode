create package pg_dj704 is
  -- Author  : ADMINISTRATOR
  -- Created : 2016/4/11 8:56:16
  -- Purpose : DJ704电机维修物资分类配置
  --1.查询：pg_dj704.getitypelist，页面加载时自动查询数据。
  procedure getitypelist(ret out sys_refcursor);
  -- 4.删除，调用过程pg_dj704.deleteitype,调用成功，更新表格内的数据。
  procedure deleteitype(a_typecode varchar2, --分类编码
                        a_userid   varchar2, --用户ID
                        a_username varchar2, --姓名
                        ret        out varchar2,
                        ret_msg    out varchar2);
  --5.新增-保存，调用过程pg_dj704.additype,其中使用状态和回收状态传入的参数为括号内的值。
  procedure additype(a_typecode    varchar2, --分类编码
                     a_typename    varchar2, --分类名
                     a_status      varchar2, --状态
                     a_type_prefix varchar2, --编码前缀
                     a_type_unit   varchar2, --默认单位
                     a_rec_status  varchar2, --回收状态
                     a_userid      varchar2, --用户ID
                     a_username    varchar2, --用户姓名
                     a_index       number,
                     ret           out varchar2,
                     ret_msg       out varchar2);
  --       7.修改-保存，调用过程pg_dj704.updteitype,其中使用状态和回收状态传入的参数为括号内的值。
  procedure updteitype(a_typecode    varchar2, --分类编码
                       a_typename    varchar2, --分类名
                       a_status      varchar2, --状态
                       a_type_prefix varchar2, --编码前缀
                       a_type_unit   varchar2, --默认单位
                       a_rec_status  varchar2, --回收状态
                       a_userid      varchar2, --用户ID
                       a_username    varchar2, --用户姓名
                       a_index       number,
                       ret           out varchar2,
                       ret_msg       out varchar2);
end pg_dj704;
/

