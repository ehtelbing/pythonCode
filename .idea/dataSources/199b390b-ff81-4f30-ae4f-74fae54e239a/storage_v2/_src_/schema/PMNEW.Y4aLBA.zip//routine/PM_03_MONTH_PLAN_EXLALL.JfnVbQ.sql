create procedure PM_03_MONTH_PLAN_EXLALL(V_V_YEAR      IN VARCHAR2, --年份
                                         V_V_MONTH     IN VARCHAR2, --月份
                                         V_V_ORGCODE   IN VARCHAR2, --厂矿编码
                                         V_V_DEPTCODE  IN VARCHAR2, --作业区变啊
                                         V_V_EQUTYPE   IN VARCHAR2, --设备类型编码
                                         V_V_EQUCODE   IN VARCHAR2, --设备名称编码
                                         V_V_ZY        IN VARCHAR2, --专业编码
                                         V_V_CONTENT   IN VARCHAR2, --检修内容
                                         V_V_STATECODE IN VARCHAR2, --计划状态
                                         V_V_PEROCDE   IN VARCHAR2, --人员编码
                                         V_CURSOR      OUT SYS_REFCURSOR) is

  /*
  月计划查询
    */
begin

  /*SELECT COUNT(*)
    INTO V_V_SNUM
    FROM VIEW_PM_PLAN_MONTH M
   WHERE M.V_YEAR = V_V_YEAR
     AND M.V_MONTH = V_V_MONTH
     AND NVL(M.V_ORGCODE, '%') LIKE V_V_ORGCODE
     AND NVL(M.V_DEPTCODE, '%') LIKE V_V_DEPTCODE
     AND NVL(M.V_REPAIRMAJOR_CODE, '%') LIKE NVL(V_V_ZY, '%')
     AND NVL(M.V_EQUCODE, '%') LIKE V_V_EQUCODE
     AND NVL(M.V_EQUTYPECODE, '%') LIKE V_V_EQUTYPE
     AND NVL(M.V_STATE, '%') IN ('70', '80')
     AND NVL(M.V_CONTENT, '%') LIKE '%' || V_V_CONTENT || '%'
   ORDER BY M.V_YEAR, M.V_MONTH, M.V_INDATE DESC;*/

  OPEN V_CURSOR FOR
    SELECT D.*
      FROM (SELECT C.*, rownum as rn
              FROM (SELECT M.*,
                           B.V_BASENAME AS V_FLOWNAME,
                           C.V_BASENAME AS V_STATENAME
                      FROM VIEW_PM_PLAN_MONTH M
                      LEFT JOIN PM_BASEDIC B
                        ON M.V_FLOWCODE = B.V_BASECODE
                       AND B.V_BASETYPE = 'PLAN/FLOW'
                      LEFT JOIN PM_BASEDIC C
                        ON M.V_STATE = C.V_BASECODE
                       AND C.V_BASETYPE = 'SBBPLAN/STATE'
                     WHERE M.V_YEAR = V_V_YEAR
                       AND M.V_MONTH = V_V_MONTH
                       AND NVL(M.V_ORGCODE, '%') LIKE V_V_ORGCODE
                       AND NVL(M.V_DEPTCODE, '%') LIKE V_V_DEPTCODE
                       AND NVL(M.V_REPAIRMAJOR_CODE, '%') LIKE
                           NVL(V_V_ZY, '%')
                       AND NVL(M.V_EQUCODE, '%') LIKE V_V_EQUCODE
                       AND NVL(M.V_EQUTYPECODE, '%') LIKE V_V_EQUTYPE
                       AND NVL(M.V_STATE, '%') IN ('70', '80')
                       AND NVL(M.V_CONTENT, '%') LIKE
                           '%' || V_V_CONTENT || '%'

                     ORDER BY M.V_YEAR, M.V_MONTH, M.V_INDATE DESC) C) D;
end PM_03_MONTH_PLAN_EXLALL;
/

