create package PG_SY201005 is
  --过电压保护器试验记录
  --1. 查询
  --1. 查询
  procedure pro_sy201005_onedetail(recordcode_in varchar2, --记录ID
                                   v_cursor      out sys_refcursor);
  --1.添加
  procedure pro_sy201005_oneadd(usercode_in     varchar2, --登录人cookie
                                username_in     varchar2, --登录人姓名cookie
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿cookie
                                departcode_in   varchar2, --部门cookie
                                plantname_in    varchar2, --厂矿名称cookie
                                departname_in   varchar2, --部门名称cookie
                                sydate_in          DATE, --实验时间
                                syloccode_in       varchar2, --实验地点编码
                                sylocname_in       varchar2, --实验地点名称
                                syequcode_in       varchar2, --实验设备编码
                                syequname_in       varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN   VARCHAR2,
                                SYEQUTYPTNAME_IN   VARCHAR2,
                                SYWEATHER_in       varchar2, --天气
                                sytemp_in          number, --气温
                                syreason_in        varchar2, --实验原因
                                SYVERDICT_in       varchar2, --结论
                                SYEXAUSERNAME_code varchar2, --审核人
                                SYEXAUSERNAME_in   varchar2,
                                SYRECORDID_IN      VARCHAR2, --记录人
                                SYRECORDNAME_IN    VARCHAR2,
                                SY_OPUSERID_in     VARCHAR2, ---操作人
                                SY_OPUSERNAME_in   VARCHAR2,
                                SY_JXUSERID_in     VARCHAR2, --接线人
                                SY_JXUSERNAME_in   VARCHAR2,
                                v_gdytype varchar2, --避雷器型号
                                v_gdykv   varchar2, --工作电压
                                v_gdymake varchar2, --制造厂
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2);
  --1,更新
  procedure pro_sy201005_oneupdate(recordcode_in      varchar2,
                                   usercode_in        varchar2, --登录人cookie
                                   username_in        varchar2, --登录人姓名cookie
                                   sydate_in          DATE, --实验时间
                                   syloccode_in       varchar2, --实验地点编码
                                   sylocname_in       varchar2, --实验地点名称
                                   syequcode_in       varchar2, --实验设备编码
                                   syequname_in       varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN   VARCHAR2,
                                   SYEQUTYPTNAME_IN   VARCHAR2,
                                   SYWEATHER_in       varchar2, --天气
                                   sytemp_in          number, --气温 12.3
                                   syreason_in        varchar2, --实验原因
                                   SYVERDICT_in       varchar2, --结论
                                   SYEXAUSERNAME_code varchar2, --审核人
                                   SYEXAUSERNAME_in   varchar2,
                                   SYRECORDID_IN      VARCHAR2, --记录人
                                   SYRECORDNAME_IN    VARCHAR2,
                                   SY_OPUSERID_in     VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in   VARCHAR2,
                                   SY_JXUSERID_in     VARCHAR2, --接线人
                                   SY_JXUSERNAME_in   VARCHAR2,
                                   v_gdytype varchar2, --避雷器型号
                                   v_gdykv   varchar2, --工作电压
                                   v_gdymake varchar2, --制造厂
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2);
  --2.查询
  procedure pro_sy201005_twodetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor);
  --2,添加
  procedure pro_sy201005_twoadd(recordcode_in varchar2, --记录ID
                                v_YQXS        VARCHAR2, --仪器型式
                                v_YQBM        VARCHAR2, --仪器编码
                                v_ID_A1       VARCHAR2,
                                v_MAKEDATE_A1 DATE,
                                v_A1_DZ       NUMBER,
                                v_A1_1        NUMBER,
                                v_A1_2        NUMBER,
                                v_A1_XS       VARCHAR2,
                                v_A1_REMARK   VARCHAR2,
                                v_ID_A2       VARCHAR2,
                                v_MAKEDATE_A2 DATE,
                                v_A1_DZ2      NUMBER,
                                v_A2_1        NUMBER,
                                v_A2_2        NUMBER,
                                v_A2_XS       VARCHAR2,
                                v_A2_REMARK   VARCHAR2,
                                v_ID_A3       VARCHAR2,
                                v_MAKEDATE_A3 DATE,
                                v_A3_DZ       NUMBER,
                                v_A3_1        NUMBER,
                                v_A3_2        NUMBER,
                                v_A3_XS       VARCHAR2,
                                v_A3_REMARK   VARCHAR2,
                                v_ID_B1       VARCHAR2,
                                v_MAKEDATE_B1 DATE,
                                v_B1_DZ       NUMBER,
                                v_B1_1        NUMBER,
                                v_B1_2        NUMBER,
                                v_B1_XS       VARCHAR2,
                                v_B1_REMARK   VARCHAR2,
                                v_ID_B2       VARCHAR2,
                                v_MAKEDATE_B2 DATE,
                                v_B2_DZ       NUMBER,
                                v_B2_1        NUMBER,
                                v_B2_2        NUMBER,
                                v_B2_XS       VARCHAR2,
                                v_B2_REMARK   VARCHAR2,
                                v_ID_B3       VARCHAR2,
                                v_MAKEDATE_B3 DATE,
                                v_B3_DZ3      NUMBER,
                                v_B3_1        NUMBER,
                                v_B3_2        NUMBER,
                                v_B3_XS       VARCHAR2,
                                v_B3_REMARK   VARCHAR2,
                                v_ID_C1       VARCHAR2,
                                v_MAKEDATE_C1 DATE,
                                v_A1_DZ3      NUMBER,
                                v_C1_1        NUMBER,
                                v_C1_2        NUMBER,
                                v_C1_XS       VARCHAR2,
                                v_C1_REMARK   VARCHAR2,
                                v_ID_C2       VARCHAR2,
                                v_MAKEDATE_C2 DATE,
                                v_C2_DZ       NUMBER,
                                v_C2_1        NUMBER,
                                v_C2_2        NUMBER,
                                v_C2_XS       VARCHAR2,
                                v_C2_REMARK   VARCHAR2,
                                v_ID_C3       VARCHAR2,
                                v_MAKEDATE_C3 DATE,
                                v_C3_DZ       NUMBER,
                                v_C3_1        NUMBER,
                                v_C3_2        NUMBER,
                                v_C3_XS       VARCHAR2,
                                v_C3_REMARK   VARCHAR2,
                                --v_OP_USER     VARCHAR2,
                                -- v_RECORD_USER VARCHAR2,
                                -- v_JX_USER VARCHAR2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2);
  --2，修改
  procedure pro_sy201005_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2, --记录ID
                                   v_YQXS        VARCHAR2, --仪器型式
                                   v_YQBM        VARCHAR2, --仪器编码
                                   v_ID_A1       VARCHAR2,
                                   v_MAKEDATE_A1 DATE,
                                   v_A1_DZ       NUMBER,
                                   v_A1_1        NUMBER,
                                   v_A1_2        NUMBER,
                                   v_A1_XS       VARCHAR2,
                                   v_A1_REMARK   VARCHAR2,
                                   v_ID_A2       VARCHAR2,
                                   v_MAKEDATE_A2 DATE,
                                   v_A1_DZ2      NUMBER,
                                   v_A2_1        NUMBER,
                                   v_A2_2        NUMBER,
                                   v_A2_XS       VARCHAR2,
                                   v_A2_REMARK   VARCHAR2,
                                   v_ID_A3       VARCHAR2,
                                   v_MAKEDATE_A3 DATE,
                                   v_A3_DZ       NUMBER,
                                   v_A3_1        NUMBER,
                                   v_A3_2        NUMBER,
                                   v_A3_XS       VARCHAR2,
                                   v_A3_REMARK   VARCHAR2,
                                   v_ID_B1       VARCHAR2,
                                   v_MAKEDATE_B1 DATE,
                                   v_B1_DZ       NUMBER,
                                   v_B1_1        NUMBER,
                                   v_B1_2        NUMBER,
                                   v_B1_XS       VARCHAR2,
                                   v_B1_REMARK   VARCHAR2,
                                   v_ID_B2       VARCHAR2,
                                   v_MAKEDATE_B2 DATE,
                                   v_B2_DZ       NUMBER,
                                   v_B2_1        NUMBER,
                                   v_B2_2        NUMBER,
                                   v_B2_XS       VARCHAR2,
                                   v_B2_REMARK   VARCHAR2,
                                   v_ID_B3       VARCHAR2,
                                   v_MAKEDATE_B3 DATE,
                                   v_B3_DZ3      NUMBER,
                                   v_B3_1        NUMBER,
                                   v_B3_2        NUMBER,
                                   v_B3_XS       VARCHAR2,
                                   v_B3_REMARK   VARCHAR2,
                                   v_ID_C1       VARCHAR2,
                                   v_MAKEDATE_C1 DATE,
                                   v_A1_DZ3      NUMBER,
                                   v_C1_1        NUMBER,
                                   v_C1_2        NUMBER,
                                   v_C1_XS       VARCHAR2,
                                   v_C1_REMARK   VARCHAR2,
                                   v_ID_C2       VARCHAR2,
                                   v_MAKEDATE_C2 DATE,
                                   v_C2_DZ       NUMBER,
                                   v_C2_1        NUMBER,
                                   v_C2_2        NUMBER,
                                   v_C2_XS       VARCHAR2,
                                   v_C2_REMARK   VARCHAR2,
                                   v_ID_C3       VARCHAR2,
                                   v_MAKEDATE_C3 DATE,
                                   v_C3_DZ       NUMBER,
                                   v_C3_1        NUMBER,
                                   v_C3_2        NUMBER,
                                   v_C3_XS       VARCHAR2,
                                   v_C3_REMARK   VARCHAR2,
                                   --v_OP_USER     VARCHAR2,
                                   -- v_RECORD_USER VARCHAR2,
                                   --v_JX_USER VARCHAR2,
                                   ret out varchar2);
  --3,查询
  procedure pro_sy201005_threedetail(recordcode_in varchar2,
                                     v_cursor      out sys_refcursor);
  --3,添加
  procedure pro_sy201005_threeadd(recordcode_in VARCHAR2,
                                  v_yqxs        VARCHAR2,
                                  v_yqbh        VARCHAR2,
                                  v_a_ype       VARCHAR2,
                                  v_a_id        VARCHAR2,
                                  v_a_dz        NUMBER,
                                  v_a_kv        NUMBER,
                                  v_a_jg        VARCHAR2,
                                  v_b_type      VARCHAR2,
                                  v_b_id        VARCHAR2,
                                  v_b_dz        NUMBER,
                                  v_b_kv        NUMBER,
                                  v_b_jg        VARCHAR2,
                                  v_c_type      VARCHAR2,
                                  v_c_id        VARCHAR2,
                                  v_c_dz        NUMBER,
                                  v_c_kv        NUMBER,
                                  v_c_jg        VARCHAR2,
                                  -- v_op_user     VARCHAR2,
                                  -- v_record_user VARCHAR2,
                                  --v_jx_user VARCHAR2,
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2);
  --3,更新
  procedure pro_sy201005_threeupdate(v_id          varchar2,
                                     recordcode_in VARCHAR2,
                                     v_yqxs        VARCHAR2,
                                     v_yqbh        VARCHAR2,
                                     v_a_ype       VARCHAR2,
                                     v_a_id        VARCHAR2,
                                     v_a_dz        NUMBER,
                                     v_a_kv        NUMBER,
                                     v_a_jg        VARCHAR2,
                                     v_b_type      VARCHAR2,
                                     v_b_id        VARCHAR2,
                                     v_b_dz        NUMBER,
                                     v_b_kv        NUMBER,
                                     v_b_jg        VARCHAR2,
                                     v_c_type      VARCHAR2,
                                     v_c_id        VARCHAR2,
                                     v_c_dz        NUMBER,
                                     v_c_kv        NUMBER,
                                     v_c_jg        VARCHAR2,
                                     --v_op_user     VARCHAR2,
                                     --v_record_user VARCHAR2,
                                     --v_jx_user VARCHAR2,
                                     ret out VARCHAR2);
end PG_SY201005;
/

