create PROCEDURE BASE_GX_WL_UPD(V_V_JXGX_CODE IN VARCHAR2,
                                           V_V_WLCODE    IN VARCHAR2,
                                           V_V_WLSM      IN VARCHAR2,
                                           V_V_GGXH      IN VARCHAR2,
                                           V_V_JLDW      IN VARCHAR2,
                                           V_V_PRICE     IN VARCHAR2,
                                           V_V_USE_NUM   IN VARCHAR2,
                                           V_INFO        OUT VARCHAR2) IS
    /*修改检修工序的物料*/
BEGIN
    UPDATE PM_1917_JXGX_WL_DATA B
    SET    B.V_WLSM    = V_V_WLSM,
           B.V_GGXH    = V_V_GGXH,
           B.V_JLDW    = V_V_JLDW,
           B.V_PRICE   = V_V_PRICE,
           B.V_USE_NUM = V_V_USE_NUM
    WHERE  B.V_JXGX_CODE = V_V_JXGX_CODE
    AND    B.V_WLCODE = V_V_WLCODE;
    V_INFO := 'SUCCESS';
EXCEPTION
    WHEN OTHERS THEN
        V_INFO := SQLERRM;
END BASE_GX_WL_UPD;
/

