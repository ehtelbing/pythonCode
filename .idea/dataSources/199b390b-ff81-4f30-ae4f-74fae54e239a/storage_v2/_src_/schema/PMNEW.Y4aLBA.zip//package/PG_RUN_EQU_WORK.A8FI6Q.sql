create PACKAGE PG_RUN_EQU_WORK
/*
说明：设备运行
*/
 IS
  --查询当前设备报警台账
  FUNCTION GET_EQU_ALERT_ALL(A_EQUID    VARCHAR2,
                             A_CYCLE_ID VARCHAR2,
                             RET        OUT SYS_REFCURSOR) RETURN VARCHAR2;
END PG_RUN_EQU_WORK;
/

