create package pg_dj1006 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/2 15:14:51
  -- Purpose :
  -- 获取消耗待回收工单
  procedure getconsumebyorder(a_begindate  date, --起始日期
                              a_enddate    date, --结束日期
                              a_orderid    varchar2, --检修单号
                              a_plantcode  varchar2, --厂矿编码
                              a_departcode varchar2, --部门编码
                              ret          out sys_refcursor);
  -- 获取消耗待回收
  procedure getordermatconsume(a_orderid varchar2, --检修单号
                               ret       out sys_refcursor);
  -- 获取消耗待回收
  procedure getconsume(a_begindate    date, --起始日期
                       a_enddate      date, --结束日期
                       a_orderid      varchar2, --检修单号
                       a_plantcode    varchar2, --厂矿编码
                       a_departcode   varchar2, --部门编码
                       a_itype        varchar2, --物资分类
                       a_storedesc    varchar2, --库房描述
                       a_materialcode varchar2, --物资分类
                       a_materialname varchar2, --物资名称
                       a_etalon       varchar2, --规格
                       a_lcodesc      varchar2, --存放位置描述
                       ret            out sys_refcursor);
  -- 获取消耗待回收
  procedure getconsumeselect(a_begindate    date, --起始日期
                             a_enddate      date, --结束日期
                             a_orderid      varchar2, --检修单号
                             a_plantcode    varchar2, --厂矿编码
                             a_departcode   varchar2, --部门编码
                             a_itype        varchar2, --物资分类
                             a_storedesc    varchar2, --库房描述
                             a_materialcode varchar2, --物资分类
                             a_materialname varchar2, --物资名称
                             a_etalon       varchar2, --规格
                             a_lcodesc      varchar2, --存放位置描述
                             ret            out sys_refcursor);
  --保存回收数量
  procedure save_recamount(a_id         varchar2, --工单物料消耗id
                           a_rec_amount varchar2, --回收数量
                           a_userid     varchar2, --用户ID
                           a_username   varchar2, --用户姓名
                           ret_msg      out varchar2,
                           ret          out varchar2);
  --确认回收
  procedure confirm_rec(a_id     varchar2, --工单物料消耗id
                        a_userid varchar2, --用户ID
                        ret_msg  out varchar2,
                        ret      out varchar2);
end pg_dj1006;
/

