create PACKAGE BODY PG_WP_MENDTYPE
/*
说明：维修计划——维修类型
*/
IS
    --查询全部维修类型
    FUNCTION GET_MENDTYPE_ALL(A_USEFLAG VARCHAR2
    ,RET OUT SYS_REFCURSOR)
    RETURN VARCHAR2
    IS
BEGIN
    OPEN RET FOR
    SELECT MENDTYPE_CODE --维修类型编码
          ,MENDTYPE_DESC --维修类型描述
          ,USEFLAG
          ,CASE USEFLAG WHEN '1' THEN '已启用' ELSE '已停用' END USEFLAG_DESC
      FROM WP_MENDTYPE
     WHERE USEFLAG LIKE A_USEFLAG;
    RETURN 'Success';
END;
--添加，修改维修类型
FUNCTION OP_MENDTYPE(A_MENDTYPE VARCHAR2 --维修类型
,A_MENDTYPE_DESC VARCHAR2 --维修类型描述
,A_USEFLAG VARCHAR2--使用状态
,A_OP VARCHAR2
)
RETURN VARCHAR2
IS
    P_RET VARCHAR2(10) := 'Fail';
    BEGIN
        IF A_OP = 'add' THEN
            INSERT INTO WP_MENDTYPE
                   (MENDTYPE_CODE
                   ,MENDTYPE_DESC
                   ,USEFLAG)
            VALUES (A_MENDTYPE
                   ,A_MENDTYPE_DESC
                   ,A_USEFLAG) ;
        ELSIF A_OP = 'update' THEN
            UPDATE WP_MENDTYPE
               SET MENDTYPE_DESC = A_MENDTYPE_DESC
                  ,USEFLAG = A_USEFLAG
             WHERE MENDTYPE_CODE = A_MENDTYPE;
        END IF;
        COMMIT;
        RETURN 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            RETURN P_RET;
    END;
END PG_WP_MENDTYPE;
/

