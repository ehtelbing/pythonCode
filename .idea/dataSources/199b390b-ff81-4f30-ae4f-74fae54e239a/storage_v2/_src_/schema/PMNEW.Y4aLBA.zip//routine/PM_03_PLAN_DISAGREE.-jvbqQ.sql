create procedure PM_03_PLAN_DISAGREE(V_V_GUID     IN VARCHAR2, --待办guid
                                                V_V_PLANTYPE IN VARCHAR2, --计划类型
                                                V_V_IDEA     IN VARCHAR2, --审批意见
                                                V_V_INPER    IN VARCHAR2, --审批人编码
                                                V_INFO       OUT VARCHAR2) is
  /*计划管理流程驳回*/
  V_V_DBGUID   VARCHAR2(50);
  V_V_ORDER    VARCHAR2(50);
  V_V_FLOWCODE VARCHAR2(50);

  V_V_PLANTYPE_NAME VARCHAR2(50);
  V_V_URL           VARCHAR2(50);
begin

  IF V_V_PLANTYPE = 'YEAR' THEN
    V_V_PLANTYPE_NAME := '年计划审批流程';
    V_V_URL           := '/PM_03010216/index.html';
  ELSIF V_V_PLANTYPE = 'QUARTER' THEN
    V_V_PLANTYPE_NAME := '季度计划审批流程';
    V_V_URL           := '/PM_03010115/index.html';
  ELSIF V_V_PLANTYPE = 'MONTH' THEN
    V_V_PLANTYPE_NAME := '月计划审批流程';
    V_V_URL           := '/PM_03010214/index.html';
  ELSIF V_V_PLANTYPE = 'WEEK' THEN
    V_V_PLANTYPE_NAME := '周计划审批流程';
    V_V_URL           := '/PM_03010308/index.html';
  END IF;
  --查询待办guid
  SELECT D.V_DBGUID
    INTO V_V_DBGUID
    FROM PM_WORKORDER_FLOW_DB D
   WHERE D.V_FLOWTYPE = V_V_PLANTYPE
     AND D.V_ORDERID = V_V_GUID
     AND D.I_STATUS = 0
     AND D.V_PERCODE = V_V_INPER;

  --修改审批信息
  UPDATE PM_WORKORDER_FLOW_DB D
     SET D.I_STATUS = 1,
         D.V_IDEA   = V_V_IDEA,
         D.V_DATE   = to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
   WHERE D.V_DBGUID = V_V_DBGUID;

  UPDATE PM_WORKORDER_FLOW_DB D
     SET D.I_STATUS = 1
   WHERE D.V_ORDERID = V_V_GUID;

  SELECT MIN(D.V_ORDER)
    INTO V_V_ORDER
    FROM PM_WORKORDER_FLOW_DB D
   WHERE D.V_ORDERID = V_V_GUID
     AND D.I_STATUS = 1;

  /*添加发起人信息*/
  INSERT INTO PM_WORKORDER_FLOW_DB
    (V_ORDERID,
     V_DBGUID,
     V_FLOWSTEP,
     I_STATUS,
     V_PERCODE,
     V_TS,
     V_FLOWTYPE,
     V_FLOWCODE,
     V_FLOWNAME,
     V_URL,
     V_ORDER)
    SELECT D.V_ORDERID,
           CREATEGUID(),
           '点检员重新发起',
           0,
           D.V_PERCODE,
           V_V_URL,
           V_V_PLANTYPE,
           D.V_FLOWCODE,
           V_V_PLANTYPE_NAME,
           V_V_URL,
           D.V_ORDER
      FROM PM_WORKORDER_FLOW_DB D
     WHERE D.V_ORDERID = V_V_GUID
       AND D.V_ORDER = V_V_ORDER
       AND ROWNUM = 1;

  SELECT DISTINCT D.V_FLOWCODE
    INTO V_V_FLOWCODE
    FROM PM_WORKORDER_FLOW_DB D
   WHERE D.V_ORDERID = V_V_GUID
     AND D.V_ORDER = V_V_ORDER;

  IF V_V_PLANTYPE = 'YEAR' THEN
    UPDATE PM_03_PLAN_YEAR Y
       SET Y.V_FLOWCODE = V_V_FLOWCODE, Y.V_STATE = 99
     WHERE Y.V_GUID = V_V_GUID;
  ELSIF V_V_PLANTYPE = 'QUARTER' THEN
    UPDATE PM_03_PLAN_QUARTER Q
       SET Q.V_FLOWCODE = V_V_FLOWCODE, Q.V_STATE = 99
     WHERE Q.V_GUID = V_V_GUID;
  ELSIF V_V_PLANTYPE = 'MONTH' THEN
    UPDATE PM_03_PLAN_MONTH M
       SET M.V_FLOWCODE = V_V_FLOWCODE, M.V_STATE = 99
     WHERE M.V_GUID = V_V_GUID;
  ELSIF V_V_PLANTYPE = 'WEEK' THEN
    UPDATE PM_03_PLAN_WEEK W
       SET W.V_FLOWCODE = V_V_FLOWCODE, W.V_STATE = 99
     WHERE W.V_GUID = V_V_GUID;
  END IF;
  COMMIT;
  V_INFO := '成功';

EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
end PM_03_PLAN_DISAGREE;
/

