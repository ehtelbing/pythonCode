create PROCEDURE ADD_PRELOADWARE(X_MODELNUMBER VARCHAR2,
                                            X_MODELNAME   VARCHAR2,
                                            X_UNIT        VARCHAR2,
                                            X_TYPE        VARCHAR2,
                                            X_SETSITE     VARCHAR2,
                                            X_MEMO        VARCHAR2,
                                            X_DRAWING     VARCHAR2,
                                            X_EQUTYPECODE VARCHAR2,
                                            X_DEPTCODE    VARCHAR2,
                                            X_SPAREPARTS  VARCHAR2, --
                                            X_YBJCODE     VARCHAR2,
                                            V_INFO        OUT VARCHAR2 ---
                                            ) IS
  TYPE A_SPAREPART IS RECORD(
    SPCODE      VARCHAR2(500),
    SPNAME      VARCHAR2(500),
    SPSIZE      VARCHAR2(500),
    SPUNITPRICE NUMBER,
    SPNUMBER    NUMBER);
  TYPE SPAREPARTS IS TABLE OF A_SPAREPART;
  T_SPAREPARTS SPAREPARTS := SPAREPARTS();
  FUNCTION SPAREPARTS_ANALYSE(X VARCHAR2) RETURN SPAREPARTS IS
    I               NUMBER := 1;
    J               NUMBER := 0;
    LEN             NUMBER;
    SPAREPARTDETAIL SPAREPARTS := SPAREPARTS();
    PIECE           VARCHAR2(2000);
  BEGIN
    LEN := LENGTH(X);
    WHILE J < LEN LOOP
      J := INSTR(X, '☆', I);
      IF J = 0 THEN
        J     := LEN;
        PIECE := SUBSTR(X, I);
        SPAREPARTDETAIL.EXTEND;
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPCODE := SUBSTR(PIECE,
                                                                1,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      1) - 1);
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPNAME := SUBSTR(PIECE,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      1) + 1,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      2) -
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      1) - 1);
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPSIZE := SUBSTR(PIECE,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      2) + 1,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      3) -
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      2) - 1);
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPUNITPRICE := TO_NUMBER(SUBSTR(PIECE,
                                                                               INSTR(PIECE,
                                                                                     ',',
                                                                                     1,
                                                                                     3) + 1,
                                                                               INSTR(PIECE,
                                                                                     ',',
                                                                                     1,
                                                                                     4) -
                                                                               INSTR(PIECE,
                                                                                     ',',
                                                                                     1,
                                                                                     3) - 1));
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPNUMBER := TO_NUMBER(SUBSTR(PIECE,
                                                                            INSTR(PIECE,
                                                                                  ',',
                                                                                  1,
                                                                                  4) + 1));
        IF I >= LEN THEN
          EXIT;
        END IF;
      ELSE
        PIECE := SUBSTR(X, I, J - I);
        I     := J + 1;
        SPAREPARTDETAIL.EXTEND;
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPCODE := SUBSTR(PIECE,
                                                                1,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      1) - 1);
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPNAME := SUBSTR(PIECE,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      1) + 1,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      2) -
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      1) - 1);
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPSIZE := SUBSTR(PIECE,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      2) + 1,
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      3) -
                                                                INSTR(PIECE,
                                                                      ',',
                                                                      1,
                                                                      2) - 1);
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPUNITPRICE := TO_NUMBER(SUBSTR(PIECE,
                                                                               INSTR(PIECE,
                                                                                     ',',
                                                                                     1,
                                                                                     3) + 1,
                                                                               INSTR(PIECE,
                                                                                     ',',
                                                                                     1,
                                                                                     4) -
                                                                               INSTR(PIECE,
                                                                                     ',',
                                                                                     1,
                                                                                     3) - 1));
        SPAREPARTDETAIL(SPAREPARTDETAIL.COUNT).SPNUMBER := TO_NUMBER(SUBSTR(PIECE,
                                                                            INSTR(PIECE,
                                                                                  ',',
                                                                                  1,
                                                                                  4) + 1));
      END IF;
    END LOOP;
    RETURN SPAREPARTDETAIL;
  END;
BEGIN
  T_SPAREPARTS := SPAREPARTS_ANALYSE(X_SPAREPARTS);
  ADD_PRELOADWARE_MAIN(X_MODELNUMBER,
                       X_MODELNAME,
                       X_UNIT,
                       X_TYPE,
                       X_SETSITE,
                       X_MEMO,
                       X_DRAWING,
                       X_EQUTYPECODE,
                       X_DEPTCODE,
                       X_YBJCODE);
  FOR I IN T_SPAREPARTS.FIRST .. T_SPAREPARTS.LAST LOOP
    ADD_PRELOADWARE_COMPONENT(X_MODELNUMBER,
                              I,
                              T_SPAREPARTS (I).SPCODE,
                              T_SPAREPARTS (I).SPNAME,
                              T_SPAREPARTS (I).SPSIZE,
                              T_SPAREPARTS (I).SPUNITPRICE,
                              T_SPAREPARTS (I).SPNUMBER);
  END LOOP;
  
  COMMIT;

END ADD_PRELOADWARE;
/

