create procedure BASE_PERSON_SEL_BYDEPT(V_V_DEPTCODE IN VARCHAR2,
                                                V_CURSOR     OUT SYS_REFCURSOR) is

  /*
  查询
  */
begin
  OPEN V_CURSOR FOR
    SELECT P.*
      FROM BASE_PERSON P
     WHERE P.V_DEPTCODE = V_V_DEPTCODE;
end BASE_PERSON_SEL_BYDEPT;
/

