create PROCEDURE BASE_JXMX_GJ_INS(V_V_JXGX_CODE IN VARCHAR2, --检修工序编码
                                             V_V_GJ_CODE   IN VARCHAR2, --工具编码
                                             V_V_GJ_NAME   IN VARCHAR2, --工具名称
                                             V_V_GJ_TYPE   IN VARCHAR2, --工具类型
                                             V_INFO        OUT VARCHAR2) IS
  /*
  新增检修工序的工具
  */
  V_NUMBER NUMBER;
BEGIN
  SELECT COUNT(*)
    INTO V_NUMBER
    FROM PM_1917_JXGX_GJ_DATA P
   WHERE P.V_JXGX_CODE = V_V_JXGX_CODE
     AND P.V_GJ_CODE = V_V_GJ_CODE;

  IF V_NUMBER = 0 THEN
    INSERT INTO PM_1917_JXGX_GJ_DATA
      (V_JXGX_CODE, V_GJ_CODE, V_GJ_NAME, V_GJ_TYPE)
    VALUES
      (V_V_JXGX_CODE, V_V_GJ_CODE, V_V_GJ_NAME, V_V_GJ_TYPE);
  END IF;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

END BASE_JXMX_GJ_INS;
/

