create procedure PM_03_PLAN_CPZL_SEL(V_V_SCLB IN VARCHAR2,
                                                V_CURSOR OUT SYS_REFCURSOR) is

  /*
  大修产品种类查询
  */
begin

  OPEN V_CURSOR FOR
    SELECT *
      FROM PM_03_PLAN_CPZL C
     WHERE C.V_LBBM = V_V_SCLB
     ORDER BY C.V_XH;

end PM_03_PLAN_CPZL_SEL;
/

