create function fund_dept_view_role2 return VARCHAR2 is 
                                                    V_CURSOR VARCHAR2(200);
 
BEGIN
  V_CURSOR:=('99060201,99060202,99060203');
  return(V_CURSOR);
end fund_dept_view_role2;
/

