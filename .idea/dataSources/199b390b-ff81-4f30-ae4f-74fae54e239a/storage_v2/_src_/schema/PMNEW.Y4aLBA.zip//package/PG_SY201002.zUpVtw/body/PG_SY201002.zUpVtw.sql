create package BODY PG_SY201002 is
  --刀闸实验数据录入修改
  --1 查询
  procedure pro_sy201002_onedetail(recordcode_in in varchar2,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select a.SY_LOC_DESC,
             a.sy_loc_code,
             a.sy_equ_id,
             a.sy_equ_name,
             a.sy_date,
             a.sy_weather,
             a.sy_temp,
             b.dz_code,
             b.dz_make,
             b.dz_type,
             b.dz_kv,
             b.dz_a,
             b.dz_outdate,
             a.sy_resp_username, --负责人
             a.sy_resp_userid,
             a.sy_exa_userid,
             a.sy_exa_username, --审核人
             a.sy_reason,
             a.sy_verdict,
             a.record_id,
             a.sy_recordid,
             a.sy_recordname, --记录人
             a.equtype_code,
             a.equtype_name, --设备种类
             a.sy_opuserid,
             a.sy_opusername, --操作人
             a.sy_jxuserid,
             a.sy_jxusername, --接线人
             a.make_date, --制造日期
             a.outplant_date --出厂日期
        from SY_RECORD_MAIN a
        left outer join SY_RE_DZ_MAIN b
          on a.record_id = b.record_id
       where b.record_id = recordcode_in;
  end;
  --1.添加
  procedure pro_sy201002_oneadd(usercode_in     varchar2,
                                username_in     varchar2,
                                itemtypecode_in varchar2,
                                itemcode_in     varchar2,
                                plantcode_in    varchar2,
                                departcode_in   varchar2,
                                plantname_in    varchar2,
                                departname_in   varchar2,
                                sydate_in           DATE,
                                syloccode_in        varchar2,
                                sylocname_in        varchar2,
                                syequcode_in        varchar2,
                                syequname_in        varchar2,
                                SYEQUTYPTCODE_IN    VARCHAR2, --设备种类编码
                                SYEQUTYPTNAME_IN    VARCHAR2, -- 设备种类名称
                                SYWEATHER_in        varchar2,
                                sytemp_in           number,
                                syreason_in         varchar2,
                                SYVERDICT_in        varchar2,
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,
                                v_dzcode    varchar2,
                                v_dzmake    varchar2,
                                v_dztype    varchar2,
                                v_dzkv      varchar2,
                                v_dza       varchar2,
                                v_dzoutdate date,
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2,
                                v_info           out varchar2,
                                v_info1          out varchar2,
                                v_info2          out varchar2) as
    p_recordcode   varchar2(36) := FUNC_NEW_GUID();
    p_itemtypedesc varchar2(100);
    p_itemdesc     varchar2(50);
    p_printurl     varchar2(200);
  begin
    savepoint s;
    select t.itemtype_desc
      into p_itemtypedesc
      from SY_ITEM_TYPE t
     where t.itemtype = itemtypecode_in;
    select d.item_name
      into p_itemdesc
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    select d.item_url
      into p_printurl
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    insert into SY_RECORD_MAIN
      (RECORD_ID,
       RECORD_DATE,
       SY_DATE,
       RECORD_USERID,
       RECORD_USERNAME,
       DEPARTCODE,
       DEPARTNAME,
       PLANTCODE,
       PLANTNAME,
       SY_LOC_CODE,
       SY_LOC_DESC,
       SY_EQU_ID,
       SY_EQU_NAME,
       SY_WEATHER,
       SY_TEMP,
       SY_URL,
       SY_REASON,
       SY_VERDICT,
       SY_RESP_USERID,
       SY_RESP_USERNAME,
       SY_EXA_USERID,
       SY_EXA_USERNAME,
       RECORD_STATUS,
       ITEM_CODE,
       ITEM_NAME,
       ITEMTYPE,
       ITEMTYPE_DESC,
       SUBMIT_DATE,
       SUBMIT_USERID,
       SUBMIT_USERNAME,
       SY_USERID,
       SY_USERNAME,
       SY_RECORDID,
       SY_RECORDNAME,
       EQUTYPE_CODE,
       EQUTYPE_NAME,
       SY_OPUSERID,
       SY_OPUSERNAME,
       SY_JXUSERID,
       SY_JXUSERNAME,
       make_date,
       outplant_date)
    values
      (p_recordcode,
       sysdate,
       sydate_in,
       usercode_in,
       username_in,
       departcode_in,
       departname_in,
       plantcode_in,
       plantname_in,
       syloccode_in,
       sylocname_in,
       syequcode_in,
       syequname_in,
       SYWEATHER_in,
       sytemp_in,
       p_printurl,
       syreason_in,
       SYVERDICT_in,
       SYRESPUSERNAME_code,
       SYRESPUSERNAME_in,
       SYEXAUSERNAME_code,
       SYEXAUSERNAME_in,
       '未提交',
       itemcode_in,
       p_itemdesc,
       itemtypecode_in,
       p_itemtypedesc,
       null,
       null,
       null,
       null,
       null,
       SYRECORDID_IN,
       SYRECORDNAME_IN,
       SYEQUTYPTCODE_IN,
       SYEQUTYPTNAME_IN,
       SY_OPUSERID_in,
       SY_OPUSERNAME_in,
       SY_JXUSERID_in,
       SY_JXUSERNAME_in,
       make_date_in,
       outplant_date_in);
    insert into SY_RE_DZ_MAIN
    values
      (p_recordcode,
       v_dzcode,
       v_dzmake,
       v_dztype,
       v_dzkv,
       v_dza,
       v_dzoutdate);
    commit;
    ret     := p_recordcode;
    v_info  := SYRECORDNAME_IN;
    v_info1 := SY_OPUSERNAME_in;
    v_info2 := SY_JXUSERNAME_in;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --更新
  procedure pro_sy201002_oneupdate(recordcode_in       varchar2,
                                   usercode_in         varchar2, --登录人cookie
                                   username_in         varchar2, --登录人姓名cookie
                                   sydate_in           DATE, --实验时间
                                   syloccode_in        varchar2, --实验地点编码
                                   sylocname_in        varchar2, --实验地点名称
                                   syequcode_in        varchar2, --实验设备编码
                                   syequname_in        varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN    VARCHAR2, --设备种类编码
                                   SYEQUTYPTNAME_IN    VARCHAR2, -- 设备种类名称
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温 12.3
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,
                                   v_dzcode         varchar2, --刀闸编码
                                   v_dzmake         varchar2, --制造商
                                   v_dztype         varchar2, --型号
                                   v_dzkv           varchar2, --定额电压
                                   v_dza            varchar2, --定额电流
                                   v_dzoutdate      date, --出厂,
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2) is
  begin
    savepoint s;
    update SY_RECORD_MAIN a
       set RECORD_DATE      = sysdate,
           SY_DATE          = sydate_in,
           RECORD_USERID    = usercode_in,
           RECORD_USERNAME  = username_in,
           SY_LOC_CODE      = syloccode_in,
           SY_LOC_DESC      = sylocname_in,
           SY_EQU_ID        = syequcode_in,
           SY_EQU_NAME      = syequname_in,
           SY_WEATHER       = SYWEATHER_in,
           SY_TEMP          = sytemp_in,
           SY_REASON        = syreason_in,
           SY_VERDICT       = SYVERDICT_in,
           sy_resp_userid   = SYRESPUSERNAME_code,
           SY_RESP_USERNAME = SYRESPUSERNAME_in,
           sy_exa_userid    = SYEXAUSERNAME_code,
           SY_EXA_USERNAME  = SYEXAUSERNAME_in,
           a.sy_recordid    = SYRECORDID_IN,
           a.sy_recordname  = SYRECORDNAME_IN,
           a.equtype_code   = SYEQUTYPTCODE_IN,
           a.equtype_name   = SYEQUTYPTNAME_IN,
           a.sy_opuserid    = SY_OPUSERID_in,
           a.sy_opusername  = SY_OPUSERNAME_in,
           a.sy_jxuserid    = SY_JXUSERID_in,
           a.sy_jxusername  = SY_JXUSERNAME_in,
           a.make_date      = make_date_in,
           a.outplant_date  = outplant_date_in
     where RECORD_ID = recordcode_in;
    update SY_RE_DZ_MAIN a
       set a.dz_code    = v_dzcode,
           a.dz_make    = v_dzmake,
           a.dz_type    = v_dztype,
           a.dz_kv      = v_dzkv,
           a.dz_a       = v_dza,
           a.dz_outdate = v_dzoutdate
     where a.record_id = recordcode_in;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
end PG_SY201002;
/

