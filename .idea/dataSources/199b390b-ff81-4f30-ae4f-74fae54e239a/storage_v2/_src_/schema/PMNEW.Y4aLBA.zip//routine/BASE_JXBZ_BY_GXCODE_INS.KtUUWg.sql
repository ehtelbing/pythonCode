create procedure BASE_JXBZ_BY_GXCODE_INS(V_V_JXGX_CODE in varchar2, --检修工序编码
                                                    V_V_JSYQ_CODE in varchar2, --技术要求编码
                                                    V_V_JSYQ_NAME in varchar2, --技术要求名称（零件名称）
                                                    V_INFO        out varchar2) is
  /*新增检修工序的检修技术标准*/
  V_NUMBER number;
begin

  select count(*)
    into V_NUMBER
    from PM_1917_JXGX_JSYQ_DATA P
   where P.V_JXGX_CODE = V_V_JXGX_CODE
     and P.V_JSYQ_CODE = V_V_JSYQ_CODE;

  if V_NUMBER = 0 then
    insert into PM_1917_JXGX_JSYQ_DATA (V_JXGX_CODE, V_JSYQ_CODE, V_JSYQ_NAME) values (V_V_JXGX_CODE, V_V_JSYQ_CODE, V_V_JSYQ_NAME);
  end if;

  V_INFO := 'SUCCESS';
exception
  when others then
    V_INFO := sqlerrm;

end BASE_JXBZ_BY_GXCODE_INS;
/

