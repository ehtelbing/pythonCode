create PROCEDURE BASE_JXMX_WL_INS(V_V_JXGX_CODE IN VARCHAR2, --检修工序编码
                                             V_V_WLCODE    IN VARCHAR2, --物料编码
                                             V_V_KFNAME    IN VARCHAR2, --库房名称
                                             V_V_WLSM      IN VARCHAR2, --物料描述
                                             V_V_GGXH      IN VARCHAR2, --规格型号
                                             V_V_JLDW      IN VARCHAR2, --计量单位
                                             V_V_PRICE     IN VARCHAR2, --单价
                                             V_V_USE_NUM   IN VARCHAR2, --使用数量
                                             V_INFO        OUT VARCHAR2) IS
    /*
    新增检修工序的物料
    */
    V_NUMBER NUMBER;
BEGIN
    SELECT COUNT(*)
    INTO   V_NUMBER
    FROM   PM_1917_JXGX_WL_DATA P
    WHERE  P.V_JXGX_CODE = V_V_JXGX_CODE
    AND    P.V_WLCODE = V_V_WLCODE;
    IF V_NUMBER = 0
    THEN
        INSERT INTO PM_1917_JXGX_WL_DATA
            (V_JXGX_CODE,
             V_WLCODE,
             V_KFNAME,
             V_WLSM,
             V_GGXH,
             V_JLDW,
             V_PRICE,
             V_USE_NUM)
        VALUES
            (V_V_JXGX_CODE,
             V_V_WLCODE,
             V_V_KFNAME,
             V_V_WLSM,
             V_V_GGXH,
             V_V_JLDW,
             V_V_PRICE,
             V_V_USE_NUM);
    END IF;
    V_INFO := 'SUCCESS';
EXCEPTION
    WHEN OTHERS THEN
        V_INFO := SQLERRM;
END BASE_JXMX_WL_INS;
/

