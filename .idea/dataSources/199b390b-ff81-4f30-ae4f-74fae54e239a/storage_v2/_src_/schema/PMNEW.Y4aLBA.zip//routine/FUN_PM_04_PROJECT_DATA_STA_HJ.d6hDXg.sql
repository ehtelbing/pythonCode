create FUNCTION FUN_PM_04_PROJECT_DATA_STA_HJ(V_D_DATE_B IN VARCHAR,
                                                         V_D_DATE_E IN VARCHAR,
                                                         V_V_GUID   IN VARCHAR)

 RETURN INTEGER IS
  V_I_RESULT INTEGER;

  V_WL_NUM NUMBER;
  V_GZ_NUM NUMBER;
  V_JJ_NUM NUMBER;
  V_GJ_NUM NUMBER;

BEGIN
  V_WL_NUM := 0;
  V_GZ_NUM := 0;
  V_JJ_NUM := 0;

  SELECT NVL(SUM(W.V_DJ), 0)
    INTO V_WL_NUM
    FROM PM_EQUREPAIRPLAN_TREE_WL W
   WHERE W.V_GUID IN
         (SELECT T.V_GUID
            FROM PM_EQUREPAIRPLAN_TREE T
           WHERE V_GUID_FXJH = V_V_GUID
             AND TO_DATE(T.V_DATE_B, 'YYYY/MM/DD  hh24:mi:ss') BETWEEN
                 TO_DATE(V_D_DATE_B || '00:00:00', 'YYYY/MM/DD  hh24:mi:ss') AND
                 TO_DATE(V_D_DATE_E || '23:59:59', 'YYYY/MM/DD  hh24:mi:ss'));

  SELECT NVL(SUM(Y.V_DE), 0)
    INTO V_GZ_NUM
    FROM PM_EQUREPAIRPLAN_TREE_YG Y
   WHERE /*Y.V_FLAG = 1
       AND*/
   Y.V_GUID IN
   (SELECT T.V_GUID
      FROM PM_EQUREPAIRPLAN_TREE T
     WHERE V_GUID_FXJH = V_V_GUID
       AND TO_DATE(T.V_DATE_B, 'YYYY/MM/DD  hh24:mi:ss') BETWEEN
           TO_DATE(V_D_DATE_B || '00:00:00', 'YYYY/MM/DD  hh24:mi:ss') AND
           TO_DATE(V_D_DATE_E || '23:59:59', 'YYYY/MM/DD  hh24:mi:ss'));

  SELECT NVL(SUM(C.V_DE), 0)
    INTO V_JJ_NUM
    FROM PM_EQUREPAIRPLAN_TREE_JJ J
    LEFT JOIN BASE_EXAMINE_CAR C
      ON J.V_JJ_CODE = C.V_CARCODE
   WHERE J.V_GUID IN
         (SELECT T.V_GUID
            FROM PM_EQUREPAIRPLAN_TREE T
           WHERE V_GUID_FXJH = V_V_GUID
             AND TO_DATE(T.V_DATE_B, 'YYYY/MM/DD  hh24:mi:ss') BETWEEN
                 TO_DATE(V_D_DATE_B || '00:00:00', 'YYYY/MM/DD  hh24:mi:ss') AND
                 TO_DATE(V_D_DATE_E || '23:59:59', 'YYYY/MM/DD  hh24:mi:ss'));

  V_I_RESULT := V_WL_NUM + V_GZ_NUM + V_JJ_NUM;

  RETURN V_I_RESULT;
END FUN_PM_04_PROJECT_DATA_STA_HJ;
/

