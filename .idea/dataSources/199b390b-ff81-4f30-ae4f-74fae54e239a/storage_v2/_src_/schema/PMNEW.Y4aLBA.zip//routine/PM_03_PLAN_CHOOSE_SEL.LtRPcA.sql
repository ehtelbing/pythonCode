create procedure PM_03_PLAN_CHOOSE_SEL(V_V_GUID     IN VARCHAR2,
                                                  V_V_PLANTYPE IN VARCHAR2,
                                                  V_CURSOR     OUT SYS_REFCURSOR) is

  /*计划选择单条计划查询过程*/
begin

  IF V_V_PLANTYPE = 'QUARTER' THEN
    OPEN V_CURSOR FOR
      SELECT * FROM VIEW_PM_PLAN_QUARTER Q WHERE Q.V_GUID = V_V_GUID;
  ELSIF V_V_PLANTYPE = 'MONTH' THEN
    OPEN V_CURSOR FOR
      SELECT * FROM VIEW_PM_PLAN_MONTH M WHERE M.V_GUID = V_V_GUID;
  END IF;

end PM_03_PLAN_CHOOSE_SEL;
/

