create package pg_run7113 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/2/15 9:11:08
  -- Purpose :

  -- 获取工单物资条码表
  procedure getordermatbarcode(a_orderid      varchar2, --工单号
                               a_materialcode varchar2, --物料号
                               ret            out sys_refcursor);
end pg_run7113;
/

