create procedure BASE_INSPECT_DAY_INSERT(V_MAINGUID VARCHAR2,
V_EQUCODE VARCHAR2,--设备编码
                                                    V_EQUNAME VARCHAR2,--设备名称
                                                    V_INSPECT_UNIT_CODE VARCHAR2,----点检部位编码
                                                    V_INSPECT_UNIT VARCHAR2, --点检部位名称
                                                    V_INSPECT_CONTENT VARCHAR2,--点检内容
                                                    V_INSPECT_STANDARD VARCHAR2,--点检标准
                                                    V_UUID VARCHAR2,----异常状态
                                                    V_PERCODE VARCHAR2,--当前登入人
                                                    V_PERNAME  VARCHAR2,--当前登入人姓名
                                                    RET OUT VARCHAR2
                                                    ) is
   --V_MAINGUID varchar2(50):=createguid();
begin
  INSERT INTO BASE_INSPECT_DAY_CONTENT(MAINGUID,
                                       EQUCODE,
                                       EQUNAME,
                                       INSPECT_UNIT_CODE,
                                       INSPECT_UNIT,
                                       INSPECT_CONTENT,
                                       INSPECT_STANDARD,
                                       IN_PERCODE,
                                       IN_PERNAME,
                                       IN_DATE,
                                       UUID)VALUES(V_MAINGUID,
                                       V_EQUCODE,
                                       V_EQUNAME,
                                       V_INSPECT_UNIT_CODE,
                                       V_INSPECT_UNIT,
                                       V_INSPECT_CONTENT,
                                       V_INSPECT_STANDARD,
                                       V_PERCODE,
                                       V_PERNAME,
                                       SYSDATE,
                                       V_UUID);
                                       COMMIT;
                                       RET:=V_MAINGUID;
                                       EXCEPTION
                                         WHEN OTHERS THEN 
                                           RET:='fail';

                                     
                                       
                                       
end BASE_INSPECT_DAY_INSERT;
/

