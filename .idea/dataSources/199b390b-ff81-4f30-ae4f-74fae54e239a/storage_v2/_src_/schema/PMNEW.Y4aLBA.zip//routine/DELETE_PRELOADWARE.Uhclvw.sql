create PROCEDURE DELETE_PRELOADWARE(X_MODELNUMBER IN VARCHAR2, -- 
                                               V_INFO           OUT VARCHAR2 --   
                                                                                            ) IS
  I_NUMBER           NUMBER;
  V_V_CK_LINK_TYPE_T VARCHAR2(50);
BEGIN
  /* 点检线路.线路点 写入/修改 */
  BEGIN
    DELETE FROM BASE_PRELOADWARECOMPONENT
     WHERE V_MODELNUMBER = X_MODELNUMBER;
    DELETE FROM BASE_PRELOADWAREMODEL WHERE V_MODELNUMBER = X_MODELNUMBER;
    
    commit;

    V_INFO := 'success';
  EXCEPTION
    WHEN OTHERS THEN
      V_INFO := SQLERRM;
  END;

END DELETE_PRELOADWARE;
/

