create procedure BASE_PERSON_DJY_SEL(V_V_DEPTCODE IN VARCHAR2,
                                                V_CURSOR     OUT SYS_REFCURSOR) is

  /*
  查询相应厂矿下的点检人员
  */
begin
  OPEN V_CURSOR FOR
    SELECT P.V_PERSONCODE, P.V_PERSONNAME
      FROM BASE_PERSON P
     WHERE P.V_ROLECODE = '01'
       AND P.V_DEPTCODE = V_V_DEPTCODE

    UNION
    SELECT '%' AS V_PERSONCODE, '全部' AS V_PERSONNAME FROM DUAL;
end BASE_PERSON_DJY_SEL;
/

