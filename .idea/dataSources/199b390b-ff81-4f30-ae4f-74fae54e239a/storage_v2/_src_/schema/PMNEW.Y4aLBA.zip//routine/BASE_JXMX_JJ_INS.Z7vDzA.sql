create PROCEDURE BASE_JXMX_JJ_INS(V_V_JXGX_CODE IN VARCHAR2, --检修工序编码
                                             V_V_JJ_CODE   IN VARCHAR2, --车辆编码
                                             V_V_JJ_NAME   IN VARCHAR2, --车辆名称
                                             V_V_JJ_TYPE   IN VARCHAR2, --车辆类型
                                             V_V_JJ_TS     IN VARCHAR2, --检修台时
                                             V_V_JJ_DE     IN VARCHAR2, --车辆定额
                                             V_INFO        OUT VARCHAR2) IS
  /*
  新增检修工序的机具
  */
  V_NUMBER NUMBER;
BEGIN
  SELECT COUNT(*)
    INTO V_NUMBER
    FROM PM_1917_JXGX_JJ_DATA P
   WHERE P.V_JXGX_CODE = V_V_JXGX_CODE
     AND P.V_JJ_CODE = V_V_JJ_CODE;

  IF V_NUMBER = 0 THEN
    INSERT INTO PM_1917_JXGX_JJ_DATA
      (V_JXGX_CODE,
       V_JJ_CODE,
       V_JJ_NAME,
       V_JJ_TYPE,
       V_JJ_TS,
       V_JJ_DE)
    VALUES
      (V_V_JXGX_CODE,
       V_V_JJ_CODE,
       V_V_JJ_NAME,
       V_V_JJ_TYPE,
       V_V_JJ_TS,
       V_V_JJ_DE);
  END IF;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

END BASE_JXMX_JJ_INS;
/

