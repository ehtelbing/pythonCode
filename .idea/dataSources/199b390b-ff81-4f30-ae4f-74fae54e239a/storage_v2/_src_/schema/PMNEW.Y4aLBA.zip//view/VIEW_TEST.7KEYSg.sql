create view VIEW_TEST as
SELECT PW.I_ID,
       PW.V_ORDERGUID, --工单GUID
       PW.V_ORDERID, --工单号
       PW.V_ORDER_TYP, --工单类型
       (CASE
         WHEN D.V_SOURCECODE = 'defct01' THEN
          PW.V_ORDER_TYP_TXT || '(快捷)'
         ELSE
          PW.V_ORDER_TYP_TXT
       END) AS V_ORDER_TYP_TXT,
       --  FUN_GET_V_ORDER_TYP_TXT(V_ORDERGUID) AS V_ORDER_TYP_TXT, --工单类型描述
       PW.V_FUNC_LOC, --功能位置编码
       PW.V_EQUSITENAME, --功能位置名称
       PW.V_EQUIP_NO, --设备编码
       PW.V_EQUIP_NAME, --设备名称
       PW.V_PLANT, --计划工厂编码
       PW.V_IWERK, --维护工厂编码
       PW.D_START_DATE, --计划开始时间
       PW.D_FINISH_DATE, --计划完成时间
       PW.D_FACT_START_DATE, --   实际开始日期
       PW.D_FACT_FINISH_DATE, --   实际完成日期
       (SELECT SUM(OP.I_WORK_ACTIVITY)
          FROM PM_WORKORDER_ET_OPERATIONS OP
         WHERE OP.V_ORDERGUID = PW.V_ORDERGUID) AS PLANTIME, --计划定额时间
       (SELECT SUM(OP.I_ACTUAL_TIME)
          FROM PM_WORKORDER_ET_OPERATIONS OP
         WHERE OP.V_ORDERGUID = PW.V_ORDERGUID) AS FACTTIME, --实际时间
       PW.V_ACT_TYPE, --PM作业类型
       PW.V_PLANNER, --计划员组
       PW.V_WORK_CTR, --维护工作中心
       PW.V_SHORT_TXT, --工单描述
       PW.V_GSBER, --业务范围
       PW.V_GSBER_TXT, --业务范围描述
       PW.V_WORK_AREA, --作业区
       PW.V_WBS, --WBS元素
       PW.V_WBS_TXT, --WBS元素描述
       PW.V_ENTERED_BY, --输入者
       PW.V_PERSONNAME,
       PW.D_ENTER_DATE, --创建日期
       PW.V_SYSTEM_STATUS, --系统状态
       PW.V_SYSNAME, --三级系统名称
       PW.V_ORGCODE, --d厂矿编码
       PW.V_ORGNAME, --厂矿名称
       PW.V_DEPTCODE, --w作业区编码
       PW.V_DEPTNAME, --作业区名称
       PW.V_DEPTCODEREPARIR, --检修单位编码
       PW.V_DEPTNAMEREPARIR, --检修单位名称
       PW.V_DEFECTGUID, --缺陷GUID
       PW.V_STATECODE, --工单状态编码
       PW.V_STATENAME, --工单状态名称 
       (SELECT TO_CHAR(WMSYS.WM_CONCAT(S.V_MATERIALNAME))
          FROM PM_WORKORDER_SPARE S
         WHERE S.V_ORDERGUID = PW.V_ORDERGUID) AS V_SPARE, 
       PW.V_TOOL, --工具
       PW.V_TECHNOLOGY, --工艺技术要求
       PW.V_SAFE, --安全措施要求
       PW.D_DATE_FK, --反馈时间.
       PW.D_DATE_ACP, --验收日期
       PW.I_OTHERHOUR, --提前/逾期时间
       PW.V_OTHERREASON, --逾期原因
       PW.V_REPAIRCONTENT, --检修方说明
       PW.V_REPAIRSIGN, --检修方签字
       PW.V_REPAIRPERSON, --检修人员
       PW.V_POSTMANSIGN, --岗位签字
       PW.V_CHECKMANCONTENT, --点检员验收意见
       PW.V_CHECKMANSIGN, --点检员签字
       PW.V_WORKSHOPCONTENT, --作业区验收
       PW.V_WORKSHOPSIGN, --作业区签字
       V_DEPTSIGN, --部门签字
       PW.V_SEND_STATE,
       (SELECT COUNT(*)
          FROM VIEW_PM_WORKORDER V
         WHERE V.V_ORDERGUID_UP = PW.V_ORDERGUID) AS WORKORDERNUM --子工单数量
  FROM VIEW_PM_WORKORDER PW
  LEFT JOIN PM_DEFECT D
    ON PW.V_DEFECTGUID = D.V_GUID
 WHERE PW.V_ORGCODE LIKE '9906' || '%'
   AND PW.V_DEPTCODE LIKE '%'
   AND NVL(PW.V_DEPTCODEREPARIR, ' ') LIKE '%'
   AND PW.V_STATECODE LIKE '%'
   AND PW.V_ORDER_TYP LIKE '%'
   AND NVL(PW.V_SHORT_TXT, ' ') || NVL(PW.V_ORDERID, '') LIKE '%'
   AND NVL(NVL(PW.V_SPARE, FUNC_GET_WORKORDER_OTHER_SPARE(PW.V_ORDERGUID)),
           '%') LIKE '%'
   AND PW.D_ENTER_DATE BETWEEN
       TO_DATE('2018-08-01' || '00:00:00', 'YYYY-mm-dd HH24:mi:ss') AND
       TO_DATE('2018-08-31' || '23:59:59', 'YYYY-mm-dd HH24:mi:ss')
   AND PW.V_ORDERGUID_UP IS NULL
/

