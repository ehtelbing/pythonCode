create PROCEDURE BASE_AQCS_ZG_EDIT(V_V_ZG_GUID   IN VARCHAR2,
                                              V_V_ZG_TIME   IN VARCHAR2,
                                              V_V_ZG_PLACE  IN VARCHAR2,
                                              V_V_ZG_PERSON IN VARCHAR2,
                                              V_V_ZG_DETAIL IN VARCHAR2,
                                              V_V_ZG_COST   IN VARCHAR2,
                                              V_INFO      OUT VARCHAR2) IS
  /*安全措施——整改新增与修改*/
  V_V_NUMBER VARCHAR2(50);
BEGIN

  SELECT COUNT(*)
    INTO V_V_NUMBER
    FROM BASE_AQCS_ZG T
   WHERE T.V_ZG_GUID = V_V_ZG_GUID;

  IF V_V_NUMBER = 0 THEN
    INSERT INTO BASE_AQCS_ZG
      (V_ZG_TIME, V_ZG_PLACE, V_ZG_PERSON, V_ZG_DETAIL, V_ZG_COST)
    VALUES
      (V_V_ZG_TIME,
       V_V_ZG_PLACE,
       V_V_ZG_PERSON,
       V_V_ZG_DETAIL,
       V_V_ZG_COST);

  ELSE
    UPDATE BASE_AQCS_ZG
       SET V_ZG_TIME   = V_V_ZG_TIME,
           V_ZG_PLACE  = V_V_ZG_PLACE,
           V_ZG_PERSON = V_V_ZG_PERSON,
           V_ZG_DETAIL = V_V_ZG_DETAIL,
           V_ZG_COST   = V_V_ZG_COST
     WHERE V_ZG_GUID = V_V_ZG_GUID;
  END IF;

  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

END BASE_AQCS_ZG_EDIT;
/

