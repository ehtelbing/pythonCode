create FUNCTION FUNC_SAP_GETTYPETX(V_V_EQUTYPECODE IN VARCHAR2,
                                              V_NUMBER        IN VARCHAR2)
  RETURN VARCHAR2 IS
  V_RESULT VARCHAR2(50);
BEGIN
  SELECT CASE V_NUMBER
           WHEN '1' THEN
            V_EQUTYPETX1
           WHEN '2' THEN
            V_EQUTYPETX2
           WHEN '3' THEN
            V_EQUTYPETX3
           WHEN '4' THEN
            V_EQUTYPETX4
           WHEN '5' THEN
            V_EQUTYPETX5
           WHEN '6' THEN
            V_EQUTYPETX6
           WHEN '7' THEN
            V_EQUTYPETX7
           WHEN '8' THEN
            V_EQUTYPETX8
           WHEN '9' THEN
            V_EQUTYPETX9
           WHEN '10' THEN
            V_EQUTYPETX10
           WHEN '11' THEN
            V_EQUTYPETX11
           WHEN '12' THEN
            V_EQUTYPETX12
           WHEN '13' THEN
            V_EQUTYPETX13
           WHEN '14' THEN
            V_EQUTYPETX14
           WHEN '15' THEN
            V_EQUTYPETX15
           WHEN '16' THEN
            V_EQUTYPETX16
           WHEN '17' THEN
            V_EQUTYPETX17
           WHEN '18' THEN
            V_EQUTYPETX18
           WHEN '19' THEN
            V_EQUTYPETX19
           WHEN '20' THEN
            V_EQUTYPETX20
           WHEN '21' THEN
            V_EQUTYPETX21
           WHEN '22' THEN
            V_EQUTYPETX22
           WHEN '23' THEN
            V_EQUTYPETX23
           WHEN '24' THEN
            V_EQUTYPETX24
           WHEN '25' THEN
            V_EQUTYPETX25
           WHEN '26' THEN
            V_EQUTYPETX26
           WHEN '27' THEN
            V_EQUTYPETX27
           WHEN '28' THEN
            V_EQUTYPETX28
           WHEN '29' THEN
            V_EQUTYPETX29
           WHEN '30' THEN
            V_EQUTYPETX30
           WHEN '31' THEN
            V_EQUTYPETX31
           WHEN '32' THEN
            V_EQUTYPETX32
           WHEN '33' THEN
            V_EQUTYPETX33
           WHEN '34' THEN
            V_EQUTYPETX34
           WHEN '35' THEN
            V_EQUTYPETX35
           WHEN '36' THEN
            V_EQUTYPETX36
           WHEN '37' THEN
            V_EQUTYPETX37
           WHEN '38' THEN
            V_EQUTYPETX38
           WHEN '39' THEN
            V_EQUTYPETX39
           WHEN '40' THEN
            V_EQUTYPETX40
           WHEN '41' THEN
            V_EQUTYPETX41
           WHEN '42' THEN
            V_EQUTYPETX42
           WHEN '43' THEN
            V_EQUTYPETX43
           WHEN '44' THEN
            V_EQUTYPETX44
           WHEN '45' THEN
            V_EQUTYPETX45
           WHEN '46' THEN
            V_EQUTYPETX46
           WHEN '47' THEN
            V_EQUTYPETX47
           WHEN '48' THEN
            V_EQUTYPETX48
           WHEN '49' THEN
            V_EQUTYPETX49
           WHEN '50' THEN
            V_EQUTYPETX50
           WHEN '51' THEN
            V_EQUTYPETX51
           WHEN '52' THEN
            V_EQUTYPETX52
           WHEN '53' THEN
            V_EQUTYPETX53
           WHEN '54' THEN
            V_EQUTYPETX54
           WHEN '55' THEN
            V_EQUTYPETX55
           WHEN '56' THEN
            V_EQUTYPETX56
           WHEN '57' THEN
            V_EQUTYPETX57
           WHEN '58' THEN
            V_EQUTYPETX58
           WHEN '59' THEN
            V_EQUTYPETX59
           WHEN '60' THEN
            V_EQUTYPETX60
           WHEN '61' THEN
            V_EQUTYPETX61
           WHEN '62' THEN
            V_EQUTYPETX62
           WHEN '63' THEN
            V_EQUTYPETX63
           WHEN '64' THEN
            V_EQUTYPETX64
           WHEN '65' THEN
            V_EQUTYPETX65
           WHEN '66' THEN
            V_EQUTYPETX66
           WHEN '67' THEN
            V_EQUTYPETX67
           WHEN '68' THEN
            V_EQUTYPETX68
         END
         into V_RESULT
    FROM SAP_PM_EQU_TYPE
   WHERE V_EQUTYPECODE = V_V_EQUTYPECODE;
  RETURN(V_RESULT);
END FUNC_SAP_GETTYPETX;
/

