create package BODY pg_dj1007 is
  --获取申料清单
  procedure getapplymat(a_begindate date, --起始日期
                        a_enddate   date, --结束日期
                        a_itype     varchar2, --物资分类
                        a_name      varchar2, --物资名称
                        ret         out sys_refcursor) is
    p_begin number(8, 0) := to_number(to_char(a_begindate, 'YYYYMMDD'));
    p_end   number(8, 0) := to_number(to_char(a_enddate, 'YYYYMMDD'));
  begin
    open ret for
      select a.applyid,
             a.materialname,
             a.etalon,
             a.unit,
             a.amount,
             a.groupname,
             a.remark,
             to_char(a.apply_date, 'YYYYMMDD') apply_date
        from dj_mat_apply a
       where to_number(to_char(a.apply_date, 'YYYYMMDD')) between p_begin and
             p_end
         and a.i_type like a_itype
         and a.materialname like '%' || a_name || '%'
         and del_flag = '0';
  end;
  --新增申料
  procedure saveapplymat(a_code       varchar2, --物资编码
                         a_name       varchar2, --物资名称
                         a_etalon     varchar2, --规格型号
                         a_unit       varchar2, --计量单位
                         a_itype      varchar2, --物资分类
                         a_amount     number, --数量
                         a_applydate  date, --日期
                         a_remark     varchar2, --备注
                         a_groupname  varchar2, --班组
                         a_lypersonid varchar2,
                         a_lyperson   varchar2, --领用人名
                         a_userid     varchar2, --用户ID
                         a_username   varchar2, --用户名
                         a_kcid       varchar2, --库存ID
                         ret_msg      out varchar2,
                         ret          out varchar2) is
  begin
    ret := 'Fail';
    savepoint s;
    insert into dj_mat_apply
      (APPLYID,
       MATERIALCODE,
       MATERIALNAME,
       ETALON,
       UNIT,
       AMOUNT,
       GROUPNAME,
       REMARK,
       INSERT_USERID,
       INSERT_USERNAME,
       INSERTDATE,
       DEL_FLAG,
       DEL_PERSON,
       I_TYPE,
       APPLY_DATE,
       kc_id,
       apply_userid,
       apply_username)
    values
      (func_new_guid(),
       a_code,
       a_name,
       a_etalon,
       a_unit,
       a_amount,
       a_groupname,
       a_remark,
       a_userid,
       a_username,
       sysdate,
       '0',
       null,
       a_itype,
       a_applydate,
       a_kcid,
       a_lypersonid,
       a_lyperson);
    update dj_mat_kc
       set ky_amount = ky_amount - a_amount
     where kcid = a_kcid;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret_msg := sqlerrm;
  end;
  --删除申料
  procedure deleteapplymat(a_applyid  varchar2, --申料ID
                           a_userid   varchar2, --用户ID
                           a_username varchar2, --用户名
                           ret_msg    out varchar2,
                           ret        out varchar2) is
    p_kcid   dj_mat_apply.kc_id%type;
    p_amount dj_mat_apply.amount%type;
  begin
    ret := 'Fail';
    select nvl(kc_id, '0'), nvl(a.amount, 0)
      into p_kcid, p_amount
      from dj_mat_apply a
     where a.applyid = a_applyid;

    savepoint s;
    update dj_mat_apply a
       set a.del_flag = '1', a.del_person = a_username
     where a.applyid = a_applyid;
    update dj_mat_kc k
       set k.ky_amount = ky_amount + p_amount
     where k.kcid = p_kcid;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret_msg := sqlerrm;
  end;
end pg_dj1007;
/

