create trigger PRO_CL_WORKORDER_DATA_SET_TRI
  before insert
  on CL_WORKORDER_DATA
  for each row
declare
  -- local variables here
begin
  SELECT PRO_CL_WORKORDER_DATA_SET_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
end PRO_CL_WORKORDER_DATA_SET_TRI;
/

