create package pg_oil11 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/6 13:41:16
  -- Purpose : 1.1 设备润滑规范管理（地址：JMM_AK/page/oil/11.jsp）

  --1.选择设备类型列表：pg_oil11.getequtypelist_able
  procedure getequtypelist_able(ret out sys_refcursor);
  --2.查询，更新左侧主机名称表格，调用过程pg_oil11.get_equlist
  procedure get_equlist(a_equtype varchar2, --设备类型编码
                        ret       out sys_refcursor);
  --新增规范：显示出新增规范界面，保存调用过程pg_oil11.addequ
  procedure addequ(a_equtype    varchar2, --设备类型编码
                   a_equip_no   varchar2, --主机编号
                   a_equip_name varchar2, --主机名
                   a_remark     varchar2, --备注
                   a_equ_level  varchar2,
                   ret_msg      out varchar2, --反馈信息
                   ret          out varchar2 --执行结果
                   );
  --删除调用过程pg_oil11.deleteequ
  procedure deleteequ(a_equip_no varchar2, --主机编号
                      ret_msg    out varchar2, --反馈信息
                      ret        out varchar2 --执行结果
                      );
  --原选中行数据调用过程pg_oil11.getequdetail获取
  procedure getequdetail(a_equip_no varchar2, --主机编号
                         ret        out sys_refcursor);
  --保存调用过程pg_oil11.updateequ
  procedure updateequ(a_equip_no   varchar2, --主机编号
                      a_equip_name varchar2, --主机名
                      a_equtype    varchar2, --设备类型编码
                      a_remark     varchar2, --备注
                      a_equ_level  varchar2,
                      ret_msg      out varchar2, --反馈信息
                      ret          out varchar2 --执行结果
                      );
  --点击“润滑规范”，更新右侧的部位表格，调用过程pg_oil11.getpartlist
  procedure getpartlist_select(a_equip_no  varchar2, --主机编号
                               a_mat_no    varchar2,
                               a_mat_desc  varchar2,
                               a_part_desc varchar2,
                               ret         out sys_refcursor);
  procedure getpartlist(a_equip_no varchar2, --主机编号
                        a_mat_no   varchar2,
                        ret        out sys_refcursor);

  --新增部位按钮，打开“新增部位”界面，保存调用过程pg_oil11.addpart
  procedure addpart(a_part_no          varchar2, --部位编号
                    a_part_desc        varchar2, --部位名
                    a_equip_no         varchar2, --主机编号
                    a_work_desc        varchar2, --工况情况
                    a_oil_type         varchar2, --加油方式
                    a_oil_etalon       varchar2, --规范油品型号
                    a_oil_qs           varchar2, --产品标准
                    a_part_remark      varchar2, --部位备注
                    a_design_oil_code  varchar2, --设计油品牌号
                    a_summer_oil_code  varchar2, --夏季油品牌号
                    a_winter_oil_code  varchar2, --冬季油品牌号
                    a_current_oil_code varchar2, --目前使用油品牌号
                    a_userid           varchar2,
                    a_ip               varchar2,
                    a_part_level       varchar2,
                    ret_msg            out varchar2, --反馈信息
                    ret                out varchar2 --执行结果
                    );
  --根据物料号获取物料名
  function getmatdesc(a_mat_no varchar2) return varchar2;
  --点击“删除选中的部位”，调用过程pg_oil11.deletepart
  procedure deletepart(a_part_no varchar2, --部位编号
                       a_userid  varchar2,
                       a_ip      varchar2,
                       ret_msg   out varchar2, --反馈信息
                       ret       out varchar2 --执行结果
                       );
  --部位详细信息调用pg_oil11.getpartdetail过程获取
  procedure getpartdetail(a_part_no varchar2, --部位编号
                          ret       out sys_refcursor);
  --其中部位编号只读，保存调用过程pg_oil11.updatepart
  procedure updatepart(a_part_no          varchar2, --部位编号
                       a_part_desc        varchar2, --部位名
                       a_equip_no         varchar2, --主机编号
                       a_work_desc        varchar2, --工况情况
                       a_oil_type         varchar2, --加油方式
                       a_oil_etalon       varchar2, --规范油品型号
                       a_oil_qs           varchar2, --产品标准
                       a_part_remark      varchar2, --部位备注
                       a_design_oil_code  varchar2, --设计油品牌号
                       a_summer_oil_code  varchar2, --夏季油品牌号
                       a_winter_oil_code  varchar2, --冬季油品牌号
                       a_current_oil_code varchar2, --目前使用油品牌号
                       a_userid           varchar2,
                       a_ip               varchar2,
                       a_part_level       varchar2,
                       ret_msg            out varchar2, --反馈信息
                       ret                out varchar2 --执行结果
                       );
  --原加油周期数据调用过程pg_oil11.getpart_oil获取
  procedure getpart_oil(a_part_no varchar2, ret out sys_refcursor);
  --保存调用pg_oil11.setpart_oil
  procedure setpart_oil(a_equip_no      varchar2, --主机编号
                        a_part_no       varchar2, --部位编号
                        a_cycle_type    varchar2, --计算方式
                        a_cycle_unit    varchar2, --计算单位
                        a_cycle_value   number, --周期值
                        a_insert_amount number, --单次加油量
                        a_insert_unit   varchar2, --加油单位
                        ret_msg         out varchar2, --反馈信息
                        ret             out varchar2 --执行结果
                        );
  --计算方式选择列表调用pg_oil11.getmathtype
  procedure getmathtype(ret out sys_refcursor);
  -- 计量单位选择列表，调用过程pg_oil11.getmathunit
  procedure getmathunit(a_cycle_type varchar2, --计算方式
                        ret          out sys_refcursor);
  --加油单位，调用过程pg_oil.getunit获取
  procedure getunit(ret out sys_refcursor);
end pg_oil11;
/

