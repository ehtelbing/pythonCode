create PACKAGE ACTIVITI_MANAGE IS

  -- AUTHOR  : ZJH
  -- CREATED : 2018/6/6 15:22:16
  -- PURPOSE :

  PROCEDURE getProcessAndOrgdept(V_V_BUSINESSKEY   IN VARCHAR2, --流程BUSINESSKEY
                                 V_V_ACTIVITI_TYPE IN VARCHAR2, --流程类型
                                 V_CURSOR          OUT SYS_REFCURSOR);

  /*
  组织机构树（逐级加载）
  */
  PROCEDURE GETORGTREE(V_V_DEPTCODE IN VARCHAR2,
                       V_CURSOR     OUT SYS_REFCURSOR);
END ACTIVITI_MANAGE;
/

