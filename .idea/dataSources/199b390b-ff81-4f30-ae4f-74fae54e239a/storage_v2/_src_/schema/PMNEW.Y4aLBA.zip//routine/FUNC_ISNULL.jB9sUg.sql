create function func_isnull(a_str varchar2) return varchar2 is  --对前台脚本传递的空或者%时转换的参数进行反转
  ret varchar2(50) := a_str;
begin
  if a_str = 'N/A' then
    ret := '';
  elsif a_str = 'all' then
    ret := '%';
  end if;
  return(ret);
end func_isnull;
/

