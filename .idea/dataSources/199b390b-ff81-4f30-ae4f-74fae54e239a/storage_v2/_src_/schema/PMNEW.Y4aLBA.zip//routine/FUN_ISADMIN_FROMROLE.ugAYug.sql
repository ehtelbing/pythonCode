create FUNCTION FUN_ISADMIN_FROMROLE(V_V_ORGCODE  IN VARCHAR2,
                                                V_V_ROLECODE IN VARCHAR2)

  /*
  根据厂矿，角色返回公司级管理员，厂矿级管理员，不是管理员
  */
 RETURN INTEGER IS
  V_I_RESULT INTEGER;
BEGIN
  --不是管理员
  V_I_RESULT := 0;
  IF V_V_ROLECODE IN ('00', '05', '06', '07', '08', '09', '12', '16') THEN
    --厂矿管理员
    V_I_RESULT := 1;
  END IF;
  RETURN V_I_RESULT;
END FUN_ISADMIN_FROMROLE;
/

