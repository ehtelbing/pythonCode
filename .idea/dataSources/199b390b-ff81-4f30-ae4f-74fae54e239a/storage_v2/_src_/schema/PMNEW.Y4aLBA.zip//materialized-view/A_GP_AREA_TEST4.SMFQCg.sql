create materialized view A_GP_AREA_TEST4
  on prebuilt table
  refresh fast on demand
as
SELECT "A_GP_AREA_TEST3"."SNO" "SNO","A_GP_AREA_TEST3"."SNAME" "SNAME","A_GP_AREA_TEST3"."DORMITORY" "DORMITORY","A_GP_AREA_TEST3"."GRADE" "GRADE" FROM "PMNEW"."A_GP_AREA_TEST3" "A_GP_AREA_TEST3"


/

