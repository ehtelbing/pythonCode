create package pg_dj1001 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/8/10 14:33:39
  -- Purpose :
  --查询储备入库
  procedure getinput(a_plantcode    varchar2, --厂矿编码
                     a_departcode   varchar2, --部门编码
                     a_itype        varchar2, --物资分类
                     a_store_desc   varchar2, --库房描述
                     a_materialcode varchar2, --物资编码
                     a_materialname varchar2, --物资名称
                     a_etalon       varchar2, --规格
                     a_loc_desc     varchar2, --存放位置描述
                     a_userid       varchar2, --用户ID
                     ret            out sys_refcursor);
  --入库
  procedure saveinput(a_kcid         varchar2, --原库存ID
                      a_materialcode varchar2, -- 物资编码
                      a_materialname varchar2, --物资名称
                      a_etalon       varchar2, --规格
                      a_unit         varchar2, --单位
                      a_price        number, --单价
                      a_amount       number, --数量
                      a_storedesc    varchar2, --库房描述
                      a_locdesc      varchar2, --位置描述
                      a_itype        varchar2, --物资分类
                      a_plantcode    varchar2, --厂矿编码
                      a_departcode   varchar2, --部门编码
                      a_departname   varchar2, --部门名称
                      a_userid       varchar2, --录入人ID
                      a_username     varchar2, --录入人
                      a_mpid         varchar2,
                      ret_msg        out varchar2,
                      ret            out varchar2);
  --删除
  procedure deleteinput(a_kcid  varchar2, --库存ID
                        ret_msg out varchar2,
                        ret     out varchar2);
  --确认
  procedure confirminput(a_kcid  varchar2, --库存ID
                         ret_msg out varchar2,
                         ret     out varchar2);
  --获取分类自定义单位和编码
  procedure mattype_unitandprefix(a_itype    varchar2,
                                  ret_prefix out varchar2,
                                  ret_unit   out varchar2);
  --查询计划
  procedure getmp(a_year       number, --年份
                  a_month      number, --月份
                  a_plantcode  varchar2,
                  a_departcode varchar2,
                  a_code       varchar2, --物资编码
                  a_name       varchar2, --物资名称
                  ret          out sys_refcursor);
  --提帐物资关联
  procedure mptokc(a_mpid   varchar2, --计划ID
                   a_kcid   varchar2, --库存ID
                   a_remark varchar2, --备注信息
                   ret      out varchar2,
                   ret_msg  out varchar2);
end pg_dj1001;
/

