create view VIEW_MM_FJWZ_WAITSEND as
select t.i_id,
        t.v_orderguid,
        o.v_orderid,
        o.v_equip_no,
        o.v_equip_name,
        o.v_entered_by,
        t.v_fetchorderguid,
        t.v_activity,
        t.v_materialcode,
        t.v_materialname,
        t.v_spec,
        t.v_unit,
        t.f_unitprice,
        t.i_planamount,
        t.f_planmoney,
        t.i_actualamount,
        t.f_actualmoney,
        t.v_type,
        t.v_memo,
        t.v_subtype,
        t.v_status,
        t.i_abandonedamount,
        t.i_reclaimedamount,
        t.i_fixedamount,
        t.v_id,
        t.i_jiip,
        t.i_back,
        t.i_kc_id,
        t.d_date_edittime,
        t.v_edit_guid,
        t.v_guid,
        t.v_fjwz_flag,
        t.d_fjwz_date
  from PM_WORKORDER_SPARE t
left outer join pm_workorder o on o.v_orderguid = t.v_orderguid
where o.v_system_status = 'TECO' and nvl(v_fjwz_flag,'0') = '1' and t.i_actualamount>0
/

