create package pg_mm_split_string is
  -- Author  : WY
  -- Created : 2013/11/11 14:43:26
  -- Purpose :
  type split_table is table of varchar2(50);
  function get_substr(a_source    varchar2,
                      a_splitchar varchar2,
                      ret         out MM_STRINGLIST) return varchar2;
  function deletezero(a_source varchar2, a_dircetion varchar2)
    return varchar2;
end pg_mm_split_string;
/

