create package pg_dj1005 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/2 14:59:41
  -- Purpose :
  --获取收发存
  procedure getsfc(a_begindate  date, --起始日期
                   a_enddate    date, --结束日期
                   a_plantcode  varchar2, --厂矿编码
                   a_departcode varchar2, --部门编码
                   a_itype      varchar2, --物资分类
                   a_code       varchar2, --物资编码
                   a_name       varchar2, --物资名称
                   ret          out sys_refcursor);
end pg_dj1005;
/

