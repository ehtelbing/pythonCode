create procedure BASE_PER_POST_SEL(V_V_DEPTCODE IN VARCHAR2, --作业区编码
                                              V_V_POSTNAME IN VARCHAR2, --岗位名称
                                              V_CURSOR     OUT SYS_REFCURSOR) is

  /*
  查询相应厂矿下的特定岗位人员
  */
begin
  OPEN V_CURSOR FOR
    SELECT P.V_PERSONCODE, P.V_PERSONNAME, P.V_POSTCODE, P.V_POSTNAME
      FROM VIEW_BASE_POSTTOPERSON P
     WHERE P.V_POSTNAME LIKE '%' || V_V_POSTNAME || '%'
       AND P.V_DEPTCODEUSER = V_V_DEPTCODE
     ORDER BY P.V_PERSONNAME, p.V_PERSONNAME;
end BASE_PER_POST_SEL;
/

