create package pg_oil32 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/12 10:46:19
  -- Purpose : 3.2 润滑油脂消耗部位情况查询（地址：JMM_AK/page/oil/3_2.jsp）

  -- 查询和导出，调用过程pg_oil32.get_oilconsumelist加载表格
  procedure get_oilconsumelist(a_plantcode  varchar2, --厂矿编码
                               a_departcode varchar2, --部门编码
                               a_equtype    varchar2, --设备类型编码
                               a_equip_id   varchar2, --设备ID（设备编码）
                               a_orderid    varchar2, --工单号
                               a_billcode   varchar2, --出库单号
                               a_begindate  date, --开始日期
                               a_enddate    date, --结束日期
                               a_mat_no     varchar2, --物料号
                               a_mat_desc   varchar2, --物料名
                               ret          out sys_refcursor);
  --点击“写实明细”的“查看”按钮，显示写实明细界面，并调用过程pg_oil32.getpartconsume加载该界面表格
  procedure getpartconsume(a_consume_id varchar2, --消耗ID
                           ret          out sys_refcursor --返回结果集
                           );
end pg_oil32;
/

