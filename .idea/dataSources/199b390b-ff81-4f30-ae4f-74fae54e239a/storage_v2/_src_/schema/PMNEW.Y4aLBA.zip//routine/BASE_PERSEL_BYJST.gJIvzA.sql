create procedure BASE_PERSEL_BYJST(V_V_JSTCODE IN VARCHAR2,
                                              V_CURSOR    OUT SYS_REFCURSOR) is

  /*
  根据即时通账号查询人员信息
  */
begin

  OPEN V_CURSOR FOR
    SELECT * FROM BASE_PERSON P WHERE P.V_JST = V_V_JSTCODE;

end BASE_PERSEL_BYJST;
/

