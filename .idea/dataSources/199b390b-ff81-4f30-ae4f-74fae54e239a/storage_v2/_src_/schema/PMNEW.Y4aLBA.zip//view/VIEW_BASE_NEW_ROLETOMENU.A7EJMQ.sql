create view VIEW_BASE_NEW_ROLETOMENU as
Select base_menu.I_MENUID,
       base_menu.V_MENUCODE,
       base_menu.V_MENUNAME,
       base_menu.V_MENUCODE_UP,
       base_menu.V_URL,
       base_menu.V_ICOURL,
       base_menu.V_SYSTYPE,
       base_menu.I_ORDERID,
       BASE_ROLETOMENU.V_ROLECODE,
       base_personrole.V_ROLENAME,
       base_menu.V_FLAG,
       base_menu.V_HOME_MENU,
       BASE_ROLETOMENU.V_DEPTCODE,
       base_menu.v_other,
       base_menu.v_type
  From BASE_ROLETOMENU, base_menu, base_personrole
 Where base_menu.V_MENUCODE = BASE_ROLETOMENU.V_MENUCODE(+)
   And base_personrole.V_ROLECODE(+) = BASE_ROLETOMENU.V_ROLECODE
   And BASE_ROLETOMENU.V_DEPTCODE = base_personrole.V_DEPTCODE(+)
/

