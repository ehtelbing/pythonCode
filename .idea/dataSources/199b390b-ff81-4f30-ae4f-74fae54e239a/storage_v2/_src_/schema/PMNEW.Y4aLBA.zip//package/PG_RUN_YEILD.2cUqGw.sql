create package pg_run_yeild
/*
说明：设备作业量
*/
 is
  --查询当前设备的作业量
  function get_work_yeild(a_equid     varchar2, --设备id
                          a_begindate date, --起始日期
                          a_enddate   date, --结束日期
                          a_cycle_id  varchar2, --周期id
                          ret_sum     out number, --合计
                          ret         out sys_refcursor) return varchar2;
  --查询当前设备的作业量
  procedure get_work_yeild_table(a_plantcode  varchar2,
                                 a_departcode varchar2,
                                 a_equid      varchar2, --设备id
                                 a_begindate  date, --起始日期
                                 a_enddate    date, --结束日期
                                 a_cycle_id   varchar2, --周期id
                                 ret_sum      out number, --合计
                                 ret          out sys_refcursor);
  --录入作业量
  function input_yeild(a_equ_id      varchar2, --设备id
                       a_cycle_id    varchar2, --周期id
                       a_workdate    date, --作业日期
                       a_insertvalue number, --作业量
                       a_insrtperson varchar2, --录入人
                       ret_msg       out varchar2) return varchar2;
  --录入作业量
  function input_yeild_pp(a_equ_id      varchar2, --设备id
                          a_cycle_id    varchar2, --周期id
                          a_workdate    date, --作业日期
                          a_insertvalue number, --作业量
                          a_insrtperson varchar2, --录入人
                          a_ppcode      varchar2,
                          ret_msg       out varchar2) return varchar2;
  --录入作业量
  function input_yeild_ppnew(a_equ_id      varchar2, --设备id
                             a_cycle_id    varchar2, --周期id
                             a_workdate    date, --作业日期
                             a_insertvalue number, --作业量
                             a_insrtperson varchar2, --录入人
                             a_ppcode      varchar2,
                             ret_msg       out varchar2) return varchar2;
  --删除作业量
  function delete_yeild(a_id    varchar2, --id
                        ret_msg out varchar2) return varchar2;
end pg_run_yeild;
/

