create PACKAGE PG_RUN_SITE
/*
说明：设备位置
*/
 IS
  --添加，删除，修改位置信息
  FUNCTION OP_SITE(A_SITE_ID         VARCHAR2 --位置ID
                  ,
                   A_SITE_DESC       VARCHAR2 --位置描述
                  ,
                   A_EQUID           VARCHAR2 --设备Id
                  ,
                   A_REMARK          VARCHAR2 --备注
                  ,
                   A_USERNAME        VARCHAR2 --录入人
                  ,
                   A_MEND_DEPART     VARCHAR2 --维修单位
                  ,
                   A_MEND_USERNAME   VARCHAR2 --维修负责人
                  ,
                   A_MEND_USERNAMEID VARCHAR2 --维修负责人ID
                  ,
                   A_BJ_ID           VARCHAR2 --备件ID
                  ,
                   a_bj_amount       number,
                   A_OP              VARCHAR2,
                   RET_MSG           OUT VARCHAR2) RETURN VARCHAR2;
  --查询当前设备的位置信息
  FUNCTION GET_SITE_LIST(A_EQU_ID VARCHAR2 --设备ID
                        ,
                         RET      OUT SYS_REFCURSOR) RETURN VARCHAR2;
END PG_RUN_SITE;
/

