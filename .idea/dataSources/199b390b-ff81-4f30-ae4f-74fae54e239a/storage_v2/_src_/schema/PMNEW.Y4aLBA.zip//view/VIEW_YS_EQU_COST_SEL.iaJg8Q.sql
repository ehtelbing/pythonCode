create view VIEW_YS_EQU_COST_SEL as
SELECT SUBSTR(SUBSTR(W.V_YS_TIME, 1, INSTR(W.V_YS_TIME, ' ')), 1, 4) V_YEAR,
           W.V_EQUIP_NAME,
           SUM(W.V_TOTAL_A_CHARGE) V_TOTAL_A_PROJECT,
           SUM(W.V_TOTAL_P_CHARGE) V_TOTAL_P_PROJECT,
           W.V_ORGNAME,
           W.V_ORGCODE,
           W.V_DEPTNAME,
           W.V_DEPTCODE,
           W.V_EQUIP_NO,
           S.V_EQUTYPECODE
      FROM ys_charge_workorder W
      LEFT JOIN SAP_PM_EQU_P S ON S.V_EQUCODE = W.V_EQUIP_NO
     GROUP BY W.V_EQUIP_NAME,
              SUBSTR(SUBSTR(W.V_YS_TIME, 1, INSTR(W.V_YS_TIME, ' ')), 1, 4),
              W.V_ORGNAME,
              W.V_ORGCODE,
              W.V_DEPTNAME,
              W.V_DEPTCODE,
              W.V_EQUIP_NO,
              S.V_EQUTYPECODE
     ORDER BY V_YEAR
/

