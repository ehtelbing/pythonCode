create trigger BASE_CAR_DE_TRI
  before insert
  on BASE_CAR_DE
  for each row
BEGIN
  SELECT BASE_CAR_DE_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
END BASE_CAR_DE_TRI;
/

