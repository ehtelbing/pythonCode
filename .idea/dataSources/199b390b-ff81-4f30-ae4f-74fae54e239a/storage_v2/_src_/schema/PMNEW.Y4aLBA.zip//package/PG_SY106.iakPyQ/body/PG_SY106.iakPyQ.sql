create package body pg_sy106 is
  --3.查询：pg_sy106.syuserlist
  procedure syuserlist(a_plantcode  varchar2, --厂矿编码
                       a_departcode varchar2, --部门编码
                       a_loc_code   varchar2, --试验地点编号
                       ret          out sys_refcursor) is
  begin
    open ret for
      select S.USER_CODE, --用户编码
             S.USER_NAME, --姓名
             S.PLANTCODE, --厂矿编码
             S.DEPTCODE, --部门编码
             S.LOC_CODE, --试验地点编号
             S.STS, --状态
             CASE S.STS
               WHEN '1' THEN
                '启用'
               ELSE
                '停用'
             END STS_DESC, --状态描述
             S.DEPTNAME, --部门名
             S.PLANTNAME, --厂矿名
             S.LOC_NAME --试验地点名
        from sy_user s
       where s.plantcode like a_plantcode
         and s.deptcode like a_departcode
         and nvl(s.loc_code,'-') like a_loc_code;
  end;
  --5.新增保存：pg_sy106.addsyuser
  procedure addsyuser(a_usercode  varchar2, --用户编号
                      a_username  varchar2, --姓名
                      a_plantcode varchar2, --厂矿编码
                      a_deptcode  varchar2, --部门编码
                      a_loc_code  varchar2, --试验地点编号
                      a_sts       varchar2, --状态
                      a_plantname varchar2, --厂矿名称
                      a_deptname  varchar2, --部门名称
                      a_loc_name  varchar2, --试验地点名
                      ret         out varchar2,
                      ret_msg     out varchar2) is
  begin
    ret := 'Fail';
    insert into sy_user
      (user_code,
       user_name,
       deptcode,
       plantcode,
       loc_code,
       sts,
       deptname,
       plantname,
       loc_name)
    values
      (a_usercode,
       a_username,
       a_deptcode,
       a_plantcode,
       a_loc_code,
       a_sts,
       a_deptname,
       a_plantname,
       a_loc_name);
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因：' || sqlerrm;
  end;
  --7.修改-保存：pg_sy106.updatesyuser
  procedure updatesyuser(a_usercode  varchar2, --用户编号
                         a_username  varchar2, --姓名
                         a_plantcode varchar2, --厂矿编码
                         a_deptcode  varchar2, --部门编码
                         a_loc_code  varchar2, --试验地点编号
                         a_sts       varchar2, --状态
                         a_plantname varchar2, --厂矿名称
                         a_deptname  varchar2, --部门名称
                         a_loc_name  varchar2, --试验地点名
                         ret         out varchar2,
                         ret_msg     out varchar2) is
  begin
    ret := 'Fail';
    update sy_user u
       set u.user_name = a_username,
           u.deptcode  = a_deptcode,
           u.plantcode = a_plantcode,
           u.loc_code  = a_loc_code,
           u.deptname  = a_deptname,
           u.plantname = a_plantname,
           u.loc_name  = a_loc_name
     where u.user_code = a_usercode;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因：' || sqlerrm;
  end;
  ---8.删除：pg_sy106.deletesyuser
  procedure deletesyuser(a_usercode varchar2, --用户编号
                         ret        out varchar2,
                         ret_msg    out varchar2) is
  begin
    ret := 'Fail';
    delete from sy_user u where u.user_code = a_usercode;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因：' || sqlerrm;
  end;
  --9.启用：pg_sy106.startsyuser
  procedure startsyuser(a_usercode varchar2, --用户编号
                        ret        out varchar2,
                        ret_msg    out varchar2) is
  begin
    update sy_user u set u.sts = '1' where u.user_code = a_usercode;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因：' || sqlerrm;
  end;
  --10.停用：pg_sy106.stopsyuser
  procedure stopsyuser(a_usercode varchar2, --用户编号
                       ret        out varchar2,
                       ret_msg    out varchar2) is
  begin
    update sy_user u set u.sts = '0' where u.user_code = a_usercode;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因：' || sqlerrm;
  end;
end pg_sy106;
/

