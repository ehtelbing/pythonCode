create view VIEW_RUN7130_BJTIME as
select cy.bj_unique_code,--????
cy.materialcode,--????
cy.neworold,--????
cy.bj_status,--????
cy.plantcode,--????
p.v_deptname plantname,
cy.departcode,--?????
d.v_deptname,--????
ls.supply_code,--?????
ls.supply_name,--?????
ls.change_site_id, --????
ls.changedate changedate_s,--????
ls.change_amount,
ld.changedate changedate_d,--????
ls.remark || ld.remark remark,--??
s.v_materialname materialname,
s.v_spec materialetalon,
s.v_unit unit,
s.f_unitprice f_price,
ls.change_site_desc site_desc,--????
ls.change_equ_id equ_id,
ls.change_equ_desc equ_desc,
ld.jk_status,
ld.jk_status_mining,
ld.id,
d.v_sap_dept,
ld.faultreason,
1 amount,
(select nvl(sum(insert_value),0) from run_equ_yeild y left outer join run_cycle_dic d on y.cycle_id = d.cycle_id where y.equ_id=ls.change_equ_id and d.cycle_desc = '作业时间' and to_number(to_char(y.workdate,'YYYYMMDD'))<=to_number(to_char(nvl(ld.changedate,sysdate),'YYYYMMDD')) and to_number(to_char(y.workdate,'YYYYMMDD'))>=to_number(to_char(ls.changedate,'YYYYMMDD'))) worktime,
ls.orderid orderid_s,--安装工单
ld.orderid orderid_d, --换下工单
ld.mm_bj_status,
func_wp_getusernamebycode(ls.changeperson) person_s,
func_wp_getusernamebycode(ld.changeperson) person_d
from run_bj_cycle cy
left outer join run_cycle_bj_change_log ls on cy.bj_unique_code = ls.bj_unique_code and ls.direction='安装'
left outer join run_cycle_bj_change_log ld on cy.bj_unique_code = ld.bj_unique_code and ld.direction='换下' and ls.pair_flag=ld.pair_flag
left outer join run_mat m on cy.materialcode = m.materialcode
left outer join run_site_dic sd on ls.change_site_id = sd.site_id
left outer join run_equ_dic ed on sd.equ_id = ed.equ_id
left outer join base_dept d on d.v_deptcode=cy.departcode
left outer join base_dept p on p.v_deptcode = cy.plantcode
left outer join pm_workorder w on w.v_orderid = ls.orderid
left outer join pm_workorder_spare s on s.v_orderguid = w.v_orderguid and s.v_materialcode = cy.materialcode
/

