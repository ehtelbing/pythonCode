create package body pg_mm_basic is

  --获取组织机构名称
  function depart_getname(v_code varchar2) return varchar2 is
    p_ret varchar2(50);
  begin
    select d.v_deptname
      into p_ret
      from base_dept d
     where d.v_deptcode = v_code;
    return p_ret;
  exception
    when others then
      return 'N/A';
  end;
end pg_mm_basic;
/

