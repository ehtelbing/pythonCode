create package pg_dj603 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/21 8:34:05
  -- Purpose :
  -- 获取任务维修票
  procedure getmendbilldetail(a_orderid varchar2, --工单号
                              ret       out sys_refcursor);
end pg_dj603;
/

