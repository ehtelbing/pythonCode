create package BODY PG_SY201008 is
  --绝缘工具试验数据录入
  procedure pro_sy201008_onedetail(recordcode_in varchar,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select a.record_id,
             a.SY_LOC_DESC,
             a.sy_loc_code,
             a.sy_equ_id,
             a.sy_equ_name,
             a.sy_date,
             a.sy_weather,
             a.sy_temp,
             a.sy_reason,
             a.sy_verdict,
             a.sy_resp_username, --负责人
             a.sy_resp_userid,
             a.sy_exa_userid,
             a.sy_exa_username, --审核人
             a.sy_recordid,
             a.sy_recordname, --记录人
             a.equtype_code,
             a.equtype_name, --设备种类
             sy_opuserid,
             sy_opusername,
             sy_jxuserid,
             sy_jxusername,
             a.make_date, --制造日期
             a.outplant_date --出厂日期
        from SY_RECORD_MAIN a
       where a.record_id = recordcode_in;
  end;
  --t添加
  procedure pro_sy201008_oneadd(usercode_in     varchar2, --登录人
                                username_in     varchar2, --登录人姓名
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿
                                departcode_in   varchar2, --部门
                                plantname_in    varchar2, --厂矿名称
                                departname_in   varchar2, --部门名称
                                sydate_in        DATE, --实验时间
                                syloccode_in     varchar2, --实验地点编码
                                sylocname_in     varchar2, --实验地点名称
                                syequcode_in     varchar2, --实验设备编码
                                syequname_in     varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN VARCHAR2,
                                SYEQUTYPTNAME_IN VARCHAR2,
                                SYWEATHER_in        varchar2, --天气
                                sytemp_in           number, --气温
                                syreason_in         varchar2, --实验原因
                                SYVERDICT_in        varchar2, --结论
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2) as
    p_recordcode   varchar2(36) := FUNC_NEW_GUID();
    p_itemtypedesc varchar2(100);
    p_itemdesc     varchar2(50);
    p_printurl     varchar2(200);
  begin
    savepoint s;
    select t.itemtype_desc
      into p_itemtypedesc
      from SY_ITEM_TYPE t
     where t.itemtype = itemtypecode_in;
    select d.item_name
      into p_itemdesc
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    select d.item_url
      into p_printurl
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    insert into SY_RECORD_MAIN
      (RECORD_ID,
       RECORD_DATE,
       SY_DATE,
       RECORD_USERID,
       RECORD_USERNAME,
       DEPARTCODE,
       DEPARTNAME,
       PLANTCODE,
       PLANTNAME,
       SY_LOC_CODE,
       SY_LOC_DESC,
       SY_EQU_ID,
       SY_EQU_NAME,
       SY_WEATHER,
       SY_TEMP,
       SY_URL,
       SY_REASON,
       SY_VERDICT,
       SY_RESP_USERID,
       SY_RESP_USERNAME,
       SY_EXA_USERID,
       SY_EXA_USERNAME,
       RECORD_STATUS,
       ITEM_CODE,
       ITEM_NAME,
       ITEMTYPE,
       ITEMTYPE_DESC,
       SUBMIT_DATE,
       SUBMIT_USERID,
       SUBMIT_USERNAME,
       sy_recordid,
       sy_recordname,
       EQUTYPE_CODE,
       EQUTYPE_NAME,
       sy_opuserid,
       sy_opusername,
       sy_jxuserid,
       sy_jxusername,
       make_date,
       outplant_date)
    values
      (p_recordcode,
       sysdate,
       sydate_in,
       usercode_in,
       username_in,
       departcode_in,
       departname_in,
       plantcode_in,
       plantname_in,
       syloccode_in,
       sylocname_in,
       syequcode_in,
       syequname_in,
       SYWEATHER_in,
       sytemp_in,
       p_printurl,
       syreason_in,
       SYVERDICT_in,
       SYRESPUSERNAME_code,
       SYRESPUSERNAME_in,
       SYEXAUSERNAME_code,
       SYEXAUSERNAME_in,
       '未提交',
       itemcode_in,
       p_itemdesc,
       itemtypecode_in,
       p_itemtypedesc,
       null,
       null,
       null,
       SYRECORDID_IN,
       SYRECORDNAME_IN,
       SYEQUTYPTCODE_IN,
       SYEQUTYPTNAME_IN,
       SY_OPUSERID_in,
       SY_OPUSERNAME_in,
       SY_JXUSERID_in,
       SY_JXUSERNAME_in,
       make_date_in,
       outplant_date_in);
    commit;
    ret := p_recordcode;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --更新
  procedure pro_sy201008_oneupdate(recordcode_in       varchar2,
                                   usercode_in         varchar2, --登录人
                                   username_in         varchar2, --登录人姓名
                                   sydate_in           DATE, --实验时间
                                   syloccode_in        varchar2, --实验地点编码
                                   sylocname_in        varchar2, --实验地点名称
                                   syequcode_in        varchar2, --实验设备编码
                                   syequname_in        varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN    VARCHAR2,
                                   SYEQUTYPTNAME_IN    VARCHAR2,
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温 12.3
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2) as
  begin
    savepoint s;
    update SY_RECORD_MAIN a
       set RECORD_DATE      = sysdate,
           SY_DATE          = sydate_in,
           RECORD_USERID    = usercode_in,
           RECORD_USERNAME  = username_in,
           SY_LOC_CODE      = syloccode_in,
           SY_LOC_DESC      = sylocname_in,
           SY_EQU_ID        = syequcode_in,
           SY_EQU_NAME      = syequname_in,
           SY_WEATHER       = SYWEATHER_in,
           SY_TEMP          = sytemp_in,
           SY_REASON        = syreason_in,
           SY_VERDICT       = SYVERDICT_in,
           sy_resp_userid   = SYRESPUSERNAME_code,
           SY_RESP_USERNAME = SYRESPUSERNAME_in,
           sy_exa_userid    = SYEXAUSERNAME_code,
           SY_EXA_USERNAME  = SYEXAUSERNAME_in,
           a.sy_recordid    = SYRECORDID_IN,
           a.sy_recordname  = SYRECORDNAME_IN,
           a.equtype_code   = SYEQUTYPTCODE_IN,
           a.equtype_name   = SYEQUTYPTNAME_IN,
           a.sy_opuserid    = SY_OPUSERID_in,
           a.sy_opusername  = SY_OPUSERNAME_in,
           a.sy_jxuserid    = SY_JXUSERID_in,
           a.sy_jxusername  = SY_JXUSERNAME_in,
           a.make_date      = make_date_in,
           a.outplant_date  = outplant_date_in
     where RECORD_ID = recordcode_in;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --属性表添加
  --2,查询
  procedure pro_sy201008_twodetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select * from SY_RE_JYGJ_MAIN a where a.record_id = recordcode_in;
  end;
  --2.添加
  procedure pro_sy201008_twoadd(recordcode_in varchar2,
                                v_A1          VARCHAR2,
                                v_A2          NUMBER,
                                v_A3          VARCHAR2,
                                v_A4          VARCHAR2,
                                v_B1          VARCHAR2,
                                v_B2          NUMBER,
                                v_B3          VARCHAR2,
                                v_B4          VARCHAR2,
                                v_C1          VARCHAR2,
                                v_C2          NUMBER,
                                v_C3          VARCHAR2,
                                v_C4          VARCHAR2,
                                v_D1          VARCHAR2,
                                v_D2          NUMBER,
                                v_D3          VARCHAR2,
                                v_D4          VARCHAR2,
                                v_E1          VARCHAR2,
                                v_E2          NUMBER,
                                v_E3          VARCHAR2,
                                v_E4          VARCHAR2,
                                v_F1          VARCHAR2,
                                v_F2          NUMBER,
                                v_F3          VARCHAR2,
                                v_F4          VARCHAR2,
                                v_G1          VARCHAR2,
                                v_G2          NUMBER,
                                v_G3          VARCHAR2,
                                v_G4          VARCHAR2,
                                v_H1          VARCHAR2,
                                v_H2          NUMBER,
                                v_H3          VARCHAR2,
                                v_H4          VARCHAR2,
                                v_I1          VARCHAR2,
                                v_I2          NUMBER,
                                v_I3          VARCHAR2,
                                v_I4          VARCHAR2,
                                v_J1          VARCHAR2,
                                v_J2          NUMBER,
                                v_J3          VARCHAR2,
                                v_J4          VARCHAR2,
                                v_K1          VARCHAR2,
                                v_K2          NUMBER,
                                v_K3          VARCHAR2,
                                v_K4          VARCHAR2,
                                -- v_OP_USER     VARCHAR2,
                                --v_RECORD_USER VARCHAR2,
                                -- v_JX_USER VARCHAR2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_JYGJ_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_A1,
       v_A2,
       v_A3,
       v_A4,
       v_B1,
       v_B2,
       v_B3,
       v_B4,
       v_C1,
       v_C2,
       v_C3,
       v_C4,
       v_D1,
       v_D2,
       v_D3,
       v_D4,
       v_E1,
       v_E2,
       v_E3,
       v_E4,
       v_F1,
       v_F2,
       v_F3,
       v_F4,
       v_G1,
       v_G2,
       v_G3,
       v_G4,
       v_H1,
       v_H2,
       v_H3,
       v_H4,
       v_I1,
       v_I2,
       v_I3,
       v_I4,
       v_J1,
       v_J2,
       v_J3,
       v_J4,
       v_K1,
       v_K2,
       v_K3,
       v_K4,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2，更新
  procedure pro_sy201008_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2,
                                   v_A1          VARCHAR2,
                                   v_A2          NUMBER,
                                   v_A3          VARCHAR2,
                                   v_A4          VARCHAR2,
                                   v_B1          VARCHAR2,
                                   v_B2          NUMBER,
                                   v_B3          VARCHAR2,
                                   v_B4          VARCHAR2,
                                   v_C1          VARCHAR2,
                                   v_C2          NUMBER,
                                   v_C3          VARCHAR2,
                                   v_C4          VARCHAR2,
                                   v_D1          VARCHAR2,
                                   v_D2          NUMBER,
                                   v_D3          VARCHAR2,
                                   v_D4          VARCHAR2,
                                   v_E1          VARCHAR2,
                                   v_E2          NUMBER,
                                   v_E3          VARCHAR2,
                                   v_E4          VARCHAR2,
                                   v_F1          VARCHAR2,
                                   v_F2          NUMBER,
                                   v_F3          VARCHAR2,
                                   v_F4          VARCHAR2,
                                   v_G1          VARCHAR2,
                                   v_G2          NUMBER,
                                   v_G3          VARCHAR2,
                                   v_G4          VARCHAR2,
                                   v_H1          VARCHAR2,
                                   v_H2          NUMBER,
                                   v_H3          VARCHAR2,
                                   v_H4          VARCHAR2,
                                   v_I1          VARCHAR2,
                                   v_I2          NUMBER,
                                   v_I3          VARCHAR2,
                                   v_I4          VARCHAR2,
                                   v_J1          VARCHAR2,
                                   v_J2          NUMBER,
                                   v_J3          VARCHAR2,
                                   v_J4          VARCHAR2,
                                   v_K1          VARCHAR2,
                                   v_K2          NUMBER,
                                   v_K3          VARCHAR2,
                                   v_K4          VARCHAR2,
                                   -- v_OP_USER     VARCHAR2,
                                   -- v_RECORD_USER VARCHAR2,
                                   --v_JX_USER VARCHAR2,
                                   ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_JYGJ_MAIN
       set RECORD_ID = recordcode_in,
           A1        = v_A1,
           A2        = v_A2,
           A3        = v_A3,
           A4        = v_A4,
           B1        = v_B1,
           B2        = v_B2,
           B3        = v_B3,
           B4        = v_B4,
           C1        = v_C1,
           C2        = v_C2,
           C3        = v_C3,
           C4        = v_C4,
           D1        = v_D1,
           D2        = v_D2,
           D3        = v_D3,
           D4        = v_D4,
           E1        = v_E1,
           E2        = v_E2,
           E3        = v_E3,
           E4        = v_E4,
           F1        = v_F1,
           F2        = v_F2,
           F3        = v_F3,
           F4        = v_F4,
           G1        = v_G1,
           G2        = v_G2,
           G3        = v_G3,
           G4        = v_G4,
           H1        = v_H1,
           H2        = v_H2,
           H3        = v_H3,
           H4        = v_H4,
           I1        = v_I1,
           I2        = v_I2,
           I3        = v_I3,
           I4        = v_I4,
           J1        = v_J1,
           J2        = v_J2,
           J3        = v_J3,
           J4        = v_J4,
           K1        = v_K1,
           K2        = v_K2,
           K3        = v_K3,
           K4        = v_K4
    --OP_USER   = v_OP_USER,
    --RECORD_USER = v_RECORD_USER,
    --JX_USER = v_JX_USER
     where id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
end PG_SY201008;
/

