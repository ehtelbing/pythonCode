create view VIEW_RUN_SITE_BJ as
SELECT S.SITE_ID
      ,S.SITE_DESC
      ,S.EQU_ID
      ,S.BJ_ID
      ,B.BJ_UNIQUE_CODE
      ,B.MATERIALCODE
      ,B.MATERIALNAME
      ,B.UNIT
      ,B.CHANGEDATE
      ,B.BJ_STATUS
      ,B.SUPPLY_CODE
      ,B.SUPPLY_NAME
      ,bj.PLANTCODE
      ,bj.DEPARTCODE
      ,s.bj_amount
      ,bj.pre_flag
  FROM RUN_SITE_DIC S
  left outer join run_bj bj on bj.bj_id = s.bj_id
  LEFT OUTER
  JOIN VIEW_RUN_BJ_CYCLE B ON B.SITE_ID=S.SITE_ID
/

