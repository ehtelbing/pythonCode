create package pg_dj501 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/8/10 13:36:57
  -- Purpose :
  --设置检修编号
  procedure savemendcodec(a_applyid  varchar2, --工单申请ID
                          a_mendcode varchar2, --检修编号
                          ret_msg    out varchar2,
                          ret        out varchar2);
end pg_dj501;
/

