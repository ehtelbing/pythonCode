create function fund_dept_view_role(V_V_PERSONCODE IN VARCHAR2,
                                               V_V_DEPTCODE   IN VARCHAR2,
                                               -- V_V_DEPTCODENEXT IN VARCHAR2,
                                               V_V_DEPTTYPE IN VARCHAR2)
  return VARCHAR2 is
  V_CURSOR     VARCHAR2(4000);
  V_V_ROLECODE VARCHAR2(50);
  V_V_ISADMIN  VARCHAR2(50);
  --返回组织机构，根据不同人员返回可以查询的组织机构
  --V_NUMBER NUMBER;
BEGIN

  SELECT B.V_ROLECODE
    INTO V_V_ROLECODE
    FROM BASE_PERSON B
   WHERE B.V_PERSONCODE = V_V_PERSONCODE;

  V_V_ISADMIN := FUN_ISADMIN(V_V_ROLECODE);

  IF V_V_DEPTTYPE IN ('[基层单位]', '[公司]', '基层单位', '公司') THEN
    IF V_V_ISADMIN = 1 THEN
      --管理员权限
      PRO_BASE_DEPT_VIEW2('%', V_V_DEPTTYPE, V_CURSOR);
    ELSIF V_V_ISADMIN = 2 THEN
      PRO_BASE_DEPT_VIEW2(V_V_DEPTCODE, V_V_DEPTTYPE, V_CURSOR);
    ELSE
      PRO_BASE_DEPT_VIEW_PER2(V_V_DEPTCODE,
                              V_V_DEPTTYPE,
                              V_V_PERSONCODE,
                              V_CURSOR);

    END IF;
  ELSE
    --其它组织机构[主体作业区][检修作业区]
    IF V_V_ISADMIN = 1 THEN
      --管理员权限
      PRO_BASE_DEPT_VIEW_ADMIN2(V_V_DEPTCODE, V_V_DEPTTYPE, V_CURSOR);
    ELSIF V_V_ISADMIN = 2 THEN
      PRO_BASE_DEPT_VIEW2(V_V_DEPTCODE, V_V_DEPTTYPE, V_CURSOR);
    ELSE
      PRO_BASE_DEPT_VIEW_PER2(V_V_DEPTCODE,
                              V_V_DEPTTYPE,
                              V_V_PERSONCODE,
                              V_CURSOR);
    END IF;
  END IF;
  return(V_CURSOR);
end fund_dept_view_role;
/

