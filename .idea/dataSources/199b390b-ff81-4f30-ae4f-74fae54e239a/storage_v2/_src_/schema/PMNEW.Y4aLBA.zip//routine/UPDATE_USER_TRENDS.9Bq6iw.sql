create function update_user_trends(a_userid varchar2,
                           a_workcenter varchar2) return varchar2 is
    p_ret varchar2(10) := 'Fail';
    --  p_count number(2, 0) := 0;
  begin
    begin
      UPDATE BASE_USER_TRENDS B
      SET B.INSERTDATE = sysdate,
      B.WORKCENTER = a_workcenter
      WHERE B.USERID = a_userid;
      commit;
      p_ret := 'Success';
    end;
    return p_ret;
  end;
/

