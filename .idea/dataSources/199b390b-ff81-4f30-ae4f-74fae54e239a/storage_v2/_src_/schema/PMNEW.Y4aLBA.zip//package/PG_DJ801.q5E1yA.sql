create package PG_DJ801 is
  --检修模型信息查询
  procedure pro_dj801_select(v_modelname in varchar2,
                             v_cursor    out sys_refcursor);
  --查看模型工序
  procedure pro_dj801_selectet(v_modelcode varchar2,
                               v_cursor    out sys_refcursor);
  --查看模型物料
  procedure pro_dj801_selectmet(v_modelcode varchar2,
                                v_cursor    out sys_refcursor);
end PG_DJ801;
/

