create PROCEDURE BASE_EXAMINE_CAR_UPD(V_V_GUID      IN VARCHAR2, --GUID
                                                 V_V_CARCODE   IN VARCHAR2, --车辆编码
                                                 V_V_CARNAME   IN VARCHAR2, --车辆名称
                                                 V_V_CARTYPE   IN VARCHAR2, --车辆类型
                                                 V_V_CARGUISUO IN VARCHAR2, --车辆归属
                                                 V_V_CARINDATE IN VARCHAR2, --车辆入厂时间
                                                 V_V_FLAG      IN VARCHAR2, --车辆状态
                                                 V_V_CARINFO   IN VARCHAR2, --车辆信息
                                                 V_V_DE        IN VARCHAR2, --车辆定额
                                                 V_INFO        OUT VARCHAR2) IS

  /*修改机具*/
BEGIN

  UPDATE BASE_EXAMINE_CAR B
     SET B.V_CARCODE   = V_V_CARCODE,
         B.V_CARNAME   = V_V_CARNAME,
         B.V_CARTYPE   = V_V_CARTYPE,
         B.V_CARGUISUO = V_V_CARGUISUO,
         B.V_CARINDATE = TO_DATE(V_V_CARINDATE, 'yyyy-mm-dd'),
         B.V_FLAG      = V_V_FLAG,
         B.V_CARINFO   = V_V_CARINFO,
         B.V_DE        = V_V_DE
   WHERE B.V_GUID = V_V_GUID;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

END BASE_EXAMINE_CAR_UPD;
/

