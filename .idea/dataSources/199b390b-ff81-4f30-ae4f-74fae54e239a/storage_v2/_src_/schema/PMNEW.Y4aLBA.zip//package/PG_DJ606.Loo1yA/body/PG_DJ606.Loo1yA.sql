create package BODY pg_dj606 is
  --查询工单试验记录
  procedure getordersy(a_plantcode varchar2, --厂矿编码
                       a_menddept  varchar2, --检修部门编码
                       a_orderid   varchar2, --工单号
                       a_begindate date, --起始日期
                       a_enddate   date, --结束日期
                       ret         out sys_refcursor) is
  begin
    open ret for
      select O.ORDERID,
             O.DJ_NAME,
             S.BCSY_RESULT,
             S.CSY_RESULT,
             O.MEND_CONTEXT,
               nvl(o.menddept_name,m.menddept_name) menddept_name
        from dj_order o
               left outer join dj_menddept m on m.menddept_code = o.menddept_code
        left outer join dj_order_sy s
          on o.orderid = s.orderid
        left outer join dj_order_status t
          on t.order_status = o.order_status
       where o.plantcode like a_plantcode
         and o.departcode like a_menddept
         and o.orderid like '%' || a_orderid || '%'
         and s.sy_date between a_begindate and a_enddate
       order by orderid desc;
  end;
end pg_dj606;
/

