create PROCEDURE BASE_GX_WL_DEL(V_V_JXGX_CODE IN VARCHAR2,
                                           V_V_WLCODE    IN VARCHAR2,
                                           V_INFO        OUT VARCHAR2) IS
  /*删除检修工序的物料*/
BEGIN
  DELETE FROM PM_1917_JXGX_WL_DATA B
   WHERE B.V_JXGX_CODE = V_V_JXGX_CODE
     AND B.V_WLCODE = V_V_WLCODE;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
END BASE_GX_WL_DEL;
/

