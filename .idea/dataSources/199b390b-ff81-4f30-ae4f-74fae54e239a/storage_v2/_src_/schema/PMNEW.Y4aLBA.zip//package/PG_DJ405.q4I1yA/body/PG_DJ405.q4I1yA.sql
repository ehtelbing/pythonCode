create package body pg_dj405 is
  --查询待确认申请
  procedure get_waitapplylist(plantcode_in  varchar2,
                              departcode_in varchar2,
                              usercode_in   varchar2,
                              ret           out sys_refcursor) is
  begin
    open ret for
      select APPLY_ID,
             ORDERID,
             DJ_UQ_CODE,
             DJ_NAME,
             APPLY_PLANT,
             APPLY_PLANTNAME,
             APPLY_DEPART,
             APPLY_DEPARTNAME,
             MEND_CONTEXT,
             PLAN_BEGINDATE,
             PLAN_ENDDATE,
             INSERTDATE,
             INSERT_USERID,
             INSERT_USERNAME,
             REC_FLAG,
             REC_PLANT,
             REC_DEPART,
             REC_USERID,
             REC_USERNAME,
             REMARK,
             FLAG,
             ORDER_FLAG
        from DJ_OS_ORDERAPPLY o
       where APPLY_PLANT = plantcode_in
         and APPLY_DEPART like departcode_in || '%'
         and nvl(FLAG, '0') = '1'
         and nvl(confirm_flag, '0') = '0'
         and nvl(o.rec_flag, '0') = '0';
  end;
  --确认申请
  procedure confirm_apply(applyid_in varchar2,
                          a_userid   varchar2,
                          ret        out varchar2,
                          ret_msg    out varchar2) is
  begin
    ret := 'Fail';
    update DJ_OS_ORDERAPPLY o
       set o.confirm_flag   = '1',
           o.confirm_person = (select V_PERSONNAME from BASE_PERSON where V_PERSONCODE = a_userid),
           o.confirm_date   = sysdate
     where apply_id = applyid_in;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因:' || sqlerrm;
  end;
  --退回到申请单位
  procedure back_apply(applyid_in varchar2,
                       a_userid   varchar2,
                       ret        out varchar2,
                       ret_msg    out varchar2) is
  begin
    ret := 'Fail';
    update DJ_OS_ORDERAPPLY o
       set o.confirm_flag   = '0',
           o.flag           = '0',
           o.confirm_person = (select V_PERSONNAME from BASE_PERSON where V_PERSONCODE = a_userid),
           o.confirm_date   = sysdate
     where apply_id = applyid_in;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := '操作失败，原因:' || sqlerrm;
  end;
end pg_dj405;
/

