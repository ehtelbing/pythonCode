create trigger PM_06_DJ_DATA_TRI
  before insert
  on PM_06_DJ_DATA
  for each row
BEGIN
  SELECT PM_06_DJ_DATA_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
END PM_06_DJ_DATA_TRI;
/

