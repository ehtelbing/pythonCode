create PROCEDURE BASE_JJ_BYJXBZ_SEL(V_V_JXBZ_GUID IN VARCHAR2, --检修技术标准guid
                                               V_CURSOR      OUT SYS_REFCURSOR) IS
  /*传入检修技术标准guid查询机具*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT *
      FROM PM_1917_JXGX_JJ_DATA P
     WHERE P.V_JXGX_CODE IN
           (SELECT V_GUID
              FROM PM_WORKORDER_ET_OPERATIONS
             WHERE V_JXBZ = V_V_JXBZ_GUID);
END BASE_JJ_BYJXBZ_SEL;
/

