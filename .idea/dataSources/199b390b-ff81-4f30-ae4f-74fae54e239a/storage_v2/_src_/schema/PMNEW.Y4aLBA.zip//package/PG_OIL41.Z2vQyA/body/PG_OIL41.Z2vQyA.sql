create package body pg_oil41 is

  -- 调用过程pg_oil41.getcountry获取国家选择列表
  procedure getcountry(ret out sys_refcursor --返回结果集
                       ) is
  begin
    open ret for
      select c.country_code, --国家代码
             c.country_name --国家名
        from mm_country c;
  end;
  --调用过程pg_oil41.getprovince获取省份选择列表
  procedure getprovince(a_country_code varchar2, --国家代码
                        ret            out sys_refcursor --返回结果集
                        ) is
  begin
    open ret for
      select p.province_code, --省份代码
             p.province_name --省名
        from mm_provinces p
       where p.country_code = a_country_code
       order by p.province_code;
  end;
  --调用过程pg_oil41.getcity获取城市选择列表
  procedure getcity(a_country_code  varchar2, --国家代码
                    a_province_code varchar2, --省份代码
                    ret             out sys_refcursor) is
  begin
    open ret for
      select c.city_code, --城市代码
             c.city_name --城市名
        from mm_city c
       where c.province_code = a_province_code
       order by c.city_code;
  end;
  --对选定供应商的评级，调用过程pg_oil41.getlevellist加载选择列表
  procedure getlevellist(ret out sys_refcursor --返回结果集
                         ) is
  begin
    open ret for
      select l.level_code, --级别编号
             l.level_desc --级别描述
        from mm_supply_level l
       where l.level_status = '1';
  end;
  -- 查询和导出，调用过程pg_oil41.getoilsupplylist获取数据，并加载表格。
  procedure getoilsupplylist(a_country_code  varchar2, --国家代码
                             a_province_code varchar2, --省份代码
                             a_city_code     varchar2, --城市代码
                             a_supply_code   varchar2, --供应商编号（客商编码）
                             a_supply_name   varchar2, --供应商名（客商名）
                             ret             out sys_refcursor) is
  begin
    open ret for
      select *
        from (select s.supply_code, --供应商编码
                     s.supply_name, --供应商名
                     s.country_name || ',' || s.province_name || ',' ||
                     s.city_name supply_address, --地址
                     s.link_person, --联系人
                     s.link_phonecode, --联系方式
                     l.level_desc, --当前级别
                     (select sum(c.oil_amount)
                        from oil_equip_consume c
                       where c.supplier_code = s.supply_code
                         and c.oil_status = '1') oil_amount, --油品总消耗量
                     (select count(*)
                        from mm_supply_mat m
                       where m.supply_code = s.supply_code
                         and nvl(m.mat_no, '0') in
                             (select mat_no from oil_mats)) oil_count
                from mm_supply_dic s
                left outer join mm_supply_level l
                  on l.level_code = s.supply_level
               where nvl(s.country_code, '0') like a_country_code
                 and nvl(s.province_code, '0') like a_province_code
                 and nvl(s.city_code, '0') like a_city_code
                 and s.supply_code like '%' || a_supply_code || '%'
                 and s.supply_name like '%' || a_supply_name || '%') a
       where nvl(a.oil_amount, 0) >= 0
         and a.oil_count > 0
       order by a.supply_code;
  end;
  --点击"确认评级"按钮，调用过程pg_oil41.approve对选定的供应商进行评级。
  procedure approve(a_supply_code varchar2, --供应商编号
                    a_level_code  varchar2, --级别编号
                    a_userid      varchar2, --用户名
                    a_plantcode   varchar2, --厂矿编码（用户信息）
                    ret_msg       out varchar2, --反馈信息
                    ret           out varchar2 --执行结果
                    ) is
    p_username varchar2(50) := pg_mm_user.getusername(a_userid);
  begin
    ret := 'Fail';
    savepoint s;
    update mm_supply_dic s
       set s.supply_level = a_level_code
     where s.supply_code = a_supply_code;
    insert into mm_supply_appraise
      (id, supply_code, context, insertdate, plant, person, level_code)
    values
      (func_mm_guid(),
       a_supply_code,
       '修改供应商评级',
       sysdate,
       a_plantcode,
       p_username,
       a_level_code);
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      rollback to s;
      ret_msg := '操作失败：' || sqlerrm;
  end;
  --点击“使用明细”列的“查看”按钮，打开“供应商油品使用情况”窗口，并调用过程pg_oil41.getsupplyuseoillist加载该界面表格。
  procedure getsupplyuseoillist(a_supply_code varchar2, --供应商编号
                                a_begindate   date, --起始日期
                                a_enddate     date, --结束日期
                                a_plantcode   varchar2, --使用单位编号
                                ret           out sys_refcursor) is
  begin
    open ret for
      select p.detail_id, --写实ID
             i.inst_equip_name, --设备名
             s.part_desc, --部位名
             e.oil_mat_no, --物料号
             e.oil_mat_desc, --物料名
             e.oil_price, --单价
             p.use_amount, --数量
             (e.oil_price * p.use_amount) use_money, --金额
             pg_mm_basic.depart_getname(e.plantcode) plantname, --使用单位
             p.oil_approve --油品评价
        from oil_equip_part_consume p
        left outer join oil_equip_consume e
          on e.consume_id = p.consume_id
        left outer join oil_equip_inst i
          on i.inst_equip_id = e.inst_equip_code
        left outer join oil_equip_parts s
          on s.part_no = p.part_no
       where to_number(to_char(p.oiling_date, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(p.oiling_date, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and e.supplier_code = a_supply_code
         and e.plantcode like a_plantcode
         and p.submit_flag = '1';
  end;
end pg_oil41;
/

