create view VIEW_CHARGE_WORKORDER_TOOL as
select W.I_ID,
         D.V_JXGX_CODE,
         D.V_JJ_CODE,
         D.V_JJ_NAME,
         D.V_JJ_TS,
         D.V_JJ_DE,
         ROUND(NVL2(D.V_JJ_DE * D.V_JJ_TS, D.V_JJ_DE * D.V_JJ_TS, 0),
                       2) CARCOST
    from  PM_1917_JXGX_JJ_DATA D
    left join PM_WORKORDER_OTHER W on W.V_ORDERGUID=D.V_JXGX_CODE
/

