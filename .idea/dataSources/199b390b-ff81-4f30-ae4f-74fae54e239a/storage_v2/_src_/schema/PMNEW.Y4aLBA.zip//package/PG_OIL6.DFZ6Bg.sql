create package pg_oil6 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/13 9:08:09
  -- Purpose : 6.统计分析

  --6.1 按主机设备统计油品使用情况
  --查询和导出，调用过程pg_oil6.get_equoilconsume_table获取数据，并加载主机设备润滑油脂使用情况表格
  procedure get_equoilconsume_table(a_plantcode  varchar2, --厂矿编码
                                    a_departcode varchar2, --部门编码
                                    a_equtype    varchar2, --设备类型编码
                                    a_equip_id   varchar2, --设备编号（ID）
                                    a_begindate  date, --查询起始日期
                                    a_enddate    date, --查询结束日期
                                    a_mat_no     varchar2,
                                    a_mat_desc   varchar2,
                                    ret          out sys_refcursor --返回结果集
                                    );
  --6.2 按主机设备部位统计油品使用情况
  --调用过程pg_oil6.get_equpart_draw获取数据，并更新图表。
  procedure get_equpart_draw(a_plantcode  varchar2, --厂矿编码
                             a_departcode varchar2, --部门编码
                             a_equtype    varchar2, --设备类型编码
                             a_equip_no   varchar2, --主机编号
                             a_part_no    varchar2, --部位码
                             a_begindate  date, --查询起始日期
                             a_enddate    date, --查询结束日期
                             ret          out sys_refcursor --返回结果集
                             );
  --6.3 按油品统计使用情况
  --查询和导出：调用过程pg_oil6.get_oilmat_table获取数据，并加载润滑油品使用（消耗）情况表格
  procedure get_oilmat_table(a_plantcode  varchar2, --厂矿编码
                             a_departcode varchar2, --部门编码
                             a_begindate  date, --查询起始日期
                             a_enddate    date, --查询结束日期
                             a_mat_no     varchar2, --物料号
                             a_mat_desc   varchar2, --物料名
                             ret          out sys_refcursor --返回结果集
                             );
  --6.4 按供应商统计使用情况
  --4.查询和导出，调用过程pg_oil6.get_supplyoiluse_table获取数据并加载表格。
  procedure get_supplyoiluse_table(a_plantcode   varchar2, --厂矿编码
                                   a_departcode  varchar2, --部门编码
                                   a_begindate   date, --查询起始日期
                                   a_enddate     date, --查询结束日期
                                   a_mat_desc    varchar2, --物料名
                                   a_supply_code varchar2, --供应商编码
                                   ret           out sys_refcursor --返回结果集
                                   );
  --6.5 按油品单价统计使用情况
  --查询，调用过程pg_oil6.get_oilprice_draw加载图表。
  procedure get_oilprice_draw(a_plantcode  varchar2, --厂矿编码
                              a_departcode varchar2, --部门编码
                              a_begindate  date, --查询起始日期
                              a_enddate    date, --查询结束日期
                              ret          out sys_refcursor --返回结果集
                              );
  --6.6 按作业区统计使用情况
  --查询，调用过程pg_oil6.get_depart_draw加载图表。
  procedure get_depart_draw(a_plantcode varchar2, --厂矿编码
                            a_begindate date, --查询起始日期
                            a_enddate   date, --查询结束日期
                            ret         out sys_refcursor --返回结果集
                            );
end pg_oil6;
/

