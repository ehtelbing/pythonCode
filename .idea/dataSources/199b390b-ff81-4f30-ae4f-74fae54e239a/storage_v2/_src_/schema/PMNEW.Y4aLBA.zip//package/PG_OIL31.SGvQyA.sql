create package pg_oil31 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/12 8:24:01
  -- Purpose : 3.1 润滑油脂消耗部位写实（地址：JMM_AK/page/oil/3_1.jsp）

  --查询，调用过程pg_oil31.get_waitoilconsumelist获取待处理润滑物资表数据，并加载表格。
  procedure get_waitoilconsumelist(a_plantcode  varchar2, --厂矿编码
                                   a_departcode varchar2, --部门编码
                                   a_equip_id   varchar2, --设备ID（设备编码）
                                   a_orderid    varchar2, --工单号
                                   a_billcode   varchar2, --出库单号
                                   a_mat_desc   varchar2, --物资描述
                                   ret          out sys_refcursor --返回结果集
                                   );
  --点击待处理润滑物资表的写实列，打开“写实操作”界面。并调用过程pg_oil31.get_partconsumelist加载表格
  procedure get_partconsumelist(a_consume_id varchar2, --消耗ID
                                ret          out sys_refcursor --返回结果集
                                );
  procedure get_daypartconsumelist(a_consume_id varchar2, --消耗ID
                                   ret          out sys_refcursor --返回结果集
                                   );
  --获取当前换油部位的上次评价信息
  function get_lastpart_approve(a_equip_id varchar2,
                                a_part_no  varchar2,
                                a_date     date) return varchar2;
  --调用过程pg_oil31.submitpartconsume将用户的写实数据保存
  procedure submitpartconsume(a_consume_id varchar2, --消耗ID
                              a_oil_remark varchar2, --写实情况说明
                              a_userid     varchar2, --用户名
                              ret_msg      out varchar2, --反馈信息
                              ret          out varchar2 --执行结果
                              );
  --点击“平均分配”按钮，调用过程pg_oil31.insertpartavg，调用成功更新该界面的表格数据。
  procedure insertpartavg(a_consume_id varchar2, --消耗ID
                          a_userid     varchar2, --用户名
                          ret_msg      out varchar2, --反馈信息
                          ret          out varchar2 --执行结果
                          );
  --点击“按规范分配”按钮，调用过程pg_oil31.insertpartmain，调用成功更新该界面的表格数据。
  procedure insertpartmain(a_consume_id varchar2, --消耗ID
                           a_userid     varchar2, --用户名
                           ret_msg      out varchar2, --反馈信息
                           ret          out varchar2 --执行结果
                           );
  --点击写实操作表格的“保存”按钮，调用过程pg_oil31.savepartconsume保存行数据
  procedure savepartconsume(a_detail_id  varchar2, --写实ID
                            a_consume_id varchar2, --消耗ID
                            a_equip_id   varchar2, --设备ID（设备编码）
                            a_part_no    varchar2, --部位码
                            a_useamount  number, --部位写实数量
                            a_oil_date   date, --润滑日期
                            a_approve    varchar2, --上次油品评价
                            a_userid     varchar2, --用户ID
                            ret_msg      out varchar2, --反馈信息
                            ret          out varchar2 --执行结果
                            );
  procedure daysavepartconsume(a_detail_id  varchar2, --写实ID
                               a_consume_id varchar2, --消耗ID
                               a_equip_id   varchar2, --设备ID（设备编码）
                               a_part_no    varchar2, --部位码
                               a_useamount  number, --部位写实数量
                               a_begin_date date,
                               a_end_date   date,
                               a_approve    varchar2, --上次油品评价
                               a_userid     varchar2, --用户ID
                               ret_msg      out varchar2, --反馈信息
                               ret          out varchar2 --执行结果
                               );
end pg_oil31;
/

