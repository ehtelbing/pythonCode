create package body PG_DJ703 is
  --检修状态配置页
  --查询
  procedure pro_dj703_select(v_orderdesc varchar2,
                             v_cursor    out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from DJ_ORDER_STATUS a
       where a.order_status_desc like v_orderdesc || '%';
  end;
  --删除
  procedure pro_dj703_delete(v_ordersts varchar2, ret out varchar2) as
  begin
    savepoint s;
    delete DJ_ORDER_STATUS a
     where a.use_flag = '1'
       and a.order_status = v_ordersts;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --选择
  procedure pro_dj703_updateflag(v_ordersts varchar2,
                                 v_flag     number,
                                 ret        out varchar2) as
  begin
    savepoint s;
    update DJ_ORDER_STATUS a
       set a.use_flag = v_flag
     where a.order_status = v_ordersts;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --新增
  procedure pro_dj703_insert(v_ordersts  varchar2,
                             v_orderdesc varchar2,
                             v_userflag  varchar2,
                             v_nextsts   varchar2,
                             ret         out varchar2) as
  begin
    savepoint s;
    insert into DJ_ORDER_STATUS
    values
      (v_ordersts, v_orderdesc, v_userflag, v_nextsts, '', '');
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := SQLERRM;
  end;
end PG_DJ703;
/

