create procedure PM_03_PLAN_GX_SEL(V_V_CPCODE IN VARCHAR2,
                                              V_CURSOR   OUT SYS_REFCURSOR) is

  /*
  大修工序查询
  */
begin

  OPEN V_CURSOR FOR
    SELECT G.*
      FROM PM_03_PLAN_GX G
     INNER JOIN PM_03_PLAN_CPGX C
        ON G.V_UID = C.V_GXBM
     WHERE C.V_CPBM = V_V_CPCODE
     ORDER BY G.V_XH;

end PM_03_PLAN_GX_SEL;
/

