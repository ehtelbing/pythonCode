create procedure PM_03_FLOW_STATE_SEL(V_V_ORGCODE  IN VARCHAR2,
                                                 V_V_DEPTCODE IN VARCHAR2,
                                                 V_V_PLANTYPE IN VARCHAR2,
                                                 V_CURSOR     OUT SYS_REFCURSOR) is
  /*计划流程设置查询*/
begin
  OPEN V_CURSOR FOR
    SELECT P.*
      FROM VIEW_03_PLAN_FLOW_STATE P
     WHERE P.V_ORGCODE = V_V_ORGCODE
       AND P.V_DEPTCODE = V_V_DEPTCODE
       AND P.V_PLANTYPE = V_V_PLANTYPE
     ORDER BY P.V_ORDER;

end PM_03_FLOW_STATE_SEL;
/

