create FUNCTION FUNC_WP_GETUSERNAME(A_USERID VARCHAR2)
  RETURN VARCHAR2 IS
  p_username base_person.v_personname%type;
BEGIN
  select v_personname
    into p_username
    from base_person p
   where p.v_loginname = a_userid;
  RETURN p_username;
exception
  when others then
    return null;
END FUNC_WP_GETUSERNAME;
/

