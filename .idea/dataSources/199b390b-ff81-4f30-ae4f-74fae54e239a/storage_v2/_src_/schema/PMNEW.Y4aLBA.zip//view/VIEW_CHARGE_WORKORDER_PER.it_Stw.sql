create view VIEW_CHARGE_WORKORDER_PER as
select P.I_ID,  --?????
         P.V_ORDERGUID,
         P.I_NUMBER_OF_PEOPLE,
         D.V_TS,
         D.V_DE,
         D.V_PERCODE_DE,
         D.V_PERNAME_DE,
         ROUND(NVL2(D.V_TS * D.V_DE * P.I_NUMBER_OF_PEOPLE,
                            D.V_TS * D.V_DE * P.I_NUMBER_OF_PEOPLE,
                            0),
                       2) PERSONCOST
    from PM_WORKORDER_ET_OPERATIONS P
    left join PM_1917_JXGX_PER_DATA D ON D.V_JXGX_CODE = P.V_ORDERGUID
/

