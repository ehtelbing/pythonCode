create view VIEW_BASE_ROLETOMENU as
SELECT base_menu.i_menuid, base_menu.v_menucode, base_menu.v_menuname,
          base_menu.v_menucode_up, base_menu.v_address, base_menu.v_icourl,
          base_menu.v_systype, base_menu.i_orderid,
          base_roletomenu.v_rolecode, base_personrole.v_rolename,base_personrole.v_deptcode
     FROM base_roletomenu, base_menu, base_personrole
    WHERE base_menu.v_menucode = base_roletomenu.v_menucode
      AND base_personrole.v_rolecode = base_roletomenu.v_rolecode
      AND base_personrole.v_deptcode = base_roletomenu.v_deptcode
/

