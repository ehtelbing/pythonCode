create FUNCTION FUNC_GETYZJCODE(V_V_DEPTCODE IN VARCHAR2)
  RETURN VARCHAR2 IS
  V_V_ORDERID VARCHAR2(50);
  V_I_ID      NUMBER;
BEGIN
  /*?????CODE
  ?????????+ ???.
  */
  BEGIN
    SELECT TO_NUMBER(NVL(MAX(REPLACE(V_CODE, 'yzj')), 0))
    INTO   V_I_ID
    FROM   PM_PRELOADWARE
    WHERE  V_OWNERDEPT = V_V_DEPTCODE
    -- AND    ROWNUM < 2
    ORDER  BY V_CODE DESC;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_I_ID := V_V_DEPTCODE || REPLACE(TO_CHAR(0, '00000000'), ' ', '');
  END;
  V_I_ID := V_I_ID + 1;
  V_V_ORDERID := V_V_DEPTCODE ||
                 REPLACE(TO_CHAR(REPLACE(TO_CHAR(V_I_ID), V_V_DEPTCODE),
                                 '00000000'),
                         ' ',
                         '');
  RETURN 'yzj' || V_V_ORDERID;
END FUNC_GETYZJCODE;
/

