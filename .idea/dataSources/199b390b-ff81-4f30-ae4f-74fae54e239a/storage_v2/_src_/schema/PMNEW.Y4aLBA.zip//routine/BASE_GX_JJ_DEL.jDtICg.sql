create PROCEDURE BASE_GX_JJ_DEL(V_V_JXGX_CODE IN VARCHAR2,
                                           V_V_JJ_CODE   IN VARCHAR2,
                                           V_INFO        OUT VARCHAR2) IS
  /*删除检修工序的机具*/
BEGIN
  DELETE FROM PM_1917_JXGX_JJ_DATA B
   WHERE B.V_JXGX_CODE = V_V_JXGX_CODE
     AND B.V_JJ_CODE = V_V_JJ_CODE;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
END BASE_GX_JJ_DEL;
/

