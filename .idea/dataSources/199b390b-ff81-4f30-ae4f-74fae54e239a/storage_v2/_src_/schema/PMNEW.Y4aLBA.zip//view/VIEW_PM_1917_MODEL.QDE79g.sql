create view VIEW_PM_1917_MODEL as
select M.I_ID,M.V_MX_CODE,M.V_MX_NAME,G.V_JXGX_CODE,G.V_JXGX_NAME,M.V_ORGCODE,M.V_DEPTCODE,M.V_EQUTYPE,M.V_EQUCODE,M.V_EQUCODE_CHILD,M.V_BZ,M.V_IN_DATE,M.V_IN_PER,G.V_GZZX_CODE,G.V_JXGX_NR,G.V_PERNUM,G.V_PERTIME,
jj.v_jj_name,gj.v_gj_name,aq.v_aqcs_name,js.v_jsyq_name
  from pm_1917_jxmx_data m
  left join pm_1917_jxgx_data g
    on m.v_mx_code = g.v_jxmx_code
  left join pm_1917_jxgx_gj_data gj
    on gj.v_jxgx_code = g.v_jxgx_code
  left join pm_1917_jxgx_jj_data jj
    on jj.v_jxgx_code = g.v_jxgx_code
  left join pm_1917_jxgx_jsyq_data js
    on js.v_jxgx_code = g.v_jxgx_code
  left join pm_1917_jxgx_aqcs_data aq
    on aq.v_jxgx_code = g.v_jxgx_code
    order by m.v_mx_code
/

