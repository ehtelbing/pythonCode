create function add_user_trends(a_userid varchar2,

                                           a_workcenter varchar2)
  return varchar2 is
  p_ret varchar2(10) := 'Fail';
  --  p_count number(2, 0) := 0;
begin
  begin
    INSERT INTO BASE_USER_TRENDS B
      (ID, USERID, INSERTDATE, WORKCENTER)
    VALUES
      (CREATEGUID(), a_userid, sysdate, a_workcenter);
    commit;
    p_ret := 'Success';
  end;
  return p_ret;
end;
/

