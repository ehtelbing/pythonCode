create PROCEDURE BASE_FILE_CHAKAN_SEL(V_V_GUID IN VARCHAR2, --信息GUID
                                                 V_CURSOR OUT SYS_REFCURSOR) is
  /*查询附件列表*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT B.V_GUID,
           B.V_FILEGUID,
           B.V_FILENAME,
           B.V_FILETYPECODE,
           B.V_PLANT,
           B.V_DEPT,
           B.V_TIME,
           B.V_PERSON,
           B.V_REMARK
      FROM BASE_FILE B
     WHERE B.V_GUID = V_V_GUID;

END BASE_FILE_CHAKAN_SEL;
/

