create procedure PM_03_PLAN_REPAIR_DEPT_SEL(V_V_GUID IN VARCHAR2,
                                                       V_CURSOR OUT SYS_REFCURSOR) is

  /*
  大修工程检修单位查询
  */
begin
  OPEN V_CURSOR FOR
    SELECT * FROM PM_03_PLAN_REPAIR_DEPT D WHERE D.V_GUID = V_V_GUID;
end PM_03_PLAN_REPAIR_DEPT_SEL;
/

