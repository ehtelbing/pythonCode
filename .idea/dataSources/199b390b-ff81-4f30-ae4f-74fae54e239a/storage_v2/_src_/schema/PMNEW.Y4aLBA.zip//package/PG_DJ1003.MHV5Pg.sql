create package pg_dj1003 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/8/10 15:26:49
  -- Purpose :
  -- 查询消耗
  procedure getconsume(a_begindate    date, --起始日期
                       a_enddate      date, --结束日期
                       a_orderid      varchar2, --检修单号
                       a_plantcode    varchar2, --厂矿编码
                       a_departcode   varchar2, --部门编码
                       a_itype        varchar2, --物资分类
                       a_storedesc    varchar2, --库房描述
                       a_materialcode varchar2, --物资分类
                       a_materialname varchar2, --物资名称
                       a_etalon       varchar2, --规格
                       a_lcodesc      varchar2, --存放位置描述
                       ret            out sys_refcursor);
  --查询检修单消耗物料
  procedure getorderconsume(a_orderid varchar2, --检修单号
                            ret       out sys_refcursor);
end pg_dj1003;
/

