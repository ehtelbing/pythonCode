create package pg_oil41 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/12 14:10:59
  -- Purpose : 4.1 供应商评价（地址：JMM_AK/page/oil/4_1.jsp）

  -- 调用过程pg_oil41.getcountry获取国家选择列表
  procedure getcountry(ret out sys_refcursor --返回结果集
                       );
  --调用过程pg_oil41.getprovince获取省份选择列表
  procedure getprovince(a_country_code varchar2, --国家代码
                        ret            out sys_refcursor --返回结果集
                        );
  --调用过程pg_oil41.getcity获取城市选择列表
  procedure getcity(a_country_code  varchar2, --国家代码
                    a_province_code varchar2, --省份代码
                    ret             out sys_refcursor);
  --对选定供应商的评级，调用过程pg_oil41.getlevellist加载选择列表
  procedure getlevellist(ret out sys_refcursor --返回结果集
                         );
  -- 查询和导出，调用过程pg_oil41.getoilsupplylist获取数据，并加载表格。
  procedure getoilsupplylist(a_country_code  varchar2, --国家代码
                             a_province_code varchar2, --省份代码
                             a_city_code     varchar2, --城市代码
                             a_supply_code   varchar2, --供应商编号（客商编码）
                             a_supply_name   varchar2, --供应商名（客商名）
                             ret             out sys_refcursor);
  --点击"确认评级"按钮，调用过程pg_oil41.approve对选定的供应商进行评级。
  procedure approve(a_supply_code varchar2, --供应商编号
                    a_level_code  varchar2, --级别编号
                    a_userid      varchar2, --用户名
                    a_plantcode   varchar2, --厂矿编码（用户信息）
                    ret_msg       out varchar2, --反馈信息
                    ret           out varchar2 --执行结果
                    );
  --点击“使用明细”列的“查看”按钮，打开“供应商油品使用情况”窗口，并调用过程pg_oil41.getsupplyuseoillist加载该界面表格。
  procedure getsupplyuseoillist(a_supply_code varchar2, --供应商编号
                                a_begindate   date, --起始日期
                                a_enddate     date, --结束日期
                                a_plantcode   varchar2, --使用单位编号
                                ret           out sys_refcursor);
end pg_oil41;
/

