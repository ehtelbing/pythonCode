create PROCEDURE BASE_JJ_BY_ZGGUID_SEL(V_V_ZG_GUID IN VARCHAR2, --整改guid
                                                  V_CURSOR    OUT SYS_REFCURSOR) IS
  /*传入整改guid查询机具*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT *
      FROM PM_1917_JXGX_JJ_DATA
     WHERE V_JXGX_CODE IN
           (SELECT P.V_GUID
              FROM PM_WORKORDER_ET_OPERATIONS P
             WHERE P.V_ORDERGUID IN
                   (SELECT V_ORDER_GUID
                      FROM BASE_AQCSZG_LINK_WORKORDER
                     WHERE V_ZG_GUID = V_V_ZG_GUID));
END BASE_JJ_BY_ZGGUID_SEL;
/

