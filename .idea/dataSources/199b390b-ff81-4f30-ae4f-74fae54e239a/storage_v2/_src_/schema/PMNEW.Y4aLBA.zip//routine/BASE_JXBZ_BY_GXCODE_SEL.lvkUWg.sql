create PROCEDURE BASE_JXBZ_BY_GXCODE_SEL(V_V_GX_CODE IN VARCHAR2, --工序code
                                                    V_CURSOR    OUT SYS_REFCURSOR) IS
  /*传入工序code查询检修技术标准*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT *
      FROM PM_REPAIR_JS_STANDARD P
     WHERE P.V_GUID IN (SELECT V_JSYQ_CODE
                          FROM PM_1917_JXGX_JSYQ_DATA
                         WHERE V_JXGX_CODE = V_V_GX_CODE);
END BASE_JXBZ_BY_GXCODE_SEL;
/

