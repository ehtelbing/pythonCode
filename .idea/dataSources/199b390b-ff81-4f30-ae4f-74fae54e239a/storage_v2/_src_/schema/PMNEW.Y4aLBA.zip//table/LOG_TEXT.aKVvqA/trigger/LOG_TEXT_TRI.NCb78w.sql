create trigger LOG_TEXT_TRI
  before insert
  on LOG_TEXT
  for each row
BEGIN
  SELECT LOG_TEXT_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
END LOG_TEXT_TRI;
/

