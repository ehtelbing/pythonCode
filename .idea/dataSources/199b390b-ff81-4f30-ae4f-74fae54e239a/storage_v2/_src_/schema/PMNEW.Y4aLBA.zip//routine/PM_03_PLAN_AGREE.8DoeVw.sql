create procedure PM_03_PLAN_AGREE(V_V_GUID     IN VARCHAR2, --待办guid
                                             V_V_PLANTYPE IN VARCHAR2, --计划类型
                                             V_V_IDEA     IN VARCHAR2, --审批意见
                                             V_V_INPER    IN VARCHAR2, --审批人编码
                                             V_INFO       OUT VARCHAR2) is
  /*计划管理流程通过*/
  V_V_URL        VARCHAR2(50);
  V_V_ORDER      VARCHAR2(50);
  V_V_NEXT_ORDER VARCHAR2(50);

  V_V_ORGCODE  VARCHAR2(50);
  V_V_DEPTCODE VARCHAR2(50);

  V_V_PLANTYPE_NAME VARCHAR2(50);
  V_V_DBGUID        VARCHAR2(50);

  V_NUMBER NUMBER;
begin

  IF V_V_PLANTYPE = 'YEAR' THEN
    V_V_PLANTYPE_NAME := '年计划审批流程';
    V_V_URL           := '/PM_03020213/index.html';

    SELECT Y.V_ORGCODE, Y.V_DEPTCODE
      INTO V_V_ORGCODE, V_V_DEPTCODE
      FROM PM_03_PLAN_YEAR Y
     WHERE Y.V_GUID = V_V_GUID
     GROUP BY Y.V_ORGCODE, Y.V_DEPTCODE;

  ELSIF V_V_PLANTYPE = 'QUARTER' THEN
    V_V_PLANTYPE_NAME := '季度计划审批流程';
    V_V_URL           := '/PM_03010114/index.html';

    SELECT Q.V_ORGCODE, Q.V_DEPTCODE
      INTO V_V_ORGCODE, V_V_DEPTCODE
      FROM PM_03_PLAN_QUARTER Q
     WHERE Q.V_GUID = V_V_GUID
     GROUP BY Q.V_ORGCODE, Q.V_DEPTCODE;
  ELSIF V_V_PLANTYPE = 'MONTH' THEN
    V_V_PLANTYPE_NAME := '月计划审批流程';
    V_V_URL           := '/PM_03010213/index.html';

    SELECT M.V_ORGCODE, M.V_DEPTCODE
      INTO V_V_ORGCODE, V_V_DEPTCODE
      FROM PM_03_PLAN_MONTH M
     WHERE M.V_GUID = V_V_GUID
     GROUP BY M.V_ORGCODE, M.V_DEPTCODE;
  ELSIF V_V_PLANTYPE = 'WEEK' THEN
    V_V_PLANTYPE_NAME := '周计划审批流程';
    V_V_URL           := '/PM_03010307/index.html';

    SELECT W.V_ORGCODE, W.V_DEPTCODE
      INTO V_V_ORGCODE, V_V_DEPTCODE
      FROM PM_03_PLAN_WEEK W
     WHERE W.V_GUID = V_V_GUID
     GROUP BY W.V_ORGCODE, W.V_DEPTCODE;
  END IF;

  SELECT D.V_DBGUID, D.V_ORDER
    INTO V_V_DBGUID, V_V_ORDER
    FROM PM_WORKORDER_FLOW_DB D
   WHERE D.V_ORDERID = V_V_GUID
     AND D.I_STATUS = 0
     AND D.V_PERCODE = V_V_INPER;

  UPDATE PM_WORKORDER_FLOW_DB D
     SET D.I_STATUS = 1,
         D.V_IDEA   = V_V_IDEA,
         D.V_DATE   = to_char(sysdate, 'yyyy-mm-dd hh24:mi:ss')
   WHERE D.V_DBGUID = V_V_DBGUID;

  UPDATE PM_WORKORDER_FLOW_DB D
     SET D.I_STATUS = 1
   WHERE D.V_ORDERID = V_V_GUID;

  --查询下一步是否有步骤
  SELECT COUNT(*)
    INTO V_NUMBER
    FROM PM_03_FLOW_SET S
   WHERE S.V_PLANTYPE = V_V_PLANTYPE
     AND S.V_ORGCODE = V_V_ORGCODE
     AND S.V_DEPTCODE = V_V_DEPTCODE
     AND S.V_ORDER > V_V_ORDER;

  IF V_NUMBER > 0 THEN

    --查询下一步排序
    SELECT MIN(S.V_ORDER)
      INTO V_V_NEXT_ORDER
      FROM PM_03_FLOW_SET S
     WHERE S.V_PLANTYPE = V_V_PLANTYPE
       AND S.V_ORGCODE = V_V_ORGCODE
       AND S.V_DEPTCODE = V_V_DEPTCODE
       AND S.V_ORDER > V_V_ORDER;

    /*添加审批人信息*/
    FOR C IN (SELECT S.V_PERCODE, S.V_FLOWNAME
                FROM PM_03_FLOW_SET S
               WHERE S.V_PLANTYPE = V_V_PLANTYPE
                 AND S.V_ORGCODE = V_V_ORGCODE
                 AND S.V_DEPTCODE = V_V_DEPTCODE
                 AND S.V_ORDER = V_V_NEXT_ORDER) LOOP

      /*添加审批人信息*/
      INSERT INTO PM_WORKORDER_FLOW_DB
        (V_ORDERID,
         V_DBGUID,
         V_FLOWSTEP,
         I_STATUS,
         V_PERCODE,
         V_TS,
         V_FLOWTYPE,
         V_FLOWCODE,
         V_FLOWNAME,
         V_URL,
         V_ORDER)
      VALUES
        (V_V_GUID,
         CREATEGUID(),
         C.V_FLOWNAME,
         0,
         C.V_PERCODE,
         '',
         V_V_PLANTYPE,
         V_V_PLANTYPE_NAME,
         V_V_PLANTYPE_NAME,
         V_V_URL,
         V_V_NEXT_ORDER);

      /*--查看是否超时上报，并记录超时上报
      PRO_PM_PLAN_LOCKING_SET(V_V_INPER,
                              V_V_GUID,
                              C.V_FLOWNAME,
                              V_V_PLANTYPE,
                              V_INFO);*/

      IF V_V_PLANTYPE = 'YEAR' THEN
        UPDATE PM_03_PLAN_YEAR Y
           SET Y.V_FLOWCODE = C.V_FLOWNAME
         WHERE Y.V_GUID = V_V_GUID;
      ELSIF V_V_PLANTYPE = 'QUARTER' THEN
        UPDATE PM_03_PLAN_QUARTER Q
           SET Q.V_FLOWCODE = C.V_FLOWNAME
         WHERE Q.V_GUID = V_V_GUID;
      ELSIF V_V_PLANTYPE = 'MONTH' THEN
        UPDATE PM_03_PLAN_MONTH M
           SET M.V_FLOWCODE = C.V_FLOWNAME
         WHERE M.V_GUID = V_V_GUID;
      ELSIF V_V_PLANTYPE = 'WEEK' THEN
        UPDATE PM_03_PLAN_WEEK W
           SET W.V_FLOWCODE = C.V_FLOWNAME
         WHERE W.V_GUID = V_V_GUID;
      END IF;
    END LOOP;

  ELSE

    IF V_V_PLANTYPE = 'YEAR' THEN
      UPDATE PM_03_PLAN_YEAR Y
         SET Y.V_FLOWCODE = '', Y.V_STATE = 30
       WHERE Y.V_GUID = V_V_GUID;
    ELSIF V_V_PLANTYPE = 'QUARTER' THEN
      UPDATE PM_03_PLAN_QUARTER Q
         SET Q.V_FLOWCODE = '', Q.V_STATE = 30
       WHERE Q.V_GUID = V_V_GUID;
    ELSIF V_V_PLANTYPE = 'MONTH' THEN
      UPDATE PM_03_PLAN_MONTH M
         SET M.V_FLOWCODE = '', M.V_STATE = 30
       WHERE M.V_GUID = V_V_GUID;
    ELSIF V_V_PLANTYPE = 'WEEK' THEN
      UPDATE PM_03_PLAN_WEEK W
         SET W.V_FLOWCODE = '', W.V_STATE = 30, w.v_workflag = '10'
       WHERE W.V_GUID = V_V_GUID;
    END IF;

  END IF;

  COMMIT;
  V_INFO := '成功';

EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
end PM_03_PLAN_AGREE;
/

