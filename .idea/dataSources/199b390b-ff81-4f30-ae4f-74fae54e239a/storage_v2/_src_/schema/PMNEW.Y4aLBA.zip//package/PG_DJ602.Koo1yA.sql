create package pg_dj602 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/21 13:57:10
  -- Purpose :
  --退回工单到上一步
  procedure rollbacktoprestep(a_orderid  varchar2, --工单号
                              a_userid   varchar2, --用户ID
                              a_username varchar2, --用户名
                              ret_msg    out varchar2,
                              ret        out varchar2);
end pg_dj602;
/

