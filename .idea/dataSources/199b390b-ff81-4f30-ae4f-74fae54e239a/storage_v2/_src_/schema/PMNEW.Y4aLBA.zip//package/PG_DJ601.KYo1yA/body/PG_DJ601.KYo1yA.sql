create package BODY pg_dj601 is
  -- 查询可用库存
  procedure getmatkc(a_plantcode    varchar2, --厂矿编码
                     a_departcode   varchar2, --部门编码
                     a_itype        varchar2, --物资分类
                     a_materialcode varchar2, --物资编号
                     a_materialname varchar2, --物资名称
                     a_etalon varchar2,--规格型号
                     ret            out sys_refcursor) is
  begin
    open ret for
      select k.kcid,
             k.materialcode,
             k.materialname,
             k.etalon,
             k.unit,
             k.f_price,
             k.ky_amount,
             k.store_desc
        from dj_mat_kc k
       where k.plantcode = a_plantcode
         and k.departcode = a_departcode
         and k.i_type like a_itype
         and k.materialcode like '%' || a_materialcode || '%'
         and k.materialname like '%' || a_materialname || '%'
         and nvl(k.etalon,'0') like '%'||a_etalon||'%'
         and k.ky_amount >0;
  end getmatkc;
end;
/

