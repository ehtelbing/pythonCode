create package body pg_run_yeild
/*
说明：设备作业量
*/
 is
  --查询当前设备的作业量
  function get_work_yeild(a_equid     varchar2, --设备id
                          a_begindate date, --起始日期
                          a_enddate   date, --结束日期
                          a_cycle_id  varchar2, --周期id
                          ret_sum     out number, --合计
                          ret         out sys_refcursor) return varchar2 is
  begin
    begin
      select sum(insert_value)
        into ret_sum
        from view_run_equ_yeild
       where to_number(to_char(workdate, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(workdate, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and equ_id = a_equid
         and cycle_id like a_cycle_id;
    exception
      when others then
        ret_sum := 0;
    end;
    open ret for
      select id,
             equname, --设备名称
             cycle_desc, --周期类型
             cycle_unit, --计算单位
             to_char(workdate, 'YYYYMMDD') workdate, --作业日期
             insert_value, --作业量
             insert_person, --录入人
             insertdate --录入时间
        from view_run_equ_yeild
       where to_number(to_char(workdate, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(workdate, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and equ_id = a_equid
         and cycle_id like a_cycle_id;
    return 'Success';
  end;
  --查询当前设备的作业量
  procedure get_work_yeild_table(a_plantcode  varchar2,
                                 a_departcode varchar2,
                                 a_equid      varchar2, --设备id
                                 a_begindate  date, --起始日期
                                 a_enddate    date, --结束日期
                                 a_cycle_id   varchar2, --周期id
                                 ret_sum      out number, --合计
                                 ret          out sys_refcursor) is
  begin
    begin
      select sum(insert_value)
        into ret_sum
        from view_run_equ_yeild y
       where to_number(to_char(workdate, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(workdate, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and equ_id like a_equid
         and cycle_id like a_cycle_id
         and y.plantcode = a_plantcode
         and y.departcode = a_departcode;
    exception
      when others then
        ret_sum := 0;
    end;
    open ret for
      select equ_id,
             equname, --设备名称
             cycle_desc, --周期类型
             cycle_unit, --计算单位
             to_char(workdate, 'YYYYMMDD') workdate, --作业日期
             sum(nvl(insert_value, 0)) insert_value --作业量
        from view_run_equ_yeild y
       where to_number(to_char(workdate, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(workdate, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and equ_id like a_equid
         and cycle_id like a_cycle_id
         and y.plantcode = a_plantcode
         and y.departcode = a_departcode
       group by equ_id,
                equname,
                cycle_desc,
                cycle_unit,
                to_char(workdate, 'YYYYMMDD')
       order by equname, workdate desc;
  end;
  --录入作业量
  function input_yeild(a_equ_id      varchar2, --设备id
                       a_cycle_id    varchar2, --周期id
                       a_workdate    date, --作业日期
                       a_insertvalue number, --作业量
                       a_insrtperson varchar2, --录入人
                       ret_msg       out varchar2) return varchar2 is
    p_ret varchar2(10) := 'Fail';
    cursor c is
      select bj_unique_code from view_run_bj_cycle where equ_id = a_equ_id;
    p_equ_yeild_id varchar2(36) := func_run_guid();
  begin
    begin
      savepoint s;
      insert into run_equ_yeild
        (id,
         equ_id,
         cycle_id,
         workdate,
         insert_value,
         insert_person,
         insertdate)
      values
        (p_equ_yeild_id,
         a_equ_id,
         a_cycle_id,
         a_workdate,
         a_insertvalue,
         a_insrtperson,
         sysdate);
      for i in c loop
        insert into run_bj_yeild
          (id,
           bj_unique_code,
           cycle_id,
           insertdate,
           insert_value,
           insertperson,
           equ_yeild_id)
        values
          (func_run_guid(),
           i.bj_unique_code,
           a_cycle_id,
           sysdate,
           a_insertvalue,
           a_insrtperson,
           p_equ_yeild_id);
      end loop;
      commit;
      ret_msg := '操作成功';
      p_ret   := 'Success';
    exception
      when others then
        ret_msg := '操作失败';
        rollback to s;
    end;
    return p_ret;
  end;

  --录入作业量
  function input_yeild_pp(a_equ_id      varchar2, --设备id
                          a_cycle_id    varchar2, --周期id
                          a_workdate    date, --作业日期
                          a_insertvalue number, --作业量
                          a_insrtperson varchar2, --录入人
                          a_ppcode      varchar2,
                          ret_msg       out varchar2) return varchar2 is
    p_ret          varchar2(10) := 'Fail';
    p_equ_yeild_id varchar2(36) := func_run_guid();
    p_count        number(2, 0) := 0;
  begin
    select count(*)
      into p_count
      from run_equ_yeild y
     where y.pp_code = a_ppcode
       and to_char(y.workdate, 'YYYYMMDD') =
           to_char(a_workdate, 'YYYYMMDD')
       and y.cycle_id = a_cycle_id;
    begin
      savepoint s;
      if p_count = 0 then
        insert into run_equ_yeild
          (id,
           equ_id,
           cycle_id,
           workdate,
           insert_value,
           insert_person,
           insertdate,
           pp_code)
        values
          (p_equ_yeild_id,
           a_equ_id,
           a_cycle_id,
           a_workdate,
           a_insertvalue,
           a_insrtperson,
           sysdate,
           a_ppcode);
      else
        update run_equ_yeild
           set insert_value  = a_insertvalue,
               insert_person = a_insrtperson,
               insertdate    = sysdate
         where pp_code = a_ppcode
           and to_char(workdate, 'YYYYMMDD') =
               to_char(a_workdate, 'YYYYMMDD')
           and cycle_id = a_cycle_id;
      end if;
      commit;
      ret_msg := '操作成功';
      p_ret   := 'Success';
    exception
      when others then
        ret_msg := '操作失败' || sqlerrm;
        rollback to s;
    end;
    return p_ret;
  end;
  --录入作业量
  function input_yeild_ppnew(a_equ_id      varchar2, --设备id
                             a_cycle_id    varchar2, --周期id
                             a_workdate    date, --作业日期
                             a_insertvalue number, --作业量
                             a_insrtperson varchar2, --录入人
                             a_ppcode      varchar2,
                             ret_msg       out varchar2) return varchar2 is
    p_ret          varchar2(10) := 'Fail';
    p_equ_yeild_id varchar2(36) := func_run_guid();
    p_count        number(2, 0) := 0;
  begin
    select count(*)
      into p_count
      from run_equ_yeild y
     where y.pp_code = a_ppcode
       and to_char(y.workdate, 'YYYYMMDD') =
           to_char(a_workdate, 'YYYYMMDD')
       and y.cycle_id = a_cycle_id;
    begin
      savepoint s;
      if p_count = 0 then
        insert into run_equ_yeild
          (id,
           equ_id,
           cycle_id,
           workdate,
           insert_value,
           insert_person,
           insertdate,
           pp_code)
        values
          (p_equ_yeild_id,
           a_equ_id,
           a_cycle_id,
           a_workdate,
           a_insertvalue,
           a_insrtperson,
           sysdate,
           a_ppcode);
      else
        update run_equ_yeild
           set insert_value  = a_insertvalue,
               insert_person = a_insrtperson,
               insertdate    = sysdate
         where pp_code = a_ppcode
           and to_char(workdate, 'YYYYMMDD') =
               to_char(a_workdate, 'YYYYMMDD')
           and cycle_id = a_cycle_id;
      end if;
      ret_msg := '操作成功';
      p_ret   := 'Success';
    exception
      when others then
        ret_msg := '操作失败' || sqlerrm;
        rollback to s;
    end;
    return p_ret;
  end;
  --删除作业量
  function delete_yeild(a_id    varchar2, --id
                        ret_msg out varchar2) return varchar2 is
    p_ret varchar2(10) := 'Fail';
  begin
    begin
      savepoint s;
      delete from run_equ_yeild where id = a_id;
      delete from run_bj_yeild where equ_yeild_id = a_id;
      commit;
      ret_msg := '操作成功';
      p_ret   := 'Success';
    exception
      when others then
        ret_msg := '操作失败';
        rollback to s;
    end;
    return p_ret;
  end;
end pg_run_yeild;
/

