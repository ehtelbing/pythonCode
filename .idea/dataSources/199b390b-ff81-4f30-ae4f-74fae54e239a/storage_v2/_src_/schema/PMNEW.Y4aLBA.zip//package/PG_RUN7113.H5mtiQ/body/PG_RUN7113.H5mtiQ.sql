create package body pg_run7113 is

  -- 获取工单物资条码表
  procedure getordermatbarcode(a_orderid      varchar2, --工单号
                               a_materialcode varchar2, --物料号
                               ret            out sys_refcursor) is
  begin
    open ret for
      select b.barcode, --条码（唯一标识）
             b.barid --条码ID
        from run_wo_barcode b
       where b.materialcode = a_materialcode
         and b.orderid = a_orderid
         and nvl(b.change_flag, '0') = '0'
       order by barcode;
  end;
end pg_run7113;
/

