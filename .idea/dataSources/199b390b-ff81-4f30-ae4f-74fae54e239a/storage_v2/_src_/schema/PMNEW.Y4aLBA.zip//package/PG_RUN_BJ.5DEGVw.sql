create package pg_run_bj
/*
说明：设备备件字典管理
*/
 is
  --添加，修改，删除备件信息
  function op_bj(a_bj_id      varchar2, --id
                 a_bj_desc    varchar2, --备件描述
                 a_bj_type    varchar2, --规格型号
                 a_bj_unit    varchar2, --计量单位
                 a_bj_remark  varchar2, --备注
                 a_plantcode  varchar2, --厂矿编码
                 a_departcode varchar2, --作业区编码
                 a_equid      varchar2, --设备id
                 a_op         varchar2, --操作
                 a_pre_flag   varchar2,
                 ret_msg      out varchar2) return varchar2;
  --查询当前备件信息
  function get_bj_all(a_plantcode  varchar2, --厂矿编码
                      a_departcode varchar2, --作业区编码
                      a_equid      varchar2, --设备id
                      ret          out sys_refcursor) return varchar2;
  --获取备件描述
  function get_bj_desc(a_bj_id varchar2) return varchar2;
  --添加删除备件标准报警周期
  function op_bj_cycle_basic(a_bj_id       varchar2, --备件id
                             a_cycle_id    varchar2, --周期id
                             a_cycle_value number, --周期报警值
                             a_op          varchar2,
                             ret_msg       out varchar) return varchar2;
  --查询当前备件的标准报警周期信息
  function get_bj_cycle_basic_all(a_bj_id varchar2, --备件id
                                  ret     out sys_refcursor) return varchar2;
  --获取备件对应的物资字典
  function get_bj_material(a_bj_id varchar2, --备件id
                           ret     out sys_refcursor) return varchar2;
  --添加,删除备件对应物资
  function op_bj_mat(a_bj_id          varchar2, --备件id
                     a_materialcode   varchar2, --物资编码
                     a_materialname   varchar2, --物资名称
                     a_materialetalon varchar2, --规格型号
                     a_unit           varchar2, --计量单位
                     a_price          number, --单价
                     a_op             varchar2,
                     ret_msg          out varchar2) return varchar2;
end pg_run_bj;
/

