create package PG_DJ802 is
  --前置工序下拉
  procedure pro_dj802_gxdroplist(v_cursor out sys_refcursor);
  --检修模型维护页面
  procedure pro_dj802_select(v_modelname in varchar2,
                             v_cursor    out sys_refcursor);
  --新增
  procedure pro_dj802_insert(v_modelcode  varchar2, --模型编码
                             v_modelname  varchar2, --模型名称
                             v_userid     varchar2, --创建人
                             v_username   varchar2, --创建名称
                             v_insertdate date, --创建日期
                             v_userflag   varchar2, --使用状态
                             v_remark     varchar2, --备注
                             ret          out varchar2);
  --删除
  procedure pro_dj802_delete(v_modelcode in varchar2, ret out varchar2);
  --点击模型工序
  procedure pro_dj802_gxselect(v_modelcode varchar2,
                               v_cursor    out sys_refcursor);
  --模型工序新增
  procedure pro_dj802_gxinsert(v_etno         varchar2, --工序号
                               v_modelcode    varchar2, --模型编码
                               v_etcontext    varchar2, --工序内容
                               v_planworktime number, --计划工时
                               v_planperson   number, --计划人数
                               v_peretid      varchar2, --前置工序ID
                               ret            out varchar2);
  --模型工序删除
  procedure pro_dj802_gxdelete(v_modeletid varchar2, ret out varchar2);
  --模型物耗维护页面
  procedure pro_dj802_whselect(v_modelcode varchar2,
                               v_cursor    out sys_refcursor);
  --模型物耗 新增
  procedure pro_dj802_whinsert(v_modelcode    varchar2, --模型编码
                               v_MATERIALCODE varchar2, --物料编码
                               v_MATERIALNAME varchar2, --物料名称
                               v_ETALON       varchar2, --规格型号
                               v_MATCL        varchar2, --材质
                               v_UNIT         varchar2, --单位
                               v_F_PRICE      number, --单价
                               v_PLAN_AMOUNT  number, --计划数量
                               ret            out varchar);
  --模型物耗删除
  procedure pro_dj802_whdelete(v_modelmatid varchar2, ret out varchar2);
end PG_DJ802;
/

