create trigger PM_WORKORDER_TOOL_TRI
  before insert
  on PM_WORKORDER_TOOL
  for each row
declare
  -- local variables here
begin
  SELECT PM_WORKORDER_TOOL_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
end PM_WORKORDER_TOOL_TRI;
/

