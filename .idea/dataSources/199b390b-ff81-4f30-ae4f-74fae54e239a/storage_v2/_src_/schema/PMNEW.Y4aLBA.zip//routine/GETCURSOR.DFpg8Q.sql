create PROCEDURE getcursor(v_cur out sys_refcursor)
IS 
BEGIN
  open v_cur for
   select fund_dept_view_role('aqgaoss',
                              '9906',
                               '%') from dual;--打开游标，并写查询语句，用关键字for连接
END;
/

