create FUNCTION FUNC_GETPERSONPOST(V_V_PERSONCODE IN VARCHAR2)
  RETURN VARCHAR2 IS
  V_RESULT VARCHAR2(4000);
BEGIN
  /*返回人员的岗位*/
  FOR C IN (SELECT V_POSTCODE,
                   V_POSTNAME,
                   V_POSTMEMO,
                   '' AS V_DEPTCODE,
                   V_PERSONNAME,
                   V_LOGINNAME,
                   V_PASSWORD,
                   V_DEPTCODEUSER,
                   V_ROLECODE,
                   I_ORDERID,
                   V_POSTCODE_UP,
                   V_CLASSCODE,
                   V_PERSONCODE
              FROM VIEW_BASE_POSTTOPERSON
             WHERE V_PERSONCODE = V_V_PERSONCODE) LOOP
    V_RESULT := NVL(V_RESULT, '') || C.V_POSTNAME || '|';
  END LOOP;
  RETURN(V_RESULT);
END FUNC_GETPERSONPOST;
/

