create procedure AM_TASK_SEND_SET(V_V_TYPE IN VARCHAR2,
                                             V_INFO   OUT VARCHAR2) is

  /*定时发送即时通*/
begin
  IF V_V_TYPE = 'ERROR' THEN
    /*
    除设备部外  每十分钟检索未发送成功的即时通，重新发送
    */
    FOR C IN (SELECT DISTINCT A.V_RECEIVE_PERSON
                FROM AM_SEND_LOG A
               INNER JOIN BASE_PERSON P
                  ON A.V_RECEIVE_PERSON = P.V_PERSONCODE
               WHERE A.I_SEND = '-1'
                 AND A.V_RECEIVE_PERSON IS NOT NULL
                 AND P.V_DEPTCODE NOT LIKE '9900%') LOOP
    
      UPDATE AM_SEND_LOG L
         SET L.I_SEND = '0'
       WHERE L.V_RECEIVE_PERSON = C.V_RECEIVE_PERSON
         AND TO_DATE(TO_CHAR(L.D_SEND_DATE, 'YYYY-MM-DD'), 'YYYY-MM-DD') =
             TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD');
    
    END LOOP;
  ELSE
    /*
    设备部定时发送
    周计划每周四的1点
    月计划 每月22号9点
    年计划 每年的11月1号9点
    */
    FOR C IN (SELECT DISTINCT A.V_RECEIVE_PERSON
                FROM AM_SEND_LOG A
               INNER JOIN BASE_PERSON P
                  ON A.V_RECEIVE_PERSON = P.V_PERSONCODE
               WHERE A.V_TYPE LIKE V_V_TYPE
                 AND A.I_SEND = '-1'
                 AND A.V_RECEIVE_PERSON IS NOT NULL
                 AND P.V_DEPTCODE LIKE '9900%') LOOP
    
      UPDATE AM_SEND_LOG L
         SET L.I_SEND = '0'
       WHERE L.V_RECEIVE_PERSON = C.V_RECEIVE_PERSON
         AND L.V_TYPE LIKE V_V_TYPE;
    
    END LOOP;
  
  END IF;

  V_INFO := 'success';

end AM_TASK_SEND_SET;
/

