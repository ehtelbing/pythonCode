create procedure PM_03_PLAN_PROJECT_FILE_SELB(V_V_GUID     IN VARCHAR2, --关系guid
                                                         V_V_FILEGUID IN VARCHAR2, --附件唯一值
                                                         V_V_BLOB     OUT BLOB,
                                                         V_CURSOR     OUT SYS_REFCURSOR) is

begin

  SELECT F.V_FILE
    INTO V_V_BLOB
    FROM PM_03_PLAN_PROJECT_FILE F
   WHERE F.V_GUID = V_V_GUID
     AND F.V_FILEGUID LIKE V_V_FILEGUID;

  OPEN V_CURSOR FOR
    SELECT F.ID,
           F.V_GUID,
           F.V_FILEGUID,
           F.V_FILENAME,
           F.V_INPERCODE,
           F.V_INPERNAME,
           F.V_TYPE,
           F.V_INTIME,
           F.V_FILETYPE
      FROM PM_03_PLAN_PROJECT_FILE F
     WHERE F.V_GUID = V_V_GUID
       AND F.V_FILEGUID LIKE V_V_FILEGUID;
end PM_03_PLAN_PROJECT_FILE_SELB;
/

