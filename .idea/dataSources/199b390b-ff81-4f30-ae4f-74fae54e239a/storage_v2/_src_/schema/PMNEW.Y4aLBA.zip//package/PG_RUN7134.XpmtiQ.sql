create package pg_run7134 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/11/10 9:13:16
  -- Purpose : no7134重点备件字典设置

  --1.查询，导出：pg_run7134.getbjlist
  procedure getbjlist(a_mat_no   varchar2, --备件编码
                      a_mat_desc varchar2, --备件名称
                      ret        out sys_refcursor);
  --2.新增，打开新增界面。点击选择按钮，打开物料搜索界面进行查询（查询：pg_run7134.getmatlist）。点击选择列，将选中行的信息填入并管理搜索界面。保存（保存：pg_run7134.addbj）后关闭新增界面。
  procedure getmatlist(a_mat_no   VARCHAR2, --备件编码
                       a_mat_desc varchar2, --备件名称
                       ret        out sys_refcursor);
  procedure addbj(a_mat_no   varchar2, --备件编码
                  a_mat_desc varchar2, --备件名称
                  a_etalon   varchar2, --规格型号
                  a_unit     varchar2, --计量单位
                  a_price    number, --计划价
                  ret_msg    out varchar2,
                  ret        out varchar2);
  --3.删除，pg_run7134.deletebj
  procedure deletebj(a_mat_no varchar2, --备件编码
                     ret_msg  out varchar2,
                     ret      out varchar2);
  --4.安装位置-查看（pg_run7134.getsitelist），更新右侧表格
  procedure getsitelist(a_mat_no varchar2, --备件编码
                        ret      out sys_refcursor);
  --保存预期寿命
  procedure saveBjPreTime(v_ip     varchar2,
                          v_userid varchar2,
                          v_mat_no varchar2, --备件代码
                          f_time   number, --预期寿命
                          ret_msg  out varchar2,
                          ret      out varchar2);
end pg_run7134;
/

