create package BODY PG_SY201006 is
  --互感器绝缘试验记录
  --1,查询
  procedure pro_sy201006_onedetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select a.record_id,
             a.SY_LOC_DESC,
             a.sy_loc_code,
             a.sy_equ_id,
             a.sy_equ_name,
             a.sy_date,
             a.sy_weather,
             a.sy_temp,
             a.sy_reason,
             a.sy_verdict,
             b.hgq_type,
             b.hgq_rl,
             b.hgq_xbb,
             b.hgq_kv,
             b.hgq_make,
             b.hgq_datea,
             b.hgq_dateb,
             b.hgq_datec,
             b.hgq_tgtype,
             a.sy_resp_username, --负责人
             a.sy_resp_userid,
             a.sy_exa_userid,
             a.sy_exa_username, --审核人
             a.sy_recordid,
             a.sy_recordname, --记录人
             a.equtype_code,
             a.equtype_name, --设备种类
             a.sy_opuserid,
             a.sy_opusername,
             a.sy_jxuserid,
             a.sy_jxusername,
             a.make_date, --制造日期
             a.outplant_date --出厂日期
        from SY_RECORD_MAIN a
        left outer join SY_RE_HGQ_MAIN b
          on a.record_id = b.record_id
       where a.record_id = recordcode_in;
  end;
  --1,t添加
  procedure pro_sy201006_oneadd(usercode_in     varchar2, --登录人
                                username_in     varchar2, --登录人姓名
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿
                                departcode_in   varchar2, --部门
                                plantname_in    varchar2, --厂矿名称
                                departname_in   varchar2, --部门名称
                                sydate_in           DATE, --实验时间
                                syloccode_in        varchar2, --实验地点编码
                                sylocname_in        varchar2, --实验地点名称
                                syequcode_in        varchar2, --实验设备编码
                                syequname_in        varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN    VARCHAR2,
                                SYEQUTYPTNAME_IN    VARCHAR2,
                                SYWEATHER_in        varchar2, --天气
                                sytemp_in           number, --气温
                                syreason_in         varchar2, --实验原因
                                SYVERDICT_in        varchar2, --结论
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,
                                v_hgqtype        varchar2, --型式
                                v_hgqrl          varchar2, --容量
                                v_hgqxbb         varchar2, --相变化
                                v_hgqkv          number, --额定电压
                                v_hgmake         varchar2, --制造厂
                                v_hgqdatea       date, --制造时间
                                v_hgqdateb       date,
                                v_hgqdatec       date,
                                v_hgqtgtype      varchar2, --套管型式
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2,
                                v_info           out varchar2,
                                v_info1          out varchar2,
                                v_info2          out varchar2) as
    p_recordcode   varchar2(36) := FUNC_NEW_GUID();
    p_itemtypedesc varchar2(100);
    p_itemdesc     varchar2(50);
    p_printurl     varchar2(200);
  begin
    savepoint s;
    select t.itemtype_desc
      into p_itemtypedesc
      from SY_ITEM_TYPE t
     where t.itemtype = itemtypecode_in;
    select d.item_name
      into p_itemdesc
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    select d.item_url
      into p_printurl
      from SY_ITEM_DIC d
     where d.item_code = itemcode_in;
    insert into SY_RECORD_MAIN
      (RECORD_ID,
       RECORD_DATE,
       SY_DATE,
       RECORD_USERID,
       RECORD_USERNAME,
       DEPARTCODE,
       DEPARTNAME,
       PLANTCODE,
       PLANTNAME,
       SY_LOC_CODE,
       SY_LOC_DESC,
       SY_EQU_ID,
       SY_EQU_NAME,
       SY_WEATHER,
       SY_TEMP,
       SY_URL,
       SY_REASON,
       SY_VERDICT,
       SY_RESP_USERID,
       SY_RESP_USERNAME,
       SY_EXA_USERID,
       SY_EXA_USERNAME,
       RECORD_STATUS,
       ITEM_CODE,
       ITEM_NAME,
       ITEMTYPE,
       ITEMTYPE_DESC,
       SUBMIT_DATE,
       SUBMIT_USERID,
       SUBMIT_USERNAME,
       sy_recordid,
       sy_recordname,
       EQUTYPE_CODE,
       EQUTYPE_NAME,
       sy_opuserid,
       sy_opusername,
       sy_jxuserid,
       sy_jxusername,
       make_date,
       outplant_date)
    values
      (p_recordcode,
       sysdate,
       sydate_in,
       usercode_in,
       username_in,
       departcode_in,
       departname_in,
       plantcode_in,
       plantname_in,
       syloccode_in,
       sylocname_in,
       syequcode_in,
       syequname_in,
       SYWEATHER_in,
       sytemp_in,
       p_printurl,
       syreason_in,
       SYVERDICT_in,
       SYRESPUSERNAME_code,
       SYRESPUSERNAME_in,
       SYEXAUSERNAME_code,
       SYEXAUSERNAME_in,
       '未提交',
       itemcode_in,
       p_itemdesc,
       itemtypecode_in,
       p_itemtypedesc,
       null,
       null,
       null,
       SYRECORDID_IN,
       SYRECORDNAME_IN,
       SYEQUTYPTCODE_IN,
       SYEQUTYPTNAME_IN,
       SY_OPUSERID_in,
       SY_OPUSERNAME_in,
       SY_JXUSERID_in,
       SY_JXUSERNAME_in,
       make_date_in,
       outplant_date_in);
    insert into SY_RE_HGQ_MAIN
    values
      (p_recordcode,
       v_hgqtype,
       v_hgqrl,
       v_hgqxbb,
       v_hgqkv,
       v_hgmake,
       v_hgqdatea,
       v_hgqdateb,
       v_hgqdatec,
       v_hgqtgtype);
    commit;
    ret     := p_recordcode;
    v_info  := SYRECORDNAME_IN;
    v_info1 := SY_OPUSERNAME_in;
    v_info2 := SY_JXUSERNAME_in;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --1,更新
  procedure pro_sy201006_oneupdate(recordcode_in       varchar2,
                                   usercode_in         varchar2, --登录人
                                   username_in         varchar2, --登录人姓名
                                   sydate_in           DATE, --实验时间
                                   syloccode_in        varchar2, --实验地点编码
                                   sylocname_in        varchar2, --实验地点名称
                                   syequcode_in        varchar2, --实验设备编码
                                   syequname_in        varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN    VARCHAR2,
                                   SYEQUTYPTNAME_IN    VARCHAR2,
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温 12.3
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,
                                   v_hgqtype        varchar2, --型式
                                   v_hgqrl          varchar2, --容量
                                   v_hgqxbb         varchar2, --相变化
                                   v_hgqkv          number, --额定电压
                                   v_hgmake         varchar2, --制造厂
                                   v_hgqdatea       date, --制造时间
                                   v_hgqdateb       date,
                                   v_hgqdatec       date,
                                   v_hgqtgtype      varchar2, --套管型式
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2) as
  begin
    savepoint s;
    update SY_RECORD_MAIN A
       set RECORD_DATE      = sysdate,
           SY_DATE          = sydate_in,
           RECORD_USERID    = usercode_in,
           RECORD_USERNAME  = username_in,
           SY_LOC_CODE      = syloccode_in,
           SY_LOC_DESC      = sylocname_in,
           SY_EQU_ID        = syequcode_in,
           SY_EQU_NAME      = syequname_in,
           SY_WEATHER       = SYWEATHER_in,
           SY_TEMP          = sytemp_in,
           SY_REASON        = syreason_in,
           SY_VERDICT       = SYVERDICT_in,
           sy_resp_userid   = SYRESPUSERNAME_code,
           SY_RESP_USERNAME = SYRESPUSERNAME_in,
           sy_exa_userid    = SYEXAUSERNAME_code,
           SY_EXA_USERNAME  = SYEXAUSERNAME_in,
           a.sy_recordid    = SYRECORDID_IN,
           a.sy_recordname  = SYRECORDNAME_IN,
           a.equtype_code   = SYEQUTYPTCODE_IN,
           a.equtype_name   = SYEQUTYPTNAME_IN,
           a.sy_opuserid    = SY_OPUSERID_in,
           a.sy_opusername  = SY_OPUSERNAME_in,
           a.sy_jxuserid    = SY_JXUSERID_in,
           a.sy_jxusername  = SY_JXUSERNAME_in,
           a.make_date      = make_date_in,
           a.outplant_date  = outplant_date_in
     where RECORD_ID = recordcode_in;
    update SY_RE_HGQ_MAIN a
       set a.hgq_type   = v_hgqtype,
           a.hgq_rl     = v_hgqrl,
           a.hgq_xbb    = v_hgqxbb,
           a.hgq_kv     = v_hgqkv,
           a.hgq_make   = v_hgmake,
           a.hgq_datea  = v_hgqdatea,
           a.hgq_dateb  = v_hgqdateb,
           a.hgq_datec  = v_hgqdatec,
           a.hgq_tgtype = v_hgqtgtype
     where a.record_id = recordcode_in;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2,介质损失角试验数据
  --2，查询
  procedure pro_sy201006_twodetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select * from SY_RE_HGQ_JZ_MAIN a where a.record_id = recordcode_in;
  end;
  --2,添加
  procedure pro_sy201006_twoadd(recordcode_in varchar2,
                                v_YQXS        VARCHAR2, --仪器型式
                                v_YQBM        VARCHAR2, --仪器编码
                                v_aid         varchar2,
                                v_an          number,
                                v_ap          number,
                                v_ar          number,
                                v_asc         number,
                                v_a20         varchar2,
                                v_bid         varchar2,
                                v_bn          number,
                                v_bp          number,
                                v_br          number,
                                v_bsc         number,
                                v_b20         varchar2,
                                v_cid         varchar2,
                                v_cn          number,
                                v_cp          number,
                                v_cr          number,
                                v_csc         number,
                                v_c20         varchar2,
                                --v_opuser      varchar2,
                                --v_recorduser  varchar2,
                                --v_jxuser varchar2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_HGQ_JZ_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_YQXS,
       v_YQBM,
       v_aid,
       v_an,
       v_ap,
       v_ar,
       v_asc,
       v_a20,
       v_bid,
       v_bn,
       v_bp,
       v_br,
       v_bsc,
       v_b20,
       v_cid,
       v_cn,
       v_cp,
       v_cr,
       v_csc,
       v_c20,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --2,更新
  procedure pro_sy201006_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2,
                                   v_YQXS        VARCHAR2, --仪器型式
                                   v_YQBM        VARCHAR2, --仪器编码
                                   v_aid         varchar2,
                                   v_an          number,
                                   v_ap          number,
                                   v_ar          number,
                                   v_asc         number,
                                   v_a20         varchar2,
                                   v_bid         varchar2,
                                   v_bn          number,
                                   v_bp          number,
                                   v_br          number,
                                   v_bsc         number,
                                   v_b20         varchar2,
                                   v_cid         varchar2,
                                   v_cn          number,
                                   v_cp          number,
                                   v_cr          number,
                                   v_csc         number,
                                   v_c20         varchar2,
                                   --v_opuser      varchar2,
                                   -- v_recorduser  varchar2,
                                   --v_jxuser varchar2,
                                   ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_HGQ_JZ_MAIN a
       set a.record_id = recordcode_in,
           a.yqxs      = v_yqxs,
           a.yqbh      = v_YQBM,
           a.a_id      = v_aid,
           a.a_n       = v_an,
           a.a_p       = v_ap,
           a.a_r       = v_ar,
           a.a_sc      = v_asc,
           a.a_20      = v_a20,
           a.b_id      = v_bid,
           a.b_n       = v_bn,
           a.b_p       = v_bp,
           a.b_r       = v_br,
           a.b_sc      = v_bsc,
           a.b_20      = v_b20,
           a.c_id      = v_cid,
           a.c_n       = v_cn,
           a.c_p       = v_cp,
           a.c_r       = v_cr,
           a.c_sc      = v_csc,
           a.c_20      = v_c20
    -- a.op_user   = v_opuser,
    --a.record_user = v_recorduser,
    --a.jx_user = v_jxuser
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3,查询
  procedure pro_sy201006_threedetail(recordcode_in varchar2,
                                     v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from SY_RE_HGQ_JYDZ_MAIN a
       where a.record_id = recordcode_in;
  end;
  --3,t添加
  procedure pro_sy201006_threeadd(recordcode_in varchar2,
                                  v_YQXS        VARCHAR2, --仪器型式
                                  v_YQBM        VARCHAR2, --仪器编码
                                  v_a1          number,
                                  v_b1          number,
                                  v_c1          number,
                                  --v_opuser      varchar2,
                                  -- v_recorduser  varchar2,
                                  --v_jxuser varchar2,
                                  ret     out varchar2,
                                  v_info  out varchar2,
                                  v_info1 out varchar2,
                                  v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_HGQ_JYDZ_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_YQXS,
       v_YQBM,
       v_a1,
       v_b1,
       v_c1,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --3,更新
  procedure pro_sy201006_threeupdate(v_id          varchar2,
                                     recordcode_in varchar2,
                                     v_YQXS        VARCHAR2, --仪器型式
                                     v_YQBM        VARCHAR2, --仪器编码
                                     v_a1          number,
                                     v_b1          number,
                                     v_c1          number,
                                     --v_opuser      varchar2,
                                     --v_recorduser  varchar2,
                                     -- v_jxuser varchar2,
                                     ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_HGQ_JYDZ_MAIN a
       set a.record_id = recordcode_in,
           a.yqxs      = v_yqxs,
           a.yqbh      = v_yqbm,
           a.a_1       = v_a1,
           a.b_1       = v_b1,
           a.c_1       = v_c1
    -- a.op_user   = v_opuser,
    -- a.record_user = v_recorduser,
    --a.jx_user = v_jxuser
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := sqlerrm;
  end;
  --4,查询
  procedure pro_sy201006_fourdetail(recordcode_in varchar2,
                                    v_cursor      out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from SY_RE_HGQ_JLNY_MAIN a
       where a.record_id = recordcode_in;
  end;
  --4,添加
  procedure pro_sy201006_fouradd(recordcode_in varchar2,
                                 v_YQXS        VARCHAR2, --仪器型式
                                 v_YQBM        VARCHAR2, --仪器编码
                                 v_akv         number,
                                 v_as          number,
                                 v_ama         number,
                                 v_ajg         varchar2,
                                 v_bkv         number,
                                 v_bs          number,
                                 v_bma         number,
                                 v_bjg         varchar2,
                                 v_ckv         number,
                                 v_cs          number,
                                 v_cma         number,
                                 v_cjg         varchar2,
                                 -- v_opuser      varchar2,
                                 --v_recorduser  varchar2,
                                 --v_jxuser varchar2,
                                 ret     out varchar2,
                                 v_info  out varchar2,
                                 v_info1 out varchar2,
                                 v_info2 out varchar2) as
    t_sy_recordname varchar2(50);
    t_sy_opusername varchar2(50);
    t_sy_jxusername varchar2(50);
  begin
    savepoint s;
    select a.sy_recordname, a.sy_opusername, a.sy_jxusername
      into t_sy_recordname, t_sy_opusername, t_sy_jxusername
      from SY_RECORD_MAIN a
     where a.record_id = recordcode_in;
    insert into SY_RE_HGQ_JLNY_MAIN
    values
      (func_new_guid(),
       recordcode_in,
       v_YQXS,
       v_YQBM,
       v_akv,
       v_as,
       v_ama,
       v_ajg,
       v_bkv,
       v_bs,
       v_bma,
       v_bjg,
       v_ckv,
       v_cs,
       v_cma,
       v_cjg,
       t_sy_opusername,
       t_sy_recordname,
       t_sy_jxusername);
    commit;
    ret     := 'Success';
    v_info  := t_sy_recordname;
    v_info1 := t_sy_opusername;
    v_info2 := t_sy_jxusername;
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
  --4,更新
  procedure pro_sy201006_fourupdate(v_id          varchar2,
                                    recordcode_in varchar2,
                                    v_YQXS        VARCHAR2, --仪器型式
                                    v_YQBM        VARCHAR2, --仪器编码
                                    v_akv         number,
                                    v_as          number,
                                    v_ama         number,
                                    v_ajg         varchar2,
                                    v_bkv         number,
                                    v_bs          number,
                                    v_bma         number,
                                    v_bjg         varchar2,
                                    v_ckv         number,
                                    v_cs          number,
                                    v_cma         number,
                                    v_cjg         varchar2,
                                    --v_opuser      varchar2,
                                    -- v_recorduser  varchar2,
                                    -- v_jxuser varchar2,
                                    ret out varchar2) as
  begin
    savepoint s;
    update SY_RE_HGQ_JLNY_MAIN a
       set a.record_id = recordcode_in,
           a.yqxs      = v_yqxs,
           a.yqbh      = v_YQBM,
           a.a_kv      = v_akv,
           a.a_s       = v_as,
           a.a_ma      = v_ama,
           a.a_jg      = v_ajg,
           a.b_kv      = v_bkv,
           a.b_s       = v_bs,
           a.b_ma      = v_bma,
           a.b_jg      = v_bjg,
           a.c_kv      = v_ckv,
           a.c_s       = v_cs,
           a.c_ma      = v_cma,
           a.c_jg      = v_cjg
    --a.op_user   = v_opuser,
    --  a.record_user = v_recorduser,
    --   a.jx_user = v_jxuser
     where a.id = v_id;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Failure';
  end;
end PG_SY201006;
/

