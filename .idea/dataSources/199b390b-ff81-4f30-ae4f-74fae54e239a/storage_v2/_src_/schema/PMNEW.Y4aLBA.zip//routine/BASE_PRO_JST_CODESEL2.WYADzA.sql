create procedure BASE_PRO_JST_CODESEL2(V_V_PERCODE IN VARCHAR2,
                                                  V_INFO      OUT SYS_REFCURSOR) is

  /*
  根据人员编码查询即时通账号
  */
begin

  OPEN V_INFO FOR
    SELECT P.V_PASSWORD, P.V_JST --即时通账号
      FROM BASE_PERSON P
     WHERE P.V_PERSONCODE = V_V_PERCODE;
     EXCEPTION
       WHEN OTHERS THEN
         NULL;
end BASE_PRO_JST_CODESEL2;
/

