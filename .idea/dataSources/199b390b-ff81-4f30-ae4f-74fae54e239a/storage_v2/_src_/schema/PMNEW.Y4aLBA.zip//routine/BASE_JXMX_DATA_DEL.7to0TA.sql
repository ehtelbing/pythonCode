create PROCEDURE BASE_JXMX_DATA_DEL(V_V_JXMX_CODE IN VARCHAR2,
                                               V_INFO        OUT VARCHAR2) IS
  /*删除检修模型管理*/
 cursor c_test is select a.v_jxgx_code from pm_1917_jxgx_data a where a.v_jxmx_code = V_V_JXMX_CODE;
 c_t c_test%rowtype;
 ret varchar2(500);
BEGIN
for c_t in c_test loop
        ret := FUNC_JXGX_DATA_DEL(c_t.v_jxgx_code);
      end loop;
  DELETE FROM PM_1917_JXMX_DATA B WHERE B.V_MX_CODE = V_V_JXMX_CODE;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
END BASE_JXMX_DATA_DEL;
/

