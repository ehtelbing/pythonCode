create PROCEDURE BASE_FILE_IMAGE_DOWNLOAD(V_V_GUID IN VARCHAR2, --附件guid
                                                     V_NAME   OUT VARCHAR2,
                                                     V_FILE   OUT BLOB) is

  /*下载基础信息设置附件*/
BEGIN
  SELECT B.V_FILENAME
    INTO V_NAME
    FROM BASE_FILE B
   WHERE B.V_FILEGUID = V_V_GUID;

  SELECT B.V_FILEBLOB
    INTO V_FILE
    FROM BASE_FILE B
   WHERE B.V_FILEGUID = V_V_GUID;

END BASE_FILE_IMAGE_DOWNLOAD;
/

