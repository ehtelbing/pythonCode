create PROCEDURE DEFECT_UPFILE_INSERT(V_GUID       IN VARCHAR2, --缺陷编码
                                                 V_FILENAME   IN VARCHAR2, --文件名称
                                                 V_BLOB       BLOB, --文件流
                                                 V_TYPE       IN VARCHAR2, --文件类型
                                                 V_PLANT      IN VARCHAR2, --厂矿
                                                 V_DEPT       IN VARCHAR2, --部门
                                                 V_PERSONCODE IN VARCHAR2, --人编码
                                                 RET          OUT VARCHAR2) IS
BEGIN
    INSERT INTO DEFECT_UPFILE
      (DEFECT_CODE,
       FILE_CODE,
       FILE_NAME,
       FILE_BLOB,
       FILE_TYPE,
       INSERT_PLANT,
       INSERT_DEPT,
       INSERT_DATE,
       INSERT_PERSON)
    VALUES
      (V_GUID,
       SYS_GUID(),
       V_FILENAME,
       V_BLOB,
       V_TYPE,
       V_PLANT,
       V_DEPT,
       SYSDATE,
       V_PERSONCODE);
    COMMIT;
    RET      := 'Success';
EXCEPTION
  WHEN OTHERS THEN
    RET := 'Fail';

END DEFECT_UPFILE_INSERT;
/

