create function update_sys_porperty(V_V_PORP_NAME     in varchar2,
                                               V_V_PORP_VALUE in varchar2,
                                               V_V_PLANT   in varchar2) return varchar2 is
    p_ret varchar2(10) := 'Fail';
    --  p_count number(2, 0) := 0;
  begin
    begin
      UPDATE PM_SYS_PORPERTY B
      SET B.INSERTDATE = sysdate,
      B.PORP_VALUE = V_V_PORP_VALUE
      WHERE B.PORP_NAME = V_V_PORP_NAME
      and b.plant = V_V_PLANT;
      commit;
      p_ret := 'Success';
    end;
    return p_ret;
  end;
/

