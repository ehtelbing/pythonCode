create PROCEDURE BASE_GX_GZ_UPD(V_V_JXGX_CODE  IN VARCHAR2,
                                           V_V_PERCODE_DE IN VARCHAR2,
                                           V_V_TS         IN VARCHAR2,
                                           V_V_DE         IN VARCHAR2,
                                           V_V_PERNUM     IN VARCHAR2,
                                           V_INFO         OUT VARCHAR2) IS
  /*修改检修工序的工种*/
BEGIN
  UPDATE PM_1917_JXGX_PER_DATA B
     SET B.V_TS = V_V_TS, B.V_DE = V_V_DE,B.V_PERNUM=V_V_PERNUM
   WHERE B.V_JXGX_CODE = V_V_JXGX_CODE
     AND B.V_PERCODE_DE = V_V_PERCODE_DE;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
END BASE_GX_GZ_UPD;
/

