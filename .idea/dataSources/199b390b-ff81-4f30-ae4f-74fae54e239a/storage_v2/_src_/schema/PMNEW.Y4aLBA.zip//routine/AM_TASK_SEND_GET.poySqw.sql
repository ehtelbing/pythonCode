create procedure AM_TASK_SEND_GET(V_V_TYPE IN VARCHAR2,
                                             V_CURSOR OUT SYS_REFCURSOR) is

  /*定时发送即时通*/
begin
  IF V_V_TYPE = 'ERROR' THEN
    /*
    除设备部外  每十分钟检索未发送成功的即时通，重新发送
    */
    FOR C IN (SELECT DISTINCT A.V_RECEIVE_PERSON
                FROM AM_SEND_LOG A
               INNER JOIN BASE_PERSON P
                  ON A.V_RECEIVE_PERSON = P.V_PERSONCODE
               WHERE A.I_SEND = '-1'
                 AND A.V_RECEIVE_PERSON IS NOT NULL
                 AND P.V_DEPTCODE NOT LIKE '9900%') LOOP
    
      INSERT INTO TEMP_TABLE
        (V_1, V_2, V_3, V_4, V_5, V_6, V_7)
        SELECT COUNT(A.I_ID) AS NUM,
               A.V_SERVERNAME,
               A.V_SENDPASSWORD,
               A.V_SEND_PERSON,
               P.V_LOGINNAME,
               P.V_JST,
               A.V_TYPE
          FROM AM_SEND_LOG A
         INNER JOIN BASE_PERSON P
            ON A.V_RECEIVE_PERSON = P.V_PERSONCODE
         WHERE A.V_RECEIVE_PERSON = C.V_RECEIVE_PERSON
           AND A.I_SEND = '-1'
           AND P.V_JST IS NOT NULL
           AND TO_DATE(TO_CHAR(A.D_SEND_DATE, 'YYYY-MM-DD'), 'YYYY-MM-DD') =
               TO_DATE(TO_CHAR(SYSDATE, 'YYYY-MM-DD'), 'YYYY-MM-DD')
         GROUP BY A.V_SERVERNAME,
                  A.V_SENDPASSWORD,
                  A.V_SEND_PERSON,
                  P.V_LOGINNAME,
                  P.V_JST,
                  A.V_TYPE;
    
    END LOOP;
  ELSE
    /*
    设备部定时发送
    周计划每周四的1点
    月计划 每月22号9点
    年计划 每年的11月1号9点
    */
    FOR C IN (SELECT DISTINCT A.V_RECEIVE_PERSON
                FROM AM_SEND_LOG A
               INNER JOIN BASE_PERSON P
                  ON A.V_RECEIVE_PERSON = P.V_PERSONCODE
               WHERE A.V_TYPE LIKE V_V_TYPE
                 AND A.I_SEND = '-1'
                 AND A.V_RECEIVE_PERSON IS NOT NULL
                 AND P.V_DEPTCODE LIKE '9900%') LOOP
    
      INSERT INTO TEMP_TABLE
        (V_1, V_2, V_3, V_4, V_5, V_6, V_7)
        SELECT COUNT(A.I_ID) AS NUM,
               A.V_SERVERNAME,
               A.V_SENDPASSWORD,
               A.V_SEND_PERSON,
               P.V_LOGINNAME,
               P.V_JST,
               A.V_TYPE
          FROM AM_SEND_LOG A
         INNER JOIN BASE_PERSON P
            ON A.V_RECEIVE_PERSON = P.V_PERSONCODE
         WHERE A.V_RECEIVE_PERSON = C.V_RECEIVE_PERSON
           AND A.V_TYPE LIKE V_V_TYPE
           AND A.I_SEND = '-1'
           AND P.V_JST IS NOT NULL
         GROUP BY A.V_SERVERNAME,
                  A.V_SENDPASSWORD,
                  A.V_SEND_PERSON,
                  P.V_LOGINNAME,
                  P.V_JST,
                  A.V_TYPE;
    
    END LOOP;
  
  END IF;

  OPEN V_CURSOR FOR
    SELECT V_1 AS NUM,
           V_2 AS V_SERVERNAME,
           V_3 AS V_SENDPASSWORD,
           V_4 AS V_SEND_PERSON,
           V_5 AS V_LOGINNAME,
           V_6 AS V_JST,
           V_7 AS V_TYPE
      FROM TEMP_TABLE;

end AM_TASK_SEND_GET;
/

