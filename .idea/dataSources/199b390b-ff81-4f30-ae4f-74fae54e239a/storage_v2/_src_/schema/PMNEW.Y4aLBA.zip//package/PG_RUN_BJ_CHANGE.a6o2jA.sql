create PACKAGE PG_RUN_BJ_CHANGE
/*
说明：备件更换
*/
 IS
  --查询当前备件使用台账
  FUNCTION GET_BJ_USE_LIST(A_PLANTCODE      VARCHAR2 --厂矿编码
                          ,
                           A_DEPARTCODE     VARCHAR2 --作业区编码
                          ,
                           A_EQUID          VARCHAR2 --设备ID
                          ,
                           A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                          ,
                           A_BEGINDATE      DATE --起始日期
                          ,
                           A_ENDDATE        DATE --结束日期
                          ,
                           RET              OUT SYS_REFCURSOR)
    RETURN VARCHAR2;
  --查询备件更换历史记录
  FUNCTION GET_BJ_CHANGE_LOG(A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                            ,
                             RET              OUT SYS_REFCURSOR)
    RETURN VARCHAR2;
  --查询当前设备位置备件情况
  FUNCTION GET_SITE_BJ_ALL(A_EQUID        VARCHAR2 --设备ID
                          ,
                           A_PLANTCODE    VARCHAR2,
                           A_DEPARTCODE   VARCHAR2,
                           A_STATUS       VARCHAR2,
                           A_MATERIALCODE VARCHAR2,
                           A_MATERIALNAME VARCHAR2,
                           RET            OUT SYS_REFCURSOR) RETURN VARCHAR2;
  FUNCTION GET_SITE_BJ_ALL_SITE(A_EQUID VARCHAR2, --设备ID
                                A_SITE  VARCHAR2,
                                RET     OUT SYS_REFCURSOR) RETURN VARCHAR2;
  --更换备件
  FUNCTION CHANGE_BJ(A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                    ,
                     a_bj_amount      number,

                     A_BJ_ID        VARCHAR2 --备件ID
                    ,
                     A_MATERIALCODE VARCHAR2 --物资编码
                    ,
                     A_SITE_ID      VARCHAR2 --更换位置Id
                    ,
                     A_EQUID        VARCHAR2 --更换设备ID
                    ,
                     A_PERSON       VARCHAR2 --更换人名
                    ,
                     A_ORDERID      VARCHAR2 --工单
                    ,
                     A_REMARK       VARCHAR2 --备注
                    ,
                     A_CHANGEDATE   DATE --更换日期
                    ,
                     A_PLANTCODE    VARCHAR2 --厂矿编码
                    ,
                     A_DEPARTCODE   VARCHAR2 --作业区编码

                    ,
                     A_SUPPLY_CODE   VARCHAR2 --供应商编码
                    ,
                     A_SUPPLY_NAME   VARCHAR2 --供应商名
                    ,
                     A_FAULTREASON   VARCHAR2,
                     A_REASON_REMARK VARCHAR2,
                     RET_BJ          OUT VARCHAR2 --换下备件唯一编码
                    ,
                     RET_MSG         OUT VARCHAR2) RETURN VARCHAR2;
  --查询当前备件的周期设置
  FUNCTION GET_BJ_CURRENT_SET(A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                             ,
                              RET              OUT SYS_REFCURSOR)
    RETURN VARCHAR2;
  --更新当前备件的周期设置
  FUNCTION SET_BJ_CURRENT_ALERT(A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                               ,
                                A_CYCLE_ID       VARCHAR2 --周期类型ID
                               ,
                                A_ALERT_VALUE    NUMBER --报警值
                               ,
                                A_OFFSET         NUMBER --预警偏移量
                               ,
                                RET_MSG          OUT VARCHAR2)
    RETURN VARCHAR2;
END PG_RUN_BJ_CHANGE;
/

