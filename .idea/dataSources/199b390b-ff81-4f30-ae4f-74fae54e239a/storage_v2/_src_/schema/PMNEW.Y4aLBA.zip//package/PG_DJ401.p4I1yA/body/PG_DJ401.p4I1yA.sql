create package BODY pg_dj401 is
  --工单申请编号生成
  procedure getapplyorderid(a_plantcode varchar2, --厂矿编码
                            ret         out varchar2) is
    p_max dj_os_orderapply.orderid%type;
    p_yymmdd varchar2(6) := to_char(sysdate,'YYMMDD');
  begin
    select max(orderid)
      into p_max
      from dj_os_orderapply
     where orderid like a_plantcode ||p_yymmdd||'%';
    if p_max is null then
      ret := a_plantcode ||p_yymmdd|| '001';
    else
      ret := to_char(to_number(p_max) + 1);
    end if;
  exception
    when others then
      ret := a_plantcode ||p_yymmdd|| '001';
  end;
end pg_dj401;
/

