create PROCEDURE PM_03_PLAN_M_CREATE_WORKORDER(V_V_GUID       IN VARCHAR2, --月计划编码，可多个周计划生成一个工单用逗号分隔
                                                          V_V_PERCODE    IN VARCHAR2,
                                                          V_INFO         OUT VARCHAR2,
                                                          V_V_ORDERGUID  OUT VARCHAR2,
                                                          V_V_SOURCECODE OUT VARCHAR2,
                                                          V_V_EQUTYPE    OUT VARCHAR2,
                                                          V_CURSOR       OUT SYS_REFCURSOR) IS
  /*月计划生成工单*/
  P_SPLIT_TABLE TYPE_SPLIT := NEW TYPE_SPLIT();
  V_RET         VARCHAR2(50);
  I_NUMBER      NUMBER;

  V_V_ORGCODE          VARCHAR2(50); --厂矿
  V_V_DEPTCODE         VARCHAR2(50); --作业区
  V_V_REPAIRCODE       VARCHAR2(50); --检修作业区
  V_V_EQUCODE          VARCHAR2(50); --设备编码
  V_V_EQUSITE          VARCHAR2(50); --设备位置
  V_V_REPAIRMAJOR_CODE VARCHAR2(50); --专业
  V_V_PERNAME          VARCHAR2(50);

  V_V_ORDER_TYPE    VARCHAR2(50);
  V_V_ORDER_TYP_TXT VARCHAR2(50);
  V_V_CONTENT       VARCHAR2(4000);

  V_V_ORDERID     VARCHAR2(50); --工单号
  V_D_ENTER_DATE  DATE; --输入时间
  V_V_WORK_AREA   VARCHAR2(50); --SAP作业区
  V_V_PLANNER     VARCHAR2(50); --SAP作业区计划组员
  V_V_DEFECT_GUID VARCHAR2(50); --缺陷GUID

  V_V_GSBER        VARCHAR2(50);
  V_V_GSBER_TXT    VARCHAR2(50);
  V_V_PLANT        VARCHAR2(50);
  V_V_IWERK        VARCHAR2(50);
  V_V_PLAN_CONTENT VARCHAR2(4000);

  V_V_FUNC_LOC   VARCHAR2(50); --功能位置
  V_V_EQUIP_NO   VARCHAR2(50); --设备编号
  V_V_EQUIP_NAME VARCHAR2(50); --设备名称

  V_V_GUID_DEFECT VARCHAR2(50); --缺陷GUID 用于添加周计划缺陷GUID字段用

  V_V_D_ORDERGUID VARCHAR2(50);
  V_V_D_DEFECT    VARCHAR2(50);

BEGIN
  BEGIN
    V_V_SOURCECODE  := 'defct13';
    V_V_ORDER_TYPE  := 'AK05';
    V_V_GUID_DEFECT := CREATEGUID();
    --获取多个周计划检修内容，用逗号分隔
    V_RET := FUNC_SPLIT(V_V_GUID, ',', P_SPLIT_TABLE);

    FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP

      DELETE FROM PM_WORKORDER W
       WHERE W.V_ORDERGUID =
             (SELECT D.V_WORKORDER_GUID
                FROM PM_DEFECTTOWORKORDER D
               WHERE D.V_WORKORDER_GUID = C.COLUMN_VALUE);

      DELETE FROM PM_WORKORDER_OTHER W
       WHERE W.V_ORDERGUID =
             (SELECT D.V_WORKORDER_GUID
                FROM PM_DEFECTTOWORKORDER D
               WHERE D.V_WORKORDER_GUID = C.COLUMN_VALUE);
      DELETE FROM PM_DEFECTTOWORKORDER D
       WHERE D.V_WEEK_GUID = C.COLUMN_VALUE;
    END LOOP;

    FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP
      IF V_V_CONTENT IS NULL OR V_V_CONTENT = '' THEN
        SELECT W.V_EQUCODE,
               W.V_ORGCODE,
               W.V_DEPTCODE,
               '',
               W.V_EQUTYPECODE,
               W.V_REPAIRMAJOR_CODE,
               W.V_CONTENT,
               W.V_EQUCODE
          INTO V_V_EQUCODE,
               V_V_ORGCODE,
               V_V_DEPTCODE,
               V_V_ORDERGUID,
               V_V_EQUTYPE,
               V_V_REPAIRMAJOR_CODE,
               V_V_PLAN_CONTENT,
               V_V_EQUIP_NO
          FROM PM_03_PLAN_MONTH W
         WHERE W.V_GUID = C.COLUMN_VALUE;
        V_V_CONTENT := V_V_PLAN_CONTENT;
      ELSE
        SELECT W.V_CONTENT
          INTO V_V_PLAN_CONTENT
          FROM PM_03_PLAN_MONTH W
         WHERE W.V_GUID = C.COLUMN_VALUE;
        V_V_CONTENT := V_V_CONTENT || ',' || V_V_PLAN_CONTENT;
      END IF;
    END LOOP;

    IF V_V_ORDERGUID IS NULL THEN
      V_V_ORDERGUID := CREATEGUID(); --工单GUID
    END IF;

    --查询设备名称以及功能位置
    SELECT P.V_EQUNAME, P.V_EQUSITE
      INTO V_V_EQUIP_NAME, V_V_FUNC_LOC
      FROM SAP_PM_EQU_P P
     WHERE P.V_EQUCODE = V_V_EQUIP_NO;

    V_V_ORDERID    := FUNC_GETWORKORDERORDERID(V_V_ORGCODE); --工单号
    V_D_ENTER_DATE := TO_DATE(TO_CHAR(SYSDATE, 'yyyy/mm/dd hh24:mi:ss'),
                              'yyyy/mm/dd hh24:mi:ss'); --输入时间

    --SAP作业区
    SELECT V_SAP_DEPT
      INTO V_V_WORK_AREA
      FROM BASE_DEPT
     WHERE V_DEPTCODE = V_V_DEPTCODE;

    --SAP作业区计划组员
    SELECT V_SAP_PER
      INTO V_V_PLANNER
      FROM SAP_PM_DEPT
     WHERE V_SAP_DEPT = V_V_WORK_AREA;

    --获取设备位置
    SELECT P.V_EQUSITE
      INTO V_V_EQUSITE
      FROM SAP_PM_EQU_P P
     WHERE P.V_EQUCODE = V_V_EQUCODE;

    --获取录入人
    SELECT B.V_PERSONNAME
      INTO V_V_PERNAME
      FROM BASE_PERSON B
     WHERE B.V_PERSONCODE = V_V_PERCODE;

    BEGIN
      SELECT BASE_DEPT.V_SAP_YWFW,
             SAP_PM_YWFW.V_YWFWNAMELONG,
             V_SAP_JHGC,
             V_SAP_JHGC
        INTO V_V_GSBER, V_V_GSBER_TXT, V_V_PLANT, V_V_IWERK
        FROM BASE_DEPT, SAP_PM_YWFW
       WHERE SAP_PM_YWFW.V_YWFW = BASE_DEPT.V_SAP_YWFW
         AND (BASE_DEPT.V_DEPTCODE = SUBSTR(V_V_DEPTCODE, 0, 4));
    EXCEPTION
      WHEN NO_DATA_FOUND THEN
        V_INFO := '错误没有对应的业务范围';
        RETURN;
    END;

    SELECT P.ORDER_TYP_TXT
      INTO V_V_ORDER_TYP_TXT
      FROM PM_WORKORDER_TYP P
     WHERE P.ORDER_TYP = V_V_ORDER_TYPE;

    FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP

      V_V_DEFECT_GUID := V_V_GUID_DEFECT; --缺陷GUID


      SELECT COUNT(*)
        INTO I_NUMBER
        FROM PM_DEFECT P
       WHERE P.V_GUID = V_V_DEFECT_GUID;
      IF I_NUMBER <> 0 THEN
        UPDATE PM_DEFECT P
           SET P.V_SOURCECODE = V_V_SOURCECODE
         WHERE P.V_GUID = V_V_DEFECT_GUID;
      END IF;

    END LOOP;

    --写入工单主表信息
    INSERT INTO PM_WORKORDER
      (V_ORDERGUID,
       V_ORDERID,
       V_ORDER_TYP,
       V_ORDER_TYP_TXT,
       V_PLANNER, --计划组员
       V_GSBER,
       V_GSBER_TXT,
       V_WORK_AREA, --作业区
       V_ENTERED_BY,
       D_ENTER_DATE, --创建时间
       V_PLANT,
       V_IWERK,
       V_DEPTCODE,
       V_STATECODE,
       V_FUNC_LOC,
       V_EQUIP_NO,
       V_EQUIP_NAME,
       V_SHORT_TXT)
    VALUES
      (V_V_ORDERGUID,
       V_V_ORDERID,
       V_V_ORDER_TYPE,
       V_V_ORDER_TYP_TXT,
       V_V_PLANNER,
       V_V_GSBER,
       V_V_GSBER_TXT,
       V_V_WORK_AREA,
       V_V_PERCODE,
       V_D_ENTER_DATE,
       V_V_PLANT,
       V_V_IWERK,
       V_V_DEPTCODE,
       '99',
       V_V_FUNC_LOC,
       V_V_EQUIP_NO,
       V_V_EQUIP_NAME,
       V_V_CONTENT);
    --写入工单_其它信息表
    INSERT INTO PM_WORKORDER_OTHER
      (V_ORDERGUID, V_STATECODE, V_DEPTCODE)
    VALUES
      (V_V_ORDERGUID, '99', V_V_DEPTCODE);
    COMMIT;

    OPEN V_CURSOR FOR
      SELECT I_ID,
             V_ORDERGUID,
             V_ORDERID,
             V_ORDER_TYP,
             V_ORDER_TYP_TXT,
             V_FUNC_LOC,
             V_EQUIP_NO,
             V_EQUIP_NAME,
             V_PLANT,
             V_IWERK,
             D_START_DATE,
             D_FINISH_DATE,
             V_ACT_TYPE,
             V_PLANNER,
             V_WORK_CTR,
             V_SHORT_TXT,
             V_GSBER,
             V_GSBER_TXT,
             V_WORK_AREA,
             V_WBS,
             V_WBS_TXT,
             V_ENTERED_BY,
             D_ENTER_DATE,
             V_SYSTEM_STATUS,
             V_SYSNAME,
             V_ORGCODE,
             V_ORGNAME,
             V_DEPTCODE,
             V_DEPTNAME,
             V_DEPTCODEREPARIR,
             V_DEPTNAMEREPARIR,
             V_DEFECTGUID,
             V_STATECODE,
             V_STATENAME,
             V_TOOL,
             V_TECHNOLOGY,
             V_SAFE,
             D_DATE_ACP, --验收日期
             I_OTHERHOUR, --提前/逾期时间
             V_OTHERREASON, --逾期原因
             V_REPAIRCONTENT, --检修方说明
             V_REPAIRSIGN, --检修方签字
             V_REPAIRPERSON, --检修人员
             V_POSTMANSIGN, --岗位签字
             V_CHECKMANCONTENT, --点检员验收意见
             V_CHECKMANSIGN, --点检员签字
             V_WORKSHOPCONTENT, --作业区验收
             V_WORKSHOPSIGN, --作业区签字
             V_DEPTSIGN --部门签字
        FROM VIEW_PM_WORKORDER
       WHERE V_ORDERGUID = V_V_ORDERGUID;

    V_INFO := 'SUCCESS';
  END;
END PM_03_PLAN_M_CREATE_WORKORDER;
/

