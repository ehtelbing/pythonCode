create FUNCTION FUNC_GETWORKCOUNT_SPARE(V_V_ORDERGUID    IN VARCHAR2,
                                                   V_V_MATERIALCODE IN VARCHAR2)
  RETURN NUMBER IS
  V_RESULT NUMBER;
BEGIN
  /*返回本作业区物料使用相关工单数量*/
  SELECT COUNT(*)
    INTO V_RESULT
    FROM (SELECT C.V_ORDERGUID
            FROM PM_WORKORDER_SPARE C
           WHERE V_MATERIALCODE = V_V_MATERIALCODE
             AND V_ORDERGUID IN
                 (SELECT V_ORDERGUID
                    FROM PM_WORKORDER W
                   WHERE W.V_STATECODE  IN (1, 2, 3, 99)
                        --AND V_ORDERGUID <> V_V_ORDERGUID
                     AND V_DEPTCODE IN
                         (SELECT V_DEPTCODE
                            FROM PM_WORKORDER
                           WHERE V_ORDERGUID = V_V_ORDERGUID))
           GROUP BY V_ORDERGUID);
  RETURN(V_RESULT);
END FUNC_GETWORKCOUNT_SPARE;
/

