create PROCEDURE BASE_GJ_BYJXBZ_SEL(V_V_JXBZ_GUID IN VARCHAR2, --检修技术标准guid
                                               V_CURSOR      OUT SYS_REFCURSOR) IS
  /*传入检修技术标准guid查询工具*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT *
      FROM BASE_WORK_TOOL
     WHERE V_TOOLCODE IN
           (SELECT V_GJ_CODE
              FROM PM_1917_JXGX_GJ_DATA P
             WHERE P.V_JXGX_CODE IN
                   (SELECT V_GUID
                      FROM PM_WORKORDER_ET_OPERATIONS
                     WHERE V_JXBZ = V_V_JXBZ_GUID));
END BASE_GJ_BYJXBZ_SEL;
/

