create trigger PM_DEFECT_TRI
  before insert
  on PM_DEFECT
  for each row
BEGIN
  SELECT PM_DEFECT_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
END PM_DEFECT_TRI;
/

