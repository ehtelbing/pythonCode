create PROCEDURE BASE_FILE_IMAGE_SEL(V_V_GUID IN VARCHAR2,
                                                V_NAME   OUT VARCHAR2,
                                                V_IMAGE  OUT BLOB) is

  /*查询基础信息附件*/
BEGIN
  SELECT B.V_FILENAME
    INTO V_NAME
    FROM BASE_FILE B
   WHERE B.V_GUID = V_V_GUID;

  SELECT B.V_FILEBLOB
    INTO V_IMAGE
    FROM BASE_FILE B
   WHERE B.V_GUID = V_V_GUID;

END BASE_FILE_IMAGE_SEL;
/

