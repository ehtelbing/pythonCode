create procedure BASE_INSPECT_GETCLASS(V_PERCODE  VARCHAR2, --当前用户code
                                                  DEPTCODE   VARCHAR2, --当前用户作业区
                                                  LOGINCLASS OUT VARCHAR2,
                                                  RET        OUT SYS_REFCURSOR) is

begin

  SELECT P.V_CLASS_CODE
    INTO LOGINCLASS
    FROM BASE_PERSON P
   WHERE P.V_PERSONCODE = V_PERCODE;

  OPEN RET FOR
    SELECT DISTINCT S.V_SAP_WORK, S.V_SAP_WORKNAME
      FROM SAP_PM_WORKCSAT S
     WHERE SUBSTR(S.V_SAP_WORK, 1, 6) IN
           (SELECT SUBSTR(D.V_SAP_WORK, 1, 6)
              FROM BASE_DEPTTOSAPWORKCSAT D
             WHERE D.V_DEPTCODE = DEPTCODE);

end BASE_INSPECT_GETCLASS;
/

