create package body pg_oil32 is

  -- 查询和导出，调用过程pg_oil32.get_oilconsumelist加载表格
  procedure get_oilconsumelist(a_plantcode  varchar2, --厂矿编码
                               a_departcode varchar2, --部门编码
                               a_equtype    varchar2, --设备类型编码
                               a_equip_id   varchar2, --设备ID（设备编码）
                               a_orderid    varchar2, --工单号
                               a_billcode   varchar2, --出库单号
                               a_begindate  date, --开始日期
                               a_enddate    date, --结束日期
                               a_mat_no     varchar2, --物料号
                               a_mat_desc   varchar2, --物料名
                               ret          out sys_refcursor) is
  begin
    open ret for
      select c.consume_id, --消耗ID
             c.billcode, --出库单号
             c.orderid, --工单号
             c.inst_equip_code, --设备ID（设备编码）
             i.inst_equip_name, --设备名
             c.oil_mat_no, --物料号
             c.oil_mat_desc, --物料名
             c.oil_unit, --计量单位
             c.oil_amount, --消耗数量
             c.oil_price, --单价
             (c.oil_amount * c.oil_price) oil_money, --金额
             (case c.oil_status
               when '1' then
                '已写实'
               else
                '未写实'
             end) oil_status, -- 写实状态
             c.oil_remark --写实情况说明
        from oil_equip_consume c
        left outer join oil_equip_inst i
          on i.inst_equip_id = c.inst_equip_code
        left outer join oil_equips e
          on e.equip_no = i.equip_no
       where c.plantcode = a_plantcode
         and c.departcode like a_departcode
         and nvl(e.type_code, '0') like a_equtype
         and c.inst_equip_code like a_equip_id
         and to_number(to_char(c.out_date, 'YYYYMMDD')) >=
             to_number(to_char(a_begindate, 'YYYYMMDD'))
         and to_number(to_char(c.out_date, 'YYYYMMDD')) <=
             to_number(to_char(a_enddate, 'YYYYMMDD'))
         and c.orderid like '%' || a_orderid || '%'
         and c.billcode like '%' || a_billcode || '%'
         and c.oil_mat_no like '%' || a_mat_no || '%'
         and c.oil_mat_desc like '%' || a_mat_desc || '%'
       order by c.oil_mat_no;
  end;
  --点击“写实明细”的“查看”按钮，显示写实明细界面，并调用过程pg_oil32.getpartconsume加载该界面表格
  procedure getpartconsume(a_consume_id varchar2, --消耗ID
                           ret          out sys_refcursor --返回结果集
                           ) is
  begin
    pg_oil31.get_partconsumelist(a_consume_id, ret);
  end;
end pg_oil32;
/

