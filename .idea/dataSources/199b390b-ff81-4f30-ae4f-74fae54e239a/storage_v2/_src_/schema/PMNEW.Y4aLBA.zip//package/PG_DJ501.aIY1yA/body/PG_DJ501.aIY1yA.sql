create package BODY pg_dj501 is
  --设置检修编号
  procedure savemendcodec(a_applyid  varchar2, --工单申请ID
                          a_mendcode varchar2, --检修编号
                          ret_msg    out varchar2,
                          ret        out varchar2) is
    p_count number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_count
      from dj_os_orderapply
     where mend_code = a_mendcode;
    if p_count = 0 then
      begin
        update dj_os_orderapply
           set mend_code = a_mendcode
         where apply_id = a_applyid;
        commit;
        ret := 'Success';
      exception
        when others then
          ret_msg := sqlerrm;
      end;
    else
      ret_msg := '该维修编号已存在';
    end if;
  end;
end pg_dj501;
/

