create package body pg_oil31 is

  --查询，调用过程pg_oil31.get_waitoilconsumelist获取待处理润滑物资表数据，并加载表格。
  procedure get_waitoilconsumelist(a_plantcode  varchar2, --厂矿编码
                                   a_departcode varchar2, --部门编码
                                   a_equip_id   varchar2, --设备ID（设备编码）
                                   a_orderid    varchar2, --工单号
                                   a_billcode   varchar2, --出库单号
                                   a_mat_desc   varchar2, --物资描述
                                   ret          out sys_refcursor --返回结果集
                                   ) is
  begin
    open ret for
      select c.consume_id, --消耗ID
             c.billcode, --出库单号
             c.orderid, --工单号
             c.inst_equip_code, --设备ID（设备编码）
             i.inst_equip_name, --设备名
             c.oil_mat_no, --物料号
             c.oil_mat_desc, --物料名
             c.oil_unit, --计量单位
             c.oil_amount, --消耗数量
             c.oil_price, --单价
             c.oil_remark --写实情况说明
        from oil_equip_consume c
        left outer join oil_equip_inst i
          on i.inst_equip_id = c.inst_equip_code
       where c.plantcode = a_plantcode
         and c.departcode = a_departcode
         and c.inst_equip_code like a_equip_id
         and c.orderid like '%' || a_orderid || '%'
         and c.billcode like '%' || a_billcode || '%'
         and c.oil_mat_desc like '%' || a_mat_desc || '%'
         and c.oil_status = '0'
       order by c.oil_mat_no;
  end;
  --点击待处理润滑物资表的写实列，打开“写实操作”界面。并调用过程pg_oil31.get_partconsumelist加载表格
  procedure get_partconsumelist(a_consume_id varchar2, --消耗ID
                                ret          out sys_refcursor --返回结果集
                                ) is
    p_equip_id oil_equip_consume.inst_equip_code%type;
    p_oil_unit oil_equip_consume.oil_unit%type;
    p_mat_no   oil_equip_consume.oil_mat_no%type;
  begin
    select inst_equip_code, i.oil_unit, i.oil_mat_no
      into p_equip_id, p_oil_unit, p_mat_no
      from oil_equip_consume i
     where i.consume_id = a_consume_id;

    open ret for
      select c.detail_id, --写实ID
             p.part_no, --部位码
             p.part_desc, --部位名
             p_oil_unit oil_unit, --计量单位
             c.oiling_date, --润滑时间
             c.use_amount, --消耗数量
             get_lastpart_approve(i.inst_equip_id,
                                  c.part_no,
                                  nvl(c.oiling_date, sysdate)) approve, --上次油品评价
             c.oil_type,
             c.oil_begindate, --开始时间
             c.oil_enddate
        from oil_equip_inst i
        left outer join oil_equip_parts p
          on i.equip_no = p.equip_no
        left outer join oil_equip_part_consume c
          on c.part_no = p.part_no
         and c.consume_id = a_consume_id
       where i.inst_equip_id = p_equip_id
         and p.current_oil_code = p_mat_no;
  end;
  procedure get_daypartconsumelist(a_consume_id varchar2, --消耗ID
                                   ret          out sys_refcursor --返回结果集
                                   ) is
    p_equip_id oil_equip_consume.inst_equip_code%type;
    p_oil_unit oil_equip_consume.oil_unit%type;
    p_mat_no   oil_equip_consume.oil_mat_no%type;
  begin
    select inst_equip_code, i.oil_unit, i.oil_mat_no
      into p_equip_id, p_oil_unit, p_mat_no
      from oil_equip_consume i
     where i.consume_id = a_consume_id;

    open ret for
      select c.detail_id, --写实ID
             p.part_no, --部位码
             p.part_desc, --部位名
             p_oil_unit oil_unit, --计量单位
             c.oil_begindate, --开始时间
             c.oil_enddate,
             c.use_amount, --消耗数量
             get_lastpart_approve(i.inst_equip_id,
                                  c.part_no,
                                  nvl(c.oiling_date, sysdate)) approve, --上次油品评价
             c.oil_type
        from oil_equip_inst i
        left outer join oil_equip_parts p
          on i.equip_no = p.equip_no
        left outer join oil_equip_part_consume c
          on c.part_no = p.part_no
         and c.consume_id = a_consume_id
       where i.inst_equip_id = p_equip_id
         and p.current_oil_code = p_mat_no;
  end;
  --获取当前换油部位的上次评价信息
  function get_lastpart_approve(a_equip_id varchar2,
                                a_part_no  varchar2,
                                a_date     date) return varchar2 is
    p_approve oil_equip_part_consume.oil_approve%type;
  begin
    begin
      select oil_approve
        into p_approve
        from (select c.oil_approve
                from oil_equip_part_consume c
                left outer join oil_equip_consume e
                  on e.consume_id = c.consume_id
               where c.submit_flag = '1'
                 and e.inst_equip_code = a_equip_id
                 and c.part_no = a_part_no
                 and c.oiling_date <= a_date
               order by c.oiling_date desc)
       where rownum = 1;
    exception
      when others then
        null;
    end;
    return p_approve;
  end;
  --调用过程pg_oil31.submitpartconsume将用户的写实数据保存
  procedure submitpartconsume(a_consume_id varchar2, --消耗ID
                              a_oil_remark varchar2, --写实情况说明
                              a_userid     varchar2, --用户名
                              ret_msg      out varchar2, --反馈信息
                              ret          out varchar2 --执行结果
                              ) is
    p_bool varchar2(1);
  begin
    ret := 'Fail';
    select (case
             when c.oil_amount =
                  (select sum(use_amount)
                     from oil_equip_part_consume pc
                    where pc.consume_id = a_consume_id) then
              '1'
             else
              '0'
           end)
      into p_bool
      from oil_equip_consume c
     where c.consume_id = a_consume_id;
    if p_bool = '1' then
      begin
        savepoint s;
        update oil_equip_consume c
           set c.oil_status   = '1',
               c.oil_date     = sysdate,
               c.oil_userid   = a_userid,
               c.oil_username = func_wp_getusername(a_userid),
               c.oil_remark   = a_oil_remark
         where c.consume_id = a_consume_id;
        update oil_equip_part_consume c
           set c.submit_flag = '1'
         where c.consume_id = a_consume_id;
        commit;
        ret     := 'Success';
        ret_msg := '操作成功';
      exception
        when others then
          ret_msg := '操作失败：' || sqlerrm;
      end;
    else
      ret_msg := '提交失败，部位写实数量合计和消耗数量不一致';
    end if;
  end;
  --点击“平均分配”按钮，调用过程pg_oil31.insertpartavg，调用成功更新该界面的表格数据。
  procedure insertpartavg(a_consume_id varchar2, --消耗ID
                          a_userid     varchar2, --用户名
                          ret_msg      out varchar2, --反馈信息
                          ret          out varchar2 --执行结果
                          ) is
    p_oil_amount oil_equip_consume.oil_amount%type;
  begin
    select c.oil_amount
      into p_oil_amount
      from oil_equip_consume c
     where c.consume_id = a_consume_id;
    ret := 'Success';
  end;
  --点击“按规范分配”按钮，调用过程pg_oil31.insertpartmain，调用成功更新该界面的表格数据。
  procedure insertpartmain(a_consume_id varchar2, --消耗ID
                           a_userid     varchar2, --用户名
                           ret_msg      out varchar2, --反馈信息
                           ret          out varchar2 --执行结果
                           ) is
    p_oil_amount oil_equip_consume.oil_amount%type;
  begin
    select c.oil_amount
      into p_oil_amount
      from oil_equip_consume c
     where c.consume_id = a_consume_id;
    ret := 'Success';
  end;
  --点击写实操作表格的“保存”按钮，调用过程pg_oil31.savepartconsume保存行数据
  procedure savepartconsume(a_detail_id  varchar2, --写实ID
                            a_consume_id varchar2, --消耗ID
                            a_equip_id   varchar2, --设备ID（设备编码）
                            a_part_no    varchar2, --部位码
                            a_useamount  number, --部位写实数量
                            a_oil_date   date, --润滑日期
                            a_approve    varchar2, --上次油品评价
                            a_userid     varchar2, --用户ID
                            ret_msg      out varchar2, --反馈信息
                            ret          out varchar2 --执行结果
                            ) is
    p_approve_detail_id oil_equip_part_consume.detail_id%type;
  begin
    ret := 'Fail';

    begin
      select detail_id
        into p_approve_detail_id
        from (select c.detail_id
                from oil_equip_part_consume c
                left outer join oil_equip_consume e
                  on e.consume_id = c.consume_id
               where c.submit_flag = '1'
                 and e.inst_equip_code = a_equip_id
                 and c.part_no = a_part_no
                 and c.oiling_date <= a_oil_date
               order by c.oiling_date desc)
       where rownum = 1;
    exception
      when others then
        null;
    end;

    savepoint s;
    if a_detail_id is null then
      insert into oil_equip_part_consume
        (detail_id,
         consume_id,
         oiling_date,
         part_no,
         use_amount,
         op_username,
         op_userid,
         op_date,
         submit_flag,
         oil_type,
         oil_begindate,
         oil_enddate)
      values
        (func_run_guid(),
         a_consume_id,
         a_oil_date,
         a_part_no,
         a_useamount,
         func_wp_getusername(a_userid),
         a_userid,
         sysdate,
         '0',
         '检修',
         a_oil_date,
         a_oil_date);
    else
      update oil_equip_part_consume c
         set c.use_amount    = a_useamount,
             c.op_username   = func_wp_getusername(a_userid),
             c.op_userid     = a_userid,
             c.op_date       = sysdate,
             c.oil_type      = '检修',
             c.oiling_date   = a_oil_date,
             c.oil_begindate = a_oil_date,
             c.oil_enddate   = a_oil_date
       where c.detail_id = a_detail_id;
    end if;
    if a_approve is not null then
      if p_approve_detail_id is not null then
        update oil_equip_part_consume c
           set c.oil_approve = a_approve
         where c.detail_id = p_approve_detail_id;
      else
        ret_msg := '但系统未找到上次油品更换记录，不能进行评价';
      end if;
    end if;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功：' || ret_msg;
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
  procedure daysavepartconsume(a_detail_id  varchar2, --写实ID
                               a_consume_id varchar2, --消耗ID
                               a_equip_id   varchar2, --设备ID（设备编码）
                               a_part_no    varchar2, --部位码
                               a_useamount  number, --部位写实数量
                               a_begin_date date,
                               a_end_date   date,
                               a_approve    varchar2, --上次油品评价
                               a_userid     varchar2, --用户ID
                               ret_msg      out varchar2, --反馈信息
                               ret          out varchar2 --执行结果
                               ) is
    p_approve_detail_id oil_equip_part_consume.detail_id%type;
  begin
    ret := 'Fail';

    begin
      select detail_id
        into p_approve_detail_id
        from (select c.detail_id
                from oil_equip_part_consume c
                left outer join oil_equip_consume e
                  on e.consume_id = c.consume_id
               where c.submit_flag = '1'
                 and e.inst_equip_code = a_equip_id
                 and c.part_no = a_part_no
                 and c.oiling_date <= a_begin_date
               order by c.oiling_date desc)
       where rownum = 1;
    exception
      when others then
        null;
    end;

    savepoint s;
    if a_detail_id is null then
      insert into oil_equip_part_consume
        (detail_id,
         consume_id,
         part_no,
         use_amount,
         op_username,
         op_userid,
         op_date,
         submit_flag,
         oil_type,
         oil_begindate,
         oil_enddate,
         oiling_date)
      values
        (func_run_guid(),
         a_consume_id,
         a_part_no,
         a_useamount,
         func_wp_getusername(a_userid),
         a_userid,
         sysdate,
         '0',
         '日常',
         a_begin_date,
         a_end_date,
         a_end_date);
    else
      update oil_equip_part_consume c
         set c.use_amount    = a_useamount,
             c.op_username   = func_wp_getusername(a_userid),
             c.op_userid     = a_userid,
             c.oil_begindate = a_begin_date,
             c.oil_enddate   = a_end_date,
             c.oiling_date   = a_end_date,
             c.oil_type      = '日常'
       where c.detail_id = a_detail_id;
    end if;
    if a_approve is not null then
      if p_approve_detail_id is not null then
        update oil_equip_part_consume c
           set c.oil_approve = a_approve
         where c.detail_id = p_approve_detail_id;
      else
        ret_msg := '但系统未找到上次油品更换记录，不能进行评价';
      end if;
    end if;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功：' || ret_msg;
  exception
    when others then
      ret_msg := '操作失败：' || sqlerrm;
  end;
end pg_oil31;
/

