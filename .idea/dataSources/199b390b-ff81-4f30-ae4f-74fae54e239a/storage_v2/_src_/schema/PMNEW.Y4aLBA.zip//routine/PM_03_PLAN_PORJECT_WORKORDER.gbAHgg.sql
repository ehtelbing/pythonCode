create PROCEDURE PM_03_PLAN_PORJECT_WORKORDER(V_V_PROJECT_CODE IN VARCHAR2, --大修工程guid
                                                         V_V_WEEK_GUID    IN VARCHAR2, --周计划编码，可多个周计划生成一个工单用逗号分隔
                                                         V_V_ORGCODE      IN VARCHAR2, --厂矿编码
                                                         V_V_PERCODE      IN VARCHAR2,
                                                         V_INFO           OUT VARCHAR2,
                                                         V_V_SOURCECODE   OUT VARCHAR2,
                                                         V_CURSOR         OUT SYS_REFCURSOR) IS
  /*周计划生成工单*/
  P_SPLIT_TABLE TYPE_SPLIT := NEW TYPE_SPLIT();
  V_RET         VARCHAR2(50);
  I_NUMBER      NUMBER;

  V_V_DEPTCODE         VARCHAR2(50); --作业区
  V_V_REPAIRMAJOR_CODE VARCHAR2(50); --专业
  V_V_PERNAME          VARCHAR2(50);

  V_V_ORDER_TYPE    VARCHAR2(50);
  V_V_ORDER_TYP_TXT VARCHAR2(50);

  V_V_ORDERID    VARCHAR2(50); --工单号
  V_V_ORDERGUID  VARCHAR2(50); --工单guid
  V_D_ENTER_DATE DATE := sysdate; --输入时间
  V_V_WORK_AREA  VARCHAR2(50); --SAP作业区
  V_V_PLANNER    VARCHAR2(50); --SAP作业区计划组员

  V_V_GSBER     VARCHAR2(50);
  V_V_GSBER_TXT VARCHAR2(50);
  V_V_PLANT     VARCHAR2(50);
  V_V_IWERK     VARCHAR2(50);

  V_V_FUNC_LOC   VARCHAR2(50); --功能位置
  V_V_EQUIP_NO   VARCHAR2(50); --设备编号
  V_V_EQUIP_NAME VARCHAR2(50); --设备名称
  V_V_SHORT_TXT  VARCHAR2(50); --工单描述

BEGIN

  V_V_SOURCECODE := 'defct12';
  V_V_ORDER_TYPE := 'AK14';

  V_V_ORDERGUID := CREATEGUID(); --工单guid
  V_V_ORDERID   := FUNC_GETWORKORDERORDERID(V_V_ORGCODE); --工单编码

  --获取多个周计划检修内容，用逗号分隔
  V_RET := FUNC_SPLIT(V_V_WEEK_GUID, ',', P_SPLIT_TABLE);

  /*判断大修工程，周计划，工单，缺陷关系表中，周计划是否存在，
  如果存在将关系表中的中计划状态改为未生成工单状态（0）*/
  --
  FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP
    SELECT COUNT(*)
      INTO I_NUMBER
      FROM PM_DEFECTTOWORKORDER P
     WHERE P.V_FLAG = 2
       AND P.V_WEEK_GUID = C.COLUMN_VALUE;
    IF I_NUMBER > 0 THEN
      UPDATE PM_DEFECTTOWORKORDER P
         SET P.V_PROJECT_GUID = V_V_PROJECT_CODE
       WHERE P.V_WEEK_GUID = C.COLUMN_VALUE
         AND P.V_FLAG = 2;
    ELSE
      INSERT INTO PM_DEFECTTOWORKORDER
        (V_WORKORDER_GUID, V_PROJECT_GUID, V_WEEK_GUID, V_FLAG)
      VALUES
        (V_V_ORDERGUID, V_V_PROJECT_CODE, C.COLUMN_VALUE, 2);
    END IF;

    SELECT W.V_EQUCODE, W.V_DEPTCODE
      INTO V_V_EQUIP_NO, V_V_DEPTCODE
      FROM PM_03_PLAN_WEEK W
     WHERE W.V_GUID = C.COLUMN_VALUE;

    SELECT P.V_EQUSITE, P.V_EQUNAME
      INTO V_V_FUNC_LOC, V_V_EQUIP_NAME
      FROM SAP_PM_EQU_P P
     WHERE P.V_EQUCODE = V_V_EQUIP_NO;

  IF V_V_SHORT_TXT IS NULL THEN
      SELECT V_CONTENT
        INTO V_V_SHORT_TXT
        FROM VIEW_PM_PLAN_WEEK
       WHERE V_GUID = C.COLUMN_VALUE;
    ELSE
      SELECT V_V_SHORT_TXT || ',' || V_CONTENT
        INTO V_V_SHORT_TXT
        FROM VIEW_PM_PLAN_WEEK
       WHERE V_GUID = C.COLUMN_VALUE;
    END IF;

  END LOOP;

  SELECT V.V_SPECIALTY
    INTO V_V_REPAIRMAJOR_CODE
    FROM VIEW_PM_EQUREPAIRPLAN_TREE V
   WHERE V.V_GUID = V_V_PROJECT_CODE;

  --工单类型
  SELECT A.ORDER_TYPE, PM_WORKORDER_TYP.ORDER_TYP_TXT
    INTO V_V_ORDER_TYPE, V_V_ORDER_TYP_TXT
    FROM PM_DEFECT_SOURCE A, PM_WORKORDER_TYP
   WHERE PM_WORKORDER_TYP.ORDER_TYP = A.ORDER_TYPE
     AND (A.V_SOURCECODE = V_V_SOURCECODE);

  --业务范围,业务范围描述 --维修工厂  V_V_PLANT     计划工厂  V_V_IWERK
  BEGIN

    SELECT BASE_DEPT.V_SAP_YWFW,
           SAP_PM_YWFW.V_YWFWNAMELONG,
           V_SAP_JHGC,
           V_SAP_JHGC
      INTO V_V_GSBER, V_V_GSBER_TXT, V_V_PLANT, V_V_IWERK
      FROM BASE_DEPT, SAP_PM_YWFW
     WHERE SAP_PM_YWFW.V_YWFW = BASE_DEPT.V_SAP_YWFW
       AND (BASE_DEPT.V_DEPTCODE = V_V_ORGCODE);
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      V_INFO := '错误没有对应的业务范围';
      RETURN;
  END;
  BEGIN
    --SAP作业区
    SELECT V_SAP_DEPT
      INTO V_V_WORK_AREA
      FROM BASE_DEPT
     WHERE V_DEPTCODE = V_V_DEPTCODE;
    --SAP作业区计划组员
    SELECT V_SAP_PER
      INTO V_V_PLANNER
      FROM SAP_PM_DEPT
     WHERE V_SAP_DEPT = V_V_WORK_AREA;
  EXCEPTION
    WHEN OTHERS THEN
      V_V_PLANNER := '';
  END;

  --查询是否存在该工单，并且该工单在编辑状态
  SELECT COUNT(*)
    INTO I_NUMBER
    FROM PM_WORKORDER p
   WHERE P.V_ORDERGUID = V_V_ORDERGUID
     AND V_STATECODE = '99';
  IF I_NUMBER = 0 THEN
    --写入主表信息到工单
    INSERT INTO PM_WORKORDER
      (V_ORDERGUID,
       V_ORDERID,
       V_ORDER_TYP,
       V_ORDER_TYP_TXT,
       V_FUNC_LOC,
       V_EQUIP_NO,
       V_EQUIP_NAME,
       V_PLANNER, --计划组员
       V_SHORT_TXT,
       V_GSBER,
       V_GSBER_TXT,
       V_WORK_AREA, --作业区
       D_ENTER_DATE, --创建时间
       V_PLANT,
       V_IWERK,
       V_DEPTCODE,
       V_ENTERED_BY,
       V_STATECODE)
    VALUES
      (V_V_ORDERGUID,
       V_V_ORDERID,
       V_V_ORDER_TYPE,
       V_V_ORDER_TYP_TXT,
       V_V_FUNC_LOC,
       V_V_EQUIP_NO,
       V_V_EQUIP_NAME,
       V_V_PLANNER,
       V_V_SHORT_TXT,
       V_V_GSBER,
       V_V_GSBER_TXT,
       V_V_WORK_AREA,
       V_D_ENTER_DATE,
       V_V_PLANT,
       V_V_IWERK,
       V_V_DEPTCODE,
       V_V_PERCODE,
       '99');
    --写入工单_其它信息表
    INSERT INTO PM_WORKORDER_OTHER
      (V_ORDERGUID, V_STATECODE, V_DEPTCODE)
    VALUES
      (V_V_ORDERGUID, '99', V_V_DEPTCODE);
  END IF;
  COMMIT;
  OPEN V_CURSOR FOR
    SELECT I_ID,
           V_ORDERGUID,
           V_ORDERID,
           V_ORDER_TYP,
           V_ORDER_TYP_TXT,
           V_FUNC_LOC,
           V_EQUIP_NO,
           V_EQUIP_NAME,
           V_PLANT,
           V_IWERK,
           D_START_DATE,
           D_FINISH_DATE,
           V_ACT_TYPE,
           V_PLANNER,
           V_WORK_CTR,
           V_SHORT_TXT,
           V_GSBER,
           V_GSBER_TXT,
           V_WORK_AREA,
           V_WBS,
           V_WBS_TXT,
           V_ENTERED_BY,
           D_ENTER_DATE,
           V_SYSTEM_STATUS,
           V_SYSNAME,
           V_ORGCODE,
           V_ORGNAME,
           V_DEPTCODE,
           V_DEPTNAME,
           V_DEPTCODEREPARIR,
           V_DEPTNAMEREPARIR,
           V_DEFECTGUID,
           V_STATECODE,
           V_STATENAME,
           V_TOOL,
           V_TECHNOLOGY,
           V_SAFE,
           D_DATE_ACP, --验收日期
           I_OTHERHOUR, --提前/逾期时间
           V_OTHERREASON, --逾期原因
           V_REPAIRCONTENT, --检修方说明
           V_REPAIRSIGN, --检修方签字
           V_REPAIRPERSON, --检修人员
           V_POSTMANSIGN, --岗位签字
           V_CHECKMANCONTENT, --点检员验收意见
           V_CHECKMANSIGN, --点检员签字
           V_WORKSHOPCONTENT, --作业区验收
           V_WORKSHOPSIGN, --作业区签字
           V_DEPTSIGN --部门签字
      FROM VIEW_PM_WORKORDER
     WHERE V_ORDERGUID = V_V_ORDERGUID;

  V_INFO := 'SUCCESS';

END PM_03_PLAN_PORJECT_WORKORDER;
/

