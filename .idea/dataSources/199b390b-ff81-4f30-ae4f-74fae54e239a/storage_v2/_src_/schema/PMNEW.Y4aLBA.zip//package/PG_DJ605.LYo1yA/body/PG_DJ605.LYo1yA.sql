create package BODY pg_dj605 is
  -- 查询可录入试验结果工单
  procedure getordersy(a_plantcode varchar2, --厂矿编码
                       a_menddept  varchar2, --检修部门编码
                       a_orderid   varchar2, --工单号
                       ret         out sys_refcursor) is
  begin
    open ret for
      select O.ORDERID,
             O.DJ_NAME,
             S.BCSY_RESULT,
             S.CSY_RESULT,
             O.MEND_CONTEXT,
             nvl(o.menddept_name, m.menddept_name) menddept_name
        from dj_order o
        left outer join dj_menddept m
          on m.menddept_code = o.menddept_code
        left outer join dj_order_sy s
          on o.orderid = s.orderid
        left outer join dj_order_status t
          on t.order_status = o.order_status
       where o.plantcode like a_plantcode
         and o.departcode like a_menddept
         and o.orderid like '%' || a_orderid || '%'
         and t.finish_flag = 0
       order by orderid desc;
  end;
  procedure getordersyamount(a_plantcode varchar2, --厂矿编码
                             a_menddept  varchar2, --检修部门编码
                             ret         out number) is
  begin
    select count(*)
      into ret
      from dj_order o
      left outer join dj_menddept m
        on m.menddept_code = o.menddept_code
      left outer join dj_order_sy s
        on o.orderid = s.orderid
      left outer join dj_order_status t
        on t.order_status = o.order_status
     where o.plantcode like a_plantcode
       and o.departcode like a_menddept
       and t.finish_flag = 0
       and s.csy_result is null;
  end;
  --获取试验详细结果
  procedure ordersydetail(a_orderid varchar2, --工单号
                          ret       out sys_refcursor) is
  begin
    open ret for
      select S.BCSY_RESULT,
             S.BCSY_RESULT_DESC,
             S.ZBCSY_RESULT,
             S.ZBCSY_RESULT_DESC,
             S.DBCSY_RESULT,
             S.DBCSY_RESULT_DESC,
             S.CSY_RESULT,
             S.CSY_RESULT_DESC,
             to_char(s.sy_date, 'YYYY-MM-DD') sy_date
        from dj_order_sy s
       where s.orderid = a_orderid;
  end;
  --保存试验结果
  procedure saveordersy(a_orderid           varchar2, --工单号
                        a_bcsy_result       varchar2, --半成品试验结果
                        a_bcsy_result_desc  varchar2, --半成品试验结果说明
                        a_zbcsy_result      varchar2, --转子半成品试验结果
                        a_zbcsy_result_desc varchar2, --转子半成品试验结果说明
                        a_dbcsy_result      varchar2, --定子半成品试验结果
                        a_dbcsy_result_desc varchar2, --定子半成品试验结果说明
                        a_csy_result        varchar2, --成品试验结果
                        a_csy_result_desc   varchar2, --成品试验救国说明
                        a_userid            varchar2, --用户Id
                        a_username          varchar2, --用户姓名
                        a_sy_date           date, --试验日期
                        ret_msg             out varchar2,
                        ret                 out varchar2) is
    p_count number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_count
      from dj_order_sy s
     where s.orderid = a_orderid;
    if p_count = 0 then
      insert into dj_order_sy
        (ORDERID,
         BCSY_RESULT,
         BCSY_RESULT_DESC,
         ZBCSY_RESULT,
         ZBCSY_RESULT_DESC,
         DBCSY_RESULT,
         DBCSY_RESULT_DESC,
         CSY_RESULT,
         CSY_RESULT_DESC,
         USERID,
         USERNAME,
         SY_DATE,
         INSERTDATE)
      values
        (a_orderid,
         a_bcsy_result,
         a_bcsy_result_desc,
         a_zbcsy_result,
         a_zbcsy_result_desc,
         a_dbcsy_result,
         a_dbcsy_result_desc,
         a_csy_result,
         a_csy_result_desc,
         a_userid,
         a_username,
         a_sy_date,
         sysdate);
    else
      update dj_order_sy
         set BCSY_RESULT       = a_bcsy_result,
             BCSY_RESULT_DESC  = a_bcsy_result_desc,
             ZBCSY_RESULT      = a_zbcsy_result,
             ZBCSY_RESULT_DESC = a_zbcsy_result_desc,
             DBCSY_RESULT      = a_dbcsy_result,
             DBCSY_RESULT_DESC = a_dbcsy_result_desc,
             CSY_RESULT        = a_csy_result,
             CSY_RESULT_DESC   = a_csy_result_desc,
             USERID            = a_userid,
             username          = a_username,
             SY_DATE           = a_sy_date,
             insertdate        = sysdate
       where orderid = a_orderid;
    end if;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
  --附件列表
  procedure filelist(a_orderid varchar2, --工单号
                     ret       out sys_refcursor) is
  begin
    open ret for
      select F.FILEID, F.FILE_NAME, F.UPLOAD_DATE
        from dj_order_sy_file f
       where f.orderid = a_orderid;
  end;
  --文件上传
  procedure fileupdate(a_orderid     varchar2, --工单号
                       a_filename    varchar2, --文件名
                       a_file_extend varchar2, --扩展名
                       a_file        blob, --文件
                       a_username    varchar2, --上传人
                       ret_msg       out varchar2,
                       ret           out varchar2) is
  begin
    ret := 'Fail';
    insert into dj_order_sy_file
      (FILEID,
       ORDERID,
       FILE_NAME,
       FILE_EXTEND,
       FILE_STREAM,
       UPLOAD_DATE,
       UPLOAD_PERSON)
    values
      (func_new_guid(),
       a_orderid,
       a_filename,
       a_file_extend,
       a_file,
       sysdate,
       a_username);
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
  --文件删除
  procedure filedelete(a_fileid varchar2, --文件ID
                       ret_msg  out varchar2,
                       ret      out varchar2) is
  begin
    delete from dj_order_sy_file where fileid = a_fileid;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
  --附件下载
  procedure filedownload(a_fileid        varchar2, --文件ID
                         ret_filename    out varchar2, --文件名
                         ret_file_extend out varchar2, --扩展名
                         ret_file        out blob --文件
                         ) is
  begin
    select f.file_name, f.file_extend, f.file_stream
      into ret_filename, ret_file_extend, ret_file
      from dj_order_sy_file f
     where f.fileid = a_fileid;
  end;
end pg_dj605;
/

