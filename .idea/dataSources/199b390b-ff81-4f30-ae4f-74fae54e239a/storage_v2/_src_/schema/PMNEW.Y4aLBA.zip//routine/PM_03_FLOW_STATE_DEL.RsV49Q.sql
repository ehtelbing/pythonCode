create procedure PM_03_FLOW_STATE_DEL(V_V_GUID IN VARCHAR2,
                                                 V_V_ID   IN VARCHAR2,
                                                 V_INFO   OUT VARCHAR2) is
  /*计划流程设置删除*/
begin
  DELETE FROM PM_03_FLOW_SET S
   WHERE S.V_GUID = V_V_GUID;
  V_INFO := 'success';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
end PM_03_FLOW_STATE_DEL;
/

