create package body pg_mm_user is

  -- 获取用户姓名
  function getusername(v_userid varchar2) return varchar2 is
    p_ret varchar2(50);
  begin
    select p.v_personname
      into p_ret
      from base_person p
     where p.v_loginname = v_userid;
    return p_ret;
  exception
    when others then
      return 'N/A';
  end;
end pg_mm_user;
/

