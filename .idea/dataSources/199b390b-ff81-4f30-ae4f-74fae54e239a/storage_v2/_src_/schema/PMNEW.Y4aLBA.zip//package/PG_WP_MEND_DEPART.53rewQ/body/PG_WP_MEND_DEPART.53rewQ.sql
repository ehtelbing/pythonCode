create PACKAGE BODY PG_WP_MEND_DEPART
/*
说明：维修单位
*/
IS
    --获取厂矿使用的维修单位
    FUNCTION GET_MEND_DEPART_PLANT(A_PLANTCODE VARCHAR2 --厂矿编码
    ,A_MENDTYPE VARCHAR2 --维修类型
    ,RET OUT SYS_REFCURSOR
    )
    RETURN VARCHAR2
    IS
BEGIN
    OPEN RET FOR
    SELECT P.MEND_DEPARTCODE --维修单位编码
          ,D.MEND_DEPARTNAME --维修单位描述
      FROM WP_MEND_DEPART_PLANT P
      LEFT OUTER
      JOIN WP_MEND_DEPART D ON P.MEND_DEPARTCODE = D.MEND_DEPARTCODE
     WHERE USEFLAG = '1'
       AND P.PLANTCODE = A_PLANTCODE
       AND D.MENDTYPE LIKE A_MENDTYPE;
    RETURN 'Success';
END;
--查询全部维修单位
FUNCTION GET_MEND_DEPART_ALL(A_USEFLAG VARCHAR2
,RET OUT SYS_REFCURSOR)
RETURN VARCHAR2
IS
    BEGIN
        OPEN RET FOR
        SELECT P.MEND_DEPARTCODE --维修单位编码
              ,P.MEND_DEPARTNAME --维修单位描述
              ,P.MENDTYPE --维修类型
              ,M.MENDTYPE_DESC --维修类型描述
              ,P.USEFLAG --使用标识
              ,CASE P.USEFLAG WHEN '1' THEN '已启用' ELSE '已停用' END USEFLAG_DESC --使用标识描述
          FROM WP_MEND_DEPART P
          LEFT OUTER
          JOIN WP_MENDTYPE M ON M.MENDTYPE_CODE = P.MENDTYPE
         WHERE P.USEFLAG LIKE A_USEFLAG;
        RETURN 'Success';
    END;
    --添加，修改，删除维修单位
    FUNCTION OP_MENDDEPART(A_MEND_DEPARTCODE VARCHAR2 --维修单位编码
    ,A_MEND_DEPARTNAME VARCHAR2 --维修单位名称
    ,A_MENDTYPE VARCHAR2 --维修类型Id
    ,A_USEFLAG VARCHAR2 --使用标识
    ,A_OP  VARCHAR2
    )
    RETURN VARCHAR2
    IS
    P_RET VARCHAR2(10) := 'Fail';
    BEGIN
        IF A_OP = 'add' THEN
            INSERT INTO WP_MEND_DEPART
                   (MEND_DEPARTCODE
                   ,MEND_DEPARTNAME
                   ,MENDTYPE
                   ,USEFLAG)
            VALUES (A_MEND_DEPARTCODE
                   ,A_MEND_DEPARTNAME
                   ,A_MENDTYPE
                   ,A_USEFLAG) ;
        ELSIF A_OP = 'update' THEN
            UPDATE WP_MEND_DEPART
               SET MEND_DEPARTNAME = A_MEND_DEPARTNAME
                  ,MENDTYPE = A_MENDTYPE
                  ,USEFLAG = A_USEFLAG
             WHERE MEND_DEPARTCODE = A_MEND_DEPARTCODE;
        ELSIF A_OP = 'delete' THEN
            DELETE
              FROM WP_MEND_DEPART
             WHERE MEND_DEPARTCODE = A_MEND_DEPARTCODE;
        END IF;
        COMMIT;
        RETURN 'Success';
    EXCEPTION
        WHEN OTHERS THEN
            RETURN P_RET;
    END;
    --添加，删除厂矿使用维修单位
    FUNCTION OP_MEND_DEPART_PLANT(A_MEND_DEPARTCODE VARCHAR2 --维修单位编码
    ,A_PLANTCODE VARCHAR2 --厂矿编码
    ,A_OP VARCHAR2
    )
    RETURN VARCHAR2
    IS
    P_RET VARCHAR2(10) := 'Fail';
    BEGIN
        IF A_OP = 'add' THEN
            INSERT INTO WP_MEND_DEPART_PLANT
                   (MEND_DEPARTCODE
                   ,PLANTCODE)
            VALUES (A_MEND_DEPARTCODE
                   ,A_PLANTCODE) ;
        ELSIF A_OP = 'update' THEN
            NULL;
        ELSIF A_OP = 'delete' THEN
            DELETE
              FROM WP_MEND_DEPART_PLANT
             WHERE MEND_DEPARTCODE = A_MEND_DEPARTCODE
               AND PLANTCODE = A_PLANTCODE;
    END IF;
    COMMIT;
    RETURN 'Success';
EXCEPTION
    WHEN OTHERS THEN
        RETURN P_RET;
END;
END PG_WP_MEND_DEPART;
/

