create PROCEDURE BASE_CAR_REP_DETAIL_SEL(V_V_CAR_GUID IN VARCHAR2, --机具GUID
                                                    V_CURSOR     OUT SYS_REFCURSOR) is

  /*查询机具维修信息*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT B.V_CARCODE, --机具编码
           B.V_CARNAME, --机具名称
           C.*
      FROM BASE_EXAMINE_CAR B, PM_WORKORDER C
     WHERE C.V_ORDERGUID IN
           (SELECT V_WORKORDER_GUID
              FROM BASE_CAR_LINK_WORKORDER
             WHERE V_CAR_GUID = V_V_CAR_GUID)
       AND B.V_GUID = V_V_CAR_GUID;

END BASE_CAR_REP_DETAIL_SEL;
/

