create procedure PM_03_FLOW_STATE_SET(V_V_GUID          IN VARCHAR2, --添加传-1
                                                 V_V_ORGCODE       IN VARCHAR2,
                                                 V_V_DEPTCODE      IN VARCHAR2,
                                                 V_V_PLANTYPE      IN VARCHAR2,
                                                 V_V_FLOWNAME      IN VARCHAR2,
                                                 V_V_FLOWNAME_NEXT IN VARCHAR2,
                                                 V_V_ORDER         IN VARCHAR2,
                                                 V_V_ROLECODE      IN VARCHAR2,
                                                 V_V_ROLENAME      IN VARCHAR2,
                                                 V_V_PERCODE       IN VARCHAR2, --审批人，用逗号分隔
                                                 V_INFO            OUT VARCHAR2) is
  /*计划流程设置编辑*/
  P_SPLIT_TABLE TYPE_SPLIT := NEW TYPE_SPLIT();
  V_RET         VARCHAR2(50);
  V_V_NEWGUID   VARCHAR2(50);
  V_V_URL       VARCHAR2(100);
begin

  IF V_V_PLANTYPE = 'YEAR' THEN
    V_V_URL := '/PM_03020213/index.html';
  ELSIF V_V_PLANTYPE = 'QUARTER' THEN
    V_V_URL := '/PM_03010114/index.html';
  ELSIF V_V_PLANTYPE = 'MONTH' THEN
    V_V_URL := '/PM_03010213/index.html';
  ELSIF V_V_PLANTYPE = 'WEEK' THEN
    V_V_URL := '/PM_03010307/index.html';
  END IF;
  IF V_V_GUID = '-1' THEN

    V_V_NEWGUID := CREATEGUID();
    V_RET       := func_split(V_V_PERCODE, ',', P_SPLIT_TABLE);

    FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP
      INSERT INTO PM_03_FLOW_SET
        (V_PLANTYPE,
         V_FLOWNAME,
         V_ORGCODE,
         V_DEPTCODE,
         V_ORDER,
         V_ROLECODE,
         V_URL,
         V_GUID,
         V_FLOWNAME_NEXT,
         V_PERCODE,
         V_ROLENAME)
      VALUES
        (V_V_PLANTYPE,
         V_V_FLOWNAME,
         V_V_ORGCODE,
         V_V_DEPTCODE,
         V_V_ORDER,
         V_V_ROLECODE,
         V_V_URL,
         V_V_NEWGUID,
         V_V_FLOWNAME_NEXT,
         C.COLUMN_VALUE,
         V_V_ROLENAME);
    END LOOP;

  ELSE
    DELETE FROM PM_03_FLOW_SET P WHERE P.V_GUID = V_V_GUID;
    V_RET := func_split(V_V_PERCODE, ',', P_SPLIT_TABLE);

    FOR C IN (SELECT COLUMN_VALUE FROM TABLE(P_SPLIT_TABLE)) LOOP
      INSERT INTO PM_03_FLOW_SET
        (V_PLANTYPE,
         V_FLOWNAME,
         V_ORGCODE,
         V_DEPTCODE,
         V_ORDER,
         V_ROLECODE,
         V_URL,
         V_GUID,
         V_FLOWNAME_NEXT,
         V_PERCODE,
         V_ROLENAME)
      VALUES
        (V_V_PLANTYPE,
         V_V_FLOWNAME,
         V_V_ORGCODE,
         V_V_DEPTCODE,
         V_V_ORDER,
         V_V_ROLECODE,
         V_V_URL,
         V_V_GUID,
         V_V_FLOWNAME_NEXT,
         C.COLUMN_VALUE,
         V_V_ROLENAME);
    END LOOP;
  END IF;
  V_INFO := 'success';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
end PM_03_FLOW_STATE_SET;
/

