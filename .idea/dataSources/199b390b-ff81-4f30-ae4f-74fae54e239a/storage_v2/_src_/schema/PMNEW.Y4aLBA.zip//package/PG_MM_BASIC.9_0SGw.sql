create package pg_mm_basic is

  -- Author  : WY
  -- Created : 2017/11/15 14:19:01
  -- Purpose :

  --获取组织机构名称
  function depart_getname(v_code varchar2) return varchar2;

end pg_mm_basic;
/

