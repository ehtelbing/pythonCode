create PACKAGE BODY PG_RUN_SITE
/*
说明：设备位置
*/
 IS
  --添加，删除，修改位置信息
  FUNCTION OP_SITE(A_SITE_ID         VARCHAR2 --位置ID
                  ,
                   A_SITE_DESC       VARCHAR2 --位置描述
                  ,
                   A_EQUID           VARCHAR2 --设备Id
                  ,
                   A_REMARK          VARCHAR2 --备注
                  ,
                   A_USERNAME        VARCHAR2 --录入人
                  ,
                   A_MEND_DEPART     VARCHAR2 --维修单位
                  ,
                   A_MEND_USERNAME   VARCHAR2 --维修负责人
                  ,
                   A_MEND_USERNAMEID VARCHAR2 --维修负责人ID
                  ,
                   A_BJ_ID           VARCHAR2 --备件ID
                  ,
                   a_bj_amount       number,
                   A_OP              VARCHAR2,
                   RET_MSG           OUT VARCHAR2) RETURN VARCHAR2 IS
    P_RET VARCHAR2(10) := 'Fail';
  BEGIN
    IF A_OP = 'add' THEN
      INSERT INTO RUN_SITE_DIC
        (SITE_ID,
         SITE_DESC,
         EQU_ID,
         REMARK,
         UPDATEDATE,
         UPDATEPERSON,
         MEND_DEPART,
         MEND_PERSON,
         MEND_PERSONID,
         BJ_ID,
         BJ_AMOUNT)
      VALUES
        (FUNC_RUN_GUID(),
         A_SITE_DESC,
         A_EQUID,
         A_REMARK,
         SYSDATE,
         A_USERNAME,
         A_MEND_DEPART,
         A_MEND_USERNAME,
         A_MEND_USERNAMEID,
         A_BJ_ID,
         a_bj_amount);
    ELSIF A_OP = 'update' THEN
      UPDATE RUN_SITE_DIC
         SET SITE_DESC     = A_SITE_DESC,
             REMARK        = A_REMARK,
             UPDATEPERSON  = A_USERNAME,
             MEND_DEPART   = A_MEND_DEPART,
             MEND_PERSON   = A_MEND_USERNAME,
             MEND_PERSONID = A_MEND_USERNAMEID,
             BJ_ID         = A_BJ_ID,
             bj_amount     = a_bj_amount,
             UPDATEDATE    = SYSDATE
       WHERE SITE_ID = A_SITE_ID;
    ELSIF A_OP = 'delete' THEN
      DELETE FROM RUN_SITE_DIC WHERE SITE_ID = A_SITE_ID;
    END IF;
    COMMIT;
    P_RET   := 'Success';
    RET_MSG := '操作成功';
    RETURN P_RET;
  EXCEPTION
    WHEN OTHERS THEN
      RET_MSG := '操作失败';
      RETURN P_RET;
  END;
  --查询当前设备的位置信息
  FUNCTION GET_SITE_LIST(A_EQU_ID VARCHAR2 --设备ID
                        ,
                         RET      OUT SYS_REFCURSOR) RETURN VARCHAR2 IS
  BEGIN
    OPEN RET FOR
      SELECT D.SITE_ID --位置ID
            ,
             D.SITE_DESC --位置描述
            ,
             D.REMARK --位置备注
            ,
             D.UPDATEPERSON --录入人
            ,
             D.MEND_DEPART --检修单位
            ,
             D.MEND_PERSON --检修人
            ,
             D.MEND_PERSONID --检修人ID
            ,
             D.BJ_ID --可放备件编码
            ,
             B.BJ_DESC --可放备件描述
            ,
             d.bj_amount,
             b.pre_flag,
             case b.pre_flag
               when '0' then
                '否'
               else
                '是'
             end pre_flag_desc
        FROM RUN_SITE_DIC D
        LEFT OUTER JOIN RUN_BJ B
          ON B.BJ_ID = D.BJ_ID
       WHERE D.EQU_ID = A_EQU_ID;
    RETURN 'Success';
  END;
END PG_RUN_SITE;
/

