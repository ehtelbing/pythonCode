create package PG_SY201002 is
  --刀闸实验数据录入修改
  --1 查询
  procedure pro_sy201002_onedetail(recordcode_in in varchar2, --记录ID
                                   v_cursor      out sys_refcursor);
  --1.添加
  procedure pro_sy201002_oneadd(usercode_in     varchar2, --登录人cookie
                                username_in     varchar2, --登录人姓名cookie
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿cookie
                                departcode_in   varchar2, --部门cookie
                                plantname_in    varchar2, --厂矿名称cookie
                                departname_in   varchar2, --部门名称cookie
                                sydate_in           DATE, --实验时间
                                syloccode_in        varchar2, --实验地点编码
                                sylocname_in        varchar2, --实验地点名称
                                syequcode_in        varchar2, --实验设备编码
                                syequname_in        varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN    VARCHAR2, --设备种类编码
                                SYEQUTYPTNAME_IN    VARCHAR2, -- 设备种类名称
                                SYWEATHER_in        varchar2, --天气
                                sytemp_in           number, --气温
                                syreason_in         varchar2, --实验原因
                                SYVERDICT_in        varchar2, --结论
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,
                                v_dzcode    varchar2, --刀闸编码
                                v_dzmake    varchar2, --制造商
                                v_dztype    varchar2, --型号
                                v_dzkv      varchar2, --定额电压
                                v_dza       varchar2, --定额电流
                                v_dzoutdate date, --出厂
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2,
                                v_info           out varchar2,
                                v_info1          out varchar2,
                                v_info2          out varchar2);
  --更新
  procedure pro_sy201002_oneupdate(recordcode_in       varchar2,
                                   usercode_in         varchar2, --登录人cookie
                                   username_in         varchar2, --登录人姓名cookie
                                   sydate_in           DATE, --实验时间
                                   syloccode_in        varchar2, --实验地点编码
                                   sylocname_in        varchar2, --实验地点名称
                                   syequcode_in        varchar2, --实验设备编码
                                   syequname_in        varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN    VARCHAR2, --设备种类编码
                                   SYEQUTYPTNAME_IN    VARCHAR2, -- 设备种类名称
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,
                                   v_dzcode         varchar2, --刀闸编码
                                   v_dzmake         varchar2, --制造商
                                   v_dztype         varchar2, --型号
                                   v_dzkv           varchar2, --定额电压
                                   v_dza            varchar2, --定额电流
                                   v_dzoutdate      date, --出厂,
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2);
end PG_SY201002;
/

