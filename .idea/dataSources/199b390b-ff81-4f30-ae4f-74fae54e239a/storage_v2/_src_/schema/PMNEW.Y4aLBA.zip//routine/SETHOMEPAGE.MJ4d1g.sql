create FUNCTION SETHOMEPAGE(A_USERID VARCHAR2, --用户ID
                                       A_MENUID VARCHAR2 --菜单Id
                                       ) RETURN VARCHAR2 IS
BEGIN
  UPDATE BASIC_MENU_FAVORITE
     SET HOMEFLAG =
         (case homeflag
           when '1' then
            '0'
           else
            '1'
         end)
   WHERE USERID = A_USERID
     AND MENU_ID = A_MENUID;
  COMMIT;
  RETURN 'Success';
EXCEPTION
  WHEN OTHERS THEN
    RETURN 'Fail';
END SETHOMEPAGE;
/

