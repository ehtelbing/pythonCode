create procedure PM_03_PLAN_PROJECT_FILE_DEL(V_V_GUID     IN VARCHAR2, --关系guid
                                                        V_V_FILEGUID IN VARCHAR2, --附件唯一值
                                                        V_INFO       OUT VARCHAR2) is

begin

  DELETE FROM PM_03_PLAN_PROJECT_FILE F
   WHERE F.V_GUID = V_V_GUID
     AND F.V_FILEGUID = V_V_FILEGUID;
  V_INFO := 'Success';
end PM_03_PLAN_PROJECT_FILE_DEL;
/

