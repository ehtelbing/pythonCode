create trigger PM_06_DJ_TYPE_TRI
  before insert
  on PM_06_DJ_TYPE
  for each row
BEGIN
  SELECT PM_06_DJ_TYPE_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
END PM_06_DJ_TYPE_TRI;
/

