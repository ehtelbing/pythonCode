create package PG_SY201008 is
  --绝缘工具试验数据录入
  procedure pro_sy201008_onedetail(recordcode_in varchar,
                                   v_cursor      out sys_refcursor);
  --t添加
  procedure pro_sy201008_oneadd(usercode_in     varchar2, --登录人
                                username_in     varchar2, --登录人姓名
                                itemtypecode_in varchar2, --项目类型编码
                                itemcode_in     varchar2, --项目编码
                                plantcode_in    varchar2, --厂矿
                                departcode_in   varchar2, --部门
                                plantname_in    varchar2, --厂矿名称
                                departname_in   varchar2, --部门名称
                                sydate_in        DATE, --实验时间
                                syloccode_in     varchar2, --实验地点编码
                                sylocname_in     varchar2, --实验地点名称
                                syequcode_in     varchar2, --实验设备编码
                                syequname_in     varchar2, --实验设备名称
                                SYEQUTYPTCODE_IN VARCHAR2,
                                SYEQUTYPTNAME_IN VARCHAR2,
                                SYWEATHER_in        varchar2, --天气
                                sytemp_in           number, --气温
                                syreason_in         varchar2, --实验原因
                                SYVERDICT_in        varchar2, --结论
                                SYRESPUSERNAME_code varchar2, --负责人
                                SYRESPUSERNAME_in   varchar2,
                                SYEXAUSERNAME_code  varchar2, --审核人
                                SYEXAUSERNAME_in    varchar2,
                                -- SYUSERID_IN VARCHAR2,--试验人
                                -- SYUSERNAME_IN  VARCHAR2,
                                SYRECORDID_IN    VARCHAR2, --记录人
                                SYRECORDNAME_IN  VARCHAR2,
                                SY_OPUSERID_in   VARCHAR2, ---操作人
                                SY_OPUSERNAME_in VARCHAR2,
                                SY_JXUSERID_in   VARCHAR2, --接线人
                                SY_JXUSERNAME_in VARCHAR2,
                                make_date_in     date, --制造日期
                                outplant_date_in date, --出厂日期
                                ret              out varchar2);
  --更新
  procedure pro_sy201008_oneupdate(recordcode_in    varchar2,
                                   usercode_in      varchar2, --登录
                                   username_in      varchar2, --登录人姓名
                                   sydate_in        DATE, --实验时间
                                   syloccode_in     varchar2, --实验地点编码
                                   sylocname_in     varchar2, --实验地点名称
                                   syequcode_in     varchar2, --实验设备编码
                                   syequname_in     varchar2, --实验设备名称
                                   SYEQUTYPTCODE_IN VARCHAR2,
                                   SYEQUTYPTNAME_IN VARCHAR2,
                                   SYWEATHER_in        varchar2, --天气
                                   sytemp_in           number, --气温 12.3
                                   syreason_in         varchar2, --实验原因
                                   SYVERDICT_in        varchar2, --结论
                                   SYRESPUSERNAME_code varchar2, --负责人
                                   SYRESPUSERNAME_in   varchar2,
                                   SYEXAUSERNAME_code  varchar2, --审核人
                                   SYEXAUSERNAME_in    varchar2,
                                   -- SYUSERID_IN VARCHAR2,--试验人
                                   -- SYUSERNAME_IN  VARCHAR2,
                                   SYRECORDID_IN    VARCHAR2, --记录人
                                   SYRECORDNAME_IN  VARCHAR2,
                                   SY_OPUSERID_in   VARCHAR2, ---操作人
                                   SY_OPUSERNAME_in VARCHAR2,
                                   SY_JXUSERID_in   VARCHAR2, --接线人
                                   SY_JXUSERNAME_in VARCHAR2,
                                   make_date_in     date, --制造日期
                                   outplant_date_in date, --出厂日期
                                   ret              out varchar2);
  --属性表添加
  --2,查询
  procedure pro_sy201008_twodetail(recordcode_in varchar2,
                                   v_cursor      out sys_refcursor);
  --2.添加
  procedure pro_sy201008_twoadd(recordcode_in varchar2,
                                v_A1          VARCHAR2,
                                v_A2          NUMBER,
                                v_A3          VARCHAR2,
                                v_A4          VARCHAR2,
                                v_B1          VARCHAR2,
                                v_B2          NUMBER,
                                v_B3          VARCHAR2,
                                v_B4          VARCHAR2,
                                v_C1          VARCHAR2,
                                v_C2          NUMBER,
                                v_C3          VARCHAR2,
                                v_C4          VARCHAR2,
                                v_D1          VARCHAR2,
                                v_D2          NUMBER,
                                v_D3          VARCHAR2,
                                v_D4          VARCHAR2,
                                v_E1          VARCHAR2,
                                v_E2          NUMBER,
                                v_E3          VARCHAR2,
                                v_E4          VARCHAR2,
                                v_F1          VARCHAR2,
                                v_F2          NUMBER,
                                v_F3          VARCHAR2,
                                v_F4          VARCHAR2,
                                v_G1          VARCHAR2,
                                v_G2          NUMBER,
                                v_G3          VARCHAR2,
                                v_G4          VARCHAR2,
                                v_H1          VARCHAR2,
                                v_H2          NUMBER,
                                v_H3          VARCHAR2,
                                v_H4          VARCHAR2,
                                v_I1          VARCHAR2,
                                v_I2          NUMBER,
                                v_I3          VARCHAR2,
                                v_I4          VARCHAR2,
                                v_J1          VARCHAR2,
                                v_J2          NUMBER,
                                v_J3          VARCHAR2,
                                v_J4          VARCHAR2,
                                v_K1          VARCHAR2,
                                v_K2          NUMBER,
                                v_K3          VARCHAR2,
                                v_K4          VARCHAR2,
                                -- v_OP_USER     VARCHAR2,
                                ---v_RECORD_USER VARCHAR2,
                                --v_JX_USER VARCHAR2,
                                ret     out varchar2,
                                v_info  out varchar2,
                                v_info1 out varchar2,
                                v_info2 out varchar2);
  --2，更新
  procedure pro_sy201008_twoupdate(v_id          varchar2,
                                   recordcode_in varchar2,
                                   v_A1          VARCHAR2,
                                   v_A2          NUMBER,
                                   v_A3          VARCHAR2,
                                   v_A4          VARCHAR2,
                                   v_B1          VARCHAR2,
                                   v_B2          NUMBER,
                                   v_B3          VARCHAR2,
                                   v_B4          VARCHAR2,
                                   v_C1          VARCHAR2,
                                   v_C2          NUMBER,
                                   v_C3          VARCHAR2,
                                   v_C4          VARCHAR2,
                                   v_D1          VARCHAR2,
                                   v_D2          NUMBER,
                                   v_D3          VARCHAR2,
                                   v_D4          VARCHAR2,
                                   v_E1          VARCHAR2,
                                   v_E2          NUMBER,
                                   v_E3          VARCHAR2,
                                   v_E4          VARCHAR2,
                                   v_F1          VARCHAR2,
                                   v_F2          NUMBER,
                                   v_F3          VARCHAR2,
                                   v_F4          VARCHAR2,
                                   v_G1          VARCHAR2,
                                   v_G2          NUMBER,
                                   v_G3          VARCHAR2,
                                   v_G4          VARCHAR2,
                                   v_H1          VARCHAR2,
                                   v_H2          NUMBER,
                                   v_H3          VARCHAR2,
                                   v_H4          VARCHAR2,
                                   v_I1          VARCHAR2,
                                   v_I2          NUMBER,
                                   v_I3          VARCHAR2,
                                   v_I4          VARCHAR2,
                                   v_J1          VARCHAR2,
                                   v_J2          NUMBER,
                                   v_J3          VARCHAR2,
                                   v_J4          VARCHAR2,
                                   v_K1          VARCHAR2,
                                   v_K2          NUMBER,
                                   v_K3          VARCHAR2,
                                   v_K4          VARCHAR2,
                                   --v_OP_USER     VARCHAR2,
                                   -- v_RECORD_USER VARCHAR2,
                                   -- v_JX_USER VARCHAR2,
                                   ret out varchar2);
end PG_SY201008;
/

