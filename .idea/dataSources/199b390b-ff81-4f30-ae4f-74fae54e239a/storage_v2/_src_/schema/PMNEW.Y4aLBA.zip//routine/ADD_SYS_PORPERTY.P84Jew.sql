create function add_sys_porperty(V_V_PORP_NAME     in varchar2,
                                               V_V_PORP_VALUE in varchar2,
                                               V_V_PLANT   in varchar2) return varchar2 is
    p_ret varchar2(10) := 'Fail';
    --  p_count number(2, 0) := 0;
  begin
    begin
      INSERT INTO PM_SYS_PORPERTY B
      (ID, PORP_NAME, PORP_VALUE, PLANT, INSERTDATE)
      VALUES
        (CREATEGUID(), V_V_PORP_NAME, V_V_PORP_VALUE, V_V_PLANT, sysdate);
      commit;
      p_ret := 'Success';
    end;
    return p_ret;
  end;
/

