create PROCEDURE BASE_EXAMINE_CAR_SEL(V_V_CARCODE IN VARCHAR2,
                                                 V_V_CARNAME IN VARCHAR2,
                                                 V_CURSOR    OUT SYS_REFCURSOR) is

  /*查询机具*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT B.V_GUID,
           B.V_CARCODE,
           B.V_CARNAME,
           B.V_CARTYPE,
           B.V_CARGUISUO,
           B.V_CARINDATE,
           B.V_FLAG,
           B.V_CARINFO,
           B.V_DE
      FROM BASE_EXAMINE_CAR B
     WHERE B.V_CARCODE LIKE '%' || V_V_CARCODE || '%'
       AND B.V_CARNAME LIKE '%' || V_V_CARNAME || '%';

END BASE_EXAMINE_CAR_SEL;
/

