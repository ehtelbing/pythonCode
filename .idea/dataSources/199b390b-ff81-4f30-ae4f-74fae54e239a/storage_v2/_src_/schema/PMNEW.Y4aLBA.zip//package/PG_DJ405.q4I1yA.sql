create package pg_dj405 is
  -- Author  : ADMINISTRATOR
  -- Created : 2016/5/20 13:34:43
  -- Purpose : 工单申请确认
  --查询待确认申请
  procedure get_waitapplylist(plantcode_in  varchar2,
                              departcode_in varchar2,
                              usercode_in   varchar2,
                              ret           out sys_refcursor);
  --确认申请
  procedure confirm_apply(applyid_in varchar2,
                          a_userid   varchar2,
                          ret        out varchar2,
                          ret_msg    out varchar2);
  --退回到申请单位
  procedure back_apply(applyid_in varchar2,
                       a_userid   varchar2,
                       ret        out varchar2,
                       ret_msg    out varchar2);
end pg_dj405;
/

