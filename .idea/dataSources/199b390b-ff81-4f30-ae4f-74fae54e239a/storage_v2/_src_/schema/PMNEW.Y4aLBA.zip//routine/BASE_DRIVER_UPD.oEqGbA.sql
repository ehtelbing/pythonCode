create PROCEDURE BASE_DRIVER_UPD(V_V_GUID        IN VARCHAR2, --GUID
                                            V_V_DRIVER_NAME IN VARCHAR2, --司机姓名
                                            V_V_WORK_DATE   IN VARCHAR2, --上岗时间
                                            V_V_DRIVER_DE   IN VARCHAR2, --司机定额
                                            V_INFO          OUT VARCHAR2) IS

  /*修改司机详情*/
BEGIN

  UPDATE BASE_DRIVER B
     SET B.V_DRIVER_NAME = V_V_DRIVER_NAME,
         B.V_WORK_DATE   = TO_DATE(V_V_WORK_DATE, 'yyyy-mm-dd'),
         B.V_DRIVER_DE   = V_V_DRIVER_DE
   WHERE B.V_GUID = V_V_GUID;
  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

END BASE_DRIVER_UPD;
/

