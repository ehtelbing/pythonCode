create procedure BASE_INSPECT_DAY_UPDATE(V_MAINGUID VARCHAR2,
                                                    V_PERCODE VARCHAR2,--当前登入人
                                                    V_UUID VARCHAR2,
                                                    V_STATE_SIGN VARCHAR2,--0 正常 1 异常
                                                    RET OUT VARCHAR2
                                                    ) is
   --V_MAINGUID varchar2(50):=createguid();
begin
  
  UPDATE BASE_INSPECT_DAY_CONTENT C
  SET C.STATE_SIGN=(case when C.STATE_SIGN='0' then '1' else '0' end)
  WHERE C.MAINGUID=V_MAINGUID
  AND C.UUID=V_UUID
  AND C.IN_PERCODE=V_PERCODE
  AND TO_CHAR(C.IN_DATE, 'yyyyMMdd') = TO_CHAR(SYSDATE, 'yyyyMMdd');
  COMMIT;
  RET:='SUCCESS';
  EXCEPTION
    WHEN OTHERS THEN 
      RET:='FAIL';
                                       
                                       
end BASE_INSPECT_DAY_UPDATE;
/

