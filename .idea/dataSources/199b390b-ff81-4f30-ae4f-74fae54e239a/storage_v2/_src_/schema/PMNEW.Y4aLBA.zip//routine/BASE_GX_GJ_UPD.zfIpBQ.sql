create PROCEDURE BASE_GX_GJ_UPD(V_V_JXGX_CODE  IN VARCHAR2,
                                           V_V_TOOLCODE   IN VARCHAR2,
                                           V_V_TOOLTYPE   IN VARCHAR2,
                                           V_V_TOOLPLACE  IN VARCHAR2,
                                           V_V_TOOLINDATE IN VARCHAR2,
                                           V_V_TOOLSTATUS IN VARCHAR2,
                                           V_INFO         OUT VARCHAR2) IS
    /*修改检修工序的工具*/
BEGIN
    UPDATE BASE_WORK_TOOL B
    SET    B.V_TOOLTYPE   = V_V_TOOLTYPE,
           B.V_TOOLPLACE  = V_V_TOOLPLACE,
           B.V_TOOLINDATE = TO_DATE(V_V_TOOLINDATE,'yyyy-mm-dd HH24:mi:ss'),
           B.V_TOOLSTATUS = V_V_TOOLSTATUS
    WHERE  B.V_TOOLCODE IN
           (SELECT V_GJ_CODE
            FROM   PM_1917_JXGX_GJ_DATA P
            WHERE  P.V_JXGX_CODE = V_V_JXGX_CODE)
    AND    B.V_TOOLCODE = V_V_TOOLCODE;
    V_INFO := 'SUCCESS';
EXCEPTION
    WHEN OTHERS THEN
        V_INFO := SQLERRM;
END BASE_GX_GJ_UPD;
/

