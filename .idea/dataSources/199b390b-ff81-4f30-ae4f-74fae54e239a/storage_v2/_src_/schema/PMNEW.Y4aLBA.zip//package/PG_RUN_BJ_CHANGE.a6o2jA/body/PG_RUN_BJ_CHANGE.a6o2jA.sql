create PACKAGE BODY PG_RUN_BJ_CHANGE
/*
说明：备件更换
*/
 IS
  --查询当前备件使用台账
  FUNCTION GET_BJ_USE_LIST(A_PLANTCODE      VARCHAR2 --厂矿编码
                          ,
                           A_DEPARTCODE     VARCHAR2 --作业区编码
                          ,
                           A_EQUID          VARCHAR2 --设备ID
                          ,
                           A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                          ,
                           A_BEGINDATE      DATE --起始日期
                          ,
                           A_ENDDATE        DATE --结束日期
                          ,
                           RET              OUT SYS_REFCURSOR)
    RETURN VARCHAR2 IS
    P_SQL VARCHAR2(1000);
  BEGIN
    P_SQL := 'SELECT BJ_UNIQUE_CODE'; --备件唯一编码
    P_SQL := P_SQL || ',MATERIALCODE'; --物资编码
    P_SQL := P_SQL || ',MATERIALNAME'; --物资名称
    P_SQL := P_SQL || ',UNIT'; --计量单位
    P_SQL := P_SQL || ',SITE_ID'; --当前位置
    P_SQL := P_SQL || ',SITE_DESC'; --当前位置
    P_SQL := P_SQL || ',to_char(CHANGEDATE,''YYYY/MM/DD'') CHANGEDATE'; --最近更换时间
    P_SQL := P_SQL || ',BJ_STATUS'; --备件状态
    P_SQL := P_SQL || ',DEPARTNAME'; --作业区
    P_SQL := P_SQL || ',EQU_NAME'; --当前设备
    P_SQL := P_SQL || ',supply_name';
    P_SQL := P_SQL || ' FROM VIEW_RUN_BJ_CYCLE';
    IF A_BJ_UNIQUE_CODE IS NOT NULL THEN
      P_SQL := P_SQL || ' where BJ_UNIQUE_CODE = :BJ_UNIQUE_CODE';
      OPEN RET FOR P_SQL
        USING A_BJ_UNIQUE_CODE;
    ELSE
      P_SQL := P_SQL ||
               ' where to_number(to_char(CHANGEDATE,''YYYYMMDD''))>= :begin';
      P_SQL := P_SQL ||
               ' and to_number(to_char(CHANGEDATE,''YYYYMMDD''))<= :end';
      P_SQL := P_SQL || ' and plantcode = :plant';
      P_SQL := P_SQL || ' and departcode like :depart';
      P_SQL := P_SQL || ' and EQU_ID like :equid';
      OPEN RET FOR P_SQL
        USING TO_NUMBER(TO_CHAR(A_BEGINDATE, 'YYYYMMDD')), TO_NUMBER(TO_CHAR(A_ENDDATE,
                                                                             'YYYYMMDD')), A_PLANTCODE, A_DEPARTCODE,

      A_EQUID;
    END IF;
    RETURN 'Success';
  END;
  --查询备件更换历史记录
  FUNCTION GET_BJ_CHANGE_LOG(A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                            ,
                             RET              OUT SYS_REFCURSOR)
    RETURN VARCHAR2 IS
  BEGIN
    OPEN RET FOR
      SELECT BJ_UNIQUE_CODE, --备件唯一编码
             TO_CHAR(CHANGEDATE, 'YYYY/MM/DD') CHANGEDATE, --更换时间
             CHANGE_SITE_DESC, --更换位置
             CHANGE_EQUNAME, --更换设备
             DIRECTION, --更换方向
             REMARK, --备注
             MATERIALNAME, --物资描述
             UNIT, --计量单位
             change_amount,
             SUPPLY_NAME
        FROM VIEW_RUN_BJ_CHANGE_LOG
       WHERE BJ_UNIQUE_CODE = A_BJ_UNIQUE_CODE
          OR CHANGE_SITE_ID IN
             (SELECT RUN_BJ_CYCLE.SITE_ID
                FROM RUN_BJ_CYCLE
               WHERE RUN_BJ_CYCLE.BJ_UNIQUE_CODE = A_BJ_UNIQUE_CODE)
       ORDER BY CHANGEDATE DESC;
    RETURN 'Success';
  END;
  --查询当前设备位置备件情况
  FUNCTION GET_SITE_BJ_ALL_SITE(A_EQUID VARCHAR2, --设备ID
                                A_SITE  VARCHAR2,
                                RET     OUT SYS_REFCURSOR) RETURN VARCHAR2 IS
    P_CYCLEID RUN_CYCLE_DIC.CYCLE_ID%TYPE := '作业时间';
  BEGIN
    OPEN RET FOR
      SELECT SITE_ID --位置ID
            ,
             SITE_DESC --当前位置描述
            ,
             BJ_ID --备件ID
            ,
             BJ_UNIQUE_CODE --备件唯一编码
            ,
             MATERIALCODE --物资编码
            ,
             MATERIALNAME --物资名称
            ,
             UNIT --计量单位
            ,
             CHANGEDATE --最近更换时间
            ,
             BJ_STATUS --当前备件状态
            ,
             (SELECT SUM(RUN_EQU_YEILD.INSERT_VALUE)
                FROM RUN_EQU_YEILD
               WHERE RUN_EQU_YEILD.EQU_ID = A_EQUID
                 AND RUN_EQU_YEILD.WORKDATE >= VIEW_RUN_SITE_BJ.CHANGEDATE
                 AND RUN_EQU_YEILD.CYCLE_ID = P_CYCLEID) INSERT_VALUE --作业时间
            ,
             (SELECT RUN_BJ_ALERT_CURENT.ALERT_VALUE
                FROM RUN_BJ_ALERT_CURENT
               WHERE RUN_BJ_ALERT_CURENT.BJ_UNIQUE_CODE =
                     VIEW_RUN_SITE_BJ.BJ_UNIQUE_CODE
                 AND RUN_BJ_ALERT_CURENT.CYCLE_ID = P_CYCLEID) ALERT_VALUE --报警值
            ,
             (SELECT RUN_BJ_ALERT_CURENT.ALERT_VALUE +
                     RUN_BJ_ALERT_CURENT.OFFSET
                FROM RUN_BJ_ALERT_CURENT
               WHERE RUN_BJ_ALERT_CURENT.BJ_UNIQUE_CODE =
                     VIEW_RUN_SITE_BJ.BJ_UNIQUE_CODE
                 AND RUN_BJ_ALERT_CURENT.CYCLE_ID = P_CYCLEID) ALERT_OFFSET_VALUE --报警值+偏移量

        FROM VIEW_RUN_SITE_BJ
       WHERE EQU_ID = A_EQUID
         AND SITE_ID LIKE A_SITE;
    RETURN 'Success';
  END;
  FUNCTION GET_SITE_BJ_ALL(A_EQUID        VARCHAR2, --设备ID
                           A_PLANTCODE    VARCHAR2,
                           A_DEPARTCODE   VARCHAR2,
                           A_STATUS       VARCHAR2,
                           A_MATERIALCODE VARCHAR2,
                           A_MATERIALNAME VARCHAR2,
                           RET            OUT SYS_REFCURSOR) RETURN VARCHAR2 IS
    P_CYCLEID  RUN_CYCLE_DIC.CYCLE_ID%TYPE := '作业时间';
    p_pre_flag number(5, 0) := 0;
  BEGIN
    select count(*)
      into p_pre_flag
      from pm_preloadware p
     where p.v_code = A_MATERIALCODE;
    if p_pre_flag = 0 then
      OPEN RET FOR
        SELECT SITE_ID, --位置ID
               SITE_DESC, --当前位置描述
               bj_amount,
               BJ_ID, --备件ID
               BJ_UNIQUE_CODE, --备件唯一编码
               MATERIALCODE, --物资编码
               MATERIALNAME, --物资名称
               UNIT, --计量单位
               CHANGEDATE, --最近更换时间
               SUPPLY_CODE,
               SUPPLY_NAME,
               NVL(BJ_STATUS, '不在用') BJ_STATUS, --当前备件状态
               (SELECT SUM(RUN_EQU_YEILD.INSERT_VALUE)
                  FROM RUN_EQU_YEILD
                 WHERE RUN_EQU_YEILD.EQU_ID = A_EQUID
                   AND RUN_EQU_YEILD.WORKDATE >= VIEW_RUN_SITE_BJ.CHANGEDATE
                   AND RUN_EQU_YEILD.CYCLE_ID = P_CYCLEID) INSERT_VALUE, --作业时间

               (SELECT RUN_BJ_ALERT_CURENT.ALERT_VALUE
                  FROM RUN_BJ_ALERT_CURENT
                 WHERE RUN_BJ_ALERT_CURENT.BJ_UNIQUE_CODE =
                       VIEW_RUN_SITE_BJ.BJ_UNIQUE_CODE
                   AND RUN_BJ_ALERT_CURENT.CYCLE_ID = P_CYCLEID) ALERT_VALUE, --报警值

               (SELECT RUN_BJ_ALERT_CURENT.ALERT_VALUE +
                       RUN_BJ_ALERT_CURENT.OFFSET
                  FROM RUN_BJ_ALERT_CURENT
                 WHERE RUN_BJ_ALERT_CURENT.BJ_UNIQUE_CODE =
                       VIEW_RUN_SITE_BJ.BJ_UNIQUE_CODE
                   AND RUN_BJ_ALERT_CURENT.CYCLE_ID = P_CYCLEID) ALERT_OFFSET_VALUE --报警值+偏移量

          FROM VIEW_RUN_SITE_BJ
         WHERE EQU_ID LIKE A_EQUID
           AND NVL(BJ_STATUS, '不在用') LIKE A_STATUS
           AND NVL(PLANTCODE, '0') LIKE A_PLANTCODE
           AND NVL(DEPARTCODE, '0') LIKE A_DEPARTCODE
           and BJ_ID in
               (select m.bj_id
                  from run_bj_material m
                 where m.materialcode LIKE A_MATERIALCODE || '%');
    else
      OPEN RET FOR
        SELECT SITE_ID, --位置ID
               SITE_DESC, --当前位置描述
               bj_amount
          FROM VIEW_RUN_SITE_BJ
         WHERE pre_flag = '1';
    end if;
    RETURN 'Success';
  END;

  --更换备件
  FUNCTION CHANGE_BJ(A_BJ_UNIQUE_CODE VARCHAR2, --备件唯一编码
                     a_bj_amount      number,
                     A_BJ_ID          VARCHAR2, --备件ID
                     A_MATERIALCODE   VARCHAR2, --物资编码
                     A_SITE_ID        VARCHAR2, --更换位置Id
                     A_EQUID          VARCHAR2, --更换设备ID
                     A_PERSON         VARCHAR2, --更换人名
                     A_ORDERID        VARCHAR2, --工单
                     A_REMARK         VARCHAR2, --备注
                     A_CHANGEDATE     DATE, --更换日期
                     A_PLANTCODE      VARCHAR2, --厂矿编码
                     A_DEPARTCODE     VARCHAR2, --作业区编码
                     A_SUPPLY_CODE    VARCHAR2, --供应商编码
                     A_SUPPLY_NAME    VARCHAR2, --供应商名
                     A_FAULTREASON    VARCHAR2,
                     A_REASON_REMARK  VARCHAR2,
                     RET_BJ           OUT VARCHAR2, --换下备件唯一编码
                     RET_MSG          OUT VARCHAR2) RETURN VARCHAR2 IS
    P_RET                VARCHAR2(10) := 'Fail';
    P_OLD_BJ_UNIQUE_CODE VARCHAR2(50);
    P_NEW_BJ_UNIQUE_CODE VARCHAR2(50);
    P_OLD_PAIR           VARCHAR2(36);
    P_NEW_PAIR           VARCHAR2(36) := FUNC_RUN_GUID();
    p_old_changeamount   number(18, 6) := 0;
    p_old_changedate     RUN_BJ_CYCLE.Changedate%type;

    p_site_desc run_site_dic.site_desc%type;
    p_equ_desc  run_equ_dic.equ_desc%type;
  BEGIN
    --获取设备和备件安装位置描述
    begin
      select s.site_desc
        into p_site_desc
        from run_site_dic s
       where s.site_id = A_SITE_ID;
      select p.v_equname
        into p_equ_desc
        from sap_pm_equ_p p
       where p.v_equcode = A_EQUID;
    exception
      when others then
        null;
    end;
    if p_site_desc is not null and p_equ_desc is not null then
      BEGIN
        SELECT BJ_UNIQUE_CODE, PAIR_FLAG, c.changedate, c.bj_amount
          INTO P_OLD_BJ_UNIQUE_CODE,
               P_OLD_PAIR,
               p_old_changedate,
               p_old_changeamount
          FROM RUN_BJ_CYCLE c
         WHERE SITE_ID = A_SITE_ID;
      EXCEPTION
        WHEN OTHERS THEN
          P_OLD_BJ_UNIQUE_CODE := NULL;
      END;
      BEGIN
        SELECT BJ_UNIQUE_CODE
          INTO P_NEW_BJ_UNIQUE_CODE
          FROM RUN_BJ_CYCLE
         WHERE BJ_UNIQUE_CODE = A_BJ_UNIQUE_CODE;
      EXCEPTION
        WHEN OTHERS THEN
          P_NEW_BJ_UNIQUE_CODE := NULL;
      END;
      if p_old_changedate is null or
         (to_number(to_char(p_old_changedate, 'YYYYMMDD')) <
         to_number(to_char(A_CHANGEDATE, 'YYYYMMDD'))) then
        BEGIN
          SAVEPOINT S;
          --换下备件
          IF P_OLD_BJ_UNIQUE_CODE IS NOT NULL THEN
            UPDATE RUN_BJ_CYCLE
               SET SITE_ID    = NULL,
                   CHANGEDATE = A_CHANGEDATE,
                   BJ_STATUS  = '在修'
            -- SUPPLY_CODE = A_SUPPLY_CODE,
            -- SUPPLY_NAME = A_SUPPLY_NAME
             WHERE BJ_UNIQUE_CODE = P_OLD_BJ_UNIQUE_CODE;
            DELETE FROM RUN_BJ_ALERT_CURENT
             WHERE BJ_UNIQUE_CODE = P_OLD_BJ_UNIQUE_CODE;
            INSERT INTO RUN_CYCLE_BJ_CHANGE_LOG
              (ID,
               BJ_UNIQUE_CODE,
               CHANGEDATE,
               CHANGE_SITE_ID,
               CHANGEPERSON,
               ORDERID,
               DIRECTION,
               REMARK,
               SUPPLY_CODE,
               SUPPLY_NAME,
               JK_STATUS,
               PAIR_FLAG,
               FAULTREASON,
               REASON_REMARK,
               change_amount)
            VALUES
              (FUNC_RUN_GUID(),
               P_OLD_BJ_UNIQUE_CODE,
               A_CHANGEDATE,
               A_SITE_ID,
               A_PERSON,
               A_ORDERID,
               '换下',
               A_REMARK,
               NULL,
               NULL,
               '0',
               P_OLD_PAIR,
               A_FAULTREASON,
               A_REASON_REMARK,
               p_old_changeamount);
          END IF;
          --安装备件
          IF P_NEW_BJ_UNIQUE_CODE IS NOT NULL THEN
            UPDATE RUN_BJ_CYCLE
               SET SITE_ID    = A_SITE_ID,
                   CHANGEDATE = A_CHANGEDATE,
                   BJ_STATUS  = '在用',
                   PAIR_FLAG  = P_NEW_PAIR,
                   bj_amount  = a_bj_amount
             WHERE BJ_UNIQUE_CODE = P_NEW_BJ_UNIQUE_CODE;
          ELSE

            P_NEW_BJ_UNIQUE_CODE := A_BJ_UNIQUE_CODE;
            INSERT INTO RUN_BJ_CYCLE
              (BJ_UNIQUE_CODE,
               MATERIALCODE,
               BJ_ID,
               SITE_ID,
               NEWOROLD,
               CHANGEDATE,
               ADMIN,
               BJ_STATUS,
               PLANTCODE,
               DEPARTCODE,
               SUPPLY_CODE,
               SUPPLY_NAME,
               PAIR_FLAG,
               bj_amount)
            VALUES
              (P_NEW_BJ_UNIQUE_CODE,
               A_MATERIALCODE,
               A_BJ_ID,
               A_SITE_ID,
               '新品',
               A_CHANGEDATE,
               A_PERSON,
               '在用',
               A_PLANTCODE,
               A_DEPARTCODE,
               A_SUPPLY_CODE,
               A_SUPPLY_NAME,
               P_NEW_PAIR,
               a_bj_amount);
          END IF;
          INSERT INTO RUN_BJ_ALERT_CURENT
            (ID, BJ_UNIQUE_CODE, CYCLE_ID, ALERT_VALUE, OFFSET)
            SELECT FUNC_RUN_GUID(),
                   P_NEW_BJ_UNIQUE_CODE,
                   CYCLE_ID,
                   CYCLE_VALUE,
                   0
              FROM RUN_BJ_CYCLE_BASIC
             WHERE BJ_ID = A_BJ_ID;
          INSERT INTO RUN_CYCLE_BJ_CHANGE_LOG
            (ID,
             BJ_UNIQUE_CODE,
             CHANGE_SITE_ID,
             CHANGEDATE,
             CHANGEPERSON,
             ORDERID,
             DIRECTION,
             REMARK,
             SUPPLY_CODE,
             SUPPLY_NAME,
             PAIR_FLAG,
             change_amount,
             change_site_desc,
             change_equ_id,
             change_equ_desc)
          VALUES
            (FUNC_RUN_GUID(),
             P_NEW_BJ_UNIQUE_CODE,
             A_SITE_ID,
             A_CHANGEDATE,
             A_PERSON,
             A_ORDERID,
             '安装',
             A_REMARK,
             A_SUPPLY_CODE,
             A_SUPPLY_NAME,
             P_NEW_PAIR,
             a_bj_amount,
             p_site_desc,
             a_equid,
             p_equ_desc);
          --更新备件条码表
          update RUN_WO_BARCODE b
             set b.change_flag = '1', b.change_date = sysdate
           where b.barcode = P_NEW_BJ_UNIQUE_CODE
             and b.orderid = a_orderid
             and b.change_flag = '0';
          COMMIT;
          P_RET   := 'Success';
          RET_MSG := '备件更换成功';
        EXCEPTION
          WHEN OTHERS THEN
            ROLLBACK TO S;
            RET_MSG := '备件更换失败' || SQLERRM;
        END;
      else
        RET_MSG := '备件更换日期不能早于安装日期';
      end if;
    else
      RET_MSG := '选择的设备或备件安装位置已失效，请联系管理员处理';
    end if;
    RET_BJ := P_OLD_BJ_UNIQUE_CODE;
    RETURN P_RET;
  END;

  --查询当前备件的周期设置
  FUNCTION GET_BJ_CURRENT_SET(A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                             ,
                              RET              OUT SYS_REFCURSOR)
    RETURN VARCHAR2 IS
  BEGIN
    OPEN RET FOR
      SELECT CYCLE_DESC --周期描述
            ,
             ALERT_VALUE --报警值
            ,
             OFFSET --预警偏移量
        FROM VIEW_RUN_BJ_ALERT
       WHERE BJ_UNIQUE_CODE = A_BJ_UNIQUE_CODE;
    RETURN 'Success';
  END;
  --更新当前备件的周期设置
  FUNCTION SET_BJ_CURRENT_ALERT(A_BJ_UNIQUE_CODE VARCHAR2 --备件唯一编码
                               ,
                                A_CYCLE_ID       VARCHAR2 --周期类型ID
                               ,
                                A_ALERT_VALUE    NUMBER --报警值
                               ,
                                A_OFFSET         NUMBER --预警偏移量
                               ,
                                RET_MSG          OUT VARCHAR2)
    RETURN VARCHAR2 IS
    P_RET   VARCHAR2(10) := 'Fail';
    P_COUNT NUMBER(2, 0) := 0;
  BEGIN
    SELECT COUNT(*)
      INTO P_COUNT
      FROM RUN_BJ_ALERT_CURENT
     WHERE BJ_UNIQUE_CODE = A_BJ_UNIQUE_CODE
       AND CYCLE_ID = A_CYCLE_ID;
    IF P_COUNT = 0 THEN
      INSERT INTO RUN_BJ_ALERT_CURENT
        (ID, BJ_UNIQUE_CODE, CYCLE_ID, ALERT_VALUE, OFFSET)
      VALUES
        (FUNC_RUN_GUID(),
         A_BJ_UNIQUE_CODE,
         A_CYCLE_ID,
         A_ALERT_VALUE,
         A_OFFSET);
    ELSE
      UPDATE RUN_BJ_ALERT_CURENT
         SET ALERT_VALUE = A_ALERT_VALUE, OFFSET = A_OFFSET
       WHERE BJ_UNIQUE_CODE = A_BJ_UNIQUE_CODE
         AND CYCLE_ID = A_CYCLE_ID;
    END IF;
    COMMIT;
    RET_MSG := '操作成功';
    P_RET   := 'Success';
    RETURN P_RET;
  EXCEPTION
    WHEN OTHERS THEN
      RET_MSG := '操作失败';
      RETURN P_RET;
  END;
END PG_RUN_BJ_CHANGE;
/

