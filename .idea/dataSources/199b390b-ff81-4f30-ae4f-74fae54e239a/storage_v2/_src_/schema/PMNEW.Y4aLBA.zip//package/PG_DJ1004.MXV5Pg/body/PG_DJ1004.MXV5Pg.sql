create package BODY pg_dj1004 is
  -- 查询入库台帐
  procedure getinputlist(a_begindate    date, --起始时间
                         a_enddate      date, --结束时间
                         a_plantcode    varchar2, --厂矿编码
                         a_departcode   varchar2, --部门编码
                         a_itype        varchar2, --物资分类
                         a_store_desc   varchar2, --库房描述
                         a_materialcode varchar2, --物资编码
                         a_materialname varchar2, --物资名称
                         a_etalon       varchar2, --规格
                         a_loc_desc     varchar2, --存放位置描述
                         a_userid       varchar2,
                         ret            out sys_refcursor) is
    p_begin number(8, 0) := to_number(to_char(a_begindate, 'YYYYMMDD'));
    p_end   number(8, 0) := to_number(to_char(a_enddate, 'YYYYMMDD'));
  begin
    open ret for
      select null materialcode,
             null kcid,
             null materialname,
             null etalon,
             null unit,
             null f_price,
             sum(k.amount) amount,
             sum(k.f_price * k.amount) f_money,
              sum(k.ky_amount) ky_amount,
             sum(k.ky_amount * k.f_price) f_kymoney,
             null store_desc,
             null i_type,
             null insertdate,
             null kcid
        from dj_mat_kc k
       where k.plantcode = a_plantcode
         and k.departcode like a_departcode
         and k.i_type like a_itype
         and nvl(k.store_desc, '0') like '%' || a_store_desc || '%'
         and nvl(k.materialcode, '0') like '%' || a_materialcode || '%'
         and nvl(k.materialname, '0') like '%' || a_materialname || '%'
         and nvl(k.loc_desc, '0') like '%' || a_loc_desc || '%'
         and nvl(k.etalon,'-') like '%' || a_etalon || '%'
         and to_number(to_char(insertdate, 'YYYYMMDD')) between p_begin and
             p_end
         and k.useflag = '1'
             union all
      select k.materialcode,
             k.kcid,
             k.materialname,
             k.etalon,
             k.unit,
             k.f_price,
             k.amount,
             (k.f_price * k.amount) f_money,
               ky_amount,
             ky_amount * f_price f_kymoney,
             k.store_desc,
             k.i_type,
             k.insertdate,
             k.kcid
        from dj_mat_kc k
       where k.plantcode = a_plantcode
         and k.departcode like a_departcode
         and k.i_type like a_itype
         and nvl(k.store_desc, '0') like '%' || a_store_desc || '%'
         and nvl(k.materialcode, '0') like '%' || a_materialcode || '%'
         and nvl(k.materialname, '0') like '%' || a_materialname || '%'
         and nvl(k.loc_desc, '0') like '%' || a_loc_desc || '%'
          and nvl(k.etalon,'-') like '%' || a_etalon || '%'
         and to_number(to_char(insertdate, 'YYYYMMDD')) between p_begin and
             p_end
          and k.useflag = '1'
       order by insertdate desc;
  end;
end pg_dj1004;
/

