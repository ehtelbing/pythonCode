create PROCEDURE DEL_SAP_PM_EQU_FILE(V_V_FILENAME IN VARCHAR2,
                                                V_CURSOR OUT VARCHAR2)IS
BEGIN
     delete
     from SAP_PM_EQU_FILE V
     where V.V_FILENAME=V_V_FILENAME;
     commit;
     V_CURSOR := 'Success';
exception
  when others then
    V_CURSOR := '删除失败:' || sqlerrm;
end DEL_SAP_PM_EQU_FILE;
/

