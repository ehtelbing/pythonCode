create package pg_dj1007 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/21 13:16:19
  -- Purpose :
  --获取申料清单
  procedure getapplymat(a_begindate date, --起始日期
                        a_enddate   date, --结束日期
                        a_itype     varchar2, --物资分类
                        a_name      varchar2, --物资名称
                        ret         out sys_refcursor);
  --新增申料
  procedure saveapplymat(a_code       varchar2, --物资编码
                         a_name       varchar2, --物资名称
                         a_etalon     varchar2, --规格型号
                         a_unit       varchar2, --计量单位
                         a_itype      varchar2, --物资分类
                         a_amount     number, --数量
                         a_applydate  date, --日期
                         a_remark     varchar2, --备注
                         a_groupname  varchar2, --班组
                         a_lypersonid varchar2,
                         a_lyperson   varchar2, --领用人名
                         a_userid     varchar2, --用户ID
                         a_username   varchar2, --用户名
                         a_kcid       varchar2, --库存ID
                         ret_msg      out varchar2,
                         ret          out varchar2);
  --删除申料
  procedure deleteapplymat(a_applyid  varchar2, --申料ID
                           a_userid   varchar2, --用户ID
                           a_username varchar2, --用户名
                           ret_msg    out varchar2,
                           ret        out varchar2);
end pg_dj1007;
/

