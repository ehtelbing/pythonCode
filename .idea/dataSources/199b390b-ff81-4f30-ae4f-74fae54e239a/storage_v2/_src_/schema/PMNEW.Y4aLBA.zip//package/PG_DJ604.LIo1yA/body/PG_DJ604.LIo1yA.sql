create package BODY pg_dj604 is
  --电机维修台帐
  procedure getdjmendtable(a_datetype        varchar2, --时间类型
                           a_begindate       date, --            起始日期
                           a_enddate         date, --结束日期
                           a_dj_series_class varchar2, --电机类型
                           a_orderid         varchar2, --检修编号
                           a_sendplant       varchar2, --送修单位
                           a_plant           varchar2, --检修单位
                           a_dept            varchar2, --检修厂矿
                           a_group           varchar2, --检修班组
                           ret               out sys_refcursor) is
  begin
    open ret for
      select o.orderid,
             a.apply_plantname,
             o.dj_vol,
             o.dj_v,
             null dj_equposition,
             o.mend_context,
             to_char(o.plan_begindate, 'YYYY/MM/DD') plan_begindate,
             to_char(o.exa_date, 'YYYY/MM/DD') exa_date,
             to_char(o.out_date, 'YYYY/MM/DD') out_date,
             round(nvl(o.exa_date, sysdate) - o.plan_begindate, 1) exa_time,
             round(nvl(o.out_date, sysdate) - o.plan_begindate, 1) out_time,
             nvl(o.menddept_name, m.menddept_name) menddept_name,
             a.remark,
             o.mend_username,
             o.mend_type
        from dj_order o
        left outer join dj_order_status s
          on s.order_status = o.order_status
        left outer join DJ_OS_ORDERAPPLY a
          on a.apply_id = o.apply_id
        left outer join dj_menddept m
          on m.menddept_code = o.menddept_code
        left outer join dj_main d on d.dj_unique_code = o.dj_uq_code
       where (a_datetype = '入厂时间' and o.plan_begindate between a_begindate and
             a_enddate or a_datetype = '出厂时间' and
             o.out_date between a_begindate and a_enddate or
             a_datetype = '合格时间' and o.exa_date between a_begindate and
             a_enddate or a_datetype = '在修电机' and s.finish_flag <> '1')
         and nvl(d.dj_series_class, 0) like a_dj_series_class
         and o.orderid like '%' || a_orderid || '%'
         and a.apply_plant like a_sendplant
         and o.plantcode like a_plant
         and o.departcode like a_dept
         and nvl(o.menddept_code, '0') like a_group;
  end;
end pg_dj604;
/

