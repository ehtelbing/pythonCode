create package PG_DJ703 is
  --检修状态配置页
  --查询
  procedure pro_dj703_select(v_orderdesc varchar2,
                             v_cursor    out sys_refcursor);
  --删除
  procedure pro_dj703_delete(v_ordersts varchar2, ret out varchar2);
  --选择
  procedure pro_dj703_updateflag(v_ordersts varchar2,
                                 v_flag     number,
                                 ret        out varchar2);
  --新增
  procedure pro_dj703_insert(v_ordersts  varchar2,
                             v_orderdesc varchar2,
                             v_userflag  varchar2,
                             v_nextsts   varchar2,
                             ret         out varchar2);
end PG_DJ703;
/

