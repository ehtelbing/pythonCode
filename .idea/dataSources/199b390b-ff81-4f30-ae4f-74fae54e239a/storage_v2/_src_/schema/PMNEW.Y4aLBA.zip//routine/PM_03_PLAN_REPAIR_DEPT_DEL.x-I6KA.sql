create procedure PM_03_PLAN_REPAIR_DEPT_DEL(V_V_GUID          IN VARCHAR2,
                                                       V_V_REPAIR_DEPTCODE IN VARCHAR2,
                                                       V_CURSOR          OUT VARCHAR2) is
begin
  /* 月计划、周计划删除*/

  Delete from PM_03_PLAN_REPAIR_DEPT D
   WHERE D.V_GUID = V_V_GUID
     AND D.V_REPAIR_DEPTCODE = V_V_REPAIR_DEPTCODE;
  COMMIT;
  V_CURSOR := 'SUCCESS';
exception
  when others then
    V_CURSOR := 'Fail';
end PM_03_PLAN_REPAIR_DEPT_DEL;
/

