create PROCEDURE BASE_FILE_IMAGE_INS(V_V_GUID         IN VARCHAR2, --信息GUID
                                                V_V_FILENAME     IN VARCHAR2, --附件名称
                                                V_V_FILEBLOB     IN BLOB, --附件流
                                                V_V_FILETYPECODE IN VARCHAR2, --附件类型编码
                                                V_V_PLANT        IN VARCHAR2, --上传厂矿
                                                V_V_DEPT         IN VARCHAR2, --上传作业区
                                                V_V_TIME         IN VARCHAR2, --上传时间
                                                V_V_PERSON       IN VARCHAR2, --上传人名
                                                V_V_REMARK       IN VARCHAR2, --备注
                                                V_INFO           OUT VARCHAR2) IS
  V_V_FILEGUID VARCHAR2(36) := FUNC_MM_GUID();
  /*附件上传过程*/
BEGIN
  INSERT INTO BASE_FILE
    (V_GUID,
     V_FILEGUID,
     V_FILENAME,
     V_FILEBLOB,
     V_FILETYPECODE,
     V_PLANT,
     V_DEPT,
     V_TIME,
     V_PERSON,
     V_REMARK)
  VALUES
    (V_V_GUID,
     V_V_FILEGUID,
     V_V_FILENAME,
     V_V_FILEBLOB,
     V_V_FILETYPECODE,
     V_V_PLANT,
     V_V_DEPT,
     TO_DATE(V_V_TIME, 'yyyy-mm-dd'),
     V_V_PERSON,
     V_V_REMARK);

  V_INFO := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;

END BASE_FILE_IMAGE_INS;
/

