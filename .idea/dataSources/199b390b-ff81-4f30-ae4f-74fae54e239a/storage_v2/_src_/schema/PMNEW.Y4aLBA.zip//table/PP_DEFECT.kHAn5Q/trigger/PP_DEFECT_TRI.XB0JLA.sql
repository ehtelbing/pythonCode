create trigger PP_DEFECT_TRI
  before insert
  on PP_DEFECT
  for each row
BEGIN
  SELECT PP_DEFECT_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
END PP_DEFECT_TRI;
/

