create package body PG_DJ802 is
  --前置工序下拉
  procedure pro_dj802_gxdroplist(v_cursor out sys_refcursor) as
  begin
    open v_cursor for
      select a.model_et_id, a.et_no from DJ_MODEL_ET a;
  end;
  --检修模型维护页面
  procedure pro_dj802_select(v_modelname in varchar2,
                             v_cursor    out sys_refcursor) as
  begin
    open v_cursor for
      select *
        from DJ_MODEL a
       where a.use_flag = '1'
         and a.model_name like v_modelname || '%';
  end;
  --新增
  procedure pro_dj802_insert(v_modelcode  varchar2, --模型编码
                             v_modelname  varchar2, --模型名称
                             v_userid     varchar2, --创建人
                             v_username   varchar2, --创建名称
                             v_insertdate date, --创建日期
                             v_userflag   varchar2, --使用状态
                             v_remark     varchar2, --备注
                             ret          out varchar2) as
  begin
    savepoint s;
    insert into DJ_MODEL
    values
      (v_modelcode,
       v_modelname,
       v_userid,
       v_username,
       v_insertdate,
       v_userflag,
       v_remark);
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --删除
  procedure pro_dj802_delete(v_modelcode in varchar2, ret out varchar2) as
  begin
    savepoint s;
    delete DJ_MODEL a where a.model_code = v_modelcode;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --点击模型工序
  procedure pro_dj802_gxselect(v_modelcode varchar2,
                               v_cursor    out sys_refcursor) as
  begin
    open v_cursor for
      select * from DJ_MODEL_ET a where a.model_code = v_modelcode;
  end;
  --模型工序新增
  procedure pro_dj802_gxinsert(v_etno         varchar2, --工序号
                               v_modelcode    varchar2, --模型编码
                               v_etcontext    varchar2, --工序内容
                               v_planworktime number, --计划工时
                               v_planperson   number, --计划人数
                               v_peretid      varchar2, --前置工序ID
                               ret            out varchar2) as
  begin
    savepoint s;
    insert into DJ_MODEL_ET
    values
      (func_new_guid(),
       v_etno,
       v_modelcode,
       v_etcontext,
       v_planworktime,
       v_planperson,
       v_peretid);
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --模型工序删除
  procedure pro_dj802_gxdelete(v_modeletid varchar2, ret out varchar2) as
  begin
    savepoint s;
    delete DJ_MODEL_ET a where a.model_et_id = v_modeletid;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --模型物耗维护页面
  procedure pro_dj802_whselect(v_modelcode varchar2,
                               v_cursor    out sys_refcursor) as
  begin
    open v_cursor for
      select * from DJ_MODEL_MAT a where a.model_code = v_modelcode;
  end;
  --模型物耗 新增
  procedure pro_dj802_whinsert(v_modelcode    varchar2, --模型编码
                               v_MATERIALCODE varchar2, --物料编码
                               v_MATERIALNAME varchar2, --物料名称
                               v_ETALON       varchar2, --规格型号
                               v_MATCL        varchar2, --材质
                               v_UNIT         varchar2, --单位
                               v_F_PRICE      number, --单价
                               v_PLAN_AMOUNT  number, --计划数量
                               ret            out varchar) as
  begin
    savepoint s;
    insert into DJ_MODEL_MAT
    values
      (func_new_guid(),
       v_modelcode,
       v_MATERIALCODE,
       v_MATERIALNAME,
       v_ETALON,
       v_MATCL,
       v_UNIT,
       v_F_PRICE,
       v_PLAN_AMOUNT);
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
  --模型物耗删除
  procedure pro_dj802_whdelete(v_modelmatid varchar2, ret out varchar2) as
  begin
    savepoint s;
    delete DJ_MODEL_MAT a where a.model_mat_id = v_modelmatid;
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret := 'Fail';
  end;
end PG_DJ802;
/

