create trigger AM_SEND_LOG_TRI
  before insert
  on AM_SEND_LOG
  for each row
BEGIN
  SELECT AM_SEND_LOG_SEQ.NEXTVAL INTO :NEW.I_ID FROM DUAL;
END AM_SEND_LOG_TRI;
/

