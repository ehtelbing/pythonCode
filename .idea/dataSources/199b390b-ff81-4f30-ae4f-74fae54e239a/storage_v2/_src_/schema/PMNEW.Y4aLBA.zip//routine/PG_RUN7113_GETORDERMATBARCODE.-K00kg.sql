create procedure pg_run7113_getordermatbarcode(a_orderid      varchar2, --???
                                                           a_materialcode varchar2, --???
                                                            V_CURSOR  out sys_refcursor)
is
begin

    open V_CURSOR for
      select b.barcode, --????????
             b.barid --??ID
        from run_wo_barcode b
       where b.materialcode = a_materialcode
         and b.orderid = a_orderid
         and nvl(b.change_flag, '0') = '0'
       order by barcode;

end pg_run7113_getordermatbarcode;
/

