create procedure BASE_GX_AQCS_DEL(V_V_JXGX_CODE in varchar2,
                                             V_V_AQCS_CODE in varchar2,
                                             V_INFO        out varchar2) is
  /*删除检修工序的安全措施*/
begin
  delete from PM_1917_JXGX_AQCS_DATA B
   where B.V_AQCS_CODE = V_V_AQCS_CODE
     and B.V_JXGX_CODE = V_V_JXGX_CODE;
  V_INFO := 'SUCCESS';
exception
  when others then
    V_INFO := sqlerrm;
end BASE_GX_AQCS_DEL;
/

