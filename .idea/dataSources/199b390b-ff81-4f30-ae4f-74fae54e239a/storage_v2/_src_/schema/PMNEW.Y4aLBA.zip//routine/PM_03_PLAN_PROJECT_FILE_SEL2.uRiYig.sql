create procedure PM_03_PLAN_PROJECT_FILE_SEL2(V_V_GUID     IN VARCHAR2, --关系guid
                                                        V_V_FILEGUID IN VARCHAR2, --附件唯一值
                                                        V_V_FILENAME IN VARCHAR2, --附件名称
                                                        V_V_TYPE     IN VARCHAR2,
                                                        V_COUNT      OUT VARCHAR2,
                                                        V_CURSOR     OUT SYS_REFCURSOR) is

begin
  SELECT COUNT(*)
    INTO V_COUNT
    FROM PM_03_PLAN_PROJECT_FILE F
    LEFT OUTER JOIN DX_FILETYPE D
      ON f.v_type = d.id
    WHERE F.V_GUID = V_V_GUID
       AND F.V_FILEGUID LIKE '%' || V_V_FILEGUID || '%'
       AND F.V_FILENAME LIKE '%' || V_V_FILENAME || '%'
       AND F.V_TYPE like '%' || V_V_TYPE || '%'
       AND F.V_MODE_GUID IS NULL;
  OPEN V_CURSOR FOR
    SELECT F.ID,
           F.V_GUID,
           F.V_FILEGUID,
           F.V_FILENAME,
           F.V_INPERCODE,
           F.V_INPERNAME,
           F.V_TYPE,
           F.V_INTIME,
           F.V_FILETYPE,
           D.FNAME
      FROM PM_03_PLAN_PROJECT_FILE F
      LEFT OUTER JOIN DX_FILETYPE D
        ON f.v_type = d.id
     WHERE F.V_GUID = V_V_GUID
       AND F.V_FILEGUID LIKE '%' || V_V_FILEGUID || '%'
       AND F.V_FILENAME LIKE '%' || V_V_FILENAME || '%'
       AND F.V_TYPE like '%' || V_V_TYPE || '%'
       AND F.V_MODE_GUID IS NULL;
end PM_03_PLAN_PROJECT_FILE_SEL2;
/

