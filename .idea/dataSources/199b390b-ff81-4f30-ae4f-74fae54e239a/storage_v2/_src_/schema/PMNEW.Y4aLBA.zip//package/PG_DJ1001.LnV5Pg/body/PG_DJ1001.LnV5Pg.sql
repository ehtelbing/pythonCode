create package BODY pg_dj1001 is
  --查询储备入库
  procedure getinput(a_plantcode    varchar2, --厂矿编码
                     a_departcode   varchar2, --部门编码
                     a_itype        varchar2, --物资分类
                     a_store_desc   varchar2, --库房描述
                     a_materialcode varchar2, --物资编码
                     a_materialname varchar2, --物资名称
                     a_etalon       varchar2, --规格
                     a_loc_desc     varchar2, --存放位置描述
                     a_userid       varchar2,
                     ret            out sys_refcursor) is
  begin
    open ret for
      select k.materialcode,
             k.kcid,
             k.materialname,
             k.etalon,
             k.unit,
             k.f_price,
             k.amount,
             (k.f_price * k.amount) f_money,
             k.store_desc,
             k.i_type,
             k.loc_desc,
             k.mpid,
             k.remark
        from dj_mat_kc k
       where k.useflag = '0'
         and k.plantcode = a_plantcode
         and k.departcode = a_departcode
         and k.i_type like a_itype
         and nvl(k.store_desc, '0') like '%' || a_store_desc || '%'
         and nvl(k.materialcode, '0') like '%' || a_materialcode || '%'
         and nvl(k.materialname, '0') like '%' || a_materialname || '%'
         and nvl(k.loc_desc, '0') like '%' || a_loc_desc || '%'
         and nvl(k.etalon, '0') like '%' || a_etalon || '%'
         and insert_userid = a_userid
       order by insertdate desc;
  end;
  --入库
  procedure saveinput(a_kcid         varchar2, --原库存ID
                      a_materialcode varchar2, -- 物资编码
                      a_materialname varchar2, --物资名称
                      a_etalon       varchar2, --规格
                      a_unit         varchar2, --单位
                      a_price        number, --单价
                      a_amount       number, --数量
                      a_storedesc    varchar2, --库房描述
                      a_locdesc      varchar2, --位置描述
                      a_itype        varchar2, --物资分类
                      a_plantcode    varchar2, --厂矿编码
                      a_departcode   varchar2, --部门编码
                      a_departname   varchar2, --部门名称
                      a_userid       varchar2, --录入人ID
                      a_username     varchar2, --录入人
                      a_mpid         varchar2,
                      ret_msg        out varchar2,
                      ret            out varchar2) is
    p_kcid         dj_mat_kc.kcid%type := func_new_guid();
    p_materialcode dj_mat_kc.materialcode%type := a_materialcode;
    p_unit         dj_mat_itype.type_unit%type := a_unit;
  begin
    ret := 'Fail';
    savepoint s;
    if a_kcid is not null then
      delete from dj_mat_kc where kcid = a_kcid;
    else
      mattype_unitandprefix(a_itype, p_materialcode, p_unit);
    end if;

    insert into dj_mat_kc
      (kcid,
       plantcode,
       departcode,
       departname,
       materialcode,
       materialname,
       etalon,
       unit,
       f_price,
       amount,
       ky_amount,
       insertdate,
       insert_userid,
       insert_username,
       store_desc,
       loc_desc,
       useflag,
       i_type,
       mpid)
    values
      (p_kcid,
       a_plantcode,
       a_departcode,
       a_departname,
       p_materialcode,
       a_materialname,
       a_etalon,
       a_unit,
       a_price,
       a_amount,
       a_amount,
       sysdate,
       a_userid,
       a_username,
       a_storedesc,
       a_locdesc,
       '0',
       a_itype,
       a_mpid);
    commit;
    ret := 'Success';
  exception
    when others then
      rollback to s;
      ret     := 'Fail';
      ret_msg := sqlerrm;
  end;
  --删除
  procedure deleteinput(a_kcid  varchar2, --库存ID
                        ret_msg out varchar2,
                        ret     out varchar2) is
  begin
    ret := 'Fail';
    delete from dj_mat_kc
     where kcid = a_kcid
       and useflag = '0';
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
  --确认
  procedure confirminput(a_kcid  varchar2, --库存ID
                         ret_msg out varchar2,
                         ret     out varchar2) is
  begin
    ret := 'Fail';
    update dj_mat_kc
       set useflag = '1'
     where kcid = a_kcid
       and useflag = '0';
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
  --获取分类自定义单位和编码
  procedure mattype_unitandprefix(a_itype    varchar2,
                                  ret_prefix out varchar2,
                                  ret_unit   out varchar2) is
    p_unit   dj_mat_itype.type_unit%type;
    p_prefix dj_mat_itype.type_prefix%type;
    p_max    dj_mat_kc.materialcode%type;
  begin
    begin
      select nvl(type_unit, 'PC'), nvl(type_prefix, a_itype)
        into p_unit, p_prefix
        from dj_mat_itype t
       where t.typecode = a_itype;
    exception
      when others then
        p_unit   := 'PC';
        p_prefix := 'TMP';
    end;
    ret_unit := p_unit;
    begin
      select max(kc.materialcode)
        into p_max
        from dj_mat_kc kc
       where kc.materialcode like p_prefix || '%';
      if p_max is not null then
        ret_prefix := p_prefix ||
                      to_char(to_number(substr(p_max,
                                               length(p_prefix) + 1,
                                               length(p_max))) + 1);
      else
        ret_prefix := p_prefix || '100000000001';
      end if;
    exception
      when others then
        ret_prefix := p_prefix || '100000000001';
    end;
  end;
  --查询计划
  procedure getmp(a_year       number, --年份
                  a_month      number, --月份
                  a_plantcode  varchar2,
                  a_departcode varchar2,
                  a_code       varchar2, --物资编码
                  a_name       varchar2, --物资名称
                  ret          out sys_refcursor) is
  begin
    open ret for
      select mo.*, (mo.amount - mo.ly_amount) able_amount
        from (select m.id,
                     m.materialcode,
                     m.materialname,
                     m.materialelaton,
                     m.materialunit,
                     m.plan_price,
                     m.amount,
                     m.i_type,
                     m.plan_price * m.amount f_money,
                     (select nvl(sum(amount), 0)
                        from dj_mat_kc k
                       where k.mpid = m.id) ly_amount
                from view_mm_monthplan_detail@NAMM.FJWZ m
               where m.plantcode = a_plantcode
                 and m.departcode = a_departcode
                 and m.i_year = a_year
                 and m.i_month = a_month
                 and m.materialcode like '%' || a_code || '%'
                 and m.materialname like '%' || a_name || '%'
                 and m.cancelflag = 0
                 and m.id not in (select nvl(mpid, '0')
                                    from dj_mat_kc k
                                   where k.mp_kc_flag = '1')) mo
       where (mo.amount - mo.ly_amount) > 0;
  end;
  --提帐物资关联
  procedure mptokc(a_mpid   varchar2, --计划ID
                   a_kcid   varchar2, --库存ID
                   a_remark varchar2, --备注信息
                   ret      out varchar2,
                   ret_msg  out varchar2) is
  begin
    ret := 'Fail';
    update dj_mat_kc k
       set k.mpid = a_mpid, k.remark = a_remark, k.mp_kc_flag = '1'
     where k.kcid = a_kcid;
    commit;
    ret     := 'Success';
    ret_msg := '操作成功';
  exception
    when others then
      ret_msg := '操作失败，原因：' || sqlerrm;
  end;
end pg_dj1001;
/

