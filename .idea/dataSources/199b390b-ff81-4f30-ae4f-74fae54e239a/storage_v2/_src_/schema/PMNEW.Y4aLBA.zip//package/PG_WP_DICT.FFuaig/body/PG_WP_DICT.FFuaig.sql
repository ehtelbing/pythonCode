create PACKAGE BODY PG_WP_DICT
/*
说明：维修计划专业分类
*/
IS
    --获取全部专业分类
    FUNCTION GET_DICT_ALL(A_USEFLAG VARCHAR2
    ,RET OUT SYS_REFCURSOR)
    RETURN VARCHAR2
    IS
BEGIN
    OPEN RET FOR
    SELECT DICTID --专业分类Id
          ,DICT_DESC --专业分类描述
          ,USEFLAG
          ,CASE USEFLAG WHEN '1' THEN '已启用' ELSE '已停用' END USEFLAG_DESC
      FROM WP_PLAN_DICT
     WHERE USEFLAG LIKE A_USEFLAG;
    RETURN 'Success';
END;
--添加，修改专业分类
FUNCTION OP_DICT(A_DICTID VARCHAR2 --专业分类Id
,A_DICT_DESC VARCHAR2 --专业分类描述
,A_USEFLAG VARCHAR2 --使用标识
,A_OP VARCHAR2)
RETURN VARCHAR2
IS
    P_RET VARCHAR2(10) := 'Fail';
    BEGIN
        IF A_OP = 'add' THEN
            INSERT INTO WP_PLAN_DICT
                   (DICTID
                   ,DICT_DESC
                   ,USEFLAG)
            VALUES (A_DICTID
                   ,A_DICT_DESC
                   ,A_USEFLAG) ;
        ELSIF A_OP = 'update' THEN
            UPDATE WP_PLAN_DICT
               SET DICT_DESC = A_DICT_DESC
                  ,USEFLAG = A_USEFLAG
             WHERE DICTID = A_DICTID;
        END IF;
        COMMIT;
        RETURN 'Success';
    EXCEPTION
        WHEN OTHERS THEN
        --  dbms_output.put_line(sqlerrm);
            RETURN P_RET;
    END;
    --获取厂矿专业室负责人列表
    FUNCTION GET_DICT_PLANT_MANAGER(A_DICTID VARCHAR2 --专业分类Id
    ,A_PLANTCODE VARCHAR2 --厂矿编码
    ,RET OUT SYS_REFCURSOR
    )
    RETURN VARCHAR2
    IS
    BEGIN
        OPEN RET FOR
        SELECT ID,DICT_USERID --负责人ID
              ,DICT_USERNAME --负责人名
          FROM WP_PLAN_DICT_PLANT_MANAGER
         WHERE DICTID = A_DICTID
           AND PLANTCODE = A_PLANTCODE;
        RETURN 'Success';
END;
--添加，删除厂矿设备室负责人
FUNCTION OP_DICT_PLANT_MANAGER(A_ID VARCHAR2 --ID
,A_DICTID VARCHAR2--专业分类Id
,A_PLANTCODE VARCHAR2--厂矿编码
,A_USERID VARCHAR2 --负责人ID
,A_OP VARCHAR2)
RETURN VARCHAR2
IS
    P_RET VARCHAR2(10) := 'Fail';
    BEGIN
        IF A_OP = 'add' THEN
            INSERT INTO WP_PLAN_DICT_PLANT_MANAGER
                   (ID
                   ,DICTID
                   ,PLANTCODE
                   ,DICT_USERID
                   ,DICT_USERNAME)
            VALUES (FUNC_RUN_GUID()
                   ,A_DICTID
                   ,A_PLANTCODE
                   ,A_USERID
                   ,FUNC_WP_GETUSERNAME(A_USERID) ) ;
        ELSIF A_OP = 'delete' THEN
            DELETE
              FROM WP_PLAN_DICT_PLANT_MANAGER
             WHERE ID = A_ID;
    END IF;
    COMMIT;
    RETURN 'Success';
EXCEPTION
    WHEN OTHERS THEN
        RETURN P_RET;
END;
--获取厂矿使用的专业分类
FUNCTION GET_DICT_PLANT(A_PLANTCODE VARCHAR2 --厂矿编码
,RET OUT SYS_REFCURSOR)
RETURN VARCHAR2
IS
    BEGIN
        OPEN RET FOR
        SELECT P.DICTID --专业分类Id
              ,D.DICT_DESC --专业分类描述
          FROM WP_PLAN_DICT_PLANT P
          LEFT OUTER
          JOIN WP_PLAN_DICT D ON D.DICTID = P.DICTID
         WHERE D.USEFLAG = '1'
           AND P.PLANTCODE = A_PLANTCODE;
        RETURN 'Success';
END;
--添加,删除厂矿使用专业分类
FUNCTION OP_PLANT_DICT(A_DICTID VARCHAR2 ----专业分类Id
,A_PLANTCODE VARCHAR2--厂矿编码
,A_OP VARCHAR2)
RETURN VARCHAR2
IS
    P_RET VARCHAR2(10) := 'Fail';
    BEGIN
        IF A_OP = 'add' THEN
            INSERT INTO WP_PLAN_DICT_PLANT
                   (DICTID
                   ,PLANTCODE)
            VALUES (A_DICTID
                   ,A_PLANTCODE) ;
        ELSIF A_OP = 'delete' THEN
            DELETE
              FROM WP_PLAN_DICT_PLANT
             WHERE DICTID = A_DICTID
               AND PLANTCODE = A_PLANTCODE;
    END IF;
    COMMIT;
    RETURN 'Success';
EXCEPTION
    WHEN OTHERS THEN
        RETURN P_RET;
END;
END PG_WP_DICT;
/

