create package body PG_DJ801 is
  --检修模型信息查询
  procedure pro_dj801_select(v_modelname in varchar2,
                             v_cursor    out sys_refcursor) as
  begin
    open v_cursor for
      select * from DJ_MODEL a where a.model_name like v_modelname || '%';

  end;
  --查看模型工序
  procedure pro_dj801_selectet(v_modelcode varchar2,
                               v_cursor    out sys_refcursor) as
  begin
    open v_cursor for
      select * from DJ_MODEL_ET a where a.model_code = v_modelcode;
  end;
  --查看模型物料
  procedure pro_dj801_selectmet(v_modelcode varchar2,
                                v_cursor    out sys_refcursor) as
  begin
    open v_cursor for
      select * from DJ_MODEL_MAT a where a.model_code = v_modelcode;
  end;
end PG_DJ801;
/

