create package pg_dj1002 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/8/10 15:14:47
  -- Purpose :
  -- 获取库存列表
  procedure getkc(a_plantcode    varchar2, --厂矿编码
                  a_departcode   varchar2, --部门编码
                  a_itype        varchar2, --物资分类
                  a_store_desc   varchar2, --库房描述
                  a_materialcode varchar2, --物资编码
                  a_materialname varchar2, --物资名称
                  a_etalon       varchar2, --规格
                  a_loc_desc     varchar2, --存放位置描述
                  a_userid       varchar2, --用户ID
                  ret            out sys_refcursor);
  --消耗明细
  procedure getconsumedetail(a_kcid varchar2, --库存ID
                             ret    out sys_refcursor);
  --修改库房描述
  procedure setStoredesc(a_kcid          varchar2,
                         a_new_storedesc varchar2,
                         ret_msg         out varchar2,
                         ret             out varchar2);
end pg_dj1002;
/

