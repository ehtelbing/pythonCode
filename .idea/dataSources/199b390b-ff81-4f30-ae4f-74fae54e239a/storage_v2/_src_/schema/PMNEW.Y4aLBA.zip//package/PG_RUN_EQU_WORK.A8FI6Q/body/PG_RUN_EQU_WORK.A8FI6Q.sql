create PACKAGE BODY PG_RUN_EQU_WORK
/*
说明：设备运行
*/
 IS
  --查询当前设备报警台账
  FUNCTION GET_EQU_ALERT_ALL(A_EQUID    VARCHAR2,
                             A_CYCLE_ID VARCHAR2,
                             RET        OUT SYS_REFCURSOR) RETURN VARCHAR2 IS
  BEGIN
    OPEN RET FOR
      SELECT BJ_UNIQUE_CODE --备件唯一编码
            ,
             ALERT_VALUE --报警值
            ,
             OFFSET --预警偏移量
            ,
             ACT_ALERT_VALUE --实际报警值
            ,
             SUM_YEILD --作业量
            ,
             MATERIALCODE --物资编码
            ,
             MATERIALNAME --物资名称
            ,
             UNIT --计量单位
            ,
             SITE_DESC --当前位置
            ,
             NEWOROLD --新旧程度
            ,
             CHANGEDATE --更换时间
            ,
             BJ_STATUS --备件状态
            ,
             CYCLE_DESC || '(' || CYCLE_UNIT || ')' CYCLE_DESC --周期类型
        FROM VIEW_RUN_BJ_ALERT
       WHERE EQU_ID = A_EQUID
         AND CYCLE_ID LIKE A_CYCLE_ID;
    RETURN 'Success';
  END;
END PG_RUN_EQU_WORK;
/

