create PACKAGE PG_RUN_CYCLE
/*
说明：备件生命周期类型
*/
 IS
  --获取可用周期类型列表
  FUNCTION GET_CYCLE_ABLE(RET OUT SYS_REFCURSOR) RETURN VARCHAR2;
  --添加，修改，删除周期类型列表
  FUNCTION OP_CYCLE(A_CYCLE_ID   VARCHAR2 --周期ID
                   ,
                    A_CYCLE_DESC VARCHAR2 --周期描述
                   ,
                    A_CYCLE_UNIT VARCHAR2 --计算单位
                   ,
                    A_OP         VARCHAR2,
                    RET_MSG      OUT VARCHAR2) RETURN VARCHAR2;
  --查询所有周期类型
  FUNCTION GET_CYCLE_ALL(RET OUT SYS_REFCURSOR) RETURN VARCHAR2;
END PG_RUN_CYCLE;
/

