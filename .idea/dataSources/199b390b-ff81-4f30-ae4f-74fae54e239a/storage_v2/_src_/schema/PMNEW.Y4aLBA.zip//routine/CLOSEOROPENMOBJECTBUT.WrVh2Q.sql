create PROCEDURE CLOSEOROPENMOBJECTBUT(V_V_SOURCCEID   IN VARCHAR2,
                                                  V_V_WORKORDERID IN VARCHAR2,
                                                  V_V_TYPE        IN VARCHAR2,
                                                  V_CURSOR        OUT VARCHAR2) IS
BEGIN
  V_CURSOR := '';
  --return;

  CLOSEOROPENMOBJECTBUT_XSTZH(V_V_SOURCCEID, 
                              V_V_WORKORDERID,
                              V_V_TYPE,
                              V_CURSOR);

END CLOSEOROPENMOBJECTBUT;
/

