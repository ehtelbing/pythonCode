create package BODY pg_dj1006 is
  -- 获取消耗待回收工单
  procedure getconsumebyorder(a_begindate  date, --起始日期
                              a_enddate    date, --结束日期
                              a_orderid    varchar2, --检修单号
                              a_plantcode  varchar2, --厂矿编码
                              a_departcode varchar2, --部门编码
                              ret          out sys_refcursor) is
  begin
    open ret for
      select m.orderid,
             o.insertdate,
             o.dj_vol,
             o.dj_v,
             o.dj_name,
             o.dj_code,
             o.dj_uq_code,
             o.dj_type
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
        left outer join dj_mat_rec r
          on r.ordermatid = m.id
       where o.insertdate between a_begindate and a_enddate
         and m.orderid like '%' || a_orderid || '%'
         and o.PLANTCODE = a_plantcode
         and o.departcode = a_departcode
         and nvl(r.rec_flag, '0') = '0'
       group by m.orderid,
                o.insertdate,
                o.dj_vol,
                o.dj_v,
                o.dj_name,
                o.dj_code,
                o.dj_uq_code,
                o.dj_type;
  end;
  -- 获取消耗待回收
  procedure getordermatconsume(a_orderid varchar2, --检修单号
                               ret       out sys_refcursor) is
  begin
    open ret for
      select null orderid,
             null materialcode,
             '合计' materialname,
             null etalon,
             null unit,
             null f_price,
             sum(nvl(m.act_amount, m.plan_amount)) plan_amount,
             sum(m.f_price * nvl(m.act_amount, m.plan_amount)) f_money,
             null insertdate,
             null store_desc,
             null i_type,
             sum(rec_amount) rec_amount,
             null id,
             null dj_vol,
             null dj_v,
             null menddept_name,
             null mend_username
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
        left outer join dj_mat_rec r
          on r.ordermatid = m.id
       where m.orderid like '%' || a_orderid || '%'
         and nvl(r.rec_flag, '0') = '0'
      union all
      select m.orderid,
             m.materialcode,
             m.materialname,
             m.etalon,
             m.unit,
             m.f_price,
             nvl(m.act_amount, m.plan_amount),
             m.f_price * nvl(m.act_amount, m.plan_amount) f_money,
             o.insertdate,
             k.store_desc,
             k.i_type,
             r.rec_amount,
             m.id,
             o.dj_vol,
             o.dj_v,
             o.menddept_name,
             o.mend_username
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
        left outer join dj_mat_rec r
          on r.ordermatid = m.id
       where m.orderid like '%' || a_orderid || '%'
         and nvl(r.rec_flag, '0') = '0';
  end;
  -- 获取消耗待回收
  procedure getconsume(a_begindate    date, --起始日期
                       a_enddate      date, --结束日期
                       a_orderid      varchar2, --检修单号
                       a_plantcode    varchar2, --厂矿编码
                       a_departcode   varchar2, --部门编码
                       a_itype        varchar2, --物资分类
                       a_storedesc    varchar2, --库房描述
                       a_materialcode varchar2, --物资分类
                       a_materialname varchar2, --物资名称
                       a_etalon       varchar2, --规格
                       a_lcodesc      varchar2, --存放位置描述
                       ret            out sys_refcursor) is
  begin
    open ret for
      select null orderid,
             null materialcode,
             '合计' materialname,
             null etalon,
             null unit,
             null f_price,
             sum(nvl(m.act_amount, m.plan_amount)) plan_amount,
             sum(m.f_price * nvl(m.act_amount, m.plan_amount)) f_money,

             null insertdate,
             null store_desc,
             null i_type,
             sum(rec_amount) rec_amount,
             null id,
             null dj_vol,
             null dj_v,
             null menddept_name,
             null mend_username
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
        left outer join dj_mat_rec r
          on r.ordermatid = m.id
       where o.insertdate between a_begindate and a_enddate
         and m.orderid like '%' || a_orderid || '%'
         and o.PLANTCODE = a_plantcode
         and o.departcode = a_departcode
         and nvl(k.i_type, '0') in
             (select t.typecode
                from dj_mat_itype t
               where t.typecode like a_itype
                 and t.rec_status = '1')
         and nvl(k.store_desc, '0') like '%' || a_storedesc || '%'
         and nvl(m.materialcode, '0') like '%' || a_materialcode || '%'
         and nvl(m.materialname, '0') like '%' || a_materialname || '%'
         and nvl(m.etalon, '0') like '%' || a_etalon || '%'
         and nvl(k.loc_desc, '0') like '%' || a_lcodesc || '%'
         and nvl(r.rec_flag, '0') = '0'
      union all
      select m.orderid,
             m.materialcode,
             m.materialname,
             m.etalon,
             m.unit,
             m.f_price,
             nvl(m.act_amount, m.plan_amount) plan_amount,
             m.f_price * nvl(m.act_amount, m.plan_amount) f_money,
             o.insertdate,
             k.store_desc,
             k.i_type,
             r.rec_amount,
             m.id,
             o.dj_vol,
             o.dj_v,
             d.menddept_name,
             o.mend_username
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
        left outer join dj_mat_rec r
          on r.ordermatid = m.id
        left outer join dj_menddept d
          on d.menddept_code = o.menddept_code
       where o.insertdate between a_begindate and a_enddate
         and m.orderid like '%' || a_orderid || '%'
         and o.PLANTCODE = a_plantcode
         and o.departcode = a_departcode
         and nvl(k.i_type, '0') in
             (select t.typecode
                from dj_mat_itype t
               where t.typecode like a_itype
                 and t.rec_status = '1')
         and nvl(k.store_desc, '0') like '%' || a_storedesc || '%'
         and nvl(m.materialcode, '0') like '%' || a_materialcode || '%'
         and nvl(m.materialname, '0') like '%' || a_materialname || '%'
         and nvl(m.etalon, '0') like '%' || a_etalon || '%'
         and nvl(k.loc_desc, '0') like '%' || a_lcodesc || '%'
         and nvl(r.rec_flag, '0') = '0';
  end;
  -- 获取消耗待回收
  procedure getconsumeselect(a_begindate    date, --起始日期
                             a_enddate      date, --结束日期
                             a_orderid      varchar2, --检修单号
                             a_plantcode    varchar2, --厂矿编码
                             a_departcode   varchar2, --部门编码
                             a_itype        varchar2, --物资分类
                             a_storedesc    varchar2, --库房描述
                             a_materialcode varchar2, --物资分类
                             a_materialname varchar2, --物资名称
                             a_etalon       varchar2, --规格
                             a_lcodesc      varchar2, --存放位置描述
                             ret            out sys_refcursor) is
  begin
    open ret for
      select null orderid,
             null materialcode,
             '合计' materialname,
             null etalon,
             null unit,
             null f_price,
             sum(nvl(m.act_amount, m.plan_amount)) plan_amount,
             sum(m.f_price * nvl(m.act_amount, m.plan_amount)) f_money,
             null insertdate,
             null store_desc,
             null i_type,
             sum(rec_amount) rec_amount,
             null id,
             null dj_vol,
             null dj_v,
             null menddept_name,
             null MEND_USERNAME
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
        left outer join dj_mat_rec r
          on r.ordermatid = m.id
       where o.insertdate between a_begindate and a_enddate
         and m.orderid like '%' || a_orderid || '%'
         and o.PLANTCODE = a_plantcode
         and o.menddept_code like a_departcode || '%'
         and nvl(k.i_type, '0') like a_itype
         and nvl(k.store_desc, '0') like '%' || a_storedesc || '%'
         and nvl(m.materialcode, '0') like '%' || a_materialcode || '%'
         and nvl(m.materialname, '0') like '%' || a_materialname || '%'
         and nvl(m.etalon, '0') like '%' || a_etalon || '%'
         and nvl(k.loc_desc, '0') like '%' || a_lcodesc || '%'
         and nvl(r.rec_amount, 0) >= 0
         and nvl(r.rec_id, '0') <> '0'
      union all
      select m.orderid,
             null,
             m.materialname,
             null,
             max(m.unit),
             null,
             sum(nvl(m.act_amount, m.plan_amount)) plan_amount,
             sum(m.f_price * nvl(m.act_amount, m.plan_amount)) f_money,
             null,
             max(k.store_desc) store_desc,
             max(k.i_type) i_type,
             sum(r.rec_amount) rec_amount,
             null,
             max(o.dj_vol),
             max(o.dj_v),
             max(d.menddept_name) menddept_name,
             max(o.mend_username) MEND_USERNAME
        from dj_order_mat m
        left outer join dj_order o
          on o.orderid = m.orderid
        left outer join dj_mat_kc k
          on k.kcid = m.kcid
        left outer join dj_mat_rec r
          on r.ordermatid = m.id
        left outer join dj_menddept d
          on d.menddept_code = o.menddept_code
       where o.insertdate between a_begindate and a_enddate
         and m.orderid like '%' || a_orderid || '%'
         and o.PLANTCODE = a_plantcode
         and o.menddept_code like a_departcode || '%'
         and nvl(k.i_type, '0') like a_itype
         and nvl(k.store_desc, '0') like '%' || a_storedesc || '%'
         and nvl(m.materialcode, '0') like '%' || a_materialcode || '%'
         and nvl(m.materialname, '0') like '%' || a_materialname || '%'
         and nvl(m.etalon, '0') like '%' || a_etalon || '%'
         and nvl(k.loc_desc, '0') like '%' || a_lcodesc || '%'
         and nvl(r.rec_amount, 0) >= 0
         and nvl(r.rec_id, '0') <> '0'
       group by m.orderid, m.materialname;
  end;
  --保存回收数量
  procedure save_recamount(a_id         varchar2, --工单物料消耗id
                           a_rec_amount varchar2, --回收数量
                           a_userid     varchar2, --用户ID
                           a_username   varchar2, --用户姓名
                           ret_msg      out varchar2,
                           ret          out varchar2) is
    p_count number(2, 0) := 0;
  begin
    ret := 'Fail';
    select count(*)
      into p_count
      from dj_mat_rec r
     where r.ordermatid = a_id;
    if p_count = 0 then
      insert into dj_mat_rec
        (REC_ID,
         ORDERID,
         ORDERMATID,
         MAT_CODE,
         MAT_NAME,
         MAT_ETALON,
         MAT_CL,
         UNIT,
         F_PRICE,
         REC_AMOUNT,
         REC_DATE,
         USERID,
         USERNAME,
         REC_FLAG)
        select func_new_guid(),
               om.orderid,
               om.id,
               om.materialcode,
               om.materialname,
               om.etalon,
               om.mat_cl,
               om.unit,
               om.f_price,
               a_rec_amount,
               sysdate,
               a_userid,
               a_username,
               '0'
          from dj_order_mat om
         where om.id = a_id;
    else
      update dj_mat_rec
         set REC_AMOUNT = a_rec_amount
       where ordermatid = a_id
         and userid = a_userid;
    end if;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
  --确认回收
  procedure confirm_rec(a_id     varchar2, --工单物料消耗id
                        a_userid varchar2, --用户ID
                        ret_msg  out varchar2,
                        ret      out varchar2) is
  begin
    ret := 'Fail';
    update dj_mat_rec
       set rec_flag = '1'
     where ordermatid = a_id
       and userid = a_userid;
    commit;
    ret := 'Success';
  exception
    when others then
      ret_msg := sqlerrm;
  end;
end pg_dj1006;
/

