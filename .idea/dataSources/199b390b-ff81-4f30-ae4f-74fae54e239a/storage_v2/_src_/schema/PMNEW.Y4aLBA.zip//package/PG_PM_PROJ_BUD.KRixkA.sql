create package pg_pm_proj_bud is

  -- Author  : WY
  -- Created : 2017/11/6 8:57:01
  -- Purpose : 检修工程预算定额管理业务包

  --获取工程大类列表
  procedure getProjectClassList(ret out sys_refcursor);
  --获取工程列表
  procedure getProjectList(v_class_code varchar2, --工程大类代码
                           ret          out sys_refcursor);
  --获取定额预算费用表
  procedure getProjBudgetItemTable(v_class_code   varchar2, --工程大类代码
                                   v_proj_code    varchar2, --工程代码
                                   v_item_code    varchar2, --项目代码
                                   v_item_desc    varchar2, --项目描述
                                   v_dinge_code   varchar2, --定额代码
                                   v_machine_type varchar2, --主机规格型号
                                   v_machine_code varchar2, --主机代码
                                   v_machine_desc varchar2, --主机名
                                   ret            out sys_refcursor);
  --根据定额ID，获取项目预算详细信息，pg_pm_proj_bud.getProjectBudgetItemMessage
  procedure getProjectBudgetItemMessage(v_dinge_id varchar2, --定额ID
                                        ret        out sys_refcursor);
  --根据定额ID，获取人工预算明细，pg_pm_proj_bud.getProjectBudgetItemPersonTable。
  procedure getProjectBudgetItemPerTable(v_dinge_id varchar2, --定额ID
                                         ret        out sys_refcursor);
  --根据定额ID，获取机械预算明细，pg_pm_proj_bud.getProjectBudgetItemJXTable。
  procedure getProjectBudgetItemJXTable(v_dinge_id varchar2, --定额ID
                                        ret        out sys_refcursor);
  --根据定额ID，获取材料备件费用明细，pg_pm_proj_bud.getProjectBudgetItemMatTable。
  procedure getProjectBudgetItemMatTable(v_dinge_id varchar2, --定额ID
                                         ret        out sys_refcursor);
end pg_pm_proj_bud;
/

