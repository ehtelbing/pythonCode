create package pg_oil15 is

  -- Author  : ADMINISTRATOR
  -- Created : 2016/9/7 9:51:06
  -- Purpose : 1.5 设备类型设置（地址：JMM_AK/page/oil/1_5.jsp）

  -- 单击查询按钮，调用过程pg_oil15.getequtypelist表格数据。
  procedure getequtypelist(ret out sys_refcursor --返回数据集
                           );
  --打开“新增设备类型”界面，单击“保存”按钮，调用过程pg_oil15.addequtype保存
  procedure addequtype(a_equtype        varchar2, --设备类型编码
                       a_equtype_name   varchar2, --设备类型名称
                       a_equtype_remark varchar2, --设备类型备注
                       ret_msg          out varchar2, --反馈信息
                       ret              out varchar2 --执行结果
                       );
  --原数据调用pg_oil15.getequtypedetail加载
  procedure getequtypedetail(a_equtype varchar2, --设备类型编码
                             ret       out sys_refcursor --返回数据集
                             );
  --单击“保存”按钮，调用过程pg_oil15.updateequtype保存
  procedure updateequtype(a_equtype        varchar2, --设备类型编码
                          a_equtype_name   varchar2, --设备类型名称
                          a_equtype_remark varchar2, --设备类型备注
                          ret_msg          out varchar2, --反馈信息
                          ret              out varchar2 --执行结果
                          );
  --状态变更，调用过程pg_oil15.setequtypestatus过程设置状态
  procedure setequtypestatus(a_equtype varchar2, --设备类型编码
                             ret_msg   out varchar2, --反馈信息
                             ret       out varchar2 --执行结果
                             );
end pg_oil15;
/

