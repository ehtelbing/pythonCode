create procedure PM_03_PLAN_MONTH_SEL_WEEKVIEW(V_OTHERGRID VARCHAR2,
                                                          V_TYPE      VARCHAR2,
                                                          RET         OUT SYS_REFCURSOR) is
begin
  /* 月计划、年计划查找周计划详情 */

  OPEN RET FOR
    SELECT DISTINCT W.V_GUID,
    W.*
      FROM VIEW_PM_PLAN_WEEK W
     WHERE W.V_OTHERPLAN_GUID = V_OTHERGRID
       AND W.V_OTHERPLAN_TYPE = V_TYPE;

end PM_03_PLAN_MONTH_SEL_WEEKVIEW;
/

