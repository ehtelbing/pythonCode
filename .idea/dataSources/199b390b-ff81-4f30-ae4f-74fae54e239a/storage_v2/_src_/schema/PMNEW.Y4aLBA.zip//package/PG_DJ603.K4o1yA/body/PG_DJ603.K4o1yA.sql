create package BODY pg_dj603 is
  -- 获取任务维修票
  procedure getmendbilldetail(a_orderid varchar2, --工单号
                              ret       out sys_refcursor) is
  begin
    open ret for
      select o.orderid,
             o.dj_code,
             o.dj_name,
             o.dj_type,
             o.dj_vol,
             o.dj_v,
             o.piccode,
             o.phone_number,
             o.op_person,
             o.use_loc,
             o.req_time,
             o.plan_time,
             o.build_remark,
             ('半成品试验:' || s.bcsy_result || '；' || s.bcsy_result_desc ||
             '。成品试验' || s.csy_result || '；' || s.csy_result_desc) check_log,
             o.mend_context,
             1 amount,
             m.menddept_name,
             to_char(o.insertdate, 'YYYY/MM/DD') insertdate,
             a.apply_plantname
        from dj_order o
        left outer join dj_os_orderapply a
          on a.apply_id = o.apply_id
        left outer join dj_menddept m
          on m.menddept_code = o.menddept_code
        left outer join dj_order_sy s
          on s.orderid = o.orderid
       where o.orderid = a_orderid;
  end;
end pg_dj603;
/

