create PROCEDURE PM_03_PLAN_LOCKING_DATE_GET(V_I_YEAR       IN VARCHAR2,
                                                        V_I_QUARTER    IN VARCHAR2,
                                                        V_I_MONTH      IN VARCHAR2,
                                                        V_I_WEEKNUM    IN VARCHAR2,
                                                        V_V_TYPE       IN VARCHAR2, --计划类型 W / M  /  Q
                                                        V_V_DEPTCODE   IN VARCHAR2, --厂矿编码 eg：9906
                                                        V_V_PROCESS    IN VARCHAR2, --流程编码 eg: 月检修计划
                                                        V_V_STATUSCODE IN VARCHAR2, --流程状态编码 eg：2
                                                        V_CURSOR       OUT SYS_REFCURSOR --
                                                        ) IS
  V_I_NUMBER NUMBER;
  /*
    SXX
    2014-3-31
    PRO_PM_PLAN_LOCKING_DATE_GET2(
  --增加入参V_I_QUARTER，V_V_DEPTCODE,V_V_PROCESS,V_V_STATUSCODE
  --修改其中查询逻辑, 改为按V_V_DEPTCODE,V_V_PROCESS,V_V_STATUSCODE，年季度月周等直接查出。
  --取消原有的季度查询逻辑
  V_I_YEAR       IN VARCHAR2,
  V_I_QUARTER    IN VARCHAR2,
  V_I_MONTH      IN VARCHAR2,
  V_I_WEEKNUM    IN VARCHAR2,
  V_V_TYPE       IN VARCHAR2, --计划类型 W / M  /  Q
  V_V_DEPTCODE   IN VARCHAR2, --厂矿编码 eg：9906
  V_V_PROCESS    IN VARCHAR2, --流程编码 eg: 月检修计划
  V_V_STATUSCODE IN VARCHAR2, --流程状态编码 eg：2
  V_CURSOR       OUT SYS_REFCURSOR --

    */
BEGIN
  /*计划 截止时间 返回*/
  IF (V_V_TYPE = 'W') THEN

    SELECT COUNT(*)
      INTO V_I_NUMBER
      FROM PM_03_PLAN_LOCKING_DATE
     WHERE V_TYPE = V_V_TYPE
       AND I_YEAR = V_I_YEAR
       AND I_MONTH = V_I_MONTH
       and v_statuscode = V_V_STATUSCODE
       and v_process = V_V_PROCESS
       and v_deptcode = V_V_DEPTCODE;
    IF (V_I_NUMBER > 0) THEN

      OPEN V_CURSOR FOR
        SELECT '周计划' AS V_TYPE,
               I_YEAR || '年' || I_MONTH || '月' || I_WEEKNUM || '周' AS V_PLANDATE,
               D_DATE_E,
               I_LOCK
          FROM PM_03_PLAN_LOCKING_DATE
         WHERE V_TYPE = V_V_TYPE
           AND I_YEAR = V_I_YEAR
           AND I_MONTH = V_I_MONTH
           AND I_WEEKNUM = V_I_WEEKNUM
           and v_statuscode = V_V_STATUSCODE
           and v_process = V_V_PROCESS
           and v_deptcode = V_V_DEPTCODE;
    ELSE
      OPEN V_CURSOR FOR
        SELECT '周计划' AS V_TYPE,
               V_I_YEAR || '年' || V_I_MONTH || '月' || V_I_WEEKNUM || '周' AS V_PLANDATE,
               SYSDATE AS D_DATE_E,
               1 AS I_LOCK
          FROM DUAL;
    END IF;
  END IF;
  IF (V_V_TYPE = 'M') THEN
    SELECT COUNT(*)
      INTO V_I_NUMBER
      FROM PM_03_PLAN_LOCKING_DATE
     WHERE V_TYPE = V_V_TYPE
       AND I_YEAR = V_I_YEAR
       AND I_MONTH = V_I_MONTH
       and v_statuscode = V_V_STATUSCODE
       and v_process = V_V_PROCESS
       and v_deptcode = V_V_DEPTCODE;
    IF (V_I_NUMBER > 0) THEN
      OPEN V_CURSOR FOR
        SELECT '月计划' AS V_TYPE,
               I_YEAR || '年' || I_MONTH || '月' AS V_PLANDATE,
               D_DATE_E,
               I_LOCK
          FROM PM_03_PLAN_LOCKING_DATE
         WHERE V_TYPE = V_V_TYPE
           AND I_YEAR = V_I_YEAR
           AND I_MONTH = V_I_MONTH
           and v_statuscode = V_V_STATUSCODE
           and v_process = V_V_PROCESS
           and v_deptcode = V_V_DEPTCODE;
    ELSE
      OPEN V_CURSOR FOR
        SELECT '月计划' AS V_TYPE,
               V_I_YEAR || '年' || V_I_MONTH || '月' AS V_PLANDATE,
               SYSDATE AS D_DATE_E,
               1 AS I_LOCK
          FROM DUAL;
    END IF;
  END IF;

  IF (V_V_TYPE = 'Q') THEN
    SELECT COUNT(*)
      INTO V_I_NUMBER
      FROM PM_03_PLAN_LOCKING_DATE
     WHERE V_TYPE = V_V_TYPE
       AND I_YEAR = V_I_YEAR
       AND i_quarter = V_I_QUARTER
       and v_statuscode = V_V_STATUSCODE
       and v_process = V_V_PROCESS
       and v_deptcode = V_V_DEPTCODE;
    IF (V_I_NUMBER > 0) THEN
      OPEN V_CURSOR FOR
        SELECT '季度计划' AS V_TYPE,
               I_YEAR || '年' || I_MONTH || '季度' AS V_PLANDATE,
               D_DATE_E,
               I_LOCK
          FROM PM_03_PLAN_LOCKING_DATE
         WHERE V_TYPE = V_V_TYPE
           AND I_YEAR = V_I_YEAR
           AND i_quarter = V_I_QUARTER
           and v_statuscode = V_V_STATUSCODE
           and v_process = V_V_PROCESS
           and v_deptcode = V_V_DEPTCODE;
    ELSE
      OPEN V_CURSOR FOR
        SELECT '季度计划' AS V_TYPE,
               V_I_YEAR || '年' || V_I_MONTH || '季度' AS V_PLANDATE,
               SYSDATE AS D_DATE_E,
               1 AS I_LOCK
          FROM DUAL;
    END IF;
  END IF;

END PM_03_PLAN_LOCKING_DATE_GET;
/

