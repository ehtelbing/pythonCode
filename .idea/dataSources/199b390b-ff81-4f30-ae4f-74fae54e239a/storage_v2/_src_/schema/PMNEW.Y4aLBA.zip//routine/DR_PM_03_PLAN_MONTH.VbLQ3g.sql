create function DR_PM_03_PLAN_MONTH(V_V_YEAR  IN NUMBER, --年份
                                               V_V_MONTH IN VARCHAR2 --月份
                                               ) return varchar2 is
  V_INFO   varchar2(10) := 'FAIL';
  i_count  number(2, 0) := 0;
  V_V_GUID VARCHAR2(50);
begin
  begin
    for i in (select *
                from FX_DATA_YJH
               WHERE V_YJH_JHZT = '已放行' --已放行
           AND  V_YJH_JHNF = V_V_YEAR
           AND V_YJH_JHYF = V_V_MONTH) loop
      select count(*)
        into i_count
        from PM_03_PLAN_MONTH T1
       where T1.V_YEAR = i.V_YJH_JHNF
         AND T1.V_MONTH = i.V_YJH_JHYF
         AND T1.V_CONTENT = i.V_YJH_GCNR;
      if i_count = 0 then
        begin
          V_V_GUID := CREATEGUID();
          INSERT into PM_03_PLAN_MONTH
            (V_GUID,
             V_YEAR,
             V_MONTH,
             V_MONTHID,
             V_ORGCODE,
             V_DEPTCODE,
             V_EQUTYPECODE,
             V_EQUCODE,
             V_REPAIRMAJOR_CODE,
             V_CONTENT,
             V_STARTTIME,
             V_ENDTIME,
             V_HOUR,
             V_INDATE,
             V_INPER,
             V_FLOWCODE,
             V_FLOWORDER,
             V_FLOWTYPE,
             V_BZ,
             V_OTHERPLAN_GUID,
             V_OTHERPLAN_TYPE,
             V_JHMX_GUID,
             V_REPAIRDEPT_CODE,
             V_REPAIR_PERNAME,
             V_STATE,
             V_MAIN_DEFECT,
             V_EXPECT_AGE,
             V_REPAIR_PER,
             V_SGWAY,
             V_SGWAYNAME,
             V_FLAG,
             V_SBB_GUID)
          VALUES
            (V_V_GUID,
             i.V_YJH_JHNF,
             i.V_YJH_JHYF,
             FUNC_CREATEPLANID('MONTH',
                               (select V_DEPTCODE
                                  from BASE_DEPT
                                 where V_DEPT_WBS =
                                       (select V_DEPTWBS1
                                          from FX_BASE_DEPT
                                         WHERE V_DEPTCODE = i.V_ORGCODE)
                                   and rownum = 1)),
             (select V_DEPTCODE
                from BASE_DEPT
               where V_DEPT_WBS =
                     (select V_DEPTWBS1
                        from FX_BASE_DEPT
                       WHERE V_DEPTCODE = i.V_ORGCODE)),
             '',
             '',
             '',
             (select V_ZYXX_MC
                from FX_DIC_ZYXX
               where I_ZYXX_XH = i.I_ZYXX_XH),
             i.V_YJH_GCNR,
             i.D_YJH_YJKGRQ,
             i.D_YJH_YJJGRQ,
             i.I_YJH_YJGQ,
             i.D_YJH_XGSJ,
             (select V_LOGINNAME
                from BASE_PERSON
               where I_PERSONID = i.I_PERSONID),
             '',
             '',
             'MONTH',
             i.V_YJH_BZ,
             '',
             '',
             '',
             '',
             '',
             '50', --i.V_YJH_JHZT,
             '',
             '',
             '',
             i.I_SGFS_XH,
             (select V_SGFS_MC
                from FX_DIC_SGFS
               where I_SGFS_XH = i.I_SGFS_XH),
             '1',
             '');
        
         
            if i.V_CBS_WYBS1 is not null and i.V_CBS_WYBS1 <> ' ' then
              INSERT INTO PM_03_PLAN_REPAIR_DEPT
                (V_GUID,
                 V_REPAIR_DEPTCODE,
                 V_REPAIR_DEPTNAME,
                 V_WXJH_ORGGUID)
                select V_V_GUID, V_DEPTCODE, V_DEPTNAME, V_WXJH_REPAIRGUID
                  from BASE_DEPT
                 where V_WXJH_REPAIRGUID = i.V_CBS_WYBS1;
                 
            end if;
          if i.V_CBS_WYBS2 is not null and i.V_CBS_WYBS2 <> ' ' then
              INSERT INTO PM_03_PLAN_REPAIR_DEPT
                (V_GUID,
                 V_REPAIR_DEPTCODE,
                 V_REPAIR_DEPTNAME,
                 V_WXJH_ORGGUID)
                select V_V_GUID, V_DEPTCODE, V_DEPTNAME, V_WXJH_REPAIRGUID
                  from BASE_DEPT
                 where V_WXJH_REPAIRGUID = i.V_CBS_WYBS2;
                 
            end if;
            if i.V_CBS_WYBS3 is not null and i.V_CBS_WYBS3 <> ' ' then
              INSERT INTO PM_03_PLAN_REPAIR_DEPT
                (V_GUID,
                 V_REPAIR_DEPTCODE,
                 V_REPAIR_DEPTNAME,
                 V_WXJH_ORGGUID)
                select V_V_GUID, V_DEPTCODE, V_DEPTNAME, V_WXJH_REPAIRGUID
                  from BASE_DEPT
                 where V_WXJH_REPAIRGUID = i.V_CBS_WYBS3;
                 
            end if;
            if i.V_CBS_WYBS4 is not null and i.V_CBS_WYBS4 <> ' ' then
              INSERT INTO PM_03_PLAN_REPAIR_DEPT
                (V_GUID,
                 V_REPAIR_DEPTCODE,
                 V_REPAIR_DEPTNAME,
                 V_WXJH_ORGGUID)
                select V_V_GUID, V_DEPTCODE, V_DEPTNAME, V_WXJH_REPAIRGUID
                  from BASE_DEPT
                 where V_WXJH_REPAIRGUID = i.V_CBS_WYBS4;
                 
            end if;
            if i.V_CBS_WYBS5 is not null and i.V_CBS_WYBS5 <> ' ' then
              INSERT INTO PM_03_PLAN_REPAIR_DEPT
                (V_GUID,
                 V_REPAIR_DEPTCODE,
                 V_REPAIR_DEPTNAME,
                 V_WXJH_ORGGUID)
                select V_V_GUID, V_DEPTCODE, V_DEPTNAME, V_WXJH_REPAIRGUID
                  from BASE_DEPT
                 where V_WXJH_REPAIRGUID = i.V_CBS_WYBS5;
                
            end if;
            if i.V_CBS_WYBS6 is not null and i.V_CBS_WYBS6 <> ' ' then
              INSERT INTO PM_03_PLAN_REPAIR_DEPT
                (V_GUID,
                 V_REPAIR_DEPTCODE,
                 V_REPAIR_DEPTNAME,
                 V_WXJH_ORGGUID)
                select V_V_GUID, V_DEPTCODE, V_DEPTNAME, V_WXJH_REPAIRGUID
                  from BASE_DEPT
                 where V_WXJH_REPAIRGUID = i.V_CBS_WYBS6;
                 
            end if;
          commit;
        end;
      end if;
    end loop;
  
    /*MERGE INTO PM_03_PLAN_MONTH T1
    USING (select *
             from FX_DATA_YJH
            WHERE V_YJH_JHZT = '已放行' --已放行
              AND V_YJH_JHNF = V_V_YEAR
              AND V_YJH_JHYF = V_V_MONTH) T2
    ON (T1.V_YEAR = T2.V_YJH_JHNF AND T1.V_MONTH = T2.V_YJH_JHYF AND T1.V_CONTENT = T2.V_YJH_GCNR)
    WHEN NOT MATCHED THEN
      INSERT
        (V_GUID,
         V_YEAR,
         V_MONTH,
         V_MONTHID,
         V_ORGCODE,
         V_DEPTCODE,
         V_EQUTYPECODE,
         V_EQUCODE,
         V_REPAIRMAJOR_CODE,
         V_CONTENT,
         V_STARTTIME,
         V_ENDTIME,
         V_HOUR,
         V_INDATE,
         V_INPER,
         V_FLOWCODE,
         V_FLOWORDER,
         V_FLOWTYPE,
         V_BZ,
         V_OTHERPLAN_GUID,
         V_OTHERPLAN_TYPE,
         V_JHMX_GUID,
         V_REPAIRDEPT_CODE,
         V_REPAIR_PERNAME,
         V_STATE,
         V_MAIN_DEFECT,
         V_EXPECT_AGE,
         V_REPAIR_PER,
         V_SGWAY,
         V_SGWAYNAME,
         V_FLAG,
         V_SBB_GUID)
      VALUES
        (CREATEGUID(),
         T2.V_YJH_JHNF,
         T2.V_YJH_JHYF,
         FUNC_CREATEPLANID('MONTH',
                           (select V_DEPTCODE
                              from BASE_DEPT
                             where V_DEPT_WBS =
                                   (select V_DEPTWBS1
                                      from FX_BASE_DEPT
                                     WHERE V_DEPTCODE = T2.V_ORGCODE)
                               and rownum = 1)),
         (select V_DEPTCODE
            from BASE_DEPT
           where V_DEPT_WBS =
                 (select V_DEPTWBS1
                    from FX_BASE_DEPT
                   WHERE V_DEPTCODE = T2.V_ORGCODE)),
         '',
         '',
         '',
         '',
         T2.V_YJH_GCNR,
         T2.D_YJH_YJKGRQ,
         T2.D_YJH_YJJGRQ,
         T2.I_YJH_YJGQ,
         T2.D_YJH_XGSJ,
         (select V_LOGINNAME
            from BASE_PERSON
           where I_PERSONID = T2.I_PERSONID),
         '',
         '',
         'MONTH',
         T2.V_YJH_BZ,
         '',
         '',
         '',
         '',
         '',
         T2.V_YJH_JHZT,
         '',
         '',
         '',
         T2.I_SGFS_XH,
         (select V_SGFS_MC from FX_DIC_SGFS where I_SGFS_XH = T2.I_SGFS_XH),
         '',
         '');
    commit;*/
    V_INFO := 'SUCCESS';
    return v_info;
  end;
  /*EXCEPTION
  WHEN OTHERS THEN
    V_INFO := SQLERRM;
  return V_INFO;*/
end;
/

