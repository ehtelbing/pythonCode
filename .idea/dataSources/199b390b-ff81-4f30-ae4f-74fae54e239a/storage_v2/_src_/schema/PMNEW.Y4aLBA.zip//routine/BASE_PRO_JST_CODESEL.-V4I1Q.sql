create procedure BASE_PRO_JST_CODESEL(V_V_PERCODE IN VARCHAR2,
                                                 V_INFO      OUT VARCHAR2) is

  /*
  根据人员编码查询即时通账号
  */
begin

  SELECT P.V_JST
    INTO V_INFO
    FROM BASE_PERSON P
   WHERE P.V_PERSONCODE = V_V_PERCODE;
EXCEPTION
  WHEN OTHERS THEN
    V_INFO := '';
end BASE_PRO_JST_CODESEL;
/

