create procedure PM_03_MONTH_PLAN_CKSTAT_SEL(V_V_YEAR    IN VARCHAR2, --年份
                                                        V_V_MONTH   IN VARCHAR2, --月份
                                                        V_V_ORGCODE IN VARCHAR2, --厂矿编码
                                                        V_CURSOR    OUT SYS_REFCURSOR) is
  V_ALLNUM  NUMBER;
  V_EXENUM  NUMBER;
  V_EXTRATE NUMBER;
  /*
  月计划厂矿执行率
  */

begin
  FOR C IN (SELECT D.V_DEPTCODE, D.V_DEPTNAME
              FROM BASE_DEPT D
             WHERE D.V_DEPTTYPE LIKE '%基层单位%') LOOP

    SELECT COUNT(M.V_GUID)
      INTO V_ALLNUM
      FROM PM_03_PLAN_MONTH M
     WHERE M.V_YEAR = V_V_YEAR
       AND M.V_MONTH = V_V_MONTH
       AND M.V_ORGCODE = C.V_DEPTCODE
       AND M.V_STATE NOT IN ('10', '20','80', '99', '100');

    SELECT COUNT(*)
      INTO V_EXENUM
      FROM (SELECT DISTINCT M.V_OTHERPLAN_GUID
              FROM PM_03_PLAN_WEEK M
             WHERE M.V_OTHERPLAN_GUID IS NOT NULL
               AND M.V_OTHERPLAN_TYPE = 'MONTH'
               AND M.V_MONTH = V_V_MONTH
               AND M.V_YEAR = V_V_YEAR
               AND M.V_ORGCODE = C.V_DEPTCODE
               AND M.V_STATE NOT IN ('10', '20', '80','99', '100'));

    V_EXTRATE := ROUND(V_EXENUM / (CASE
                         WHEN V_ALLNUM = 0 THEN
                          1
                         ELSE
                          V_ALLNUM
                       END) * 100,
                       2);

    INSERT INTO TEMP_TABLE
      (V_1, V_2, V_3, V_4, V_5)
    VALUES
      (C.V_DEPTCODE, C.V_DEPTNAME, V_ALLNUM, V_EXENUM, V_EXTRATE);

  END LOOP;
  OPEN V_CURSOR FOR
    SELECT T.V_1 AS V_ORGCODE,
           T.V_2 AS V_ORGNAME,
           T.V_3 AS ALLNUM,
           T.V_4 AS EXENUM,
           T.V_5 AS EXTRATE
      FROM TEMP_TABLE T;
  /* OPEN V_CURSOR FOR
  SELECT M.V_ORGCODE,
         M.V_ORGNAME,
         COUNT(NVL(M.V_GUID, 0)) as ALLNUM,
         CASE
           WHEN M.V_OTHERPLAN_GUID IS NOT NULL THEN
            COUNT(M.V_OTHERPLAN_GUID)
           ELSE
            0
         END AS EXENUM,
         (CASE
           WHEN M.V_OTHERPLAN_GUID IS NOT NULL THEN
            COUNT(M.V_OTHERPLAN_GUID)
           ELSE
            0
         END) / COUNT(NVL(M.V_GUID, 0)) AS EXTRATE
    FROM VIEW_PM_PLAN_MONTH M
    LEFT JOIN PM_BASEDIC B
      ON M.V_FLOWCODE = B.V_BASECODE
     AND B.V_BASETYPE = 'PLAN/FLOW'
    LEFT JOIN PM_BASEDIC C
      ON M.V_STATE = C.V_BASECODE
     AND C.V_BASETYPE = 'PLAN/STATE'
   WHERE M.V_YEAR = V_V_YEAR
     AND M.V_MONTH = V_V_MONTH
     AND M.V_ORGCODE LIKE '%' || V_V_ORGCODE || '%'
   GROUP BY M.V_ORGCODE, M.V_ORGNAME, M.V_OTHERPLAN_GUID;*/

end PM_03_MONTH_PLAN_CKSTAT_SEL;
/

