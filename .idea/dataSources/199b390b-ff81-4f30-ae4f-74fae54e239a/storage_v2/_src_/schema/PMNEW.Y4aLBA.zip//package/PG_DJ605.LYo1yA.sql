create package pg_dj605 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/25 12:18:31
  -- Purpose :
  -- 查询可录入试验结果工单
  procedure getordersy(a_plantcode varchar2, --厂矿编码
                       a_menddept  varchar2, --检修部门编码
                       a_orderid   varchar2, --工单号
                       ret         out sys_refcursor);
                       procedure getordersyamount(a_plantcode varchar2, --厂矿编码
                             a_menddept  varchar2, --检修部门编码
                             ret         out number);
  --获取试验详细结果
  procedure ordersydetail(a_orderid varchar2, --工单号
                          ret       out sys_refcursor);
  --保存试验结果
  procedure saveordersy(a_orderid           varchar2, --工单号
                        a_bcsy_result       varchar2, --半成品试验结果
                        a_bcsy_result_desc  varchar2, --半成品试验结果说明
                        a_zbcsy_result      varchar2, --转子半成品试验结果
                        a_zbcsy_result_desc varchar2, --转子半成品试验结果说明
                        a_dbcsy_result      varchar2, --定子半成品试验结果
                        a_dbcsy_result_desc varchar2, --定子半成品试验结果说明
                        a_csy_result        varchar2, --成品试验结果
                        a_csy_result_desc   varchar2, --成品试验救国说明
                        a_userid            varchar2, --用户Id
                        a_username          varchar2, --用户姓名
                        a_sy_date           date, --试验日期
                        ret_msg             out varchar2,
                        ret                 out varchar2);
  --附件列表
  procedure filelist(a_orderid varchar2, --工单号
                     ret       out sys_refcursor);
  --文件上传
  procedure fileupdate(a_orderid     varchar2, --工单号
                       a_filename    varchar2, --文件名
                       a_file_extend varchar2, --扩展名
                       a_file        blob, --文件
                       a_username    varchar2, --上传人
                       ret_msg       out varchar2,
                       ret           out varchar2);
  --文件删除
  procedure filedelete(a_fileid varchar2, --文件ID
                       ret_msg  out varchar2,
                       ret      out varchar2);
  --附件下载
  procedure filedownload(a_fileid        varchar2, --文件ID
                         ret_filename    out varchar2, --文件名
                         ret_file_extend out varchar2, --扩展名
                         ret_file        out blob --文件
                         );
end pg_dj605;
/

