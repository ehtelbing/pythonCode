create procedure BASE_INSPECT_DAY_SELECT(V_EQUCODE VARCHAR2, --设备编码
                                                    V_PERCODE VARCHAR2, --当前登入人
                                                    RET       OUT SYS_REFCURSOR) is
  NUMID        varchar2(5);
  V_V_MAINGUID VARCHAR2(50);
  V_PERNAME    VARCHAR2(50);

begin

  /*
  判断当前登入人当天是否有录入记录
  */

  SELECT P.V_PERSONNAME
    INTO V_PERNAME
    FROM BASE_PERSON P
   WHERE P.V_PERSONCODE = V_PERCODE;

  SELECT COUNT(C.MAINGUID)
    INTO NUMID
    FROM BASE_INSPECT_DAY_CONTENT C
   WHERE TO_CHAR(C.IN_DATE, 'yyyyMMdd') = TO_CHAR(SYSDATE, 'yyyyMMdd')
     AND C.EQUCODE LIKE '%' || V_EQUCODE || '%'
     AND C.IN_PERCODE LIKE V_PERCODE;

  IF NUMID = 0 THEN
  
    V_V_MAINGUID := createguid();
  
    INSERT INTO BASE_INSPECT_DAY_CONTENT
      (MAINGUID,
       EQUCODE,
       EQUNAME,
       INSPECT_UNIT_CODE,
       INSPECT_UNIT,
       INSPECT_CONTENT,
       INSPECT_STANDARD,
       IN_PERCODE,
       IN_PERNAME,
       UUID,
       STATE_SIGN)
      SELECT V_V_MAINGUID,
             E.EQUCODE,
             E.EQUNAME,
             T.INSPECT_UNIT_CODE,
             T.INSPECT_UNIT,
             T.INSPECT_CONTENT,
             T.INSPECT_STANDARD,
             V_PERCODE,
             V_PERNAME,
             T.UUID,
             '0'
        FROM BASE_INSPECT_TOUNIT T
        LEFT OUTER JOIN BASE_INSPECT_TOEQU E
          ON E.INSPECT_UNIT_CODE = T.INSPECT_UNIT_CODE
       WHERE E.EQUCODE = V_EQUCODE;
    /*  
      OPEN RET FOR
        SELECT E.EQUCODE, --设备编码
               E.EQUNAME, --设备名称
               T.INSPECT_UNIT_CODE, --点检部位编码
               T.INSPECT_UNIT, --点检部位
               T.INSPECT_CONTENT, --点检内容
               T.INSPECT_STANDARD, --点检标准
               T.UUID,
               '' AS STATE_SIGN, ----异常状态
               '' AS MAINGUID --主guid()
          FROM BASE_INSPECT_TOUNIT T
          LEFT OUTER JOIN BASE_INSPECT_TOEQU E
            ON E.INSPECT_UNIT_CODE = T.INSPECT_UNIT_CODE
         WHERE E.EQUCODE = V_EQUCODE;
    
    ELSE
    发起人  显示列表 
      OPEN RET FOR
        SELECT C.EQUCODE, --设备编码
               C.EQUNAME, --设备名称
               C.INSPECT_UNIT_CODE, --点检部位编码
               C.INSPECT_UNIT, --点检部位名称
               C.INSPECT_CONTENT, --点检内容
               '' AS UUID,
               C.INSPECT_STANDARD, --点检标准
               C.STATE_SIGN, --异常状态
               C.MAINGUID --主guid()
          FROM BASE_INSPECT_DAY_CONTENT C
         WHERE TO_CHAR(C.IN_DATE, 'yyyyMMdd') = TO_CHAR(SYSDATE, 'yyyyMMdd')
           AND C.EQUCODE LIKE '%' || V_EQUCODE || '%'
           AND C.IN_PERCODE LIKE V_PERCODE;*/
  END IF;
  
  COMMIT;

  OPEN RET FOR
    SELECT C.EQUCODE, --设备编码
           C.EQUNAME, --设备名称
           C.INSPECT_UNIT_CODE, --点检部位编码
           C.INSPECT_UNIT, --点检部位名称
           C.INSPECT_CONTENT, --点检内容
           C.UUID AS UUID,
           C.INSPECT_STANDARD, --点检标准
           case when C.STATE_SIGN='0' then '正常' else '异常' end as STATE_SIGN , --异常状态
           C.MAINGUID,
           C.CHILDGUID --主guid()
      FROM BASE_INSPECT_DAY_CONTENT C
     WHERE TO_CHAR(C.IN_DATE, 'yyyyMMdd') = TO_CHAR(SYSDATE, 'yyyyMMdd')
       AND C.EQUCODE LIKE '%' || V_EQUCODE || '%'
       AND C.IN_PERCODE LIKE V_PERCODE;

end BASE_INSPECT_DAY_SELECT;
/

