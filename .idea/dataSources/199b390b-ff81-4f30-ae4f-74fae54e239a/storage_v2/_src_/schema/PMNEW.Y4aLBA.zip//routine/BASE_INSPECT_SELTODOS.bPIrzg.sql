create procedure BASE_INSPECT_SELTODOS(V_CHILDGUID VARCHAR2,
V_PERSON VARCHAR2,
RET OUT SYS_REFCURSOR) is
begin
  OPEN RET FOR
  SELECT C.MAINGUID,--主guid
         C.CHILDGUID,--子guid
         C.EQUCODE,--设备编码
         C.EQUNAME,--设备名称
         C.INSPECT_UNIT_CODE,--点检部件编码
         C.INSPECT_UNIT,--点检部件
         C.INSPECT_CONTENT,--点检内容
         C.INSPECT_STANDARD,--点检标准
         CASE WHEN C.STATE_SIGN='0' THEN '正常' ELSE '异常' END AS STATE_N_SIGN,--正常(0)异常(1)
         C.IN_PERCODE,--录入人编码
         C.IN_PERNAME,--录入人姓名
         C.IN_DATE,--录入时间
         C.UUID,
         W.IN_CLASS,--记录班组
         W.IN_CLASSNAME,--记录班组名称
         W.IN_PERCODE,---记录人
         W.IN_PERNAME,--记录人姓名
         W.NEXT_CLASS,
         W.NEXT_CLASSNAME,
         W.E_INSPECT_RESULTE,--设备点检结果
         W.C_REQUESTION,--本班检修问题
         W.L_EQUESTION,--遗留设备问题
         W.OTHER_QIUEST--其他问题
  FROM BASE_INSPECT_DAY_CONTENT C 
  LEFT OUTER JOIN  BASE_INSPECT_DAY_WRITE W
  ON W.MAINGUID=C.MAINGUID
  WHERE W.FLAG='0'
  AND W.NEXT_PERCODE=V_PERSON
  AND W.CHILDGUID=V_CHILDGUID;
  
end BASE_INSPECT_SELTODOS;
/

