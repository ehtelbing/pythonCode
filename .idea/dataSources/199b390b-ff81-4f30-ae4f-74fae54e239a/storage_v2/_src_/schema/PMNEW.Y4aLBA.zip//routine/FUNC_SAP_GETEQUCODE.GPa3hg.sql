create FUNCTION FUNC_SAP_GETEQUCODE(V_V_DEPTCODE IN VARCHAR2)
  RETURN VARCHAR2 IS
  V_RESULT         VARCHAR2(18);
  V_V_EQUCODE_NEXT VARCHAR2(18);
BEGIN
  /*返回一个新的SAP设备编码*/
  SELECT SUBSTR(REPLACE(TO_CHAR(NVL(MAX(V_EQUCODE), 1),
                                '000000000000000000'),
                        ' ',
                        ''),
                5)
    INTO V_V_EQUCODE_NEXT
    FROM SAP_PM_EQU_P T
   WHERE V_EQUCODE LIKE V_V_DEPTCODE || '%';
  V_RESULT := TO_NUMBER(REPLACE(TO_CHAR(V_V_DEPTCODE || V_V_EQUCODE_NEXT,
                                        '000000000000000000'),
                                ' ',
                                '')) + 1;
  RETURN(V_RESULT);
END FUNC_SAP_GETEQUCODE;
/

