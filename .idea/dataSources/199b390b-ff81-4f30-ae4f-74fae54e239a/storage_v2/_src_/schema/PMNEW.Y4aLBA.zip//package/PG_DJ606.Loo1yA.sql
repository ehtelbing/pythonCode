create package pg_dj606 is
  -- Author  : ADMINISTRATOR
  -- Created : 2015/9/25 13:11:14
  -- Purpose :
  --查询工单试验记录
  procedure getordersy(a_plantcode varchar2, --厂矿编码
                       a_menddept  varchar2, --检修部门编码
                       a_orderid   varchar2, --工单号
                       a_begindate date, --起始日期
                       a_enddate   date, --结束日期
                       ret         out sys_refcursor);
end pg_dj606;
/

