create PROCEDURE BASE_AQCS_SEL(V_V_AQCS_NAME IN VARCHAR2,
                                          V_CURSOR      OUT SYS_REFCURSOR) IS
  /*按安全措施名模糊查询*/
BEGIN
  OPEN V_CURSOR FOR
    SELECT *
      FROM PM_1917_AQCS P
     WHERE P.V_AQCS_NAME LIKE '%' || V_V_AQCS_NAME || '%';
END BASE_AQCS_SEL;
/

