create procedure BASE_INSPECT_WRITE_UPDATE(V_MAINGUID        VARCHAR2, ---主guid
                                                      V_CHILDGUID       VARCHAR2, --子guid
                                                      V_PERCODE         VARCHAR2, --编辑人员编码
                                                      V_NEXT_CLASS      VARCHAR2, --接班人班组编码
                                                      V_NEXTPERCODE     VARCHAR2, --接班人
                                                      V_INSPECT_RESULTE VARCHAR2,
                                                      V_REQUESTION      VARCHAR2,
                                                      V_EQUESTION       VARCHAR2,
                                                      V_OTHER_QIUEST    VARCHAR2,
                                                      RET               OUT VARCHAR2) is
  V_NEXTPERNAME   VARCHAR2(50);
  V_NEXTCLASSNAME VARCHAR2(50); --接班班组名称
begin
  --查询接收人姓名
  SELECT P.V_PERSONNAME
    INTO V_NEXTPERNAME
    FROM BASE_PERSON P
   WHERE P.V_PERSONCODE = V_NEXTPERCODE;
  --查询交班班组名

  SELECT S.V_SAP_WORKNAME
    INTO V_NEXTCLASSNAME
    FROM SAP_PM_WORKCSAT S
   WHERE S.V_SAP_WORK = V_NEXT_CLASS;

  UPDATE BASE_INSPECT_DAY_WRITE U
     SET U.NEXT_CLASS        = V_NEXT_CLASS,
         U.NEXT_CLASSNAME    = V_NEXTCLASSNAME,
         U.NEXT_PERCODE      = V_NEXTPERCODE,
         U.NEXT_PERNAME      = V_NEXTPERNAME,
         U.E_INSPECT_RESULTE = V_INSPECT_RESULTE,
         U.C_REQUESTION      = V_REQUESTION,
         U.L_EQUESTION       = V_EQUESTION,
         U.OTHER_QIUEST      = V_OTHER_QIUEST
   WHERE U.MAINGUID = V_MAINGUID
     AND U.CHILDGUID = V_CHILDGUID
     AND U.IN_PERCODE = V_PERCODE;
  COMMIT;
  RET := 'SUCCESS';
EXCEPTION
  WHEN OTHERS THEN
    RET := 'FAIL';
end BASE_INSPECT_WRITE_UPDATE;
/

