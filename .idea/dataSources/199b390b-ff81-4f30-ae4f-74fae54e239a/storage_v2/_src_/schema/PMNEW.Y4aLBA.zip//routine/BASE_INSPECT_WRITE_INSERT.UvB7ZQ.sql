create procedure BASE_INSPECT_WRITE_INSERT(V_MAINGUID        VARCHAR2, --
                                                      V_INPERCODE       VARCHAR2, --交班人编码
                                                      V_NEXTPRECODE     VARCHAR2, --接班人编码
                                                      V_INCLASS         VARCHAR2, --交班班组
                                                      V_NEXTCLASS       VARCHAR2, --接班班组
                                                      V_NCLASSNAME      VARCHAR2, --接班班组名称
                                                      V_INSPECT_RESULTE VARCHAR2, --设备点检结果
                                                      V_REQUESTION      VARCHAR2, --本班检修问题
                                                      V_EQUESTION       VARCHAR2, --遗留设备问题
                                                      V_OTHER_QIUEST    VARCHAR2, --其他问题
                                                      V_CHGUID          OUT VARCHAR2,
                                                      RET               OUT VARCHAR2) is
  V_CHILDGUID   VARCHAR2(36) := createguid();
  V_INPERNAME   VARCHAR2(50);
  V_NEXTPERNAME VARCHAR2(50);
  V_CLASSNAME   VARCHAR2(50); --交班班组名称
begin
  --查询登入人名称
  SELECT P.V_PERSONNAME
    INTO V_INPERNAME
    FROM BASE_PERSON P
   WHERE P.V_PERSONCODE = V_INPERCODE;
  --查询接收人姓名
  SELECT P.V_PERSONNAME
    INTO V_NEXTPERNAME
    FROM BASE_PERSON P
   WHERE P.V_PERSONCODE = V_NEXTPRECODE;
  --查询交班班组名
  IF V_INCLASS <> '' OR V_INCLASS IS NOT NULL THEN
    SELECT DISTINCT S.V_SAP_WORKNAME
      INTO V_CLASSNAME
      FROM SAP_PM_WORKCSAT S
     WHERE S.V_SAP_WORK = V_INCLASS;
  ELSE
    V_CLASSNAME := '';
  END IF;

  UPDATE BASE_INSPECT_DAY_CONTENT C
     SET C.CHILDGUID = V_CHILDGUID
   WHERE C.MAINGUID = V_MAINGUID;
  INSERT INTO BASE_INSPECT_DAY_WRITE
    (MAINGUID,
     CHILDGUID,
     IN_CLASS,
     IN_CLASSNAME,
     IN_PERCODE,
     IN_PERNAME,
     IN_DATE, --交班时间
     NEXT_CLASS,
     NEXT_CLASSNAME,
     NEXT_PERCODE,
     NEXT_PERNAME,
     E_INSPECT_RESULTE,
     C_REQUESTION,
     L_EQUESTION,
     OTHER_QIUEST,
     FLAG)
  VALUES
    (V_MAINGUID,
     V_CHILDGUID,
     V_INCLASS,
     V_CLASSNAME,
     V_INPERCODE,
     V_INPERNAME,
     SYSDATE,
     V_NEXTCLASS,
     V_NCLASSNAME,
     V_NEXTPRECODE,
     V_NEXTPERNAME,
     V_INSPECT_RESULTE,
     V_REQUESTION,
     V_EQUESTION,
     V_OTHER_QIUEST,
     '0');
  COMMIT;
  RET := 'SUCCESS';
  V_CHGUID:=V_CHILDGUID;
EXCEPTION
  WHEN OTHERS THEN
    RET := 'FAIL';
  
end BASE_INSPECT_WRITE_INSERT;
/

