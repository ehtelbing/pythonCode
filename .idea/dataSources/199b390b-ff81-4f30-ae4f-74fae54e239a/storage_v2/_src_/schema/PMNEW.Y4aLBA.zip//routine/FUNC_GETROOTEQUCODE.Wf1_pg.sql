create function func_getrootequcode(a_equcode varchar2)
  return varchar2 is
  p_ret     sap_pm_equ_p.v_equcode%type := '0';
  p_equcode sap_pm_equ_p.v_equcode%type := a_equcode;
begin
  loop
    p_ret := p_equcode;

    select nvl(v_equcodeup, '0')
      into p_equcode
      from sap_pm_equ_p
     where v_equcode = p_equcode;

    exit when p_equcode = '0';
  end loop;
  return(p_ret);
end func_getrootequcode;
/

