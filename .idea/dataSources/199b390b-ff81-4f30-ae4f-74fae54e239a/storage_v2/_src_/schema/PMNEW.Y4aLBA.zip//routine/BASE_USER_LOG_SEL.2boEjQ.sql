create procedure BASE_USER_LOG_SEL(A_USERID  IN VARCHAR2, --用户id
                                              V_CURSOR  OUT SYS_REFCURSOR) is

  --查询该用户上次选择的工作中心
begin

  OPEN V_CURSOR FOR
    SELECT B.WORKCENTER
      FROM BASE_USER_TRENDS B
     WHERE B.USERID = A_USERID;

end BASE_USER_LOG_SEL;


/

